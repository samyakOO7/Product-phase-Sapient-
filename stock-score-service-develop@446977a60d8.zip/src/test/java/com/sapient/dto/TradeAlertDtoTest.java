package com.sapient.dto;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;

@DisplayName("Trade alert dto test")
public class TradeAlertDtoTest {
    private TradeAlertDto tradeAlertDto;

    @BeforeEach
    public void loadAlertdata() {
    }

    @Test
    public void getTickerNumber() {
        tradeAlertDto = new TradeAlertDto();
        Integer tickerno = 1;
        tradeAlertDto.setTickerNumber(1);
        Assertions.assertEquals(tickerno, tradeAlertDto.getTickerNumber());
    }

    @Test
    public void getTimeframe() {
        tradeAlertDto = new TradeAlertDto();
        Integer timeframe = 1440;
        tradeAlertDto.setTimeframe(1440);
        Assertions.assertEquals(timeframe, tradeAlertDto.getTimeframe());
    }

    @Test
    public void getTradeDirection() {
        tradeAlertDto = new TradeAlertDto();
        String direction = "Buy";
        tradeAlertDto.setTradeDirection("Buy");
        Assertions.assertEquals(direction, tradeAlertDto.getTradeDirection());
    }

    @Test
    public void getGenerationTime() {
        tradeAlertDto = new TradeAlertDto();
        Timestamp genTime = Timestamp.from(Instant.now());
        tradeAlertDto.setGenerationTime(genTime);
        Assertions.assertEquals(genTime, tradeAlertDto.getGenerationTime());
    }

    @Test
    public void getExpiryTime() {
        tradeAlertDto = new TradeAlertDto();
        Timestamp expiryTime = new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000);
        tradeAlertDto.setExpiryTime(expiryTime);
        Assertions.assertEquals(expiryTime, tradeAlertDto.getExpiryTime());
    }

    @Test
    public void getConfidence() {
        tradeAlertDto = new TradeAlertDto();
        Double confidence = 90.0;
        tradeAlertDto.setConfidence(90.0);
        Assertions.assertEquals(confidence, tradeAlertDto.getConfidence());
    }

    @Test
    public void getAtr() {
        tradeAlertDto = new TradeAlertDto();
        Double atr = 45.0;
        tradeAlertDto.setAtr(48.0);
        Assertions.assertNotEquals(atr, tradeAlertDto.getAtr());
    }

    @Test
    public void testEquals() {
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        TradeAlertDto t2 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        Boolean expected = true;
        Boolean actual = t1.equals(t2);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testNullEquals() {
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        Assertions.assertEquals(false, t1.equals(null));
    }

    @Test
    public void testReferenceEquals() {
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        TradeAlertDto t2 = t1;
        Assertions.assertEquals(true, t1.equals(t2));
    }

    @Test
    public void testClassNotEquals() {
        TickerDataDto t2 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        Assertions.assertEquals(false, t1.equals(t2));
    }

    @Test
    public void testHashCode() {
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        TradeAlertDto t2 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        Boolean expected = true;
        Boolean actual = t1.hashCode() == t2.hashCode();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testToString() {
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        String expectedTradeAlertDto = "TradeAlertDto{" +
                "tickerNumber=" + t1.getTickerNumber() +
                ", timeframe=" + t1.getTimeframe() +
                ", tradeDirection='" + t1.getTradeDirection() + '\'' +
                ", generationTime=" + t1.getGenerationTime() +
                ", expiryTime=" + t1.getExpiryTime() +
                ", confidence=" + t1.getConfidence() +
                ", atr=" + t1.getAtr() +
                '}';
        Assertions.assertEquals(expectedTradeAlertDto, t1.toString());
    }
}