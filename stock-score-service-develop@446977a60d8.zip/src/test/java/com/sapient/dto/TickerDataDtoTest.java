package com.sapient.dto;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;

@DisplayName("TickerDataDto test")
public class TickerDataDtoTest {

    private TickerDataDto tickerDataDto;

    @BeforeEach
    public void loadTickerDataDto() {
    }

    @Test
    public void getTickerId() {
        tickerDataDto = new TickerDataDto();
        String s = "HDFC.NS";
        tickerDataDto.setTickerId("HDFC.NS");
        Assertions.assertEquals(s, tickerDataDto.getTickerId());
    }

    @Test
    public void getDated() {
        tickerDataDto = new TickerDataDto();
        Timestamp tscurrent = Timestamp.from(Instant.now());
        tickerDataDto.setDated(tscurrent);
        Assertions.assertEquals(tscurrent, tickerDataDto.getDated());
    }

    @Test
    public void getHigh() {
        tickerDataDto = new TickerDataDto();
        BigDecimal b = BigDecimal.valueOf(1234.5);
        tickerDataDto.setHigh(BigDecimal.valueOf(1234.5));
        Assertions.assertEquals(b, tickerDataDto.getHigh());
    }

    @Test
    public void getClose() {
        tickerDataDto = new TickerDataDto();
        BigDecimal b = BigDecimal.valueOf(1231.5);
        tickerDataDto.setClose(BigDecimal.valueOf(1231.5));
        Assertions.assertEquals(b, tickerDataDto.getClose());
    }

    @Test
    public void getLow() {
        tickerDataDto = new TickerDataDto();
        BigDecimal b = BigDecimal.valueOf(1000.9);
        tickerDataDto.setLow(BigDecimal.valueOf(1000.9));
        Assertions.assertEquals(b, tickerDataDto.getLow());
    }

    @Test
    public void getOpen() {
        tickerDataDto = new TickerDataDto();
        BigDecimal b = BigDecimal.valueOf(1231.5);
        tickerDataDto.setOpen(BigDecimal.valueOf(1231.5));
        Assertions.assertEquals(b, tickerDataDto.getOpen());
    }

    @Test
    public void getVolume() {
        tickerDataDto = new TickerDataDto();
        long val = 27893030L;
        BigInteger volume = BigInteger.valueOf(val);
        tickerDataDto.setVolume(BigInteger.valueOf(val));
        Assertions.assertNotNull(tickerDataDto.getVolume());
    }

    @Test
    public void testEquals() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t2 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Boolean expected = true;
        Boolean actual = t1.equals(t2);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testReferenceEquals() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t2 = t1;
        Assertions.assertEquals(true, t1.equals(t2));
    }

    @Test
    public void testNullEqual() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Assertions.assertEquals(false, t1.equals(null));
    }

    @Test
    public void testClassNotEquals() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TradeAlertDto tradeAlertDto=new TradeAlertDto();
        Assertions.assertEquals(false, t1.equals(tradeAlertDto));
    }

    @Test
    public void testHashCode() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t2 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Boolean expected = true;
        Boolean actual = t1.hashCode() == t2.hashCode();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testToString() {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        String expectedTickerDto = "TickerDataDto{" +
                "dated=" + t1.getDated() +
                ", tickerId='" + t1.getTickerId() + '\'' +
                ", high=" + t1.getHigh() +
                ", close=" + t1.getClose() +
                ", low=" + t1.getLow() +
                ", open=" + t1.getOpen() +
                ", volume=" + t1.getVolume() +
                '}';
        Assertions.assertEquals(expectedTickerDto, t1.toString());
    }
}