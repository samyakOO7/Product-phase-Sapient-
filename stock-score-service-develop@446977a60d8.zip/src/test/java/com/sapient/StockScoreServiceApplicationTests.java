package com.sapient;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {StockScoreServiceApplication.class})
@TestConfiguration
class StockScoreServiceApplicationTests {

	@Test
	void contextLoads() {
		String s ="Tradezy";
		String s1 ="Tradeeasy";
		Assertions.assertNotEquals(s,s1);
	}

}
