package com.sapient.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {IndicatorTimeSpecImpl.class})
@DisplayName("Indicator time specification test")
class IndicatorTimeSpecImplTest {

    @Autowired
    IndicatorTimeSpecImpl indicatorTimeSpec;

    @Test
    @DisplayName("Test for getting max time period of all indicator available")
    void getMaxTimePeriod() {
        ReflectionTestUtils.setField(indicatorTimeSpec, "emaTimePeriod", 5);
        ReflectionTestUtils.setField(indicatorTimeSpec, "rsiTimePeriod", 7);
        ReflectionTestUtils.setField(indicatorTimeSpec, "aroonTimePeriod", 34);
        ReflectionTestUtils.setField(indicatorTimeSpec, "atrTimePeriod", 56);
        ReflectionTestUtils.setField(indicatorTimeSpec, "cmfTimePeriod", 21);
        Integer value = indicatorTimeSpec.getMaxTimePeriod();
        assertEquals(56, value);
    }

    @Test
    @DisplayName("Test to get EMA time period")
    void getEmaTimePeriod() {
        int timePeriod = 10;
        ReflectionTestUtils.setField(indicatorTimeSpec, "emaTimePeriod", timePeriod);
        assertEquals(timePeriod, indicatorTimeSpec.getEmaTimePeriod());
    }

    @Test
    @DisplayName("Test to get RSI time period")
    void getRsiTimePeriod() {
        int timePeriod = 10;
        ReflectionTestUtils.setField(indicatorTimeSpec, "rsiTimePeriod", timePeriod);
        assertEquals(timePeriod, indicatorTimeSpec.getRsiTimePeriod());
    }

    @Test
    @DisplayName("Test to get AroonUp time period")
    void getAroonTimePeriod() {
        int timePeriod = 10;
        ReflectionTestUtils.setField(indicatorTimeSpec, "aroonTimePeriod", timePeriod);
        assertEquals(timePeriod, indicatorTimeSpec.getAroonTimePeriod());
    }

    @Test
    @DisplayName("Test to get CMF time period")
    void getCmfTimePeriod() {
        int timePeriod = 10;
        ReflectionTestUtils.setField(indicatorTimeSpec, "cmfTimePeriod", timePeriod);
        assertEquals(timePeriod, indicatorTimeSpec.getCmfTimePeriod());
    }

    @Test
    @DisplayName("Test to get ATR time period")
    void getAtrTimePeriod() {
        int timePeriod = 10;
        ReflectionTestUtils.setField(indicatorTimeSpec, "atrTimePeriod", timePeriod);
        assertEquals(timePeriod, indicatorTimeSpec.getAtrTimePeriod());
    }
}