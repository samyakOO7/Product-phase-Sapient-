package com.sapient.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;
import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.ATRIndicator;
import org.ta4j.core.indicators.AroonUpIndicator;
import org.ta4j.core.indicators.EMAIndicator;
import org.ta4j.core.indicators.RSIIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.volume.ChaikinMoneyFlowIndicator;
import org.ta4j.core.num.Num;

import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {IndicatorServiceImpl.class})
@TestPropertySource("classpath:application.properties")
@DisplayName("Indiactor Service impl test")
class IndicatorServiceImplTest {

    @Autowired
    IndicatorServiceImpl indicatorService;

    @MockBean
    IndicatorTimeSpec indicatorTimeSpecImpl;

    @Test
    @DisplayName("Getting ClosePriceIndicator when called from indicator service")
    void getClosePriceIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        assertEquals(indicatorService.getClosePriceIndicator(barSeries).toString(), new ClosePriceIndicator(barSeries).toString());
    }

    @Test
    @DisplayName("Getting RSIIndicator when called from indicator service")
    void getRSIIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        Indicator<Num> testIndicator = new ClosePriceIndicator(barSeries);
        when(indicatorTimeSpecImpl.getRsiTimePeriod()).thenReturn(barSeries.getBarCount());
        assertEquals(indicatorService.getRSIIndicator(testIndicator).toString(), new RSIIndicator(testIndicator, indicatorTimeSpecImpl.getRsiTimePeriod()).toString());
    }

    @Test
    @DisplayName("Getting ATRIndicator when called from indicator service")
    void getATRIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        when(indicatorTimeSpecImpl.getAtrTimePeriod()).thenReturn(barSeries.getBarCount());
        assertEquals(indicatorService.getATRIndicator(barSeries).toString(), new ATRIndicator(barSeries, indicatorTimeSpecImpl.getAtrTimePeriod()).toString());
    }

    @Test
    @DisplayName("Getting EMAIndicator when called from indicator service")
    void getEMAIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        Indicator<Num> testIndicator = new ClosePriceIndicator(barSeries);
        when(indicatorTimeSpecImpl.getEmaTimePeriod()).thenReturn(barSeries.getBarCount());
        assertEquals(indicatorService.getEMAIndicator(testIndicator).toString(), new EMAIndicator(testIndicator, indicatorTimeSpecImpl.getEmaTimePeriod()).toString());


    }

    @Test
    @DisplayName("Getting AroonUpIndicator when called from indicator service")
    void getAroonUpIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        when(indicatorTimeSpecImpl.getAroonTimePeriod()).thenReturn(barSeries.getBarCount());
        assertEquals(indicatorService.getAroonUpIndicator(barSeries).toString(), new AroonUpIndicator(barSeries, indicatorTimeSpecImpl.getAroonTimePeriod()).toString());
    }

    @Test
    @DisplayName("Getting CMFIndicator when called from indicator service")
    void getCMFIndicator() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        when(indicatorTimeSpecImpl.getCmfTimePeriod()).thenReturn(barSeries.getBarCount());
        assertEquals(indicatorService.getCMFIndicator(barSeries).toString(), new ChaikinMoneyFlowIndicator(barSeries, indicatorTimeSpecImpl.getCmfTimePeriod()).toString());
    }

    @Test
    @DisplayName("Getting RSI upper limit when called from indicator service")
    void getRsiBuyUpperLimit() {
        float upperLimit = 90;
        ReflectionTestUtils.setField(indicatorService, "rsiBuyUpperLimit", upperLimit);
        assertEquals(upperLimit, indicatorService.getRsiBuyUpperLimit());
    }

    @Test
    @DisplayName("Getting RSI lower limit when called from indicator service")
    void getRsiBuyLowerLimit() {
        float lowerLimit = 30;
        ReflectionTestUtils.setField(indicatorService, "rsiBuyLowerLimit", lowerLimit);
        assertEquals(lowerLimit, indicatorService.getRsiBuyLowerLimit());
    }

    @Test
    @DisplayName("Getting aroon greater and eqaul percentage when called from indicator service")
    void getAroonPercentage() {
        float percentage = 10;
        ReflectionTestUtils.setField(indicatorService, "aroonPercentage", percentage);
        assertEquals(percentage, indicatorService.getAroonPercentage());
    }

    @Test
    @DisplayName("Getting chaikin money flow greater and equal value  when called from indicator service")
    void getCmfValue() {
        float cmfValue = 0.16f;
        ReflectionTestUtils.setField(indicatorService, "cmfValue", cmfValue);
        assertEquals(cmfValue, indicatorService.getCmfValue());
    }
}