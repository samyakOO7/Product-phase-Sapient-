package com.sapient.service;

import com.sapient.client.TradeServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.dto.TradeAlertDto;
import com.sapient.exception.EmptyListOfTickersException;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {AlertServiceImpl.class})
@WebMvcTest(AlertServiceImpl.class)
public class AlertServiceImplTest {

    @MockBean
    UserServiceFeignClient userServiceFeignClient;
    @MockBean
    TradeServiceFeignClient tradeServiceFeignClient;
    @MockBean
    AnalyticService analyticService;
    @Autowired
    AlertServiceImpl alertService;

    @Test
    public void cronJobFetchTickers() throws EmptyListOfTickersException {
        Map<String,Object>mp=new HashMap<>(){
            {
                put("tickerId","HDFC");
                put("tickerNumber",1);
            }
        };
        List<Map<String,Object>>l= new ArrayList<>(){
            {
                add(mp);
            }
        };
        Map<String, List<Map<String,Object>>>m = new HashMap<>(){
            {
                put("tickers",l);
            }
        };
        TradeAlertDto t1 = new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0);
        Mockito.when(userServiceFeignClient.getWatchlistTickers()).thenReturn(m);
        Mockito.when(analyticService.getStockAnalytic(any(String.class))).thenReturn(new TradeAlertDto(1, 1440, "Buy", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 864000), 90.0, 4.0));
        Mockito.when(tradeServiceFeignClient.setTradeAlerts(any(TradeAlertDto.class))).thenReturn(new ResponseEntity<>(new HashMap<>(), HttpStatus.OK));
        alertService.cronJobFetchTickers();
        verify(tradeServiceFeignClient,times(1)).setTradeAlerts(t1);
    }

    @Test
    @DisplayName("Cron job failure")
    public void cronJobFetchTickersException() {
        Exception exception = assertThrows(EmptyListOfTickersException.class, alertService::cronJobFetchTickers);
        String exceptedMessage = "No Tickers in the list";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(exceptedMessage));
    }

}