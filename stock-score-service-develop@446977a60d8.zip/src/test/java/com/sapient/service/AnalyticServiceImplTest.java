package com.sapient.service;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.dto.TickerDataDto;
import com.sapient.dto.TradeAlertDto;
import com.sapient.exception.TickerDataNotFound;
import com.sapient.util.IndicatorService;
import com.sapient.util.IndicatorTimeSpec;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;
import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.ATRIndicator;
import org.ta4j.core.indicators.AroonUpIndicator;
import org.ta4j.core.indicators.EMAIndicator;
import org.ta4j.core.indicators.RSIIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.volume.ChaikinMoneyFlowIndicator;
import org.ta4j.core.num.Num;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AnalyticServiceImpl.class})
@DisplayName("analytic service impl test")
class AnalyticServiceImplTest {

    @MockBean
    StockServiceFeignClient stockServiceFeignClient;
    @MockBean
    IndicatorService indicatorServiceImpl;
    @MockBean
    IndicatorTimeSpec indicatorTimeSpecImpl;
    @Autowired
    AnalyticServiceImpl analyticService;
    @MockBean
    SimpleDateFormat simpleDateFormat;
    String testTicker = "INFY.NS";
    List<TickerDataDto> barList=new ArrayList<>(){{
        add(new TickerDataDto(Timestamp.from(Instant.now()),testTicker, BigDecimal.valueOf(102),BigDecimal.valueOf(101),BigDecimal.valueOf(98),BigDecimal.valueOf(100), BigInteger.valueOf(1000)));
    }
    };
    Map<String, List<TickerDataDto>> map=new HashMap<>();

    @Test
    @DisplayName("test success in closePriceIndicator")
    void setClosePriceIndicatorSuccess() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ClosePriceIndicator indicator = new ClosePriceIndicator(barSeries);
        when(indicatorServiceImpl.getClosePriceIndicator(barSeries)).thenReturn(indicator);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        analyticService.setClosePriceIndicator();
        ClosePriceIndicator closePriceIndicator = (ClosePriceIndicator) ReflectionTestUtils.getField(analyticService, "closePriceIndicator");
        assertEquals(closePriceIndicator, indicator);
    }

    @Test
    @DisplayName("testing CMF indicator rule")
    void getCMFIndicatorRule() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        ChaikinMoneyFlowIndicator chaikinMoneyFlowIndicator = new ChaikinMoneyFlowIndicator(barSeries, barSeries.getBarCount());
        when(indicatorServiceImpl.getCMFIndicator(barSeries)).thenReturn(chaikinMoneyFlowIndicator);
        assertTrue(analyticService.getCMFIndicatorRule());
    }

    @Test
    @DisplayName("testing Aroon indicator rule")
    void getAroonRule() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        AroonUpIndicator indicator = new AroonUpIndicator(barSeries, barSeries.getBarCount());
        when(indicatorServiceImpl.getAroonUpIndicator(barSeries)).thenReturn(indicator);
        assertTrue(analyticService.getAroonUpRule());
    }

    @Test
    @DisplayName("testing ATR indicator rule")
    void getATRIndicatorRule() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        ATRIndicator indicator = new ATRIndicator(barSeries, barSeries.getBarCount());
        when(indicatorServiceImpl.getATRIndicator(barSeries)).thenReturn(indicator);
        when(indicatorTimeSpecImpl.getAtrTimePeriod()).thenReturn(barSeries.getBarCount() - 1);
        Double actual = indicator.getValue(barSeries.getBarCount() - 1).doubleValue();
        assertEquals(analyticService.getATRValue(), actual);
    }

    @Test
    @DisplayName("testing RSI indicator rule")
    void getRSIIndicatorRule() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        Indicator<Num> close = new ClosePriceIndicator(barSeries);
        ReflectionTestUtils.setField(analyticService, "closePriceIndicator", close);
        RSIIndicator indicator = new RSIIndicator(close, barSeries.getBarCount());
        when(indicatorServiceImpl.getRSIIndicator(close)).thenReturn(indicator);
        when(indicatorTimeSpecImpl.getRsiTimePeriod()).thenReturn(barSeries.getBarCount());
        assertFalse(analyticService.getRSIIndicatorRule());
    }

    @Test
    @DisplayName("testing EMA indicator rule")
    void getEMAIndicatorRule() {
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(analyticService, "barSeries", barSeries);
        Indicator<Num> close = new ClosePriceIndicator(barSeries);
        ReflectionTestUtils.setField(analyticService, "closePriceIndicator", close);
        EMAIndicator indicator = new EMAIndicator(close, barSeries.getBarCount());
        when(indicatorServiceImpl.getEMAIndicator(close)).thenReturn(indicator);
        assertTrue(analyticService.getEMAIndicatorRule());
    }

    @Test
    @DisplayName("Testing confidence score 4 success")
    void getConfidenceScore1() {
        AnalyticServiceImpl impl = Mockito.spy(analyticService);
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(impl, "barSeries", barSeries);
        doReturn(true).when(impl).getRSIIndicatorRule();
        doReturn(true).when(impl).getEMAIndicatorRule();
        doReturn(true).when(impl).getAroonUpRule();
        doReturn(true).when(impl).getCMFIndicatorRule();
        double actual = impl.getConfidenceScore();
        assertEquals(97.0, actual);
    }

    @Test
    @DisplayName("Testing confidence score 3 success")
    void getConfidenceScore2() {
        AnalyticServiceImpl impl = Mockito.spy(analyticService);
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(impl, "barSeries", barSeries);
        doReturn(true).when(impl).getRSIIndicatorRule();
        doReturn(true).when(impl).getEMAIndicatorRule();
        doReturn(true).when(impl).getAroonUpRule();
        doReturn(false).when(impl).getCMFIndicatorRule();
        double actual = impl.getConfidenceScore();
        assertEquals(87.0, actual);
    }

    @Test
    @DisplayName("Testing confidence score success")
    void getConfidenceScore3() {
        AnalyticServiceImpl impl = Mockito.spy(analyticService);
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(impl, "barSeries", barSeries);
        doReturn(true).when(impl).getRSIIndicatorRule();
        doReturn(true).when(impl).getEMAIndicatorRule();
        doReturn(false).when(impl).getAroonUpRule();
        doReturn(true).when(impl).getCMFIndicatorRule();
        double actual = impl.getConfidenceScore();
        assertEquals(64.0, actual);
    }

    @Test
    @DisplayName("Testing confidence score 4 success")
    void getConfidenceScore4() {
        AnalyticServiceImpl impl = Mockito.spy(analyticService);
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(impl, "barSeries", barSeries);
        doReturn(true).when(impl).getRSIIndicatorRule();
        doReturn(false).when(impl).getEMAIndicatorRule();
        doReturn(true).when(impl).getAroonUpRule();
        doReturn(true).when(impl).getCMFIndicatorRule();
        double actual = impl.getConfidenceScore();
        assertEquals(69.0, actual);
    }

    @Test
    @DisplayName("Testing confidence score 5 success")
    void getConfidenceScore5() {
        AnalyticServiceImpl impl = Mockito.spy(analyticService);
        BarSeries barSeries = new BaseBarSeriesBuilder().withName("test").build();
        barSeries.addBar(ZonedDateTime.now(), 45, 67, 78, 33, 5675);
        ReflectionTestUtils.setField(impl, "barSeries", barSeries);
        doReturn(false).when(impl).getRSIIndicatorRule();
        doReturn(true).when(impl).getEMAIndicatorRule();
        doReturn(true).when(impl).getAroonUpRule();
        doReturn(true).when(impl).getCMFIndicatorRule();
        double actual = impl.getConfidenceScore();
        assertEquals(71.0, actual);
    }

}