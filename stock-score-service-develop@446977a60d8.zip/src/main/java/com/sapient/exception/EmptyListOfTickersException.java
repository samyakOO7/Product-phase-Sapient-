package com.sapient.exception;

import lombok.Generated;

@Generated
public class EmptyListOfTickersException extends Exception {

    public EmptyListOfTickersException(String tickersMessage) {
        super(tickersMessage);
    }
}
