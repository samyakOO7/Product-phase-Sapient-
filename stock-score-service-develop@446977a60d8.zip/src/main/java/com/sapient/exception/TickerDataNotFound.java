package com.sapient.exception;

import lombok.Generated;

@Generated
public class TickerDataNotFound extends RuntimeException {
    public TickerDataNotFound(String message, String tickerId) {
        super(message + tickerId);
    }
}
