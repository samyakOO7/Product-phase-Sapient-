package com.sapient.client;

import com.sapient.dto.TradeAlertDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient(name = "trade-microservice", url = "${trade.service.feign.url}")
public interface TradeServiceFeignClient {

    @PostMapping(value = "/trade/alert", consumes = "application/json", produces = "application/json")
    ResponseEntity<Map<String,Object>> setTradeAlerts(@RequestBody TradeAlertDto tradeAlertDto);
}
