package com.sapient.client;

import com.sapient.dto.TickerDataDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@FeignClient(value = "stock-microservice", url = "${stock.service.feign.url}")
public interface StockServiceFeignClient {

    @GetMapping("/history/{tickerId}")
    Map<String, List<TickerDataDto>> getStockData(@PathVariable("tickerId") String tickerId);

    @GetMapping(value = "/{tickerId}", produces = "application/json")
    Map<String, BigDecimal> getCurrentPrice(@PathVariable("tickerId") String tickerSymbol);
}
