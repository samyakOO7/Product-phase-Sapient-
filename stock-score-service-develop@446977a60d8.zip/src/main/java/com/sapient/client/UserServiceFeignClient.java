package com.sapient.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;

@FeignClient(name = "user-microservice", url = "${user.service.feign.url}")
public interface UserServiceFeignClient {

    @GetMapping(value = "/watchlist-tickers", produces = "application/json")
    Map<String, List<Map<String, Object>>> getWatchlistTickers();
}
