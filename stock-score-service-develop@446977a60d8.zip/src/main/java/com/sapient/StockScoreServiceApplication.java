package com.sapient;

import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.TimeZone;

@SpringBootApplication
@EnableScheduling
@EnableFeignClients
@Generated
@Slf4j
public class StockScoreServiceApplication {

    public static void main(String[] args) {
        System.setProperty("user.timezone", "Asia/Kolkata");
        TimeZone.setDefault(null);
        log.debug("Timestamp: " + Timestamp.from(Instant.now()));
        SpringApplication.run(StockScoreServiceApplication.class, args);
    }

}
