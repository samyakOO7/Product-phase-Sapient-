package com.sapient.util;


public interface IndicatorTimeSpec {
    Integer getMaxTimePeriod();

    int getAroonTimePeriod();

    int getRsiTimePeriod();

    int getAtrTimePeriod();

    int getEmaTimePeriod();

    int getCmfTimePeriod();
}
