package com.sapient.util;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Component
@Getter
@Slf4j
public class IndicatorTimeSpecImpl implements IndicatorTimeSpec {
    @Value("${EMA_TIME_PERIOD:14}")
    private int emaTimePeriod;
    @Value("${RSI_TIME_PERIOD:14}")
    private int rsiTimePeriod;
    @Value("${AROON_TIME_PERIOD:20}")
    private int aroonTimePeriod;
    @Value("${CMF_TIME_PERIOD:21}")
    private int cmfTimePeriod;
    @Value("${ATR_TIME_PERIOD:20}")
    private int atrTimePeriod;

    @Override
    public Integer getMaxTimePeriod() {
        List<Integer> list = Arrays.asList(aroonTimePeriod, cmfTimePeriod, rsiTimePeriod, emaTimePeriod, atrTimePeriod);
        log.debug("getting maximum time period out of given indicators");
        Optional<Integer> maximum = list.stream().max(Integer::compare);
        return maximum.orElse(0);
    }

}

