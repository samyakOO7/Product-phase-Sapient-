package com.sapient.util;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.ta4j.core.BarSeries;
import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.ATRIndicator;
import org.ta4j.core.indicators.AroonUpIndicator;
import org.ta4j.core.indicators.EMAIndicator;
import org.ta4j.core.indicators.RSIIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.volume.ChaikinMoneyFlowIndicator;
import org.ta4j.core.num.Num;

@Component
@Slf4j
@Getter
public class IndicatorServiceImpl implements IndicatorService {
    @Autowired
    @Getter(AccessLevel.NONE)
    IndicatorTimeSpec indicatorTimeSpecImpl;
    @Value("${RSI_BUY_UPPER_LIMIT:80}")
    private float rsiBuyUpperLimit;
    @Value("${RSI_BUY_LOWER_LIMIT:60}")
    private float rsiBuyLowerLimit;
    @Value("${AROON_PERCENTAGE_GREATER_N_EQUAL:100}")
    private float aroonPercentage;
    @Value("${CMF_VALUE_GREATER_N_EQUAL:0.1}")
    private float cmfValue;

    @Override
    public ClosePriceIndicator getClosePriceIndicator(BarSeries barSeries) {
        log.debug("Setting close price indicator");
        return new ClosePriceIndicator(barSeries);
    }

    @Override
    public RSIIndicator getRSIIndicator(Indicator<Num> indicator) {
        log.debug("Instantiating RSI indicator according to given data");
        return new RSIIndicator(indicator, indicatorTimeSpecImpl.getRsiTimePeriod());
    }

    @Override
    public ATRIndicator getATRIndicator(BarSeries barSeries) {
        log.debug("Instantiating ATR indicator according to given data");
        return new ATRIndicator(barSeries, indicatorTimeSpecImpl.getAtrTimePeriod());
    }

    @Override
    public EMAIndicator getEMAIndicator(Indicator<Num> indicator) {
        log.debug("Instantiating EMA indicator according to given data");
        return new EMAIndicator(indicator, indicatorTimeSpecImpl.getEmaTimePeriod());
    }

    @Override
    public AroonUpIndicator getAroonUpIndicator(BarSeries barSeries) {
        log.debug("Instantiating AroonUp indicator according to given data");
        return new AroonUpIndicator(barSeries, indicatorTimeSpecImpl.getAroonTimePeriod());
    }

    @Override
    public ChaikinMoneyFlowIndicator getCMFIndicator(BarSeries barSeries) {
        log.debug("Instantiating CMF indicator according to given data");
        return new ChaikinMoneyFlowIndicator(barSeries, indicatorTimeSpecImpl.getCmfTimePeriod());
    }
}
