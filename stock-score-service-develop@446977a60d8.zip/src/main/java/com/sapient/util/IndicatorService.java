package com.sapient.util;

import org.ta4j.core.BarSeries;
import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.ATRIndicator;
import org.ta4j.core.indicators.AroonUpIndicator;
import org.ta4j.core.indicators.EMAIndicator;
import org.ta4j.core.indicators.RSIIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.indicators.volume.ChaikinMoneyFlowIndicator;
import org.ta4j.core.num.Num;

public interface IndicatorService {
    ClosePriceIndicator getClosePriceIndicator(BarSeries barSeries);

    RSIIndicator getRSIIndicator(Indicator<Num> indicator);

    ATRIndicator getATRIndicator(BarSeries barSeries);

    EMAIndicator getEMAIndicator(Indicator<Num> indicator);

    AroonUpIndicator getAroonUpIndicator(BarSeries barSeries);

    ChaikinMoneyFlowIndicator getCMFIndicator(BarSeries barSeries);

    float getRsiBuyUpperLimit();

    float getRsiBuyLowerLimit();

    float getAroonPercentage();

    float getCmfValue();
}
