package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Objects;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TradeAlertDto {
    private Integer tickerNumber;
    private Integer timeframe;
    private String tradeDirection;
    private Timestamp generationTime;
    private Timestamp expiryTime;
    private Double confidence;
    private Double atr;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TradeAlertDto that = (TradeAlertDto) o;
        return tickerNumber.equals(that.tickerNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerNumber);
    }

    @Override
    public String toString() {
        return "TradeAlertDto{" + "tickerNumber=" + tickerNumber + ", timeframe=" + timeframe + ", tradeDirection='" + tradeDirection + '\'' + ", generationTime=" + generationTime + ", expiryTime=" + expiryTime + ", confidence=" + confidence + ", atr=" + atr + '}';
    }
}
