package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TickerDataDto {
    private Timestamp dated;
    private String tickerId;
    private BigDecimal high;
    private BigDecimal close;
    private BigDecimal low;
    private BigDecimal open;
    private BigInteger volume;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TickerDataDto that = (TickerDataDto) o;
        return tickerId.equals(that.tickerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerId);
    }

    @Override
    public String toString() {
        return "TickerDataDto{" + "dated=" + dated + ", tickerId='" + tickerId + '\'' + ", high=" + high + ", close=" + close + ", low=" + low + ", open=" + open + ", volume=" + volume + '}';
    }
}