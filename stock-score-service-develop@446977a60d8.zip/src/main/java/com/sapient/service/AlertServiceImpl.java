package com.sapient.service;

import com.sapient.client.TradeServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.exception.EmptyListOfTickersException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class AlertServiceImpl implements AlertService {
    @Autowired
    UserServiceFeignClient userServiceFeignClient;
    @Autowired
    TradeServiceFeignClient tradeServiceFeignClient;
    @Autowired
    AnalyticService analyticService;

    @Scheduled(cron = "0 30/45 16-17 * * 1-5")
    public void cronJobFetchTickers() throws EmptyListOfTickersException {
        try {
            log.info("cron Job triggered at {}", Timestamp.from(Instant.now()));
            Map<String, List<Map<String, Object>>> mp = userServiceFeignClient.getWatchlistTickers();
            log.debug("common tickers list watchlist {}",mp);
            List<Map<String, Object>> listTickers = mp.get("tickers");
            log.debug("tickers have been fetched {}", mp.get("tickers"));
            for (Map<String, Object> m : listTickers) {
                String tickerId = (String) m.get("tickerId");
                var tradeAlertDto = analyticService.getStockAnalytic(tickerId);
                if (tradeAlertDto.getConfidence() >= 60.0) {
                    tradeAlertDto.setTickerNumber((Integer) m.get("tickerNumber"));
                    tradeAlertDto.setTradeDirection("buy");
                    tradeAlertDto.setTimeframe(1440); //in minutes
                    tradeAlertDto.setGenerationTime(getTimestamp());
                    tradeAlertDto.setExpiryTime(getExpiryTime()); //1 day in ms
                    ResponseEntity<Map<String,Object>> map=tradeServiceFeignClient.setTradeAlerts(tradeAlertDto);
                    log.info("Alert received by trade service {}",map.getBody());
                }
            }
        } catch (Exception e) {
            log.error("No Tickers in the list");
            throw new EmptyListOfTickersException("No Tickers in the list");
        }
    }

    private Timestamp getExpiryTime() {
        log.debug("expiration time {}",(Timestamp.from(Instant.now()).getTime() + 86400000));
        return new Timestamp(Timestamp.from(Instant.now()).getTime() + 86400000);
    }

    private Timestamp getTimestamp() {
        return new Timestamp(Timestamp.from(Instant.now()).getTime());

    }


}
