package com.sapient.service;

import com.sapient.exception.EmptyListOfTickersException;

public interface AlertService {
    void cronJobFetchTickers() throws EmptyListOfTickersException;
}
