package com.sapient.service;

import com.sapient.dto.TradeAlertDto;

public interface AnalyticService {
    TradeAlertDto getStockAnalytic(String tickerId);
}