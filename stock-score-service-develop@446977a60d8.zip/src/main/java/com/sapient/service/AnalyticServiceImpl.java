package com.sapient.service;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.dto.TickerDataDto;
import com.sapient.dto.TradeAlertDto;
import com.sapient.exception.TickerDataNotFound;
import com.sapient.util.IndicatorService;
import com.sapient.util.IndicatorTimeSpec;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.num.DecimalNum;
import org.ta4j.core.num.Num;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class AnalyticServiceImpl implements AnalyticService {

    @Autowired
    StockServiceFeignClient stockServiceFeignClient;
    @Autowired
    IndicatorService indicatorServiceImpl;
    @Autowired
    IndicatorTimeSpec indicatorTimeSpecImpl;
    @Autowired
    SimpleDateFormat format;
    BarSeries barSeries;
    ClosePriceIndicator closePriceIndicator;

    @Override
    @Generated
    public TradeAlertDto getStockAnalytic(String tickerId) {
        log.debug("Starting analysis of ticker with ticker id {}", tickerId);
        List<TickerDataDto> barList;
        try {
            log.debug("Fetching historical data from stock-service for tickerId {}", tickerId);
            Map<String, List<TickerDataDto>> stockData = stockServiceFeignClient.getStockData(tickerId);
            barList = stockData.get("historical");
        } catch (Exception e) {
            log.error(Constant.INVALID_TICKER + " " + tickerId);
            throw new TickerDataNotFound("Invalid Ticker Id {}", tickerId);
        }
        var tradeAlertDto = new TradeAlertDto();
        if (barList.size() < indicatorTimeSpecImpl.getMaxTimePeriod() || !format.format(barList.get(barList.size() - 1).getDated().getTime()).equals(format.format(new Timestamp(new Date().getTime())))) {
            log.debug("Insufficient data found for respective ticker {},hence returning 0.0 for atr and confidence", tickerId);
            tradeAlertDto.setAtr(0.0);
            tradeAlertDto.setConfidence(0.0);
        } else {
            setBarSeries(tickerId, barList);
            Double atr = getATRValue();
            log.debug("Initial ATR {}", atr);
            Double finalAtr = ((atr * 1.5) / barSeries.getLastBar().getClosePrice().doubleValue()) * 100;//0/0, 1/0.-2/0
            if (finalAtr.isNaN() || finalAtr.isInfinite()||barSeries.getLastBar().getClosePrice().doubleValue()==0.0) {
                tradeAlertDto.setAtr(0.0);
                tradeAlertDto.setConfidence(0.0);
                return tradeAlertDto; //not reachable after it.
            }
            log.debug("Final ATR {}", finalAtr);
            if (finalAtr < 0 || finalAtr > 100) {
                tradeAlertDto.setAtr(1.0);
                tradeAlertDto.setConfidence(getConfidenceScore());
                return tradeAlertDto;
            }
            tradeAlertDto.setAtr(finalAtr);
            tradeAlertDto.setConfidence(getConfidenceScore());
            log.info("Confidence Score and ATR value for given tickerId {}, is {} and {} respectively", tickerId, tradeAlertDto.getConfidence(), finalAtr);
            log.debug("Successfully analyzed the ticker with ticker id {}", tickerId);
        }
        return tradeAlertDto;
    }

    @Generated
    void setBarSeries(String tickerId, List<TickerDataDto> barList) {
        this.barSeries = new BaseBarSeriesBuilder().withName(tickerId).build();
        for (var i = barList.size() - indicatorTimeSpecImpl.getMaxTimePeriod() - 1; i < barList.size(); i++) {
            TickerDataDto barData = barList.get(i);
            this.barSeries.addBar(ZonedDateTime.now().plusDays(i), barData.getOpen(), barData.getHigh(), barData.getClose(), barData.getLow(), barData.getVolume());
        }
        log.debug("BarSeries build successfully for tickerId {}", tickerId);
        setClosePriceIndicator();
    }

    void setClosePriceIndicator() {
        this.closePriceIndicator = indicatorServiceImpl.getClosePriceIndicator(barSeries);
    }

    double getConfidenceScore() {
        log.debug("Calculating Confidence Score for ticker {}", barSeries.getName());
        var confidenceScore = 0.0;
        if (getRSIIndicatorRule()) confidenceScore += Double.parseDouble(Constant.RSI_CS.toString());
        if (getEMAIndicatorRule()) confidenceScore += Double.parseDouble(Constant.EMA_CS.toString());
        if (getAroonUpRule()) confidenceScore += Double.parseDouble(Constant.AROON_CS.toString());
        if (getCMFIndicatorRule()) confidenceScore += Double.parseDouble(Constant.CMF_CS.toString());
        log.debug("successfully calculated confidence score for given ticker {}", barSeries.getName());
        return confidenceScore;
    }

    Double getATRValue() {
        var atrIndicator = indicatorServiceImpl.getATRIndicator(barSeries);
        log.debug("Calculating ATR Value for ticker {}", barSeries.getName());
        return atrIndicator.getValue(indicatorTimeSpecImpl.getAtrTimePeriod() - 1).doubleValue();
    }

    boolean getRSIIndicatorRule() {
        var rsiIndicator = indicatorServiceImpl.getRSIIndicator(closePriceIndicator);
        log.debug("Calculated RSI Indicator Value");
        Num rsiIndicatorValue = rsiIndicator.getValue(indicatorTimeSpecImpl.getRsiTimePeriod() - 1);
        return rsiIndicatorValue.isGreaterThanOrEqual(DecimalNum.valueOf(indicatorServiceImpl.getRsiBuyLowerLimit())) && rsiIndicatorValue.isLessThan(DecimalNum.valueOf(indicatorServiceImpl.getRsiBuyUpperLimit()));
    }

    boolean getEMAIndicatorRule() {
        var emaIndicator = indicatorServiceImpl.getEMAIndicator(closePriceIndicator);
        log.debug("Calculated EMA Indicator Value");
        return emaIndicator.getValue(indicatorTimeSpecImpl.getEmaTimePeriod() - 1).isLessThanOrEqual(barSeries.getLastBar().getClosePrice());
    }

    boolean getAroonUpRule() {
        var aroonUpIndicator = indicatorServiceImpl.getAroonUpIndicator(barSeries);
        log.debug("Calculated Aroon Indicator Value");
        return aroonUpIndicator.getValue(indicatorTimeSpecImpl.getAroonTimePeriod() - 1).isGreaterThanOrEqual(DecimalNum.valueOf(indicatorServiceImpl.getAroonPercentage()));
    }

    boolean getCMFIndicatorRule() {
        var chaikinMoneyFlowIndicator = indicatorServiceImpl.getCMFIndicator(barSeries);
        log.debug("Calculated CMF Indicator Value");
        return chaikinMoneyFlowIndicator.getValue(indicatorTimeSpecImpl.getCmfTimePeriod() - 1).isGreaterThanOrEqual(DecimalNum.valueOf(indicatorServiceImpl.getCmfValue()));
    }

}
