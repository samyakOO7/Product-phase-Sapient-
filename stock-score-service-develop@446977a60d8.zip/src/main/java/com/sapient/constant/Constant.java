package com.sapient.constant;

import lombok.Generated;

@Generated
public enum Constant {
    INVALID_TICKER("Unable to find ticker data"),
    RSI_CS("26.0"),
    EMA_CS("28.0"),
    CMF_CS("10.0"),
    AROON_CS("33.0");
    private String message;
    private Constant(String message) {
        this.message = message;
    }
    @Override
    public String toString() {
        return message;
    }
}
