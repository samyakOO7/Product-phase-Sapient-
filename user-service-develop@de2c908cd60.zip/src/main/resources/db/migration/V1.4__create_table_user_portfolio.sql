create table user_portfolio(
	user_portfolio_id bigint primary key,
	user_id bigint references user_trading_details(user_id) not null,
	ticker_number integer references tickers(ticker_number) not null,
	quantity integer not null,  --quantity of this stock
	average_price numeric not null,  --average price of the stock
	profit_target numeric not null, --average price for selling the stocks; should be sold at this price
	stop_loss numeric not null --stop loss for which the stock should be sold.
);

alter table user_portfolio add constraint user_portfolio_user_id_ticker_number unique(user_id,ticker_number);

create index user_portfolio_ticker_number on user_portfolio(ticker_number);

