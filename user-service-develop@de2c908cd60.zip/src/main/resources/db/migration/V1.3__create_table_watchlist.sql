create table watchlist(
    watchlist_id bigint primary key,
	user_id bigint references user_trading_details(user_id) not null,
	ticker_number integer references tickers(ticker_number) not null
);

alter table watchlist add constraint watchlist_user_id_ticker_number_unique unique(user_id,ticker_number);
create index watchlist_ticker_number_index on watchlist(ticker_number);