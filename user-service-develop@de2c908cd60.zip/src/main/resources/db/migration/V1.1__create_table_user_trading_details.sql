create table user_trading_details(
	user_id bigint primary key, --user id from user service
	total_amount numeric default 0, --Total cash amount
	amount_per_trade numeric default 0,  --percentage of money per trade (0 to 100)
	risk_per_trade numeric default 0,  --risk per trade the user can take risk percentage (0 to 100)
	total_equity numeric default 0, --sum of total_amount+ portfolio value
	total_alerts_generated bigint default 0 --total alerts generated for user till date
);
alter table user_trading_details add constraint risk_per_trade_check check(risk_per_trade between 0 and 100);
alter table user_trading_details add constraint amount_per_trade_check check(amount_per_trade between 0 and 100);