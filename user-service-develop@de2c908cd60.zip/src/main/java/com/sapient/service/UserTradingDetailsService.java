package com.sapient.service;

import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.exception.InternalServerException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.model.UserTradingDetails;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

public interface UserTradingDetailsService {

    UserTradingDetails getUserTradingDetailsById(BigInteger userId) throws UserNotFoundException;

    UserTradingDetails createOrUpdate(UserTradingDetailsDto userTradingDetailsDto) throws InternalServerException, UserNotFoundException;

    Map<String, List<BigInteger>> getAllUserIds();
}
