package com.sapient.service.impl;

import com.sapient.constant.Constant;
import com.sapient.dto.WatchListCountResponseDto;
import com.sapient.dto.WatchlistDto;
import com.sapient.exception.*;
import com.sapient.model.Tickers;
import com.sapient.model.UserTradingDetails;
import com.sapient.model.Watchlist;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.repository.WatchlistRepository;
import com.sapient.service.TickersService;
import com.sapient.service.UserTradingDetailsService;
import com.sapient.service.WatchlistService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Service
public class WatchlistServiceImpl implements WatchlistService {
    @Autowired
    WatchlistRepository watchlistRepository;
    @Autowired
    UserTradingDetailsService userTradingDetailsService;
    @Autowired
    UserTradingDetailsRepository userTradingDetailsRepository;
    @Autowired
    TickersService tickersService;

    @Override
    public Watchlist setEntry(WatchlistDto watchlistDto) throws ParameterNotFoundException, TradingDetailNotFoundException, DuplicateWatchlistEntryException, TickerNotFoundException {

        var watchlist = new Watchlist();
        if(watchlistDto!=null && watchlistDto.getUserId()!=null) {
            UserTradingDetails userTradingDetails;
            try {
                userTradingDetails = userTradingDetailsService.getUserTradingDetailsById(watchlistDto.getUserId());
            } catch (UserNotFoundException e) {
                throw new TradingDetailNotFoundException("You haven't set your trading details");
            }
            Tickers tickers;
            try {
                tickers = tickersService.getTickerById(watchlistDto.getTickerNumber());
            } catch (TickerNotFoundException e) {
                throw new TickerNotFoundException("Ticker not found");
            }
            watchlist.setUserTradingDetail(userTradingDetails);
            watchlist.setTicker(tickers);
            var duplicate = watchlistRepository.selectWatchlist(watchlist.getUserTradingDetail().getUserId(), watchlist.getTicker().getTickerNumber());
            if(duplicate == null) {
                return watchlistRepository.save(watchlist);
            }
            else {
                throw new DuplicateWatchlistEntryException("Watchlist entry already exists");
            }
        }
        else {
            throw new ParameterNotFoundException("Watchlist values cannot be found");
        }
    }

    @Override
    public WatchListCountResponseDto getTickerCountByUserId(BigInteger userId) throws UserNotFoundException {
        UserTradingDetails user = null;
        try {
            user = userTradingDetailsService.getUserTradingDetailsById(userId);
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
        }
        long tickerCount = watchlistRepository.countByUserTradingDetail(user);
        log.info("Ticker Count in Watchlist for userId {} is ",userId,tickerCount);
        return new WatchListCountResponseDto(userId,tickerCount);
    }

    @Override
    public List<Watchlist> getWatchList(BigInteger userId) throws WatchlistNotFoundException, UserNotFoundException {
        Optional<UserTradingDetails> user = userTradingDetailsRepository.findById(userId);
        if (user.isEmpty()) {
            throw new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
        }
        List<Watchlist> watchlist = watchlistRepository.getWatchList(userId);
        if (watchlist == null || watchlist.isEmpty()) {
            throw new WatchlistNotFoundException(Constant.WATCHLIST_NOT_FOUND.toString());
        }
        return watchlist;
    }

    @Override

    public Set<Integer> getDistinctTickerNumber() {
        Set<Integer> tickers =new HashSet<>();
        watchlistRepository.findAll().forEach(e-> tickers.add(e.getTicker().getTickerNumber()));
        log.info("Got Distinct ticker numbers from Watchlist - from watchlist Service");
        return tickers;}

    @Override
    public List<BigInteger> getUserIdListFromTickerNumber(Integer tickerNumber) throws NoUserIdForTickerNumberException {
        List<BigInteger> userIds= watchlistRepository.getUserIdsFromTickerNumber(tickerNumber);
       if(userIds.isEmpty())
       {
          throw new NoUserIdForTickerNumberException(Constant.NO_USERID_FOR_TICKER_NUMBER_FOUND.toString());
       }
       return userIds;

    }

    @Override
    public Watchlist deleteEntry(WatchlistDto watchlistDto) throws TickerNotFoundException, UserNotFoundException, ParameterNotFoundException, WatchlistNotFoundException {

        var watchlist = watchlistRepository.selectWatchlist(watchlistDto.getUserId(), watchlistDto.getTickerNumber());
        if(watchlist == null) {
            throw new WatchlistNotFoundException("Already deleted");
        }
        watchlistRepository.deleteById(watchlist.getWatchlistId());
        return watchlist;
    }
}
