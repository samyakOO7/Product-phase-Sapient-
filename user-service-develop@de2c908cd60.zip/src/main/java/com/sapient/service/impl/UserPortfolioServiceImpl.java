package com.sapient.service.impl;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.dto.*;
import com.sapient.exception.*;
import com.sapient.model.UserPortfolio;
import com.sapient.model.UserTradingDetails;
import com.sapient.repository.TickersRepository;
import com.sapient.repository.UserPortfolioRepository;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.service.UserPortfolioService;
import com.sapient.service.UserTradingDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

@Service
@Slf4j
public class UserPortfolioServiceImpl implements UserPortfolioService {


    @Autowired
    UserTradingDetailsRepository userTradingDetailsRepository;
    @Autowired
    StockServiceFeignClient client;
    @Autowired
    UserTradingDetailsService userTradingDetailsService;
    @Autowired
    TickersRepository tickersRepository;
    @Autowired
    UserPortfolioRepository userPortfolioRepository;

    public Map<String, List<TradesDto>> winningLosingOpenTrades(BigInteger userId, String tradeType) throws EmptyUserPortfolioException, NoLosingTradesException, NoWinningTradesException, UserNotFoundException {
        var user = userTradingDetailsService.getUserTradingDetailsById(userId);
        List<UserPortfolio> userPortfolioList = userPortfolioRepository.findByUserTradingDetail(user);

        if (userPortfolioList.isEmpty()) {
            log.error(Constant.EMPTY_PORTFOLIO + "- From UserPortfolioServiceImpl: winningOrLosingTrades()");
            log.info(Constant.EMPTY_PORTFOLIO + "for user id {}", userId);
            throw new EmptyUserPortfolioException(Constant.EMPTY_PORTFOLIO.toString());
        }

        List<TradesDto> trades = new ArrayList<>();
        Map<String, List<TradesDto>> response = new HashMap<>();

        for (UserPortfolio trade : userPortfolioList) {

            BigDecimal currentPrice = client.getCurrentPrice((trade.getTicker().getTickerId())).get("price_per_stock");
            var averagePrice = BigDecimal.valueOf(trade.getAveragePrice());
            var quantity = BigDecimal.valueOf(trade.getQuantity());
            BigDecimal currentProfitOrLoss = currentPrice.subtract(averagePrice).multiply(quantity);

            if (tradeType.equals("open") || (tradeType.equals("winning") == (currentPrice.compareTo(BigDecimal.valueOf(trade.getAveragePrice()))) >= 0))

                trades.add(new TradesDto(trade.getUserPortfolioId(), trade.getTicker().getTickerId(), trade.getTicker().getTickerName(), currentProfitOrLoss, trade.getQuantity(), trade.getAveragePrice(), currentPrice));
        }
        if (trades.isEmpty() && tradeType.equals("winning")) {

            log.error(Constant.NO_WINNING_TRADES + "- From UserPortfolioServiceImpl : winningOrLosingTrades()");
            log.info(Constant.NO_WINNING_TRADES + "for userId {}", userId);
            throw new NoWinningTradesException(Constant.NO_WINNING_TRADES.toString());

        } else if (trades.isEmpty() && tradeType.equals("losing")) {

            log.error(Constant.NO_LOSING_TRADES + "- From UserPortfolioServiceImpl : winningOrLosingTrades()");
            log.info(Constant.NO_LOSING_TRADES + "for given user {}", userId);
            throw new NoLosingTradesException(Constant.NO_LOSING_TRADES.toString());

        }
        response.put(tradeType + "Trades", trades);
        return response;
    }

    public UserDashboardDto getUserDashboardData(BigInteger userId) throws EmptyUserPortfolioException, TradingDetailNotFoundException {
        log.debug("finding user portfolio for userId {}", userId);
        List<UserPortfolio> userPortfolioList = userPortfolioRepository.findPortfolioByUserId(userId);
        if (userPortfolioList.isEmpty()) {
            log.error(Constant.EMPTY_PORTFOLIO + "- From UserPortfolioServiceImpl: getDashboardData()");
            log.info(Constant.EMPTY_PORTFOLIO + "for user with userId{}", userId);
            throw new EmptyUserPortfolioException(Constant.EMPTY_PORTFOLIO.toString());
        }
        Integer winning = 0;
        Integer loosing = 0;
        double gain = 0;
        log.debug("Calling stock service for latest ticker price");
        for (UserPortfolio userPortfolio : userPortfolioList) {
            BigDecimal cmp = client.getCurrentPrice(userPortfolio.getTicker().getTickerId()).get("price_per_stock");
            double tempGain = (cmp.doubleValue() - userPortfolio.getAveragePrice()) * userPortfolio.getQuantity();
            gain += tempGain;
            if (tempGain >= 0) winning++;
            else loosing++;
        }
        log.debug("setting up user dashboard dto for userid {}", userId);
        var userDashboardDto = new UserDashboardDto();
        userDashboardDto.setGain(gain);
        userDashboardDto.setLoosing(loosing);
        userDashboardDto.setWinning(winning);
        Optional<UserTradingDetails> userTradingDetails = userTradingDetailsRepository.findById(userId);
        if (userTradingDetails.isPresent()) {
            log.debug("user trading details found for given userId {}", userId);
            userDashboardDto.setTotalEquity(userTradingDetails.get().getTotalEquity());
        } else {
            log.error(Constant.TRADING_DETAIL_NOT_FOUND + "- From UserPortfolioServiceImpl: getDashboardData()");
            log.info(Constant.TRADING_DETAIL_NOT_FOUND + "for user-id {}", userId);
            throw new TradingDetailNotFoundException(Constant.TRADING_DETAIL_NOT_FOUND.toString());
        }
        log.debug("returning user dashboard data with userId {}", userId);
        return userDashboardDto;
    }

    @Override
    public PortfolioUpdateSuccessDto updatePortfolio(UserPortfolioUpdateDto userPortfolioUpdateDto) {
        if (userPortfolioUpdateDto.getType().equals("buy")) {
            log.debug("update portfolio request type BUY");
            updatePortfolioBuy(userPortfolioUpdateDto);
        } else if (userPortfolioUpdateDto.getType().equals("sell")) {
            log.debug("update portfolio request type SELL");
            updatePortfolioSell(userPortfolioUpdateDto);
        }
        BigInteger userId = userPortfolioUpdateDto.getUserId();
        List<UserPortfolio> userPortfolioList = userPortfolioRepository.findPortfolioByUserId(userId);
        log.debug("updating user equity in user trading details ");
        Double portfolioEquity = 0.0;
        for (UserPortfolio userPortfolio : userPortfolioList) {

            portfolioEquity = portfolioEquity + userPortfolio.getAveragePrice() * userPortfolio.getQuantity();

        }
        var userTradingDetails = userTradingDetailsRepository.getById(userId);
        userTradingDetails.setTotalEquity(userTradingDetails.getTotalAmount() + portfolioEquity);
        userTradingDetailsRepository.save(userTradingDetails);
        log.debug("Successfully updated user portfolio");
        return new PortfolioUpdateSuccessDto("Success");

    }

    private void updatePortfolioBuy(UserPortfolioUpdateDto userPortfolioUpdateDto) {
        var portfolio = userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(userPortfolioUpdateDto.getUserId(), userPortfolioUpdateDto.getTickerNumber());
        var userTradingDetails = userTradingDetailsRepository.getById(userPortfolioUpdateDto.getUserId());
        if (portfolio != null) {
            log.debug("Ticker already existed in user portfolio, hence updating row for ticker number {}", userPortfolioUpdateDto.getTickerNumber());
            Integer tempQuantity = portfolio.getQuantity();
            portfolio.setQuantity(tempQuantity + userPortfolioUpdateDto.getQuantity());
            Double tempAveragePrice = portfolio.getAveragePrice();
            portfolio.setAveragePrice((tempAveragePrice * tempQuantity + userPortfolioUpdateDto.getPrice() * userPortfolioUpdateDto.getQuantity()) / portfolio.getQuantity());
            Double tempProfitTarget = portfolio.getProfitTarget();
            portfolio.setProfitTarget((tempProfitTarget * tempQuantity + userPortfolioUpdateDto.getProfitTarget() * userPortfolioUpdateDto.getQuantity()) / portfolio.getQuantity());
            Double tempStopLoss = portfolio.getStopLoss();
            portfolio.setStopLoss((tempStopLoss * tempQuantity + userPortfolioUpdateDto.getStopLoss() * userPortfolioUpdateDto.getQuantity()) / portfolio.getQuantity());
            userPortfolioRepository.save(portfolio);
        } else {
            log.debug("Generating new row in user portfolio for ticker number {}", userPortfolioUpdateDto.getTickerNumber());
            var userPortfolio = new UserPortfolio();
            userPortfolio.setUserTradingDetail(userTradingDetails);
            userPortfolio.setQuantity(userPortfolioUpdateDto.getQuantity());
            userPortfolio.setProfitTarget(userPortfolioUpdateDto.getProfitTarget());
            var tickers = tickersRepository.findByTickerNumber(userPortfolioUpdateDto.getTickerNumber());
            userPortfolio.setTicker(tickers);
            userPortfolio.setAveragePrice(userPortfolioUpdateDto.getPrice());
            userPortfolio.setStopLoss(userPortfolioUpdateDto.getStopLoss());
            userPortfolioRepository.save(userPortfolio);
        }
        userTradingDetails.setTotalAmount(userTradingDetails.getTotalAmount() - userPortfolioUpdateDto.getQuantity() * userPortfolioUpdateDto.getPrice());
        log.debug("updating available amount in user trading details with userId {}", userTradingDetails.getUserId());
        userTradingDetailsRepository.save(userTradingDetails);
    }

    private void updatePortfolioSell(UserPortfolioUpdateDto userPortfolioUpdateDto) {
        var userTradingDetails = userTradingDetailsRepository.getById(userPortfolioUpdateDto.getUserId());
        userTradingDetails.setTotalAmount(userTradingDetails.getTotalAmount() + userPortfolioUpdateDto.getQuantity() * userPortfolioUpdateDto.getPrice());
        log.debug("updating available amount in user trading details with user id {}", userPortfolioUpdateDto.getUserId());
        userTradingDetailsRepository.save(userTradingDetails);
        var userPortfolio = userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(userPortfolioUpdateDto.getUserId(), userPortfolioUpdateDto.getTickerNumber());
        log.debug("deleting row from user portfolio and updated available amount");
        userPortfolioRepository.delete(userPortfolio);
    }

    @Override
    public UserPortfolioDto getUserPortfolio(BigInteger portfolioId) throws PortfolioNotFoundException {
        Optional<UserPortfolio> portfolio = userPortfolioRepository.findById(portfolioId);
        log.debug("getting user portfolio with portfolioId {}", portfolioId);
        return mapUserPortfolio(portfolio);
    }

    @Override
    public UserPortfolioDto getUserPortfolioByUserIdAndTickerNumber(BigInteger userId, Integer tickerNumber) throws PortfolioNotFoundException {
        Optional<UserPortfolio> portfolio = Optional.ofNullable(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(userId, tickerNumber));
        log.debug("getting user portfolio with userId {} and tickerNumber {}", userId, tickerNumber);
        return mapUserPortfolio(portfolio);
    }

    private UserPortfolioDto mapUserPortfolio(Optional<UserPortfolio> portfolio) throws PortfolioNotFoundException {
        if (portfolio.isEmpty()) {
            log.error("couldn't get the user portfolio");
            throw new PortfolioNotFoundException();
        }
        var folio = portfolio.get();
        var dto = new UserPortfolioDto();
        dto.setUserId(folio.getUserTradingDetail().getUserId());
        dto.setUserPortfolioId(folio.getUserPortfolioId());
        dto.setQuantity(folio.getQuantity());
        dto.setAveragePrice(folio.getAveragePrice());
        dto.setTicker(folio.getTicker());
        return dto;
    }

    @Override
    public Map<String, List<UserPortfolioDetailsDto>> getPortfolioByUserId(BigInteger userId) {
        List<UserPortfolio> userPortfolioList = userPortfolioRepository.findPortfolioByUserId(userId);
        log.debug("getting user portfolio of userId {} ", userId);
        List<UserPortfolioDetailsDto> userPortfolioDetailsDtoList = new ArrayList<>();
        for (UserPortfolio userPortfolio : userPortfolioList) {

            var userPortfolioDetailsDto = new UserPortfolioDetailsDto();
            userPortfolioDetailsDto.setUserPortfolioId(userPortfolio.getUserPortfolioId());
            userPortfolioDetailsDto.setTickerId(userPortfolio.getTicker().getTickerId());
            userPortfolioDetailsDto.setStopLoss(userPortfolio.getStopLoss());
            userPortfolioDetailsDto.setProfitTarget(userPortfolio.getProfitTarget());
            userPortfolioDetailsDto.setAveragePrice(userPortfolio.getAveragePrice());

            userPortfolioDetailsDtoList.add(userPortfolioDetailsDto);
        }
        Map<String, List<UserPortfolioDetailsDto>> response = new HashMap<>();
        response.put("userPortfolio", userPortfolioDetailsDtoList);
        return response;
    }
}
