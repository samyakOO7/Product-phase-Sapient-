package com.sapient.service.impl;
import com.sapient.constant.Constant;
import com.sapient.dto.WatchlistTickerDto;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.model.Tickers;
import com.sapient.repository.TickersRepository;
import com.sapient.service.TickersService;
import com.sapient.service.WatchlistService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class TickersServiceImpl implements TickersService {

    @Autowired
    TickersRepository tickersRepository;

    @Autowired
    WatchlistService watchlistService;

    @Override
    public Tickers getTickerById(Integer tickerNumber) throws TickerNotFoundException {
        Optional<Tickers> ticker = tickersRepository.findById(tickerNumber);
        if(ticker.isPresent()) {
            return ticker.get();
        }
        throw new TickerNotFoundException(Constant.TICKER_NOT_FOUND.toString());
    }

    @Override
    public List<Tickers> searchTickers(String searchTicker) throws TickerNotFoundException {
        List<Tickers> tickers = tickersRepository.searchTickers(searchTicker);
        if (tickers.isEmpty()) {
            throw new TickerNotFoundException(Constant.TICKER_NOT_FOUND.toString());
        }
        return tickers;
    }
    @Override
    public Map<String, List<WatchlistTickerDto>> getWatchlistTicker() {
        Set<Integer> tickers = watchlistService.getDistinctTickerNumber();
        List<WatchlistTickerDto> watchlistStocks = tickersRepository.getWatchlistStocks(tickers);
        Map<String,List<WatchlistTickerDto>> map = new HashMap<>();
        map.put("tickers",watchlistStocks);
        log.info("Ticker details of distinct tickers -from TickerService");
        return map;
    }

}
