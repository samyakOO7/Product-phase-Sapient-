package com.sapient.service.impl;

import com.sapient.constant.Constant;
import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.exception.InternalServerException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.model.UserTradingDetails;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.service.UserTradingDetailsService;
import com.sapient.utils.UserTradingDetailsUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Slf4j
@Service
public class UserTradingDetailsServiceImpl implements UserTradingDetailsService {

    @Autowired
    UserTradingDetailsRepository userTradingDetailsRepository;

    @Autowired
    UserTradingDetailsUtil userTradingDetailsUtil;

    @Override
    public UserTradingDetails getUserTradingDetailsById(BigInteger userId) throws UserNotFoundException {
        Optional<UserTradingDetails> userTradingDetails = userTradingDetailsRepository.findById(userId);
        if (userTradingDetails.isPresent()) {
            return userTradingDetails.get();
        }
        throw new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
    }

    @Override
    public UserTradingDetails createOrUpdate(UserTradingDetailsDto userTradingDetailsDto) throws InternalServerException {
        var userTradingDetailsDB = getUserTradingDetailsByUserId(userTradingDetailsDto.getUserId());

        if (userTradingDetailsDB != null) {
            userTradingDetailsDto.setTotalEquity(userTradingDetailsDto.getTotalAmount() + userTradingDetailsDB.getTotalEquity());
            userTradingDetailsDto.setTotalAmount(userTradingDetailsDto.getTotalAmount() + userTradingDetailsDB.getTotalAmount());
            userTradingDetailsDto.setTotalAlertsGenerated(userTradingDetailsDB.getTotalAlertsGenerated());
        } else {
            userTradingDetailsDto.setTotalEquity(userTradingDetailsDto.getTotalAmount());
        }

        var userTradingDetails = userTradingDetailsUtil.mapUserTradingDetails(userTradingDetailsDto);

        try {
            userTradingDetailsRepository.save(userTradingDetails);
        } catch (Exception e) {
            log.error("Exception in createOrUpdate(): ", e);
            throw new InternalServerException(Constant.INTERNAL_SERVER_ERROR.toString());
        }
        return userTradingDetails;
    }

    private UserTradingDetails getUserTradingDetailsByUserId(BigInteger userId) {
        Optional<UserTradingDetails> userTradingDetails = userTradingDetailsRepository.findById(userId);
        return userTradingDetails.orElse(null);
    }
    @Override
    public Map<String, List<BigInteger>> getAllUserIds() {
        List<BigInteger> userIds = userTradingDetailsRepository.findAllUserIds();
        log.debug("Getting all the userIds getAllUserIds() - UserTradingDetailsServiceImpl");
        Map<String,List<BigInteger>> allUserIds = new HashMap<>();
        allUserIds.put("userIds",userIds);
        return allUserIds;
    }

}
