package com.sapient.service;

import com.sapient.dto.WatchlistTickerDto;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.model.Tickers;

import java.util.List;
import java.util.Map;

public interface TickersService {

    Tickers getTickerById(Integer tickerNumber) throws TickerNotFoundException;

    Map<String, List<WatchlistTickerDto>> getWatchlistTicker();

    List<Tickers> searchTickers(String searchTicker) throws TickerNotFoundException;

}
