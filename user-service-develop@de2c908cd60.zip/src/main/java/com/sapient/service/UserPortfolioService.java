package com.sapient.service;

import com.sapient.dto.*;
import com.sapient.exception.*;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;


public interface UserPortfolioService {
    UserPortfolioDto getUserPortfolio(BigInteger portfolioId) throws PortfolioNotFoundException;
    UserPortfolioDto getUserPortfolioByUserIdAndTickerNumber(BigInteger userId, Integer tickerNumber) throws PortfolioNotFoundException;


    UserDashboardDto getUserDashboardData(BigInteger userId) throws EmptyUserPortfolioException, TradingDetailNotFoundException;

    PortfolioUpdateSuccessDto updatePortfolio(UserPortfolioUpdateDto userPortfolioUpdateDto);

    Map<String, List<TradesDto>> winningLosingOpenTrades(BigInteger userId, String type) throws EmptyUserPortfolioException, NoLosingTradesException, NoWinningTradesException, UserNotFoundException;

    Map<String, List<UserPortfolioDetailsDto>> getPortfolioByUserId(BigInteger userId);
}

