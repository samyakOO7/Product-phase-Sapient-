package com.sapient.service;

import com.sapient.dto.WatchListCountResponseDto;
import com.sapient.dto.WatchlistDto;
import com.sapient.exception.*;
import com.sapient.model.Watchlist;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public interface WatchlistService {

    Watchlist setEntry(WatchlistDto watchlistDto) throws TickerNotFoundException, UserNotFoundException, ParameterNotFoundException, TradingDetailNotFoundException, DuplicateWatchlistEntryException;
    WatchListCountResponseDto getTickerCountByUserId(BigInteger userId) throws UserNotFoundException;
    List<Watchlist> getWatchList(BigInteger userId) throws WatchlistNotFoundException, UserNotFoundException;

    Set<Integer> getDistinctTickerNumber();
    List<BigInteger> getUserIdListFromTickerNumber(Integer tickerNumber) throws NoUserIdForTickerNumberException;

    Watchlist deleteEntry(WatchlistDto watchlistDto) throws TickerNotFoundException, UserNotFoundException, ParameterNotFoundException, WatchlistNotFoundException;

}
