package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@NoArgsConstructor
@AllArgsConstructor
public class WatchlistDto {

    private BigInteger watchlistId;
    private BigInteger userId;
    private Integer tickerNumber;

    public BigInteger getUserId() {
        return userId;
    }

    public Integer getTickerNumber() {
        return tickerNumber;
    }
}