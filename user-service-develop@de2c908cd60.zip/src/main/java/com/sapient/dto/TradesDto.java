package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TradesDto {

    private BigInteger userPortfolioId;
    private String tickerId;
    private String tickerName;
    private BigDecimal currentProfitOrLoss;
    private Integer quantity;
    private Double averagePrice;
    private BigDecimal currentPrice;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        var tradesDto = (TradesDto) o;
        return Objects.equals(userPortfolioId, tradesDto.userPortfolioId) && Objects.equals(tickerId, tradesDto.tickerId) && Objects.equals(tickerName, tradesDto.tickerName) && Objects.equals(currentProfitOrLoss, tradesDto.currentProfitOrLoss) && Objects.equals(quantity, tradesDto.quantity) && Objects.equals(averagePrice, tradesDto.averagePrice) && Objects.equals(currentPrice, tradesDto.currentPrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userPortfolioId, tickerId, tickerName, currentProfitOrLoss, quantity, averagePrice, currentPrice);
    }
}
