package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class UserPortfolioUpdateDto {

    private String type;
    private BigInteger userId;
    private Integer tickerNumber;
    private Integer quantity;
    private double price;

    private double stopLoss;

    private double profitTarget;

    @Override
    public String toString() {
        return "UserPortfolioUpdateDto{" +
                "type='" + type + '\'' +
                ", userId=" + userId +
                ", tickerNumber=" + tickerNumber +
                ", quantity=" + quantity +
                ", buyPrice=" + price +
                ", stopLoss=" + stopLoss +
                ", profitTarget=" + profitTarget +
                '}';
    }
}
