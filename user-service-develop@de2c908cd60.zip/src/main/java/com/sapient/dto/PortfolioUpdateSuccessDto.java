package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PortfolioUpdateSuccessDto {
    private String message;

    @Override
    public String toString() {
        return "PortfolioUpdateSuccessDto{" + "message='" + message + '\'' + '}';
    }
}
