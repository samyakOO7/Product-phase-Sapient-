package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserPortfolioDetailsDto {
    private BigInteger userPortfolioId;
    private String tickerId;
    private Double profitTarget;
    private Double stopLoss;

    private Double averagePrice;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserPortfolioDetailsDto that = (UserPortfolioDetailsDto) o;
        return Objects.equals(userPortfolioId, that.userPortfolioId) && Objects.equals(tickerId, that.tickerId) && Objects.equals(profitTarget, that.profitTarget) && Objects.equals(stopLoss, that.stopLoss) && Objects.equals(averagePrice, that.averagePrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userPortfolioId, tickerId, profitTarget, stopLoss, averagePrice);
    }
}

