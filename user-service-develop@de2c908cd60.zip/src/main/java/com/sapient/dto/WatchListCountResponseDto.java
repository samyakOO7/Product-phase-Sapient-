package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WatchListCountResponseDto {
    BigInteger userId;
    long tickerCount;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WatchListCountResponseDto that = (WatchListCountResponseDto) o;
        return tickerCount == that.tickerCount && userId.equals(that.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, tickerCount);
    }

    @Override
    public String toString() {
        return "WatchListCountResponseDto{" + "userId=" + userId + ", tickerCount=" + tickerCount + '}';
    }
}
