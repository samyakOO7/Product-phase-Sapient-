package com.sapient.dto;

import com.sapient.model.Tickers;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Generated
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPortfolioDto {
    private BigInteger userPortfolioId;
    private Integer quantity;
    private Double averagePrice;
    private BigInteger userId;
    private Tickers ticker;
}