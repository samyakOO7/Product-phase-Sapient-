package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserDashboardDto {
    private Double gain;
    private Double totalEquity;
    private Integer winning;
    private Integer loosing;

    @Override
    public String toString() {
        return "UserDashboardDto{" + "gain=" + gain + ", totalEquity=" + totalEquity + ", winning=" + winning + ", loosing=" + loosing + '}';
    }
}
