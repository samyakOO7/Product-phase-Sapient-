package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserTradingDetailsDto {

    @NotNull(message = "Cannot be null or empty")
    private BigInteger userId;

    private Double totalAmount;

    @NotNull(message = "Cannot be null or empty")
    @Max(value = 100, message = "Maximum value should not exceed 100 (in %)")
    @Min(value = 0, message = "Minimum value should be 0")
    private Double amountPerTrade;

    @NotNull(message = "Cannot be null or empty")
    @Max(value = 100, message = "Maximum value should not exceed 100 (in %)")
    @Min(value = 0, message = "Minimum value should be 0")
    private Double riskPerTrade;

    private BigInteger totalAlertsGenerated;
    private Double totalEquity;
}
