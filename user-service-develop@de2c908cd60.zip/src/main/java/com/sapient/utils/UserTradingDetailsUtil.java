package com.sapient.utils;

import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.model.UserTradingDetails;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Component;

@Component
public class UserTradingDetailsUtil {

    public UserTradingDetails mapUserTradingDetails(UserTradingDetailsDto userTradingDetailsDto) {

        var modelMapper = new ModelMapper();

        modelMapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.STRICT);
        return modelMapper.map(userTradingDetailsDto, UserTradingDetails.class);
    }
}

