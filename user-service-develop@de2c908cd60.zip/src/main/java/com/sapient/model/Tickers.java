package com.sapient.model;

import com.sapient.dto.WatchlistTickerDto;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "tickers" )
@AllArgsConstructor
@NoArgsConstructor
@NamedNativeQuery(
        name = "find_watchlist_ticker",
        query ="select t.ticker_number as tickerNumber,t.ticker_id as tickerId from tickers t where t.ticker_number in (:tickerNumList)",
        resultSetMapping = "watchlist_ticker"
)
@SqlResultSetMapping(
        name = "watchlist_ticker",
        classes = @ConstructorResult(
                targetClass = WatchlistTickerDto.class,
                columns = {
                        @ColumnResult(name = "tickerNumber", type = Integer.class),
                        @ColumnResult(name = "tickerId", type = String.class)
                }
        )
)
public class Tickers {

    @Id
    @Column(name="ticker_number")
    private Integer tickerNumber;

    @Column(name="ticker_name")
    private String tickerName;

    @Column(name="ticker_id")
    private String tickerId;

    @Column(name="ticker_type")
    private String tickerType;

    @Override
    public String toString() {
        return "Tickers{" +
                "tickerNumber=" + tickerNumber +
                ", tickerName='" + tickerName + '\'' +
                ", tickerId='" + tickerId + '\'' +
                ", tickerType='" + tickerType + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        var tickers = (Tickers) o;
        return Objects.equals(tickerNumber, tickers.tickerNumber) && Objects.equals(tickerName, tickers.tickerName) && Objects.equals(tickerId, tickers.tickerId) && Objects.equals(tickerType, tickers.tickerType);
    }

    public Integer getTickerNumber() {
        return tickerNumber;
    }

    public void setTickerNumber(Integer tickerNumber) {
        this.tickerNumber = tickerNumber;
    }

    public String getTickerName() {
        return tickerName;
    }

    public void setTickerName(String tickerName) {
        this.tickerName = tickerName;
    }

    public String getTickerId() {
        return tickerId;
    }

    public void setTickerId(String tickerId) {
        this.tickerId = tickerId;
    }

    public String getTickerType() {
        return tickerType;
    }

    public void setTickerType(String tickerType) {
        this.tickerType = tickerType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerNumber, tickerName, tickerId, tickerType);
    }
}
