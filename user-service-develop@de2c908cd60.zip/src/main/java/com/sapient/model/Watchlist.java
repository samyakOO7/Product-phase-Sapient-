package com.sapient.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "watchlist")
public class Watchlist {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="watchlist_id")
    private BigInteger watchlistId;
    @ManyToOne
    @JoinColumn(name="user_id")
    private UserTradingDetails userTradingDetail;
    @ManyToOne
    @JoinColumn(name = "ticker_number")
    private Tickers ticker;


}
