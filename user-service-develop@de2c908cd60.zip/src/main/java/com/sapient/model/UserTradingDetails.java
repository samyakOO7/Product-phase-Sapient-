package com.sapient.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;


@Entity
@Table(name = "user_trading_details")
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class UserTradingDetails {

    @Id
    @Column(name = "user_id")
    private BigInteger userId;

    @Column(name = "total_amount")
    private Double totalAmount;

    @Column(name = "amount_per_trade")
    private Double amountPerTrade;

    @Column(name = "risk_per_trade")
    private Double riskPerTrade;

    @Column(name = "total_alerts_generated")
    private BigInteger totalAlertsGenerated;

    @Column(name = "total_equity")
    private Double totalEquity;

}
