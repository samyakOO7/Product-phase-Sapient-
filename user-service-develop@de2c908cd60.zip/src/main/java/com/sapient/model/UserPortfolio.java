package com.sapient.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "user_portfolio")
public class UserPortfolio {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_portfolio_id")
    private BigInteger userPortfolioId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserTradingDetails userTradingDetail;
    @ManyToOne
    @JoinColumn(name = "ticker_number")
    private Tickers ticker;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "average_price")
    private Double averagePrice;

    @Column(name = "profit_target")
    private Double profitTarget;

    @Column(name = "stop_loss")
    private Double stopLoss;

    @Override
    public String toString() {
        return "UserPortfolio{" +
                "userPortfolioId=" + userPortfolioId +
                ", userTradingDetail=" + userTradingDetail +
                ", ticker=" + ticker +
                ", quantity=" + quantity +
                ", averagePrice=" + averagePrice +
                ", profitTarget=" + profitTarget +
                ", stopLoss=" + stopLoss +
                '}';
    }
}
