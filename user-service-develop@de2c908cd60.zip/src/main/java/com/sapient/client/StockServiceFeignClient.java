package com.sapient.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.Map;

@FeignClient(url = "${stock.service.feign.url}", name = "stock-microservice")
public interface StockServiceFeignClient {

    @GetMapping(value = "/{tickerId}", produces = "application/json")
    Map<String, BigDecimal> getCurrentPrice(@PathVariable("tickerId") String tickerId);

}
