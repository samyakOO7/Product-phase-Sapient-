package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.*;
import com.sapient.utils.JsonResponse;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
public class UserAdvice {

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(UserNotFoundException.class)
    public Map<String, List<Map<String, String>>> userNotFound(UserNotFoundException userNotFoundException) {
        return JsonResponse.setError(Constant.USER_NOT_FOUND.name(), userNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(TickerNotFoundException.class)
    public Map<String, List<Map<String, String>>> tickerNotFound(TickerNotFoundException tickerNotFoundException) {
        return JsonResponse.setError(Constant.TICKER_NOT_FOUND.name(), tickerNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ParameterNotFoundException.class)
    public Map<String, List<Map<String, String>>> parameterNotFound(ParameterNotFoundException parameterNotFoundException) {
        return JsonResponse.setError(Constant.PARAMETER_FOR_SEARCH_NOT_FOUND.name(), parameterNotFoundException.getMessage());

    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(WatchlistNotFoundException.class)
    public Map<String, List<Map<String, String>>> watchlistNotFound(WatchlistNotFoundException watchlistNotFoundException) {

        return JsonResponse.setError(Constant.WATCHLIST_NOT_FOUND.name(), watchlistNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoUserIdForTickerNumberException.class)
    public Map<String, List<Map<String, String>>> error(NoUserIdForTickerNumberException e) {

        return JsonResponse.setError(Constant.NO_USERID_FOR_TICKER_NUMBER_FOUND.name(), e.getMessage());

    }
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(EmptyUserPortfolioException.class)
    public Map<String, List<Map<String, String>>>  emptyPortfolio(EmptyUserPortfolioException e) {

        return JsonResponse.setError(Constant.EMPTY_PORTFOLIO.name(), e.getMessage());

    }
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoWinningTradesException.class)
    public Map<String, List<Map<String, String>>>  noWinningTrades(NoWinningTradesException e) {

        return JsonResponse.setError(Constant.NO_WINNING_TRADES.name(), e.getMessage());

    }
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoLosingTradesException.class)
    public Map<String, List<Map<String, String>>>  noLosingTrades(NoLosingTradesException e) {

        return JsonResponse.setError(Constant.NO_LOSING_TRADES.name(), e.getMessage());

    }
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(InternalServerException.class)
    public Map<String, List<Map<String, String>>>  internalServer(InternalServerException e) {

        return JsonResponse.setError(Constant.INTERNAL_SERVER_ERROR.name(), e.getMessage());

    }
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public Map<String, List<Map<String, String>>> error() {
        return JsonResponse.setError(Constant.INTERNAL_SERVER_ERROR.name(), Constant.GENERAL_EXCEPTION.toString());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, List<Map<String, String>>> returnMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        List<Map<String, String>> errorList = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String errorMessage = error.getDefaultMessage();
            errorList.add(JsonResponse.setErrors("VALIDATION_ERROR", ((FieldError) error).getField() + ": " + errorMessage));
        });
        return JsonResponse.setErrorResponse(errorList);
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(TradingDetailNotFoundException.class)
    public Map<String, List<Map<String, String>>> tradingDetailNotFound(TradingDetailNotFoundException ex) {

        return JsonResponse.setError(Constant.TRADING_DETAIL_NOT_FOUND.name(),ex.getMessage());

    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(DuplicateWatchlistEntryException.class)
    public Map<String, List<Map<String, String>>> duplicateWatchlistEntry(DuplicateWatchlistEntryException ex) {

        return JsonResponse.setError(Constant.DUPLICATE_WATCHLIST_ENTRY.name(),ex.getMessage());

    }

}

