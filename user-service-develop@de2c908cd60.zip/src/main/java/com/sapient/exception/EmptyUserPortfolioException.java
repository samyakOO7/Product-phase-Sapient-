package com.sapient.exception;

public class EmptyUserPortfolioException extends Exception{
    public EmptyUserPortfolioException(String message) {
        super(message);
    }
}
