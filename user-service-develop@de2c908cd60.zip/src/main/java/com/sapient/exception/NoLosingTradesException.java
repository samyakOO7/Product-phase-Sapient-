package com.sapient.exception;

public class NoLosingTradesException extends Exception{
    public NoLosingTradesException(String message) {
        super(message);
    }
}
