package com.sapient.exception;

public class TradingDetailNotFoundException extends Exception{
    public TradingDetailNotFoundException(String msg) {
        super(msg);
    }
}
