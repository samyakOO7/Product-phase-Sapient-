package com.sapient.exception;

public class NoWinningTradesException extends Exception{
    public NoWinningTradesException(String message) {
        super(message);
    }
}
