package com.sapient.exception;

public class PortfolioNotFoundException extends Exception {
    public PortfolioNotFoundException() {
    }

    public PortfolioNotFoundException(String message) {
        super(message);
    }
}
