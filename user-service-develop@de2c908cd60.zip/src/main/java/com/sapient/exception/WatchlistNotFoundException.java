package com.sapient.exception;

public class WatchlistNotFoundException extends Exception {
    public WatchlistNotFoundException(String message) {
        super(message);
    }
}
