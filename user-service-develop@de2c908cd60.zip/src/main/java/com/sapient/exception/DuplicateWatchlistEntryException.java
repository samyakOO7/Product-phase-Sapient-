package com.sapient.exception;

public class DuplicateWatchlistEntryException extends Exception{

    public DuplicateWatchlistEntryException(String message) {
        super(message);
    }
}