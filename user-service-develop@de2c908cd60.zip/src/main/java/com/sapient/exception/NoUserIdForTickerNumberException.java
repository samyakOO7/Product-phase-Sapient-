package com.sapient.exception;


public class NoUserIdForTickerNumberException extends Exception {
    public NoUserIdForTickerNumberException(String message) {
        super(message);
    }
}
