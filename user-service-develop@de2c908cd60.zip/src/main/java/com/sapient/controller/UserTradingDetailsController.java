package com.sapient.controller;

import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.exception.InternalServerException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.model.UserTradingDetails;
import com.sapient.service.UserTradingDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class UserTradingDetailsController {

    @Autowired
    UserTradingDetailsService userTradingDetailsService;

    @PostMapping(value = "/create-update-trading-profile", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<UserTradingDetails> createUpdateProfile(@RequestBody @Valid UserTradingDetailsDto userTradingDetailsDto) throws InternalServerException, UserNotFoundException {
        var userTradingDetails = userTradingDetailsService.createOrUpdate(userTradingDetailsDto);
        return ResponseEntity.ok(userTradingDetails);
    }

    @GetMapping(value = "/get-user-trading-details/{userId}")
    public ResponseEntity<UserTradingDetails> getTradingDetails(@PathVariable("userId") BigInteger userId) throws UserNotFoundException {
        var userTradingDetails = userTradingDetailsService.getUserTradingDetailsById(userId);
        return ResponseEntity.ok(userTradingDetails);
    }

    @GetMapping(value = "/all-users")
    public ResponseEntity<Map<String, List<BigInteger>>> getAllUserIds() {
        log.debug("Inside getAllUserIds() method - UserTradingDetails Controller");
        var userIds = userTradingDetailsService.getAllUserIds();
        return ResponseEntity.ok(userIds);
    }

}
