package com.sapient.controller;

import com.sapient.constant.Constant;
import com.sapient.dto.WatchlistTickerDto;
import com.sapient.exception.ParameterNotFoundException;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.model.Tickers;
import com.sapient.service.TickersService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class TickerController {

    @Autowired
    TickersService tickersService;

    @GetMapping(value = "/tickers/search/{ticker}")
    public ResponseEntity<List<Tickers>> searchTicker(@PathVariable("ticker") String ticker) throws TickerNotFoundException {
        List<Tickers> tickersList = tickersService.searchTickers(ticker);
        return ResponseEntity.ok().body(tickersList);
    }

    @GetMapping(value = "/tickers/search/")
    public void exceptionSearchTicker() throws ParameterNotFoundException {
        throw new ParameterNotFoundException(Constant.PARAMETER_FOR_SEARCH_NOT_FOUND.toString());
    }

    @GetMapping(value = "/watchlist-tickers")
    public ResponseEntity<Map<String, List<WatchlistTickerDto>>> tickersInWatchlist() {
        return ResponseEntity.ok(tickersService.getWatchlistTicker());
    }

}