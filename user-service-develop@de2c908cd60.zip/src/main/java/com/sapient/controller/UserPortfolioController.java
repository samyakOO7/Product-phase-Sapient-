package com.sapient.controller;

import com.sapient.dto.*;
import com.sapient.exception.*;
import com.sapient.service.UserPortfolioService;
import com.sapient.utils.JsonResponse;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import static com.sapient.constant.Constant.PORTFOLIO_DETAIL_NOT_FOUND;

@RestController
@Slf4j
@Generated
public class UserPortfolioController {
    @Autowired
    UserPortfolioService userPortfolioService;

    @GetMapping("/user-stats/{userId}")
    public ResponseEntity<UserDashboardDto> getUserDashboardData(@PathVariable("userId") BigInteger userId) throws EmptyUserPortfolioException, TradingDetailNotFoundException {
        try {
            var userDashboardDto = userPortfolioService.getUserDashboardData(userId);
            log.debug("getting user dashboard");
            return ResponseEntity.ok().body(userDashboardDto);
        } catch (EmptyUserPortfolioException e) {
            log.error("Dashboard data doesn't exist for given userID {}", userId);
            throw new EmptyUserPortfolioException(PORTFOLIO_DETAIL_NOT_FOUND.toString());
        }
    }

    @PostMapping("/portfolio/update")
    public PortfolioUpdateSuccessDto setUserPortfolio(@RequestBody UserPortfolioUpdateDto userPortfolioUpdateDto) {
        log.debug("setting up user portfolio");
        return userPortfolioService.updatePortfolio(userPortfolioUpdateDto);
    }

    @GetMapping("/winning-losing-open-trades")
    public ResponseEntity<Map<String, List<TradesDto>>> getWinningLosingOpenTrades(@RequestParam("userId") BigInteger userId, @RequestParam("type") String tradeType) throws EmptyUserPortfolioException, NoWinningTradesException, NoLosingTradesException, UserNotFoundException {
        log.info("Inside getWinningLosingOpenTrades() method - UserPortfolio Controller");
        return ResponseEntity.ok(userPortfolioService.winningLosingOpenTrades(userId, tradeType));
    }

    @GetMapping("user-portfolio/{portfolioId}")
    public ResponseEntity<UserPortfolioDto> getPortfolioByPortfolioId(@PathVariable("portfolioId") BigInteger portfolioId) throws PortfolioNotFoundException {
        log.debug("getting  user portfolio");
        return ResponseEntity.ok(userPortfolioService.getUserPortfolio(portfolioId));
    }

    @GetMapping("user-portfolio/{userId}/ticker/{tickerNum}")
    public ResponseEntity<UserPortfolioDto> getPortfolioByUserIdAndTickerNumber(@PathVariable("userId") BigInteger userId, @PathVariable("tickerNum") Integer tickerNum) throws PortfolioNotFoundException {
        log.debug("getting  user portfolio");
        return ResponseEntity.ok(userPortfolioService.getUserPortfolioByUserIdAndTickerNumber(userId, tickerNum));
    }

    @GetMapping("/user-portfolio")
    public ResponseEntity<Map<String, List<UserPortfolioDetailsDto>>> getUserPortfolio(@RequestParam("userId") BigInteger userId){
        log.debug("Inside getUserPortfolio() method - UserPortfolio Controller");
        return ResponseEntity.ok(userPortfolioService.getPortfolioByUserId(userId));
    }


    @ExceptionHandler(PortfolioNotFoundException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, List<Map<String, String>>> portfolioNotFoundHandler(PortfolioNotFoundException exp) {
        return JsonResponse.setError(PORTFOLIO_DETAIL_NOT_FOUND.name(), PORTFOLIO_DETAIL_NOT_FOUND.toString());
    }
}
