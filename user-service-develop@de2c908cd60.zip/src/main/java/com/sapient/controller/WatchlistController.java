package com.sapient.controller;

import com.sapient.dto.WatchListCountResponseDto;
import com.sapient.dto.WatchlistDto;
import com.sapient.exception.*;
import com.sapient.model.Watchlist;
import com.sapient.service.WatchlistService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

@Slf4j
@RestController
public class WatchlistController {
    @Autowired
    WatchlistService watchlistService;

    @PostMapping(value = "/watchlist/add")
    public ResponseEntity<Watchlist> addWatchlist(@RequestBody WatchlistDto watchlistDto) throws UserNotFoundException, TickerNotFoundException, ParameterNotFoundException, TradingDetailNotFoundException, DuplicateWatchlistEntryException {
        log.info("Getting request for add watchlist");
        return ResponseEntity.ok().body(watchlistService.setEntry(watchlistDto));
    }

    @GetMapping(value = "/watchlist-count/{userId}")
    public ResponseEntity<WatchListCountResponseDto> countTickerCountByUserId(@PathVariable BigInteger userId) throws UserNotFoundException {
        return ResponseEntity.ok().body(watchlistService.getTickerCountByUserId(userId));
    }

    @GetMapping("/watchlist/{userId}")
    public ResponseEntity<List<Watchlist>> getWatchList(@PathVariable BigInteger userId) throws WatchlistNotFoundException, UserNotFoundException {
        log.info("Inside getWatchList method of WatchlistController ");
        return ResponseEntity.ok().body(watchlistService.getWatchList(userId));
    }

    @GetMapping("/watchlist/ticker/{tickerNumber}")
    public ResponseEntity<Object> getUserIdListFromTickerNumber(@PathVariable("tickerNumber") Integer tickerNumber) throws NoUserIdForTickerNumberException {
        log.info("Inside getUserIdsFromTickerNumber method of watchlist controller");
        List<BigInteger> userIds = watchlistService.getUserIdListFromTickerNumber(tickerNumber);
        return ResponseEntity.ok().body(userIds);
    }
    @PostMapping(value = "/watchlist/delete")
    public ResponseEntity<Watchlist> deleteWatchlist(@RequestBody WatchlistDto watchlistDto) throws UserNotFoundException, TickerNotFoundException, ParameterNotFoundException, WatchlistNotFoundException {
        log.info("Getting request for delete watchlist");
        return ResponseEntity.ok().body(watchlistService.deleteEntry(watchlistDto));
    }

}
