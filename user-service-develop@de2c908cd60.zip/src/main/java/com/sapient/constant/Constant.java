package com.sapient.constant;

public enum Constant {
    USER_NOT_FOUND("User does not exist"),
    TICKER_NOT_FOUND("Ticker does not exist"),

    INTERNAL_SERVER_ERROR("Internal Server Error Occurred"),
    PARAMETER_FOR_SEARCH_NOT_FOUND("Parameter for search not found"),
    WATCHLIST_NOT_FOUND("Empty Watchlist"),

    NO_USERID_FOR_TICKER_NUMBER_FOUND("No userId's found for given ticker"),
    EMPTY_PORTFOLIO("Portfolio is Empty"),
    NO_WINNING_TRADES("No Winning Trades"),
    NO_LOSING_TRADES("No Losing Trades"),
    GENERAL_EXCEPTION("Some error occurred"),
    TRADING_DETAIL_NOT_FOUND("Trading detail not found"),
    PORTFOLIO_DETAIL_NOT_FOUND("PORTFOLIO_DETAIL_NOT_FOUND"),
    DUPLICATE_WATCHLIST_ENTRY("Watchlist entry already exists");
    private final String message;

    Constant(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
