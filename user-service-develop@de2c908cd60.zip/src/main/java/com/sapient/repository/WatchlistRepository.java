package com.sapient.repository;

import com.sapient.model.UserTradingDetails;
import com.sapient.model.Watchlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;


public interface WatchlistRepository extends JpaRepository<Watchlist, BigInteger> {
    long countByUserTradingDetail(UserTradingDetails userTradingDetails);
    @Query("From Watchlist where userTradingDetail.userId=:userId")
    List<Watchlist> getWatchList(BigInteger userId);

    @Query("select w.userTradingDetail.userId from Watchlist w where w.ticker.tickerNumber=:tickerNumber")
    List<BigInteger> getUserIdsFromTickerNumber(Integer tickerNumber);

    @Query("Select w from Watchlist w where w.userTradingDetail.userId=:userId AND w.ticker.tickerNumber=:tickerNumber")
    Watchlist selectWatchlist(BigInteger userId, Integer tickerNumber);
}

