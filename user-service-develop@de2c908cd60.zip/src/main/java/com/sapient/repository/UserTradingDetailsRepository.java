package com.sapient.repository;

import com.sapient.model.UserTradingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;


public interface UserTradingDetailsRepository extends JpaRepository<UserTradingDetails, BigInteger> {

    @Query("select u.userId from UserTradingDetails u")
    List<BigInteger> findAllUserIds();
}

