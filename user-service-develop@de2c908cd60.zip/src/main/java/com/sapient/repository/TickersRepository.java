package com.sapient.repository;

import com.sapient.dto.WatchlistTickerDto;
import com.sapient.model.Tickers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;


public interface TickersRepository extends JpaRepository<Tickers, Integer> {

    Tickers findByTickerNumber(Integer tickerNumber);

    @Query(nativeQuery = true,value = "select * from tickers t where upper(t.ticker_name) like upper(concat('%',:searchTicker,'%')) or upper(t.ticker_id) like upper(concat('%',:searchTicker,'%')) limit 10")
    List<Tickers> searchTickers(@Param("searchTicker") String searchTicker);

    @Query(name="find_watchlist_ticker",nativeQuery = true)
    List<WatchlistTickerDto> getWatchlistStocks(@Param("tickerNumList") Set<Integer> distinctTickerNumbers);

}

