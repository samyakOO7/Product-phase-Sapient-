package com.sapient.repository;

import com.sapient.model.UserPortfolio;
import com.sapient.model.UserTradingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface UserPortfolioRepository extends JpaRepository<UserPortfolio, BigInteger> {

    List<UserPortfolio> findByUserTradingDetail(UserTradingDetails userTradingDetails);

    @Query("select u from UserPortfolio u where u.userTradingDetail.userId=:userId")
    List<UserPortfolio> findPortfolioByUserId(BigInteger userId);

    @Query("select u from UserPortfolio u where u.userTradingDetail.userId=:userId and u.ticker.tickerNumber=:tickerNumber")
    UserPortfolio findPortfolioByUserIdAndTickerNumber(BigInteger userId, Integer tickerNumber);
}
