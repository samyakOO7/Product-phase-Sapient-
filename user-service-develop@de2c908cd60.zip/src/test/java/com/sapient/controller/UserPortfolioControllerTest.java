package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.constant.Constant;
import com.sapient.dto.TradesDto;
import com.sapient.dto.UserPortfolioDetailsDto;
import com.sapient.dto.UserPortfolioDto;
import com.sapient.exception.PortfolioNotFoundException;
import com.sapient.model.Tickers;
import com.sapient.service.UserPortfolioService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = UserPortfolioController.class)
@WebMvcTest(UserPortfolioController.class)
class UserPortfolioControllerTest {


    ObjectMapper objectMapper = new ObjectMapper();
    ObjectWriter objectWriter = objectMapper.writer();
    @MockBean
    UserPortfolioService userPortfolioService;
    @Autowired
    private MockMvc mockMvc;

    @Test
    void getWinningOrLosingTrades() throws Exception {
        BigInteger userId = BigInteger.ONE;
        final List<TradesDto> tradesDtoList = new ArrayList<>() {
            {
                add(new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0)));
                add(new TradesDto(BigInteger.TWO, "TATA", "tata", BigDecimal.valueOf(-100.0), 10, 100.0, BigDecimal.valueOf(90.0)));
            }
        };

        Map<String, List<TradesDto>> expectedMap = new HashMap<>();
        expectedMap.put("openTrades", tradesDtoList);
        when(userPortfolioService.winningLosingOpenTrades(userId, "open")).thenReturn(expectedMap);
        String responseJson = objectWriter.writeValueAsString(expectedMap);
        mockMvc.perform(MockMvcRequestBuilders.get("/winning-losing-open-trades").contentType(MediaType.APPLICATION_JSON).param("userId", String.valueOf(userId)).param("type", "open").content(responseJson)).andExpect(status().isOk());


    }

    @Test
    @DisplayName("getPortfolioByPortfolioId should return valid User Portfolio if the portfolio exists with that id")
    void getPortfolioByPortfolioId_shouldReturn_validResponse() throws Exception {
        BigInteger portfolioId = BigInteger.valueOf(2);
        BigInteger userId = BigInteger.ONE;
        Integer tickerNumber = 1;
        Tickers tickers = new Tickers(1, "INFY", "INFY-90", "STOCK");
        UserPortfolioDto portfolioDto = new UserPortfolioDto(portfolioId, 2, 34.5, userId, tickers);
        given(userPortfolioService.getUserPortfolio(portfolioId)).willReturn(portfolioDto);
        mockMvc.perform(get("/user-portfolio/2").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userPortfolioId", is(2)))
                .andExpect(jsonPath("$.quantity", is(2)));
    }

    @Test
    @DisplayName("getPortfolioByPortfolioId should return Not found response if the portfolio does not exists with that user id")
    void getPortfolioByPortfolioId_shouldReturn_NotFoundResponse() throws Exception {

        given(userPortfolioService.getUserPortfolio(BigInteger.TWO)).willThrow(new PortfolioNotFoundException(Constant.PORTFOLIO_DETAIL_NOT_FOUND.toString()));
        mockMvc.perform(get("/user-portfolio/2").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errors[0].code", is(Constant.PORTFOLIO_DETAIL_NOT_FOUND.name())))
                .andExpect(jsonPath("$.errors[0].message", is(Constant.PORTFOLIO_DETAIL_NOT_FOUND.toString())));
    }

    @Test
    @DisplayName("getPortfolioByUserIdAndTickerNumber should return valid User Portfolio if the portfolio exists with that id")
    void getPortfolioByUserIdAndTickerNumber_shouldReturn_validResponse() throws Exception {
        BigInteger portfolioId = BigInteger.valueOf(2);
        BigInteger userId = BigInteger.ONE;
        Integer tickerNumber = 1;
        Tickers tickers = new Tickers(1, "INFY", "INFY-90", "STOCK");
        UserPortfolioDto portfolioDto = new UserPortfolioDto(portfolioId, 2, 34.5, userId, tickers);
        given(userPortfolioService.getUserPortfolioByUserIdAndTickerNumber(userId, tickerNumber)).willReturn(portfolioDto);
        mockMvc.perform(get("/user-portfolio/1/ticker/1").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userPortfolioId", is(2)))
                .andExpect(jsonPath("$.quantity", is(2)));// todo:check if checking these fields would do.
    }

    @Test
    @DisplayName("getPortfolioByUserIdAndTickerNumber should return Not found response if the portfolio does not exists with that user id and ticker number")
    void getPortfolioByUserIdAndTickerNumber_shouldReturn_NotFoundResponse() throws Exception {
        BigInteger portfolioId = BigInteger.valueOf(2);
        BigInteger userId = BigInteger.ONE;
        Integer tickerNumber = 1;
        given(userPortfolioService.getUserPortfolioByUserIdAndTickerNumber(userId, tickerNumber)).willThrow(new PortfolioNotFoundException(Constant.PORTFOLIO_DETAIL_NOT_FOUND.toString()));
        mockMvc.perform(get("/user-portfolio/1/ticker/1").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errors[0].code", is(Constant.PORTFOLIO_DETAIL_NOT_FOUND.name())))
                .andExpect(jsonPath("$.errors[0].message", is(Constant.PORTFOLIO_DETAIL_NOT_FOUND.toString())));
    }

    @Test
    void getUserPortfolio() throws Exception {
        BigInteger userId = BigInteger.ONE;
        UserPortfolioDetailsDto userPortfolioDetailsDto = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        List<UserPortfolioDetailsDto> portfolioDtoList = new ArrayList<>();
        portfolioDtoList.add(userPortfolioDetailsDto);
        Map<String, List<UserPortfolioDetailsDto>> expected = new HashMap<>();
        expected.put("userPortfolio", portfolioDtoList);
        when(userPortfolioService.getPortfolioByUserId(userId)).thenReturn(expected);
        String responseJson = objectWriter.writeValueAsString(expected);
        mockMvc.perform(MockMvcRequestBuilders.get("/user-portfolio").contentType(MediaType.APPLICATION_JSON)
                .param("userId", String.valueOf(userId))
                .content(responseJson)).andExpect(status().isOk());

    }
}