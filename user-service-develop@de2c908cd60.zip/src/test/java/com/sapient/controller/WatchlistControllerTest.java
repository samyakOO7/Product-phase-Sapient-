package com.sapient.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.dto.WatchListCountResponseDto;
import com.sapient.dto.WatchlistDto;
import com.sapient.model.Tickers;
import com.sapient.model.UserTradingDetails;
import com.sapient.model.Watchlist;
import com.sapient.service.WatchlistService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {WatchlistController.class})
@WebMvcTest(WatchlistController.class)
class WatchlistControllerTest {

    static WatchlistDto dummyWatchlistDto;
    static UserTradingDetails dummyUser;
    static Tickers dummyTicker;
    static Watchlist dummyWatchlist;
    @MockBean
    WatchlistService watchlistService;
    ObjectMapper objectMapper = new ObjectMapper();
    ObjectWriter objectWriter = objectMapper.writer();
    @Autowired
    private MockMvc mockMvc;

    @BeforeAll
    static void setUp() {
        dummyWatchlistDto = new WatchlistDto(BigInteger.valueOf(1), BigInteger.valueOf(2), 3);

        dummyUser = new UserTradingDetails(BigInteger.valueOf(2), 1000.0, 100.0, 10.0, BigInteger.valueOf(13), 40.0);

        dummyTicker = new Tickers(3, "tesla", "101", "stock");

        dummyWatchlist = new Watchlist(BigInteger.valueOf(1), dummyUser, dummyTicker);
    }

    @Test
    void dataEntryWatchlistTest() throws Exception {
        String responseJson = objectWriter.writeValueAsString(dummyWatchlistDto);
        System.out.println(responseJson);
        when(watchlistService.setEntry(dummyWatchlistDto)).thenReturn(dummyWatchlist);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/watchlist/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(responseJson))
                .andExpect(status().isOk());
    }

    @Test
    void countTickerCountByUserId() throws Exception {
        BigInteger userId = BigInteger.ONE;
        long count = 1;
        WatchListCountResponseDto watchListResponseDto = new WatchListCountResponseDto(userId, count);
        when(watchlistService.getTickerCountByUserId(userId)).thenReturn(watchListResponseDto);

        mockMvc.perform(get("/watchlist-count/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(watchListResponseDto.getUserId()))
                .andExpect(jsonPath("$.tickerCount").value(watchListResponseDto.getTickerCount()));

    }

    @Test
    void getWatchList() throws Exception {
        List<Watchlist> dummy = new ArrayList<>();
        dummy.add(dummyWatchlist);
        when(watchlistService.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId())).thenReturn(dummy);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/watchlist/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getUserIdListFromTickerNumber() throws Exception {
        Integer tickerNumber = 1;
        List<BigInteger> expectedUserIds = new ArrayList<>();
        expectedUserIds.add(BigInteger.ONE);
        expectedUserIds.add(BigInteger.TWO);
        when(watchlistService.getUserIdListFromTickerNumber(tickerNumber)).thenReturn(expectedUserIds);
        String responseJson = objectWriter.writeValueAsString(expectedUserIds);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/watchlist/ticker/{tickerNumber}", tickerNumber)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(responseJson))
                .andExpect(status().isOk());

    }

    @Test
    void dataEntryWatchlistDeleteTest() throws Exception {
        String responseJson = objectWriter.writeValueAsString(dummyWatchlistDto);
        System.out.println(responseJson);
        when(watchlistService.deleteEntry(dummyWatchlistDto)).thenReturn(dummyWatchlist);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/watchlist/delete")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(responseJson))
                .andExpect(status().isOk());
    }
}