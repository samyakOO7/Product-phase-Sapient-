package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.model.UserTradingDetails;
import com.sapient.service.UserTradingDetailsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {UserTradingDetailsController.class})
@WebMvcTest(UserTradingDetailsController.class)
class UserTradingDetailsControllerTest {

    static UserTradingDetailsDto dummyDto;
    static UserTradingDetails dummyUser;
    @MockBean
    UserTradingDetailsService userTradingDetailsService;
    ObjectMapper objectMapper = new ObjectMapper();
    ObjectWriter objectWriter = objectMapper.writer();
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {

        dummyDto = new UserTradingDetailsDto(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);
        dummyUser = new UserTradingDetails(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);
    }

    @Test
    void createUpdateProfile() throws Exception {
        String responseJson = objectWriter.writeValueAsString(dummyDto);
        when(userTradingDetailsService.createOrUpdate(dummyDto)).thenReturn(dummyUser);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/create-update-trading-profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(responseJson))
                .andExpect(status().isOk());
    }

    @Test
    void getTradingDetails() throws Exception {
        // String responseJson = objectWriter.writeValueAsString(dummyDto);
        BigInteger userId = BigInteger.ONE;
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(dummyUser);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/get-user-trading-details/{userId}", userId))
                .andExpect(status().isOk());
    }

    @Test
    void getAllUserIds() throws Exception {

        final List<BigInteger> userIds = new ArrayList<>() {
            {
                add(BigInteger.ONE);
                add(BigInteger.TEN);
                add(BigInteger.TWO);
            }
        };
        Map<String, List<BigInteger>> expected = new HashMap<>();
        expected.put("userIds", userIds);
        when(userTradingDetailsService.getAllUserIds()).thenReturn(expected);
        String responseJson = objectWriter.writeValueAsString(expected);
        mockMvc.perform(MockMvcRequestBuilders.get("/all-users").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

}