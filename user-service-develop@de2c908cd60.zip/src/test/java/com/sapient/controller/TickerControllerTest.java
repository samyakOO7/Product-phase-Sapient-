package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.dto.WatchlistTickerDto;
import com.sapient.exception.ParameterNotFoundException;
import com.sapient.model.Tickers;
import com.sapient.service.TickersService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {TickerController.class})
@WebMvcTest(TickerController.class)
class TickerControllerTest {

    ObjectMapper objectMapper = new ObjectMapper();
    ObjectWriter objectWriter = objectMapper.writer();
    ObjectReader objectReader = objectMapper.reader();
    @MockBean
    TickersService tickersService;
    @Autowired
    TickerController tickerController;
    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("searchTicker method should return Reponse entity OK with content list of tickers when searched string matches")
    void searchTickerGivenStringMatches() throws Exception {
        //arrange
        final List<Tickers> tickersList = new ArrayList<Tickers>() {
            {
                add(new Tickers(11, "tesla", "TSL", "stock"));
                add(new Tickers(12, "tata", "TATA", "stock"));
                add(new Tickers(12, "testing Expert", "TESTEXP", "stock"));
            }
        };
        String stringToSearch = "tes";
        List<Tickers> expectedTickersList = new ArrayList<>();
        expectedTickersList.add(tickersList.get(0));
        expectedTickersList.add(tickersList.get(2));

        when(tickersService.searchTickers(stringToSearch)).thenReturn(expectedTickersList);

        String uri = "/tickers/search/" + stringToSearch;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri)).andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();

        List<Tickers> actualList = Arrays.asList(objectReader.readValue(content, Tickers[].class));
        assertEquals(expectedTickersList, actualList);

    }

    @Test
    @DisplayName("method should throw parameter not found exception on empty string")
    void searchParameterNotFound() {
        assertThrows(ParameterNotFoundException.class, () -> tickerController.exceptionSearchTicker());
    }

    @Test
    @DisplayName("returns Response entity with Tickerids and HTTP status as OK")
    void getTickerInWatchlist() throws Exception {
        WatchlistTickerDto watchlistTickerDto = new WatchlistTickerDto(1, "INFY");
        WatchlistTickerDto watchlistTickerDto1 = new WatchlistTickerDto(2, "ICICI");
        WatchlistTickerDto watchlistTickerDto2 = new WatchlistTickerDto(3, "HDFC");
        final List<WatchlistTickerDto> tickers = new ArrayList<>() {
            {
                add(watchlistTickerDto);
                add(watchlistTickerDto1);
                add(watchlistTickerDto2);
            }
        };
        Map<String, List<WatchlistTickerDto>> map = new HashMap<>();
        map.put("tickers", tickers);
        when(tickersService.getWatchlistTicker()).thenReturn(map);
        String responseJson = objectWriter.writeValueAsString(map);
        mockMvc.perform(MockMvcRequestBuilders.get("/watchlist-tickers").contentType(MediaType.APPLICATION_JSON).content(responseJson)).andExpect(status().isOk());

    }

}