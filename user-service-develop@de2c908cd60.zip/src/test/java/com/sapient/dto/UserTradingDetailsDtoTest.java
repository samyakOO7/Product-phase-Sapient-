package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradingDetailsDtoTest {
    UserTradingDetailsDto tradingDetailsDto;
    @BeforeEach
    void setUp() {
        tradingDetailsDto=new UserTradingDetailsDto();
    }

    @Test
    void getUserId() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(tradingDetailsDto,"userId",integer);
        assertEquals(integer,tradingDetailsDto.getUserId());
    }

    @Test
    void getTotalAmount() {
        Double  amount=1002.2;
        ReflectionTestUtils.setField(tradingDetailsDto,"totalAmount",amount);
        assertEquals(amount,tradingDetailsDto.getTotalAmount());

    }

    @Test
    void getAmountPerTrade() {
        Double  amount=1002.2;
        ReflectionTestUtils.setField(tradingDetailsDto,"amountPerTrade",amount);
        assertEquals(amount,tradingDetailsDto.getAmountPerTrade());
    }

    @Test
    void getRiskPerTrade() {
        Double  amount=1002.2;
        ReflectionTestUtils.setField(tradingDetailsDto,"riskPerTrade",amount);
        assertEquals(amount,tradingDetailsDto.getRiskPerTrade());
    }

    @Test
    void getTotalAlertsGenerated() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(tradingDetailsDto,"totalAlertsGenerated",integer);
        assertEquals(integer,tradingDetailsDto.getTotalAlertsGenerated());
    }

    @Test
    void getTotalEquity() {
        Double  amount=1002.2;
        ReflectionTestUtils.setField(tradingDetailsDto,"totalEquity",amount);
        assertEquals(amount,tradingDetailsDto.getTotalEquity());
    }

    @Test
    void setUserId() {
        BigInteger integer = BigInteger.ONE;
        tradingDetailsDto.setUserId(BigInteger.ONE);
        assertEquals(integer,tradingDetailsDto.getUserId());
    }

    @Test
    void setTotalAmount() {
        Double amount=100.1;
        tradingDetailsDto.setTotalAmount(amount);
        assertEquals(amount,tradingDetailsDto.getTotalAmount());
    }

    @Test
    void setAmountPerTrade() {
        Double amount=100.1;
        tradingDetailsDto.setAmountPerTrade(amount);
        assertEquals(amount,tradingDetailsDto.getAmountPerTrade());
    }
    @Test
    void setRiskPerTrade(){
        Double amount=100.1;
        tradingDetailsDto.setAmountPerTrade(amount);
        assertEquals(amount,tradingDetailsDto.getAmountPerTrade());
    }

    @Test
    void setTotalAlertsGenerated() {
        BigInteger integer = BigInteger.ONE;
        tradingDetailsDto.setTotalAlertsGenerated(BigInteger.ONE);
        assertEquals(integer,tradingDetailsDto.getTotalAlertsGenerated());
    }

    @Test
    void setTotalEquity() {
        Double amount=100.1;
        tradingDetailsDto.setTotalEquity(amount);
        assertEquals(amount,tradingDetailsDto.getTotalEquity());
    }

}