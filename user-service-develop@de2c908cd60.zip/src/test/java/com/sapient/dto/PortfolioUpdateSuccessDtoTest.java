package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PortfolioUpdateSuccessDtoTest {

    PortfolioUpdateSuccessDto portfolioUpdateSuccessDto;

    @BeforeEach
    void setUp(){portfolioUpdateSuccessDto=new PortfolioUpdateSuccessDto();}


    @Test
    void getMessage() {
        String message="message";
        portfolioUpdateSuccessDto.setMessage(message);
        assertEquals(message,portfolioUpdateSuccessDto.getMessage());
    }

    @Test
    void testToString() {
        PortfolioUpdateSuccessDto portfolioUpdateSuccessDto1=new PortfolioUpdateSuccessDto("message");
        String expected = "PortfolioUpdateSuccessDto{" +
                "message='" + portfolioUpdateSuccessDto1.getMessage() + '\'' +
                '}';
        Assertions.assertEquals(expected, portfolioUpdateSuccessDto1.toString());
    }
}
