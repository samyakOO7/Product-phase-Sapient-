package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserPortfolioUpdateDtoTest {

    UserPortfolioUpdateDto userPortfolioUpdateDto;

    @BeforeEach
    void setUp() {
        userPortfolioUpdateDto = new UserPortfolioUpdateDto();
    }

    @Test
    void getUserId() {
        BigInteger id = BigInteger.valueOf(1);
        userPortfolioUpdateDto.setUserId(id);
        assertEquals(id,userPortfolioUpdateDto.getUserId());
    }

    @Test
    void getType() {
        String type="buy";
        userPortfolioUpdateDto.setType(type);
        assertEquals(type,userPortfolioUpdateDto.getType());
    }

    @Test
    void getProfitTarget() {
        Double target=100.0;
        userPortfolioUpdateDto.setProfitTarget(target);
        assertEquals(target,userPortfolioUpdateDto.getProfitTarget());
    }

    @Test
    void getStopLoss() {
        double loss=100.0;
        userPortfolioUpdateDto.setStopLoss(loss);
        assertEquals(loss,userPortfolioUpdateDto.getStopLoss());
    }

    @Test
    void getTickerNumber() {
        Integer tickerNumber = 1;
        userPortfolioUpdateDto.setTickerNumber(tickerNumber);
        assertEquals(tickerNumber,userPortfolioUpdateDto.getTickerNumber());
    }

    @Test
    void getQuantity() {
        Integer quantity=1;
        userPortfolioUpdateDto.setQuantity(quantity);
        assertEquals(quantity,userPortfolioUpdateDto.getQuantity());
    }

    @Test
    void getPrice() {
        Double Price=5.0;
        userPortfolioUpdateDto.setPrice(Price);
        assertEquals(Price,userPortfolioUpdateDto.getPrice());
    }

    @Test
    void testToString() {
        UserPortfolioUpdateDto userPortfolioUpdateDto1=new UserPortfolioUpdateDto("buy",BigInteger.valueOf(1),1,1,100.0,100.0,100.0);
        String expected = "UserPortfolioUpdateDto{" +
                "type='" + userPortfolioUpdateDto1.getType() + '\'' +
                ", userId=" + userPortfolioUpdateDto1.getUserId() +
                ", tickerNumber=" + userPortfolioUpdateDto1.getTickerNumber() +
                ", quantity=" + userPortfolioUpdateDto1.getQuantity() +
                ", buyPrice=" + userPortfolioUpdateDto1.getPrice() +
                ", stopLoss=" + userPortfolioUpdateDto1.getStopLoss() +
                ", profitTarget=" + userPortfolioUpdateDto1.getProfitTarget() +
                '}';
        Assertions.assertEquals(expected, userPortfolioUpdateDto1.toString());
    }

}
