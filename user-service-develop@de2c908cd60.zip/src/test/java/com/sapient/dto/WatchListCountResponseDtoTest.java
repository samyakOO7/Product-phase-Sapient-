package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WatchListCountResponseDtoTest {

    WatchListCountResponseDto watchListCountResponseDto;

    @BeforeEach
    void setup()
    {
        watchListCountResponseDto = new WatchListCountResponseDto();
    }

    @Test
    void testEquals() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        WatchListCountResponseDto watchListCountResponseDto2 = new WatchListCountResponseDto(BigInteger.ONE,2);
        Boolean expected = true;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsUserId() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        WatchListCountResponseDto watchListCountResponseDto2 = new WatchListCountResponseDto(BigInteger.TEN,2);
        Boolean expected = false;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsTickerCount() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        WatchListCountResponseDto watchListCountResponseDto2 = new WatchListCountResponseDto(BigInteger.ONE,3);
        Boolean expected = false;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsNull() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,5);
        WatchListCountResponseDto watchListCountResponseDto2 = null;
        Boolean expected = false;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testEqualsObject() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        Object watchListCountResponseDto2 = new WatchListCountResponseDto(BigInteger.ONE,2);
        Boolean expected = true;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testEqualsForSameObject() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        WatchListCountResponseDto watchListCountResponseDto2 = watchListCountResponseDto1;
        Boolean expected = true;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsObject() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,2);
        Integer watchListCountResponseDto2 = 3;
        Boolean expected = false;
        Boolean actual = watchListCountResponseDto1.equals(watchListCountResponseDto2);
        assertEquals(expected,actual);

    }

    @Test
    void testHashCode() {
        WatchListCountResponseDto watchListCountResponseDto1 = new WatchListCountResponseDto(BigInteger.ONE,3);
        WatchListCountResponseDto watchListCountResponseDto2 = new WatchListCountResponseDto(BigInteger.ONE,3);
        assertEquals(watchListCountResponseDto1.hashCode(),watchListCountResponseDto2.hashCode());
    }

    @Test
    void testToString() {
        WatchListCountResponseDto watchListCountResponseDto = new WatchListCountResponseDto(BigInteger.ONE,2);
        String expected = "WatchListCountResponseDto{" +
                "userId=" + watchListCountResponseDto.getUserId() +
                ", tickerCount=" + watchListCountResponseDto.getTickerCount() +
                '}';
        assertEquals(expected,watchListCountResponseDto.toString());
    }

    @Test
    void getUserId() {
        BigInteger userId = BigInteger.ONE;
        ReflectionTestUtils.setField(watchListCountResponseDto,"userId",userId);
        assertEquals(userId,watchListCountResponseDto.getUserId());
    }

    @Test
    void getTickerCount() {
        long tickerCount = 2;
        ReflectionTestUtils.setField(watchListCountResponseDto,"tickerCount",tickerCount);
        assertEquals(tickerCount,watchListCountResponseDto.getTickerCount());
    }

    @Test
    void setUserId() {
        BigInteger userId = BigInteger.ONE;
        watchListCountResponseDto.setUserId(userId);
        assertEquals(userId,watchListCountResponseDto.getUserId());
    }

    @Test
    void setTickerCount() {
        long tickerCount = 2;
        watchListCountResponseDto.setTickerCount(2);
        assertEquals(tickerCount,watchListCountResponseDto.getTickerCount());
    }
}