package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WatchlistDtoTest {

    WatchlistDto watchlistDto;

    @BeforeEach
    void setUp() {
        watchlistDto = new WatchlistDto();
    }
    @Test
    void getUserId() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(watchlistDto,"userId",integer);
        assertEquals(integer,watchlistDto.getUserId());
    }

    @Test
    void getTickerNumber() {
        Integer integer = 1;
        ReflectionTestUtils.setField(watchlistDto,"tickerNumber",integer);
        assertEquals(integer,watchlistDto.getTickerNumber());
    }
}