package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TradesDtoTest {

    TradesDto tradesDto;

    @BeforeEach
    void setup() {
        tradesDto = new TradesDto();
    }

    @Test
    void getUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        ReflectionTestUtils.setField(tradesDto, "userPortfolioId", userPortfolioId);
        assertEquals(userPortfolioId, tradesDto.getUserPortfolioId());
    }

    @Test
    void getTickerId() {
        String tickerId = "HDFC";
        ReflectionTestUtils.setField(tradesDto, "tickerId", tickerId);
        assertEquals(tickerId, tradesDto.getTickerId());
    }

    @Test
    void getTickerName() {
        String tickerName = "HDFC Bank";
        ReflectionTestUtils.setField(tradesDto, "tickerName", tickerName);
        assertEquals(tickerName, tradesDto.getTickerName());
    }

    @Test
    void getCurrentProfitOrLoss() {
        BigDecimal currentProfitOrLoss = BigDecimal.valueOf(200.0);
        ReflectionTestUtils.setField(tradesDto, "currentProfitOrLoss", currentProfitOrLoss);
        assertEquals(currentProfitOrLoss, tradesDto.getCurrentProfitOrLoss());
    }

    @Test
    void getQuantity() {
        Integer quantity = 10;
        ReflectionTestUtils.setField(tradesDto, "quantity", quantity);
        assertEquals(quantity, tradesDto.getQuantity());
    }

    @Test
    void getAveragePrice() {
        Double averagePrice = 100.0;
        ReflectionTestUtils.setField(tradesDto, "averagePrice", averagePrice);
        assertEquals(averagePrice, tradesDto.getAveragePrice());
    }

    @Test
    void getCurrentPrice() {
        BigDecimal currentPrice = BigDecimal.valueOf(120.0);
        ReflectionTestUtils.setField(tradesDto, "currentPrice", currentPrice);
        assertEquals(currentPrice, tradesDto.getCurrentPrice());
    }

    @Test
    void setTickerId() {
        String tickerId = "HDFC";
        tradesDto.setTickerId(tickerId);
        assertEquals(tickerId, tradesDto.getTickerId());
    }

    @Test
    void setTickerName() {
        String tickerName = "HDFC Bank";
        tradesDto.setTickerName(tickerName);
        assertEquals(tickerName, tradesDto.getTickerName());
    }

    @Test
    void setCurrentProfitOrLoss() {
        BigDecimal currentProfitOrLoss = BigDecimal.valueOf(200.0);
        tradesDto.setCurrentProfitOrLoss(currentProfitOrLoss);
        assertEquals(currentProfitOrLoss, tradesDto.getCurrentProfitOrLoss());
    }

    @Test
    void setQuantity() {
        Integer quantity = 10;
        tradesDto.setQuantity(quantity);
        assertEquals(quantity, tradesDto.getQuantity());
    }

    @Test
    void setAveragePrice() {
        Double averagePrice = 100.0;
        tradesDto.setAveragePrice(averagePrice);
        assertEquals(averagePrice, tradesDto.getAveragePrice());
    }

    @Test
    void setCurrentPrice() {
        BigDecimal currentPrice = BigDecimal.valueOf(120.0);
        tradesDto.setCurrentPrice(currentPrice);
        assertEquals(currentPrice, tradesDto.getCurrentPrice());
    }

    @Test
    void setUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        tradesDto.setUserPortfolioId(userPortfolioId);
        assertEquals(userPortfolioId, tradesDto.getUserPortfolioId());
    }

    @Test
    void testEquals() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = true;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsObj() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Integer tradesDto2 = 2;
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }
    @Test
    void testEqualsForSameObj() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = tradesDto1;
        Boolean expected = true;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }
    @Test
    void testEqualsObject() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Object tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = true;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForNull() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = null;
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }
    @Test
    void testNotEqualsPorfolioId() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.TWO, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }
    @Test
    void testNotEqualsTickerId() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSM", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTickerName() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "Tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsCurrentProfitOrLoss() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(101.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsQuantity() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 11, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsAveragePrice() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 101.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsCurrentPrice() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(111.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        Boolean expected = false;
        Boolean actual = tradesDto1.equals(tradesDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testHashCode() {
        TradesDto tradesDto1 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        TradesDto tradesDto2 = new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0));
        assertEquals(tradesDto1.hashCode(), tradesDto2.hashCode());
    }

}