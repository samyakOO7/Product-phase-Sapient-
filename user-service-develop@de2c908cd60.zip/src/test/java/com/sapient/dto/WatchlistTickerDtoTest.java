package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WatchlistTickerDtoTest {

    WatchlistTickerDto watchlistTickerDto;

    @BeforeEach
    void setup() {
        watchlistTickerDto = new WatchlistTickerDto();
    }

    @Test
    void getTickerNumber() {
        Integer tickerNumber = 1;
        ReflectionTestUtils.setField(watchlistTickerDto, "tickerNumber", tickerNumber);
        assertEquals(tickerNumber, watchlistTickerDto.getTickerNumber());
    }

    @Test
    void getTickerId() {
        String tickerId = "HDFC";
        ReflectionTestUtils.setField(watchlistTickerDto, "tickerId", tickerId);
        assertEquals(tickerId, watchlistTickerDto.getTickerId());
    }

    @Test
    void setTickerNumber() {
        Integer tickerNumber = 1;
        watchlistTickerDto.setTickerNumber(tickerNumber);
        assertEquals(tickerNumber, watchlistTickerDto.getTickerNumber());
    }

    @Test
    void setTickerId() {
        String tickerId = "HDFC";
        watchlistTickerDto.setTickerId(tickerId);
        assertEquals(tickerId, watchlistTickerDto.getTickerId());
    }
}
