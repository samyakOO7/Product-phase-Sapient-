package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserPortfolioDetailsDtoTest {

    UserPortfolioDetailsDto userPortfolioDetailsDto;

    @BeforeEach
    void setup() {
        userPortfolioDetailsDto = new UserPortfolioDetailsDto();
    }

    @Test
    void getUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        ReflectionTestUtils.setField(userPortfolioDetailsDto, "userPortfolioId", userPortfolioId);
        assertEquals(userPortfolioId, userPortfolioDetailsDto.getUserPortfolioId());
    }

    @Test
    void getTickerId() {
        String tickerId = "HDFC";
        ReflectionTestUtils.setField(userPortfolioDetailsDto, "tickerId", tickerId);
        assertEquals(tickerId, userPortfolioDetailsDto.getTickerId());
    }

    @Test
    void getProfitTarget() {
        Double profitTarget = 10.0;
        ReflectionTestUtils.setField(userPortfolioDetailsDto, "profitTarget", profitTarget);
        assertEquals(profitTarget, userPortfolioDetailsDto.getProfitTarget());
    }

    @Test
    void getStopLoss() {
        Double stopLoss = 10.0;
        ReflectionTestUtils.setField(userPortfolioDetailsDto, "stopLoss", stopLoss);
        assertEquals(stopLoss, userPortfolioDetailsDto.getStopLoss());
    }

    @Test
    void getAveragePrice() {
        Double averagePrice = 10.0;
        ReflectionTestUtils.setField(userPortfolioDetailsDto, "averagePrice", averagePrice);
        assertEquals(averagePrice, userPortfolioDetailsDto.getAveragePrice());
    }

    @Test
    void setUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        userPortfolioDetailsDto.setUserPortfolioId(userPortfolioId);
        assertEquals(userPortfolioId, userPortfolioDetailsDto.getUserPortfolioId());
    }

    @Test
    void setTickerId() {
        String tickerId = "HDFC";
        userPortfolioDetailsDto.setTickerId(tickerId);
        assertEquals(tickerId, userPortfolioDetailsDto.getTickerId());
    }

    @Test
    void setProfitTarget() {
        Double profitTarget = 10.0;
        userPortfolioDetailsDto.setProfitTarget(profitTarget);
        assertEquals(profitTarget, userPortfolioDetailsDto.getProfitTarget());
    }

    @Test
    void setStopLoss() {
        Double stopLoss = 10.0;
        userPortfolioDetailsDto.setStopLoss(stopLoss);
        assertEquals(stopLoss, userPortfolioDetailsDto.getStopLoss());
    }

    @Test
    void setAveragePrice() {
        Double averagePrice = 10.0;
        userPortfolioDetailsDto.setAveragePrice(averagePrice);
        assertEquals(averagePrice, userPortfolioDetailsDto.getAveragePrice());
    }

    @Test
    void testEquals() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = true;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsObj() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Integer userPortfolioDto2 = 2;
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForSameObj() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = userPortfolioDetailsDto1;
        Boolean expected = true;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsObject() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Object userPortfolioDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = true;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForNull() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = null;
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsPorfolioId() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.TWO, "abc", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTickerId() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abcd", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsProfitTarget() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.56, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsStopLoss() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.31, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsAveragePrice() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 101.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDetailsDto1.equals(userPortfolioDetailsDto2);
        assertEquals(expected, actual);
    }


    @Test
    void testHashCode() {
        UserPortfolioDetailsDto userPortfolioDetailsDto1 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDetailsDto userPortfolioDetailsDto2 = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        assertEquals(userPortfolioDetailsDto1.hashCode(), userPortfolioDetailsDto2.hashCode());
    }
}