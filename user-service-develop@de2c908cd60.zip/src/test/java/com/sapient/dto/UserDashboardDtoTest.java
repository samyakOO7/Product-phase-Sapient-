package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserDashboardDtoTest {
    UserDashboardDto userDashboardDto;

    @BeforeEach
    void setUp() {
        userDashboardDto = new UserDashboardDto();
    }

    @Test
    void getGain() {
        double number = 1;
        userDashboardDto.setGain(number);
        assertEquals(number,userDashboardDto.getGain());
    }

    void getLosing() {
        Integer number = 1;
        userDashboardDto.setLoosing(number);
        assertEquals(number,userDashboardDto.getLoosing());
    }
    void getWinning() {
        Integer number = 1;
        userDashboardDto.setWinning(number);
        assertEquals(number,userDashboardDto.getWinning());
    }

    void getTotalEquity() {
        double number = 1;
        userDashboardDto.setTotalEquity(number);
        assertEquals(number,userDashboardDto.getTotalEquity());
    }

    @Test
    void testToString() {
        UserDashboardDto userDashboardDto1=new UserDashboardDto(1.0,100.0,1,1);
        String expected = "UserDashboardDto{" +
                "gain=" + userDashboardDto1.getGain() +
                ", totalEquity=" + userDashboardDto1.getTotalEquity() +
                ", winning=" + userDashboardDto1.getWinning() +
                ", loosing=" + userDashboardDto1.getLoosing() +
                '}';
        Assertions.assertEquals(expected, userDashboardDto1.toString());
    }





}
