package com.sapient.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserPortfolioTest {

    UserPortfolio userPortfolio;

    @BeforeEach
    void setUp() {
        userPortfolio = new UserPortfolio();
    }

    @Test
    void getUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        ReflectionTestUtils.setField(userPortfolio, "userPortfolioId", userPortfolioId);
        assertEquals(userPortfolioId, userPortfolio.getUserPortfolioId());
    }

    @Test
    void getUserTradingDetail() {
        UserTradingDetails userTradingDetails = new UserTradingDetails();
        ReflectionTestUtils.setField(userPortfolio, "userTradingDetail", userTradingDetails);
        assertEquals(userTradingDetails, userPortfolio.getUserTradingDetail());
    }

    @Test
    void getTicker() {
        Tickers tickers = new Tickers();
        ReflectionTestUtils.setField(userPortfolio, "ticker", tickers);
        assertEquals(tickers, userPortfolio.getTicker());
    }

    @Test
    void getQuantity() {
        Integer quantity = 10;
        ReflectionTestUtils.setField(userPortfolio, "quantity", quantity);
        assertEquals(quantity, userPortfolio.getQuantity());
    }

    @Test
    void getAveragePrice() {
        Double averagePrice = 10.0;
        ReflectionTestUtils.setField(userPortfolio, "averagePrice", averagePrice);
        assertEquals(averagePrice, userPortfolio.getAveragePrice());
    }

    @Test
    void getProfitTarget() {
        Double profitTarget = 10.0;
        ReflectionTestUtils.setField(userPortfolio, "profitTarget", profitTarget);
        assertEquals(profitTarget, userPortfolio.getProfitTarget());
    }

    @Test
    void getStopLoss() {
        Double stopLoss = 10.0;
        ReflectionTestUtils.setField(userPortfolio, "stopLoss", stopLoss);
        assertEquals(stopLoss, userPortfolio.getStopLoss());
    }

    @Test
    void setUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        userPortfolio.setUserPortfolioId(userPortfolioId);
        assertEquals(userPortfolioId, userPortfolio.getUserPortfolioId());
    }

    @Test
    void setUserTradingDetail() {
        UserTradingDetails userTradingDetails = new UserTradingDetails();
        userPortfolio.setUserTradingDetail(userTradingDetails);
        assertEquals(userTradingDetails, userPortfolio.getUserTradingDetail());
    }

    @Test
    void setTicker() {
        Tickers tickers = new Tickers();
        userPortfolio.setTicker(tickers);
        assertEquals(tickers, userPortfolio.getTicker());
    }

    @Test
    void setQuantity() {
        Integer quantity = 10;
        userPortfolio.setQuantity(quantity);
        assertEquals(quantity, userPortfolio.getQuantity());
    }

    @Test
    void setAveragePrice() {
        Double averagePrice = 10.0;
        userPortfolio.setAveragePrice(averagePrice);
        assertEquals(averagePrice, userPortfolio.getAveragePrice());
    }

    @Test
    void setProfitTarget() {
        Double profitTarget = 10.0;
        userPortfolio.setProfitTarget(profitTarget);
        assertEquals(profitTarget, userPortfolio.getProfitTarget());
    }

    @Test
    void setStopLoss() {
        Double stopLoss = 10.0;
        userPortfolio.setStopLoss(stopLoss);
        assertEquals(stopLoss, userPortfolio.getStopLoss());
    }

    @Test
    void testToString(){
        Tickers tickers=new Tickers();
        UserTradingDetails userTradingDetails=new UserTradingDetails();
        UserPortfolio userPortfolio1=new UserPortfolio(BigInteger.ONE,userTradingDetails,tickers,100,100.0,111.0,96.0);
        String excepted = "UserPortfolio{" +
                "userPortfolioId=" + userPortfolio1.getUserPortfolioId() +
                ", userTradingDetail=" + userPortfolio1.getUserTradingDetail() +
                ", ticker=" + userPortfolio1.getTicker() +
                ", quantity=" + userPortfolio1.getQuantity() +
                ", averagePrice=" + userPortfolio1.getAveragePrice() +
                ", profitTarget=" + userPortfolio1.getProfitTarget() +
                ", stopLoss=" + userPortfolio1.getStopLoss() +
                '}';
        assertEquals(excepted,userPortfolio1.toString());
    }
}