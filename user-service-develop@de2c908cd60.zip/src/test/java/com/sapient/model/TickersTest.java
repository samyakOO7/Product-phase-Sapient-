package com.sapient.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TickersTest {

    Tickers ticker;

    @BeforeEach
    void setup()
    {
        ticker = new Tickers();
    }

    @Test
    void getTickerNumber() {
        int tickerNumber = 1;
        ReflectionTestUtils.setField(ticker,"tickerNumber",tickerNumber );
        assertEquals(tickerNumber,ticker.getTickerNumber());

    }

    @Test
    void getTickerName() {
        String tickerName = "tesla";
        ReflectionTestUtils.setField(ticker,"tickerName",tickerName);
        assertEquals(tickerName,ticker.getTickerName());
    }

    @Test
    void getTickerId() {
        String tickerId = "TES";
        ReflectionTestUtils.setField(ticker,"tickerId",tickerId);
        assertEquals(tickerId,ticker.getTickerId());
    }

    @Test
    void getTickerType() {
        String tickerType = "stock";
        ReflectionTestUtils.setField(ticker,"tickerType",tickerType);
        assertEquals(tickerType,ticker.getTickerType());
    }

    @Test
    void setTickerNumber() {
        int tickerNumber = 101;
        ticker.setTickerNumber(tickerNumber);
        assertEquals(tickerNumber,ticker.getTickerNumber());
    }

    @Test
    void setTickerName() {
        String tickerName = "tesla";
        ticker.setTickerName(tickerName);
        assertEquals(tickerName,ticker.getTickerName());
    }

    @Test
    void setTickerId() {
        String tickerId = "TES";
        ticker.setTickerId(tickerId);
        assertEquals(tickerId,ticker.getTickerId());
    }

    @Test
    void setTickerType() {
        String tickerType = "stock";
        ticker.setTickerType(tickerType);
        assertEquals(tickerType,ticker.getTickerType());
    }

    @Test
    void testEquals() {
        Tickers ticker1 = new Tickers(1,"tesla","TES","stock");
        Tickers ticker2 = new Tickers(1,"tesla","TES","stock");
        Boolean expected = true;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsTickerNumber() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Tickers ticker2 = new Tickers(1,"tesla","TES","stock");
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsTickerName() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Tickers ticker2 = new Tickers(2,"tesla","TES","stock");
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsTickerId() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Tickers ticker2 = new Tickers(2,"tata","TES","stock");
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsTickerType() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Tickers ticker2 = new Tickers(2,"tata","TATA","forex");
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsNull() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Tickers ticker2 = null;
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testNotEqualsObject() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Integer ticker2 = 1;
        Boolean expected = false;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }

    @Test
    void testEqualsObject() {
        Tickers ticker1 = new Tickers(2,"tata","TATA","stock");
        Object ticker2 = new Tickers(2,"tata","TATA","stock");

        Boolean expected = true;
        Boolean actual = ticker1.equals(ticker2);
        assertEquals(expected,actual);
    }



    @Test
    void testToString(){
        Tickers ticker = new Tickers(1,"tesla","TES","stock");
        String expected = "Tickers{" +
                "tickerNumber=" + ticker.getTickerNumber()+
                ", tickerName='" + ticker.getTickerName()+"'"+
                ", tickerId='" + ticker.getTickerId()+"'"+
                ", tickerType='" + ticker.getTickerType()+"'"+
                "}";
        assertEquals(expected,ticker.toString());

    }

    @Test
    void testHashCode() {
        Tickers ticker1 = new Tickers(2,"tesla","TES","stock");
        Tickers ticker2 = new Tickers(2,"tesla","TES","stock");
        assertEquals(ticker1.hashCode(),ticker2.hashCode());
    }
}