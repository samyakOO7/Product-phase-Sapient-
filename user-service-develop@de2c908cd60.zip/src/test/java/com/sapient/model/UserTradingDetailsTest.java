package com.sapient.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;



class UserTradingDetailsTest {

    UserTradingDetails userTradingDetails;

    @BeforeEach
    void setUp() {
        userTradingDetails = new UserTradingDetails();
    }

    @Test
    void getUserId() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(userTradingDetails,"userId",integer);
        assertEquals(integer,userTradingDetails.getUserId());

    }

    @Test
    void getTotalAmount() {
        Double amount = 1000.00;
        ReflectionTestUtils.setField(userTradingDetails,"totalAmount",amount);
        assertEquals(amount,userTradingDetails.getTotalAmount());
    }

    @Test
    void getAmountPerTrade() {
        Double amount = 100.00;
        ReflectionTestUtils.setField(userTradingDetails,"amountPerTrade",amount);
        assertEquals(amount,userTradingDetails.getAmountPerTrade());

    }

    @Test
    void getRiskPerTrade() {
        Double risk = 10.50;
        ReflectionTestUtils.setField(userTradingDetails,"riskPerTrade",risk);
        assertEquals(risk,userTradingDetails.getRiskPerTrade());
    }

    @Test
    void getTotalAlertsGenerated() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(userTradingDetails,"totalAlertsGenerated",integer);
        assertEquals(integer,userTradingDetails.getTotalAlertsGenerated());
    }

    @Test
    void setUserId() {
        BigInteger integer = BigInteger.ONE;
        userTradingDetails.setUserId(BigInteger.ONE);
        assertEquals(integer,userTradingDetails.getUserId());
    }

    @Test
    void setTotalAmount() {
        Double amount=10.1;
        userTradingDetails.setTotalAmount(amount);
        assertEquals(amount,userTradingDetails.getTotalAmount());
    }

    @Test
    void setAmountPerTrade() {
        Double amount=10.1;
        userTradingDetails.setAmountPerTrade(amount);
        assertEquals(amount,userTradingDetails.getAmountPerTrade());
    }
    @Test
    void setRiskPerTrade(){
        Double amount=10.1;
        userTradingDetails.setAmountPerTrade(amount);
        assertEquals(amount,userTradingDetails.getAmountPerTrade());
    }

    @Test
    void setTotalAlertsGenerated() {
        BigInteger integer = BigInteger.ONE;
        userTradingDetails.setTotalAlertsGenerated(BigInteger.ONE);
        assertEquals(integer,userTradingDetails.getTotalAlertsGenerated());
    }

    @Test
    void setTotalEquity() {
        Double amount=100.1;
        userTradingDetails.setTotalEquity(amount);
        assertEquals(amount,userTradingDetails.getTotalEquity());
    }
}