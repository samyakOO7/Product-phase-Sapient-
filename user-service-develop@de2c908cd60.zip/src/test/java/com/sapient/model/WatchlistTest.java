package com.sapient.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WatchlistTest {

    Watchlist watchlist;

    @BeforeEach
    void setUp() {
        watchlist = new Watchlist();
    }

    @Test
    void getWatchlistId() {
        BigInteger integer = BigInteger.ONE;
        ReflectionTestUtils.setField(watchlist,"watchlistId",integer);
        assertEquals(integer,watchlist.getWatchlistId());
    }

    @Test
    void setWatchlistId() {
        BigInteger integer = BigInteger.ONE;
        watchlist.setWatchlistId(BigInteger.ONE);
        assertEquals(integer,watchlist.getWatchlistId());
    }

    @Test
    void getUserTradingDetail() {
        UserTradingDetails userTradingDetails = new UserTradingDetails();
        ReflectionTestUtils.setField(watchlist,"userTradingDetail",userTradingDetails);
        assertEquals(userTradingDetails,watchlist.getUserTradingDetail());
    }

    @Test
    void setUserTradingDetail() {
        UserTradingDetails userTradingDetails = new UserTradingDetails();
        watchlist.setUserTradingDetail(userTradingDetails);
        assertEquals(userTradingDetails,watchlist.getUserTradingDetail());
    }

    @Test
    void getTicker() {
        Tickers tickers = new Tickers();
        ReflectionTestUtils.setField(watchlist,"ticker",tickers);
        assertEquals(tickers,watchlist.getTicker());
    }

    @Test
    void setTicker() {
        Tickers tickers = new Tickers();
        watchlist.setTicker(tickers);
        assertEquals(tickers,watchlist.getTicker());
    }
}