package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = UserAdvice.class)
class UserAdviceTest {

    @Autowired
    UserAdvice userAdvice;

    @Test
    void userNotFound() {
        String msg = Constant.USER_NOT_FOUND.toString();
        UserNotFoundException ex = new UserNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.USER_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.userNotFound(ex));
    }

    @Test
    void tickerNotFound() {
        String msg = Constant.TICKER_NOT_FOUND.toString();
        TickerNotFoundException ex = new TickerNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.TICKER_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.tickerNotFound(ex));
    }

    @Test
    void noUserIdForTickerNo() {
        String msg = Constant.NO_USERID_FOR_TICKER_NUMBER_FOUND.toString();
        NoUserIdForTickerNumberException ex = new NoUserIdForTickerNumberException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.NO_USERID_FOR_TICKER_NUMBER_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.error(ex));
    }

    @Test
    void parameterNotFound() {
        String msg = Constant.PARAMETER_FOR_SEARCH_NOT_FOUND.toString();
        ParameterNotFoundException ex = new ParameterNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.PARAMETER_FOR_SEARCH_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.parameterNotFound(ex));
    }

    @Test
    void watchlistNotFound() {
        String msg = Constant.WATCHLIST_NOT_FOUND.toString();
        WatchlistNotFoundException ex = new WatchlistNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.WATCHLIST_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.watchlistNotFound(ex));
    }

    @Test
    void emptyPortfolio() {
        String msg = Constant.EMPTY_PORTFOLIO.toString();
        EmptyUserPortfolioException ex = new EmptyUserPortfolioException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.EMPTY_PORTFOLIO.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.emptyPortfolio(ex));
    }

    @Test
    void noWinningTrades() {
        String msg = Constant.NO_WINNING_TRADES.toString();
        NoWinningTradesException ex = new NoWinningTradesException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.NO_WINNING_TRADES.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.noWinningTrades(ex));
    }
    @Test
    void noLosingTrades() {
        String msg = Constant.NO_LOSING_TRADES.toString();
        NoLosingTradesException ex = new NoLosingTradesException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.NO_LOSING_TRADES.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.noLosingTrades(ex));
    }
    @Test
    void internalServer() {
        String msg = Constant.INTERNAL_SERVER_ERROR.toString();
        InternalServerException ex = new InternalServerException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INTERNAL_SERVER_ERROR.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.internalServer(ex));
    }
    @Test
    void error() {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INTERNAL_SERVER_ERROR.name());
        message.put("message", Constant.GENERAL_EXCEPTION.toString());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, userAdvice.error());
    }

}
