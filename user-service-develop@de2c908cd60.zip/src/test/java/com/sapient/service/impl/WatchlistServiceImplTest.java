package com.sapient.service.impl;

import com.sapient.dto.WatchListCountResponseDto;
import com.sapient.dto.WatchlistDto;
import com.sapient.exception.*;
import com.sapient.model.Tickers;
import com.sapient.model.UserTradingDetails;
import com.sapient.model.Watchlist;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.repository.WatchlistRepository;
import com.sapient.service.TickersService;
import com.sapient.service.UserTradingDetailsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;
import java.util.*;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {WatchlistServiceImpl.class})
class WatchlistServiceImplTest {

    @MockBean
    WatchlistRepository watchlistRepository;

    @MockBean
    UserTradingDetailsService userTradingDetailsService;
    @MockBean
    UserTradingDetailsRepository userTradingDetailsRepository;
    @MockBean
    TickersService tickersService;

    @Autowired
    WatchlistServiceImpl watchlistService;

    WatchlistDto dummyWatchlistDto = new WatchlistDto(BigInteger.valueOf(1), BigInteger.valueOf(2), 3);

    UserTradingDetails dummyUser1 = new UserTradingDetails(BigInteger.valueOf(3), 1000.0, 100.0, 10.0, BigInteger.valueOf(13), 1000.0);

    UserTradingDetails dummyUser = new UserTradingDetails(BigInteger.valueOf(2), 1000.0, 100.0, 10.0, BigInteger.valueOf(13), 40.0);

    Tickers dummyTicker = new Tickers(3, "tesla", "101", "stock");
    Tickers dummyTicker1 = new Tickers(4, "ICICI BANK", "ICICI", "stock");
    Watchlist dummyWatchlist = new Watchlist(BigInteger.valueOf(1), dummyUser, dummyTicker);
    Watchlist dummyWatchlist1 = new Watchlist(BigInteger.valueOf(2), dummyUser, dummyTicker1);
    Watchlist dummyWatchlist2 = new Watchlist(BigInteger.valueOf(3), dummyUser1, dummyTicker);

    @Test
    void getWatchlistById() throws UserNotFoundException, TickerNotFoundException, ParameterNotFoundException, TradingDetailNotFoundException, DuplicateWatchlistEntryException {
        when(watchlistRepository.save(any())).thenReturn(dummyWatchlist);
        when(userTradingDetailsService.getUserTradingDetailsById(dummyWatchlistDto.getUserId())).thenReturn(dummyUser);
        when(tickersService.getTickerById(dummyTicker.getTickerNumber())).thenReturn(dummyTicker);
        Watchlist watchlist = watchlistService.setEntry(dummyWatchlistDto);
        assertNotNull(watchlist);
        assertEquals(dummyWatchlist, watchlist);
    }
    @Test
    void getWatchlistByIdThrowsTradingDetialNotFoundException() throws UserNotFoundException {
        when(watchlistRepository.save(any())).thenReturn(dummyWatchlist);
        when(userTradingDetailsService.getUserTradingDetailsById(dummyWatchlistDto.getUserId())).thenThrow(UserNotFoundException.class);
        assertThrows(TradingDetailNotFoundException.class, () -> watchlistService.setEntry(dummyWatchlistDto));

    }
    @Test
    void getWatchlistByIdThrowsTickerNotFoundException() throws UserNotFoundException, TickerNotFoundException {
        when(watchlistRepository.save(any())).thenReturn(dummyWatchlist);
        when(userTradingDetailsService.getUserTradingDetailsById(dummyWatchlistDto.getUserId())).thenReturn(dummyUser);
        when(tickersService.getTickerById(dummyWatchlistDto.getTickerNumber())).thenThrow(TickerNotFoundException.class);
        assertThrows(TickerNotFoundException.class, () -> watchlistService.setEntry(dummyWatchlistDto));
    }
    @Test
    void getWatchlistByIdThrowsParameterNotFoundException() {
        WatchlistDto dummyWatchlistDto1 = null;
        assertThrows(ParameterNotFoundException.class, () -> watchlistService.setEntry(dummyWatchlistDto1));
    }
    @Test
    void getTickerCountByUserId() throws UserNotFoundException {

        BigInteger userId = BigInteger.valueOf(13);
        long count = 2;
        WatchListCountResponseDto watchListResponseDto = new WatchListCountResponseDto(userId, count);
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(dummyUser);

        when(watchlistRepository.countByUserTradingDetail(dummyUser)).thenReturn(count);
        assertThat(watchlistService.getTickerCountByUserId(userId)).isEqualTo(watchListResponseDto);
        verify(watchlistRepository).countByUserTradingDetail(dummyUser);

    }

    @Test
    void getTickerCountByUserIdThrowsUserNotFoundException() throws UserNotFoundException {

        BigInteger userId = BigInteger.valueOf(1);
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenThrow(UserNotFoundException.class);
        assertThrows(UserNotFoundException.class, () -> watchlistService.getTickerCountByUserId(userId));

    }

    @Test
    void getUserByIdException() throws UserNotFoundException, WatchlistNotFoundException {
        when(userTradingDetailsRepository.findById(dummyUser.getUserId())).thenReturn(Optional.empty());
        UserNotFoundException userNotFoundException = assertThrows(UserNotFoundException.class, () -> {
            watchlistService.getWatchList(dummyUser.getUserId());
        });
        assertEquals("User does not exist", userNotFoundException.getMessage());
    }


    @Test
    void getWatchList() throws WatchlistNotFoundException, UserNotFoundException {
        when(userTradingDetailsRepository.findById(dummyUser.getUserId())).thenReturn(Optional.of(dummyUser));
        when(watchlistRepository.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId())).thenReturn(List.of(dummyWatchlist));
        List<Watchlist> watchlist = watchlistService.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId());
        assertNotNull(watchlist);
        assertEquals(dummyWatchlist, watchlist.get(0));
    }

    @Test
    void getWatchlistNotFoundException() throws WatchlistNotFoundException, UserNotFoundException {
        when(userTradingDetailsRepository.findById(dummyUser.getUserId())).thenReturn(Optional.of(dummyUser));
        when(watchlistRepository.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId())).thenReturn(new ArrayList<>());
        WatchlistNotFoundException watchlistNotFoundException = assertThrows(WatchlistNotFoundException.class, () -> {
            watchlistService.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId());
        });
        assertEquals("Empty Watchlist", watchlistNotFoundException.getMessage());
    }

    @Test
    void getWatchlistNullException() throws WatchlistNotFoundException, UserNotFoundException {
        when(userTradingDetailsRepository.findById(dummyUser.getUserId())).thenReturn(Optional.of(dummyUser));
        when(watchlistRepository.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId())).thenReturn(null);
        WatchlistNotFoundException watchlistNotFoundException = assertThrows(WatchlistNotFoundException.class, () -> {
            watchlistService.getWatchList(dummyWatchlist.getUserTradingDetail().getUserId());
        });
        assertEquals("Empty Watchlist", watchlistNotFoundException.getMessage());
    }

    @Test
    void getDistinctTickerInWatchlist() {
        final List<Watchlist> watchlists = new ArrayList<>() {
            {
                add(dummyWatchlist);
                add(dummyWatchlist1);
                add(dummyWatchlist2);
            }
        };
        Set<Integer> expectedTickerIds = new HashSet<>();
        expectedTickerIds.add(3);
        expectedTickerIds.add(4);
        when(watchlistRepository.findAll()).thenReturn(watchlists);
        assertEquals(expectedTickerIds, watchlistService.getDistinctTickerNumber());
    }

    @Test
    void getUserIdListFromTickerNumber() throws NoUserIdForTickerNumberException {
        List<BigInteger> expectedUserIds = new ArrayList<>();
        expectedUserIds.add(BigInteger.ONE);
        expectedUserIds.add(BigInteger.TWO);
        Integer tickerNumber = 1;
        when(watchlistRepository.getUserIdsFromTickerNumber(tickerNumber)).thenReturn(expectedUserIds);
        List<BigInteger> actualUserIds = watchlistService.getUserIdListFromTickerNumber(tickerNumber);
        assertEquals(expectedUserIds, actualUserIds);
    }

    @Test
    void getUserIdListFromTickerNumberThrowsException() {
        List<BigInteger> expectedUserIds = new ArrayList<>();
        Integer tickerNumber = 1;
        when(watchlistRepository.getUserIdsFromTickerNumber(tickerNumber)).thenReturn(expectedUserIds);
        assertThrows(NoUserIdForTickerNumberException.class, () -> watchlistService.getUserIdListFromTickerNumber(tickerNumber));

    }

    @Test
    void deleteWatchlistTest() throws UserNotFoundException, TickerNotFoundException, WatchlistNotFoundException, ParameterNotFoundException {
        when(watchlistRepository.selectWatchlist(any(), any())).thenReturn(dummyWatchlist);
        doNothing().when(watchlistRepository).deleteById(any());
        Watchlist expected = watchlistService.deleteEntry(dummyWatchlistDto);
        assertEquals(expected, dummyWatchlist);
    }

    @Test
    void watchlistDeleteException() {
        WatchlistDto watchlistDto = new WatchlistDto();
        when(watchlistRepository.selectWatchlist(any(), any())).thenReturn(null);
        assertThrows(WatchlistNotFoundException.class, ()-> watchlistService.deleteEntry(watchlistDto));
    }

    @Test
    void duplicateWatchlistException() throws UserNotFoundException, TickerNotFoundException {
        when(userTradingDetailsService.getUserTradingDetailsById(any())).thenReturn(new UserTradingDetails());
        when(tickersService.getTickerById(any())).thenReturn(new Tickers());
        when(watchlistRepository.selectWatchlist(any(), any())).thenReturn(new Watchlist());
        assertThrows(DuplicateWatchlistEntryException.class, () -> watchlistService.setEntry(new WatchlistDto(BigInteger.ONE, BigInteger.TWO,3)));

    }

}
