package com.sapient.service.impl;

import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.exception.InternalServerException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.model.UserTradingDetails;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.utils.UserTradingDetailsUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {UserTradingDetailsServiceImpl.class})
class UserTradingDetailsServiceImplTest {

    @MockBean
    UserTradingDetailsRepository userTradingDetailsRepository;

    @Autowired
    UserTradingDetailsServiceImpl userTradingDetailsService;

    @MockBean
    UserTradingDetailsUtil userTradingDetailsUtil;

    UserTradingDetails dummy = new UserTradingDetails(BigInteger.valueOf(5), 100.2, 50.0, 10.0, BigInteger.valueOf(40), 1000.0);
    UserTradingDetailsDto dummyDto = new UserTradingDetailsDto(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);

    @Test
    void getUserTradingDetailsById() throws UserNotFoundException {
        when(userTradingDetailsRepository.findById(dummy.getUserId())).thenReturn(Optional.of(dummy));
        UserTradingDetails userTradingDetails = userTradingDetailsService.getUserTradingDetailsById(dummy.getUserId());
        assertNotNull(userTradingDetails);
        assertEquals(userTradingDetails, dummy);
    }

    @Test
    void getUserTradingDetailsByIdException() {
        when(userTradingDetailsRepository.findById(dummy.getUserId())).thenReturn(Optional.empty());
        UserNotFoundException userNotFoundException = assertThrows(UserNotFoundException.class, () -> {
            userTradingDetailsService.getUserTradingDetailsById(dummy.getUserId());
        });
        assertEquals("User does not exist", userNotFoundException.getMessage());

    }

    @Test
    void createOrUpdate() throws RuntimeException, InternalServerException, UserNotFoundException {
        UserTradingDetails userTradingDetails = new UserTradingDetails(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);
        when(userTradingDetailsUtil.mapUserTradingDetails(dummyDto)).thenReturn(userTradingDetails);
        when(userTradingDetailsRepository.save(userTradingDetails)).thenReturn(userTradingDetails);
        UserTradingDetails orUpdate = userTradingDetailsService.createOrUpdate(dummyDto);
        assertNotNull(userTradingDetails);
        assertEquals(userTradingDetails.getUserId(), orUpdate.getUserId());

    }

    @Test
    void getAllUserIds() {
        final List<BigInteger> userIds = new ArrayList<>() {
            {
                add(BigInteger.ONE);
                add(BigInteger.TEN);
                add(BigInteger.TWO);
            }
        };
        when(userTradingDetailsRepository.findAllUserIds()).thenReturn(userIds);
        Map<String, List<BigInteger>> expected = new HashMap<>();
        expected.put("userIds", userIds);
        Map<String, List<BigInteger>> actual = userTradingDetailsService.getAllUserIds();
        assertEquals(expected, actual);
    }
}
