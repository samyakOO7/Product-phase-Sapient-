package com.sapient.service.impl;


import com.sapient.constant.Constant;
import com.sapient.dto.WatchlistTickerDto;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.model.Tickers;
import com.sapient.repository.TickersRepository;
import com.sapient.service.WatchlistService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {TickersServiceImpl.class})
class TickersServiceImplTest {

    @MockBean
    TickersRepository tickersRepository;

    @MockBean
    WatchlistService watchlistService;
    @Autowired
    private TickersServiceImpl tickersService;

    Tickers dummyTicker = new Tickers(11, "tesla", "101", "stock");

    @Test
    void getTickerById() throws TickerNotFoundException {
        when(tickersRepository.findById(dummyTicker.getTickerNumber())).thenReturn(Optional.of(dummyTicker));
        Tickers ticker = tickersService.getTickerById(dummyTicker.getTickerNumber());
        assertNotNull(ticker);
        assertEquals(dummyTicker, ticker);
    }
    @Test
    void getTickerByIdException() throws TickerNotFoundException {
        when(tickersRepository.findById(dummyTicker.getTickerNumber())).thenReturn(Optional.empty());
        when(tickersRepository.findById(dummyTicker.getTickerNumber())).thenReturn(Optional.empty());
        TickerNotFoundException tickerNotFoundException = assertThrows(TickerNotFoundException.class, () -> {
            tickersService.getTickerById(dummyTicker.getTickerNumber());
        });
        assertEquals("Ticker does not exist", tickerNotFoundException.getMessage());
    }

    @Test
    @DisplayName("search method should return list of Tickers when string provided matches the ticker name or ticker id in db")
    void returnListOfTickerGivenStringMatches() throws TickerNotFoundException {

        final List<Tickers> tickersList = new ArrayList<Tickers>() {
            {
                add(new Tickers(11, "tesla", "TSL", "stock"));
                add(new Tickers(12, "tata", "TATA", "stock"));
                add(new Tickers(12, "testing Expert", "TESTEXP", "stock"));
            }
        };
        String stringToSearch = "tes";
        List<Tickers> expectedTickersList = new ArrayList<>();
        expectedTickersList.add(tickersList.get(0));
        expectedTickersList.add(tickersList.get(2));
        when(tickersRepository.searchTickers(stringToSearch)).thenReturn(expectedTickersList);

        List<Tickers> actualTickersList = tickersService.searchTickers(stringToSearch);

        assertEquals(expectedTickersList, actualTickersList);
    }

    @Test
    @DisplayName("search method should return empty list when string provided does not  matches the ticker name or ticker id in db")
    void returnEmptyListGivenStringNotMatches() throws TickerNotFoundException {

        final List<Tickers> tickersList = new ArrayList<Tickers>() {
            {
                add(new Tickers(11, "tesla", "TSL", "stock"));
                add(new Tickers(12, "tata", "TATA", "stock"));
                add(new Tickers(12, "testing Expert", "TESTEXP", "stock"));
            }
        };
        String stringToSearch = "btc";
        List<Tickers> expectedTickersList = Collections.emptyList();
        when(tickersRepository.searchTickers(stringToSearch)).thenReturn(expectedTickersList);

        TickerNotFoundException tickerNotFoundException = assertThrows(TickerNotFoundException.class, () -> {
            tickersService.searchTickers(stringToSearch);
        });
        assertEquals(Constant.TICKER_NOT_FOUND.toString(), tickerNotFoundException.getMessage());
    }

    @Test
    @DisplayName("Return Distinct Tickers Present in Watchlist Table")
    void returnMapOfTickersInWatchlist() {
        Set<Integer> tickerNumbers = new HashSet<>();
        tickerNumbers.add(1);
        tickerNumbers.add(2);
        WatchlistTickerDto watchlistTickerDto=new WatchlistTickerDto(1,"INFY");
        WatchlistTickerDto watchlistTickerDto1=new WatchlistTickerDto(2,"ICICI");
        WatchlistTickerDto watchlistTickerDto2=new WatchlistTickerDto(3,"HDFC");
        final List<WatchlistTickerDto> tickers = new ArrayList<>() {
            {
                add(watchlistTickerDto);
                add(watchlistTickerDto1);
                add(watchlistTickerDto2);
            }
        };
        Map<String, List<WatchlistTickerDto>> excpectedTickerIds = new HashMap<>();
        excpectedTickerIds.put("tickers", tickers);

        when(watchlistService.getDistinctTickerNumber()).thenReturn(tickerNumbers);
        when(tickersRepository.getWatchlistStocks(tickerNumbers)).thenReturn(tickers);
        Map<String, List<WatchlistTickerDto>> actualTickerIds = tickersService.getWatchlistTicker();
        assertEquals(excpectedTickerIds, actualTickerIds);
    }


}
