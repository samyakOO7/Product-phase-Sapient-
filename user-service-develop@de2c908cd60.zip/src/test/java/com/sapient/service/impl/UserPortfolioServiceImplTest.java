package com.sapient.service.impl;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.dto.*;
import com.sapient.exception.*;
import com.sapient.model.Tickers;
import com.sapient.model.UserPortfolio;
import com.sapient.model.UserTradingDetails;
import com.sapient.repository.TickersRepository;
import com.sapient.repository.UserPortfolioRepository;
import com.sapient.repository.UserTradingDetailsRepository;
import com.sapient.service.UserTradingDetailsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {UserPortfolioServiceImpl.class})
class UserPortfolioServiceImplTest {
    @Autowired
    UserPortfolioServiceImpl userPortfolioService;

    @MockBean
    UserPortfolioRepository userPortfolioRepository;

    @MockBean
    UserTradingDetailsRepository userTradingDetailsRepository;

    @MockBean
    UserTradingDetailsService userTradingDetailsService;

    @MockBean
    TickersRepository tickersRepository;

    @MockBean
    StockServiceFeignClient client;

    UserPortfolioUpdateDto userPortfolioUpdateDto1 = new UserPortfolioUpdateDto("buy", BigInteger.ONE, 101, 10, 10.0, 7.0, 15.0);
    UserPortfolioUpdateDto userPortfolioUpdateDto2 = new UserPortfolioUpdateDto("sell", BigInteger.ONE, 101, 10, 10.0, 7.0, 15.0);

    List<UserPortfolio> userPortfolioList = new ArrayList<>();
    Tickers tickers = new Tickers(1, "abc", "abc", "stock");
    UserTradingDetails user = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 2.0, BigInteger.valueOf(10), 100.0);
    UserPortfolio portfolio1 = new UserPortfolio(BigInteger.ONE, user, tickers, 1, 1.0, 0.5, 0.3);

    UserDashboardDto userDashboardDto = new UserDashboardDto(9.0, 1000.0, 1, 0);
    UserTradingDetails userTradingDetails = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 10.0, BigInteger.TEN, 1000.0);
    BigInteger userId = BigInteger.ONE;

    @BeforeEach
    void setUp() {
        userPortfolioList.add(portfolio1);

    }

    @Test
    void UpdatePortfolioBuy() {
        when(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(any(), any())).thenReturn(portfolio1);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);
        when(tickersRepository.findByTickerNumber(any())).thenReturn(tickers);
        when(userTradingDetailsRepository.save(any())).thenReturn(userTradingDetails);
        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(userPortfolioList);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);

        PortfolioUpdateSuccessDto expected = new PortfolioUpdateSuccessDto("Success");
        PortfolioUpdateSuccessDto actual = userPortfolioService.updatePortfolio(userPortfolioUpdateDto1);
        assertEquals(expected.toString(), actual.toString());
    }

    @Test
    void UpdatePortfolioNewEntry() {
        when(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(any(), any())).thenReturn(null);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);
        when(tickersRepository.findByTickerNumber(any())).thenReturn(tickers);
        when(userPortfolioRepository.save(any())).thenReturn(portfolio1);
        when(userTradingDetailsRepository.save(any())).thenReturn(userTradingDetails);

        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(userPortfolioList);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);

        PortfolioUpdateSuccessDto expected = new PortfolioUpdateSuccessDto("Success");
        PortfolioUpdateSuccessDto actual = userPortfolioService.updatePortfolio(userPortfolioUpdateDto1);
        assertEquals(expected.toString(), actual.toString());
    }

    @Test
    void UpdatePortfolioSell() {
        when(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(any(), any())).thenReturn(portfolio1);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);
        doNothing().when(userPortfolioRepository).delete(any(UserPortfolio.class));

        when(userTradingDetailsRepository.save(any())).thenReturn(userTradingDetails);
        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(userPortfolioList);
        when(userTradingDetailsRepository.getById(any())).thenReturn(userTradingDetails);

        PortfolioUpdateSuccessDto expected = new PortfolioUpdateSuccessDto("Success");
        PortfolioUpdateSuccessDto actual = userPortfolioService.updatePortfolio(userPortfolioUpdateDto2);
        assertEquals(expected.toString(), actual.toString());
    }

    @Test
    void UserDashboardTest() throws TradingDetailNotFoundException, EmptyUserPortfolioException {
        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(userPortfolioList);
        Map<String, BigDecimal> map = new HashMap<>();
        map.put("price_per_stock", BigDecimal.TEN);
        when(client.getCurrentPrice(anyString())).thenReturn(map);
        when(userTradingDetailsRepository.findById(any())).thenReturn(Optional.of(userTradingDetails));
        UserDashboardDto actual = userPortfolioService.getUserDashboardData(userId);
        assertEquals(actual.toString(), userDashboardDto.toString());

    }

    @Test
    void getDashboardDataException2() throws TradingDetailNotFoundException, EmptyUserPortfolioException {
        List<UserPortfolio> emptyList=new ArrayList<>();
        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(emptyList);
        assertThrows(EmptyUserPortfolioException.class, () -> {
            userPortfolioService.getUserDashboardData(userId);
        });

    }
    @Test
    void getDashboardDataException() throws  TradingDetailNotFoundException,EmptyUserPortfolioException{
        when(userPortfolioRepository.findPortfolioByUserId(any())).thenReturn(userPortfolioList);
        Map<String, BigDecimal> map = new HashMap<>();
        map.put("price_per_stock", BigDecimal.TEN);
        when(client.getCurrentPrice(anyString())).thenReturn(map);
        when(userTradingDetailsRepository.findById(any())).thenReturn(Optional.empty());
        assertThrows(TradingDetailNotFoundException.class, () -> {
            userPortfolioService.getUserDashboardData(userId);
        });
    }

    @Test
    void winningOrLosingTrades() throws EmptyUserPortfolioException, NoWinningTradesException, NoLosingTradesException, UserNotFoundException {
        UserTradingDetails user = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 2.0, BigInteger.valueOf(10), 100.0);
        BigInteger userId = BigInteger.ONE;
        Tickers ticker = new Tickers(11, "tesla", "TSL", "stock");
        Tickers ticker1 = new Tickers(12, "tata", "TATA", "stock");
        final List<UserPortfolio> portfolioList = new ArrayList<>() {
            {
                add(new UserPortfolio(BigInteger.ONE, user, ticker, 10, 100.0, 120.0, 98.0));
                add(new UserPortfolio(BigInteger.TWO, user, ticker1, 10, 100.0, 120.0, 98.0));
            }
        };
        final List<TradesDto> tradesDtoList = new ArrayList<>() {
            {
                add(new TradesDto(BigInteger.ONE, "TSL", "tesla", BigDecimal.valueOf(100.0), 10, 100.0, BigDecimal.valueOf(110.0)));
                add(new TradesDto(BigInteger.TWO, "TATA", "tata", BigDecimal.valueOf(-100.0), 10, 100.0, BigDecimal.valueOf(90.0)));
            }
        };
        Map<String, BigDecimal> currentPrice = new HashMap<>();
        Map<String, BigDecimal> currentPrice1 = new HashMap<>();
        currentPrice.put("price_per_stock", BigDecimal.valueOf(110.0));
        currentPrice1.put("price_per_stock", BigDecimal.valueOf(90.0));
        Map<String, List<TradesDto>> expectedMap = new HashMap<>();
        expectedMap.put("openTrades", tradesDtoList);
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(user);
        when(userPortfolioRepository.findByUserTradingDetail(user)).thenReturn(portfolioList);
        when(client.getCurrentPrice("TSL")).thenReturn(currentPrice);
        System.out.println(currentPrice.get("price_per_stock"));
        when(client.getCurrentPrice("TATA")).thenReturn(currentPrice1);
        Map<String, List<TradesDto>> actualMap = userPortfolioService.winningLosingOpenTrades(BigInteger.ONE, "open");
        assertEquals(expectedMap, actualMap);
    }

    @Test
    void winningOrLosingTradesThrowsEmptyPortfolioException() throws UserNotFoundException {
        UserTradingDetails user = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 2.0, BigInteger.valueOf(10), 100.0);
        BigInteger userId = BigInteger.ONE;
        final List<UserPortfolio> portfolioList = new ArrayList<>();
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(user);
        when(userPortfolioRepository.findByUserTradingDetail(user)).thenReturn(portfolioList);
        assertThrows(EmptyUserPortfolioException.class, () -> userPortfolioService.winningLosingOpenTrades(BigInteger.ONE, "open"));
    }

    @Test
    void winningOrLosingTradesThrowsNoLosingTradesException() throws UserNotFoundException {
        UserTradingDetails user = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 2.0, BigInteger.valueOf(10), 100.0);
        BigInteger userId = BigInteger.ONE;
        Tickers ticker = new Tickers(11, "tesla", "TSL", "stock");
        Tickers ticker1 = new Tickers(12, "tata", "TATA", "stock");
        final List<UserPortfolio> portfolioList = new ArrayList<>() {
            {
                add(new UserPortfolio(BigInteger.ONE, user, ticker, 10, 100.0, 120.0, 98.0));
                add(new UserPortfolio(BigInteger.TWO, user, ticker1, 10, 100.0, 120.0, 98.0));
            }
        };
        Map<String, BigDecimal> currentPrice = new HashMap<>();
        currentPrice.put("price_per_stock", BigDecimal.valueOf(110.0));
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(user);
        when(userPortfolioRepository.findByUserTradingDetail(user)).thenReturn(portfolioList);
        when(client.getCurrentPrice("TSL")).thenReturn(currentPrice);
        when(client.getCurrentPrice("TATA")).thenReturn(currentPrice);
        assertThrows(NoLosingTradesException.class, () -> userPortfolioService.winningLosingOpenTrades(BigInteger.ONE, "losing"));

    }

    @Test
    void winningOrLosingTradesThrowsNoWinningTradesException() throws UserNotFoundException {
        UserTradingDetails user = new UserTradingDetails(BigInteger.ONE, 100.0, 10.0, 2.0, BigInteger.valueOf(10), 100.0);
        BigInteger userId = BigInteger.ONE;
        Tickers ticker = new Tickers(11, "tesla", "TSL", "stock");
        Tickers ticker1 = new Tickers(12, "tata", "TATA", "stock");
        final List<UserPortfolio> portfolioList = new ArrayList<>() {
            {
                add(new UserPortfolio(BigInteger.ONE, user, ticker, 10, 100.0, 120.0, 98.0));
                add(new UserPortfolio(BigInteger.TWO, user, ticker1, 10, 100.0, 120.0, 98.0));
            }
        };
        Map<String, BigDecimal> currentPrice = new HashMap<>();
        currentPrice.put("price_per_stock", BigDecimal.valueOf(90.0));
        when(userTradingDetailsService.getUserTradingDetailsById(userId)).thenReturn(user);
        when(userPortfolioRepository.findByUserTradingDetail(user)).thenReturn(portfolioList);
        when(client.getCurrentPrice("TSL")).thenReturn(currentPrice);
        when(client.getCurrentPrice("TATA")).thenReturn(currentPrice);
        assertThrows(NoWinningTradesException.class, () -> userPortfolioService.winningLosingOpenTrades(BigInteger.ONE, "winning"));

    }

    @Test
    @DisplayName("UserPortfolio should return UserPortfolio successfully")
    void getUserPortfolio_shouldReturn_SuccessResponse() throws PortfolioNotFoundException {
        BigInteger portfolioId = BigInteger.valueOf(2);
        BigInteger userId = BigInteger.ONE;
        Integer tickerNumber = 1;
        Tickers tickers = new Tickers(1, "INFY", "INFY-90", "STOCK");
        UserTradingDetails details = new UserTradingDetails();
        details.setUserId(BigInteger.TWO);
        UserPortfolio portfolio = new UserPortfolio(portfolioId, details, tickers, 2, 34.5, 2.3, 2.5);

        UserPortfolioDto dto = new UserPortfolioDto();
        dto.setUserId(portfolio.getUserTradingDetail().getUserId());
        dto.setUserPortfolioId(portfolio.getUserPortfolioId());
        dto.setQuantity(portfolio.getQuantity());
        dto.setAveragePrice(portfolio.getAveragePrice());
        dto.setTicker(portfolio.getTicker());
        when(userPortfolioRepository.findById(portfolioId)).thenReturn(Optional.of(portfolio));
        UserPortfolioDto actual = userPortfolioService.getUserPortfolio(portfolioId);
        assertEquals(dto, actual);
    }

    @Test
    @DisplayName("UserPortfolio should throw PortfolioNotFoundException")
    void getUserPortfolio_shouldReturn_FailedResponse() throws PortfolioNotFoundException {
        BigInteger portfolioId = BigInteger.valueOf(2);
        when(userPortfolioRepository.findById(portfolioId)).thenReturn(Optional.empty());
        assertThrows(PortfolioNotFoundException.class, () -> userPortfolioService.getUserPortfolio(portfolioId));
    }

    @Test
    @DisplayName("getUserPortfolioByUserIdAndTickerNumber should return UserPortfolio successfully")
    void getUserPortfolioByUserIdAndTickerNumber_shouldReturn_SuccessResponse() throws PortfolioNotFoundException {
        BigInteger portfolioId = BigInteger.valueOf(2);
        BigInteger userId = BigInteger.ONE;
        Integer tickerNumber = 1;
        Tickers tickers = new Tickers(1, "INFY", "INFY-90", "STOCK");
        UserTradingDetails details = new UserTradingDetails();
        details.setUserId(BigInteger.TWO);
        UserPortfolio portfolio = new UserPortfolio(portfolioId, details, tickers, 2, 34.5, 2.3, 2.5);
        UserPortfolioDto dto = new UserPortfolioDto();
        dto.setUserId(portfolio.getUserTradingDetail().getUserId());
        dto.setUserPortfolioId(portfolio.getUserPortfolioId());
        dto.setQuantity(portfolio.getQuantity());
        dto.setAveragePrice(portfolio.getAveragePrice());
        dto.setTicker(portfolio.getTicker());

        when(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(userId, tickerNumber)).thenReturn(portfolio);
        UserPortfolioDto actual = userPortfolioService.getUserPortfolioByUserIdAndTickerNumber(userId, tickerNumber);
        assertEquals(dto, actual);
    }

    @Test
    @DisplayName("getUserPortfolioByUserIdAndTickerNumber should throw PortfolioNotFoundException")
    void getUserPortfolioByUserIdAndTickerNumber_shouldReturn_FailedResponse() throws PortfolioNotFoundException {
        BigInteger userId = BigInteger.valueOf(1);
        Integer tickerNumber = 1;
        when(userPortfolioRepository.findPortfolioByUserIdAndTickerNumber(userId, tickerNumber)).thenReturn(null);
        assertThrows(PortfolioNotFoundException.class, () -> userPortfolioService.getUserPortfolioByUserIdAndTickerNumber(userId, tickerNumber));
    }

    @Test
    void getPortfolioByUserId() {
        UserPortfolioDetailsDto userPortfolioDetailsDto = new UserPortfolioDetailsDto(BigInteger.ONE, "abc", 0.5, 0.3, 1.0);
        BigInteger userId = BigInteger.ONE;
        List<UserPortfolio> portfolioList = new ArrayList<>();
        portfolioList.add(portfolio1);
        when(userPortfolioRepository.findPortfolioByUserId(userId)).thenReturn(portfolioList);
        List<UserPortfolioDetailsDto> portfolioDtoList = new ArrayList<>();
        portfolioDtoList.add(userPortfolioDetailsDto);
        Map<String, List<UserPortfolioDetailsDto>> expected = new HashMap<>();
        expected.put("userPortfolio", portfolioDtoList);
        Map<String, List<UserPortfolioDetailsDto>> actual = userPortfolioService.getPortfolioByUserId(userId);
        assertEquals(expected, actual);

    }

}
