package com.sapient.utils;

import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.model.UserTradingDetails;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {UserTradingDetailsUtil.class})
class UserTradingDetailsUtilTest {
    @Autowired
    UserTradingDetailsUtil userTradingDetailsUtil;

    @Test
    void mapUserTradingDetails() {
        UserTradingDetailsDto dummyDto = new UserTradingDetailsDto(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);
        UserTradingDetails expected = new UserTradingDetails(BigInteger.ONE, 10.1, 10.1, 10.1, BigInteger.ONE, 10.1);
        UserTradingDetails actual = userTradingDetailsUtil.mapUserTradingDetails(dummyDto);
        assertEquals(expected.getUserId(),actual.getUserId());
    }
}
