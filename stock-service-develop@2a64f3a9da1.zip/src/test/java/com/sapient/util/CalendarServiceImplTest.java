package com.sapient.util;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;


@DisplayName("Calendar service tests")
public class CalendarServiceImplTest {

    @Autowired
    CalendarService calendarService;

    @Test
    public void getFromDate() {
        calendarService = new CalendarServiceImpl();
        Assertions.assertNotNull(calendarService.getFromDate(5));
    }

    @Test
    public void getToDate() {
        calendarService = new CalendarServiceImpl();
        Calendar to = Calendar.getInstance();
        Assertions.assertNotNull(calendarService.getToDate());
    }
}