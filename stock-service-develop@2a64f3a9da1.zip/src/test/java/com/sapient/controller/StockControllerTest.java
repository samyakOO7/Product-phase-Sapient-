package com.sapient.controller;

import com.sapient.advice.StockAdvice;
import com.sapient.dto.TickerDataDto;
import com.sapient.service.StockService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.CoreMatchers.is;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {StockController.class, StockService.class, StockAdvice.class})
@WebMvcTest(StockController.class)
public class StockControllerTest {

    @Autowired
    private MockMvc mvc;
    @MockBean
    StockService stockService;

    @Test
    public void getCurrentPrice() throws Exception {
        BigDecimal price = BigDecimal.TEN;
        given(stockService.getCurrentPrice("HDFC.NS")).willReturn(price);
        mvc.perform(get("/HDFC.NS").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.price_per_stock", is(10)));
    }

    @Test
    public void getIOException() throws Exception {
        BigDecimal price = BigDecimal.TEN;
        given(stockService.getCurrentPrice("HDFC.NS")).willThrow(IOException.class);
        mvc.perform(get("/HDFC.NS").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", is("Failed to get data from ticker symbol")));
    }

    @Test
    public void getHistoricalValues() throws Exception {
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        given(stockService.getHistoricalData("INFY.NS")).willReturn(tickerDataDtoList);
        mvc.perform(get("/history/INFY.NS").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}