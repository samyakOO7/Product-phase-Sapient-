package com.sapient.service;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.PriceData;
import com.sapient.entity.TickerData;
import com.sapient.entity.WatchlistData;
import com.sapient.mapper.TickerMapper;
import com.sapient.repository.PriceRepository;
import com.sapient.repository.StockRepository;
import com.sapient.util.CalendarService;
import com.sapient.util.CalendarServiceImpl;
import org.checkerframework.checker.units.qual.C;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.quotes.stock.StockQuote;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {StockServiceImpl.class, TickerMapper.class, CalendarServiceImpl.class})
@WebMvcTest(StockServiceImpl.class)
public class StockServiceImplTest {

    @Autowired
    StockService stockService;
    @MockBean
    TickerMapper tickerMapper;
    @MockBean
    StockRepository stockRepository;
    @MockBean
    PriceData priceData1;
    @MockBean
    PriceRepository priceRepository;
    @MockBean
    CalendarService calendarService;

    @Test
    public void getHistoricalData() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData = new ArrayList<>() {
            {
                add(t2);
            }
        };
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));//return null for additional current data
    }

    @Test
    public void getHistoricalDataException() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData = new ArrayList<>() {
            {
                add(t2);
            }
        };
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        given(tickerMapper.mappingTickerClass(t1)).willAnswer(invocation -> {
            throw new IOException("abc msg");
        });
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 26);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));//return null for additional current data
    }

    @Test
    public void getHistoricalDataExceptionNull() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", null, null, null, null, null);
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData = new ArrayList<>() {
            {
                add(t2);
            }
        };
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        given(tickerMapper.mappingTickerClass(t1)).willAnswer(invocation -> {
            throw new IOException("abc msg");
        });
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 26);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));//return null for additional current data
    }

    @Test
    public void getHistoricalDataNull() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", null, null, null, null, null);
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData = new ArrayList<>() {
            {
                add(t2);
            }
        };
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));//return null for additional current data
    }

    @Test
    public void getHistoricalDataFromYahoo() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(new ArrayList<>());
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 28);
        Calendar from = Calendar.getInstance();
        from.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Mockito.when(calendarService.getFromDate(any(Integer.class))).thenReturn(from);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Mockito.when(stockRepository.save(any(TickerData.class))).thenReturn(t2);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));
    }

    @Test
    public void getHistoricalDataFromYahooNull() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", null, null, null, null, null);
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(new ArrayList<>());
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 28);
        Calendar from = Calendar.getInstance();
        from.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Mockito.when(calendarService.getFromDate(any(Integer.class))).thenReturn(from);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Mockito.when(stockRepository.save(any(TickerData.class))).thenReturn(t2);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));
    }
    @Test
    public void getHistoricalDataFromYahooExceptionNull() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", null, null, null, null, null);
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(new ArrayList<>());
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 26);
        Calendar from = Calendar.getInstance();
        from.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Mockito.when(calendarService.getFromDate(any(Integer.class))).thenReturn(from);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Mockito.when(stockRepository.save(any(TickerData.class))).thenReturn(t2);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));
    }
    @Test
    public void getHistoricalDataFromYahooException() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(new ArrayList<>());
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 26);
        Calendar from = Calendar.getInstance();
        from.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Mockito.when(calendarService.getFromDate(any(Integer.class))).thenReturn(from);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Mockito.when(tickerMapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Mockito.when(stockRepository.save(any(TickerData.class))).thenReturn(t2);
        Mockito.when(tickerMapper.getDtoMapper(t2)).thenReturn(t1);
        Assertions.assertNotNull(stockService.getHistoricalData("INFY.NS"));
    }



    @Test
    public void getCurrentPrice() throws IOException {
        PriceData priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        Mockito.when(priceRepository.findById(any(String.class))).thenReturn(Optional.empty());
        Assertions.assertNotNull(stockService.getCurrentPrice("HDFC.NS"));
    }

    @Test
    public void getCurrentPriceAlreadyPresent() throws IOException {
        PriceData priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), new Timestamp(Timestamp.from(Instant.now()).getTime() + 300000), BigDecimal.valueOf(2328.8));
        Mockito.when(priceRepository.findById(any(String.class))).thenReturn(Optional.of(priceData));
        Mockito.doNothing().when(priceData1).setPrice(any(BigDecimal.class));
        Mockito.doNothing().when(priceData1).setGenerationTime(any(Timestamp.class));
        Mockito.doNothing().when(priceData1).setExpirationTime(any(Timestamp.class));
        Mockito.when(priceRepository.save(any(PriceData.class))).thenReturn(priceData);
        Mockito.when(priceData1.getPrice()).thenReturn(priceData.getPrice());
        Assertions.assertNotNull(stockService.getCurrentPrice("HDFC.NS"));
    }

    @Test
    public void getFiveDaysData() throws IOException {
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(new ArrayList<>());
        Calendar today = Calendar.getInstance();
        today.set(2022, Calendar.AUGUST, 26);
        Calendar from = Calendar.getInstance();
        from.set(2022, Calendar.AUGUST, 24);
        Mockito.when(calendarService.getToDate()).thenReturn(today);
        Mockito.when(calendarService.getFromDate(any(Integer.class))).thenReturn(from);
        Mockito.when(tickerMapper.getTickerMapper(any(HistoricalQuote.class))).thenReturn(t1);
        Assertions.assertNotNull(stockService.getFiveDaysData("INFY.NS"));
    }

    @Test
    public void getException() {
        Assertions.assertThrows(NullPointerException.class, () -> stockService.getCurrentPrice("TATA.NS"));
    }

    @Test
    public void getUpdatedWatchlist() throws IOException {
        WatchlistData watchlistData = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        Mockito.when(tickerMapper.getCurrentQuote(any(StockQuote.class))).thenReturn(watchlistData);
        Assertions.assertNotNull(stockService.getUpdatedWatchlistForStock("INFY.NS"));
    }
}