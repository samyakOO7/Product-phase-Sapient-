package com.sapient.service;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.TickerData;
import com.sapient.exception.EmptyListOfTickersException;
import com.sapient.mapper.TickerMapper;
import com.sapient.repository.StockRepository;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {DatabaseCronJobServiceImpl.class})
@WebMvcTest(DatabaseCronJobServiceImpl.class)
public class DatabaseCronJobServiceImplTest {

    @Autowired
    DatabaseCronJobService databaseCronJobService;
    @MockBean
    StockRepository stockRepository;
    @MockBean
    StockService stockService;
    @MockBean
    SimpleDateFormat format;
    @MockBean
    TickerMapper mapper;

    @Test
    public void getDatabaseScheduled() throws IOException, EmptyListOfTickersException {
        List<String> l = new ArrayList<>() {
            {
                add("HDFC.NS");
            }
        };
        TickerDataDto t1 = new TickerDataDto(Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData = new ArrayList<>() {
            {
                add(t2);
            }
        };
        TickerData t3 = new TickerData(BigInteger.ONE, new Timestamp(Timestamp.from(Instant.now()).getTime() + 604800000), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerData> tickerData1 = new ArrayList<>() {
            {
                add(t3);
            }
        };
        Mockito.when(stockRepository.findDistinctTickerId()).thenReturn(l);
        Mockito.when(stockService.getFiveDaysData(any(String.class))).thenReturn(tickerDataDtoList);
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData);
        Mockito.doNothing().when(stockRepository).deleteById(any(BigInteger.class));
        Mockito.when(mapper.mappingTickerClass(any(TickerDataDto.class))).thenReturn(t2);
        Mockito.when(stockRepository.save(any(TickerData.class))).thenReturn(t2);
        Mockito.when(stockRepository.findByTickerId(any(String.class))).thenReturn(tickerData1);
        databaseCronJobService.getDatabaseScheduled();
        verify(stockRepository, times(1)).save(t2);
    }

    @Test
    public void getDatabaseScheduledThrowException() throws IOException, EmptyListOfTickersException {
        Mockito.when(stockRepository.findDistinctTickerId()).thenReturn(new ArrayList<>());
        Assertions.assertThrows(EmptyListOfTickersException.class, () -> databaseCronJobService.getDatabaseScheduled());
    }

    @Test
    public void getDatabaseScheduledForHoliday() throws IOException, EmptyListOfTickersException {
        Calendar date = Calendar.getInstance();
        date.set(2021, 8, 12);
        List<String> l = new ArrayList<>() {
            {
                add("HDFC.NS");
            }
        };
        TickerDataDto t1 = new TickerDataDto(new Timestamp(date.getTimeInMillis()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>() {
            {
                add(t1);
            }
        };
        Mockito.when(stockRepository.findDistinctTickerId()).thenReturn(l);
        Mockito.when(stockService.getFiveDaysData(any(String.class))).thenReturn(tickerDataDtoList);
        databaseCronJobService.getDatabaseScheduled();
        verify(stockRepository, times(1)).findDistinctTickerId();
    }
}