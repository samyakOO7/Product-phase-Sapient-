package com.sapient.entity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;


@DisplayName("TickerData test")
class TickerDataTest {

    private TickerData tickerData;

    @BeforeEach
    public void loadTickerdata() {
    }

    @Test
    void getTickerId() {
        tickerData = new TickerData();
        String s = "HDFC.NS";
        tickerData.setTickerId("HDFC.NS");
        Assertions.assertEquals(s, tickerData.getTickerId());
    }

    @Test
    void getStockHistoricalDataId() {
        tickerData = new TickerData();
        BigInteger b = BigInteger.TWO;
        tickerData.setStockHistoricalDataId(BigInteger.ONE);
        Assertions.assertNotEquals(b, tickerData.getStockHistoricalDataId());
    }

    @Test
    void getDated() {
        tickerData = new TickerData();
        Timestamp tscurrent = Timestamp.from(Instant.now());
        tickerData.setDated(tscurrent);
        Assertions.assertEquals(tscurrent, tickerData.getDated());
    }

    @Test
    void getHigh() {
        tickerData = new TickerData();
        BigDecimal b = BigDecimal.valueOf(1234.5);
        tickerData.setHigh(BigDecimal.valueOf(1234.5));
        Assertions.assertEquals(b, tickerData.getHigh());
    }

    @Test
    void getClose() {
        tickerData = new TickerData();
        BigDecimal b = BigDecimal.valueOf(1231.5);
        tickerData.setClose(BigDecimal.valueOf(1231.5));
        Assertions.assertEquals(b, tickerData.getClose());
    }

    @Test
    void getLow() {
        tickerData = new TickerData();
        BigDecimal b = BigDecimal.valueOf(1000.9);
        tickerData.setLow(BigDecimal.valueOf(1000.9));
        Assertions.assertEquals(b, tickerData.getLow());
    }

    @Test
    void getOpen() {
        tickerData = new TickerData();
        BigDecimal b = BigDecimal.valueOf(1231.5);
        tickerData.setOpen(BigDecimal.valueOf(1231.5));
        Assertions.assertEquals(b, tickerData.getOpen());
    }

    @Test
    void getVolume() {
        tickerData = new TickerData();
        long val = 27893030L;
        BigInteger volume = BigInteger.valueOf(val);
        tickerData.setVolume(BigInteger.valueOf(val));
        Assertions.assertNotNull(tickerData.getVolume());
    }

    @Test
    void testEquals() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Boolean expected = true;
        Boolean actual = t1.equals(t2);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testReferenceEquals() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerData t2 = t1;
        Assertions.assertEquals(true, t1.equals(t2));
    }

    @Test
    void testNullEqual() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Assertions.assertEquals(false, t1.equals(null));
    }

    @Test
    void testClassNotEquals() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        WatchlistData watchlistData = new WatchlistData();
        Assertions.assertEquals(false, t1.equals(watchlistData));
    }

    @Test
    void testHashCode() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Boolean expected = true;
        Boolean actual = t1.hashCode() == t2.hashCode();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testToString() {
        TickerData t1 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        String expectedTickerDto = "TickerData{" +
                "stockHistoricalDataId=" + t1.getStockHistoricalDataId() +
                ", dated=" + t1.getDated() +
                ", tickerId='" + t1.getTickerId() + '\'' +
                ", high=" + t1.getHigh() +
                ", close=" + t1.getClose() +
                ", low=" + t1.getLow() +
                ", open=" + t1.getOpen() +
                ", volume=" + t1.getVolume() +
                '}';
        Assertions.assertEquals(expectedTickerDto, t1.toString());
    }
}
