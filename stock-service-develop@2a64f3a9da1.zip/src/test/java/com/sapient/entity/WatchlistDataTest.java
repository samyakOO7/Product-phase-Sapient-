package com.sapient.entity;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;

@DisplayName("Watchlist data test")
public class WatchlistDataTest {

    @Test
    public void testEquals() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        WatchlistData w2 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        Boolean expected = true;
        Boolean actual = w1.equals(w2);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testNullClass() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        Assertions.assertEquals(false, w1.equals(null));
    }

    @Test
    public void testEqualReference() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        WatchlistData w2 = w1;
        Boolean expected = true;
        Assertions.assertEquals(expected, w1.equals(w2));
    }

    @Test
    public void testDifferentClass() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        TickerData t2 = new TickerData(BigInteger.ONE, Timestamp.from(Instant.now()), "INFY.NS", BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigDecimal.valueOf(1234.5), BigInteger.valueOf(27893030));
        Boolean expected = false;
        Boolean actual = w1.equals(t2);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testHashCode() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        WatchlistData w2 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        Boolean expected = true;
        Boolean actual = w1.hashCode() == w2.hashCode();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testToString() {
        WatchlistData w1 = new WatchlistData("INFY.NS", BigDecimal.valueOf(10.2), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), BigDecimal.valueOf(1234.6), 53636L, BigDecimal.valueOf(12.5));
        String expectedWatchlist = "WatchlistData{" +
                "symbol='" + w1.getSymbol() + '\'' +
                ", price=" + w1.getPrice() +
                ", open=" + w1.getOpen() +
                ", previousClose=" + w1.getPreviousClose() +
                ", dayLow=" + w1.getDayLow() +
                ", dayHigh=" + w1.getDayHigh() +
                ", volume=" + w1.getVolume() +
                ", changeInPercent=" + w1.getChangeInPercent() +
                '}';
        Assertions.assertEquals(expectedWatchlist, w1.toString());
    }

    @Test
    public void getSymbol() {
        WatchlistData watchlistData = new WatchlistData();
        String s = "RELIANCE.NS";
        watchlistData.setSymbol(s);
        Assertions.assertEquals(s, watchlistData.getSymbol());
    }

    @Test
    public void getPrice() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(100.2);
        watchlistData.setPrice(b);
        Assertions.assertEquals(b, watchlistData.getPrice());
    }

    @Test
    public void getOpen() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(100.2);
        watchlistData.setOpen(b);
        Assertions.assertEquals(b, watchlistData.getOpen());
    }

    @Test
    public void getPreviousClose() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(100.2);
        watchlistData.setPreviousClose(b);
        Assertions.assertEquals(b, watchlistData.getPreviousClose());
    }

    @Test
    public void getDayLow() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(90.2);
        watchlistData.setDayLow(b);
        Assertions.assertEquals(b, watchlistData.getDayLow());
    }

    @Test
    public void getDayHigh() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(1000.2);
        watchlistData.setDayHigh(b);
        Assertions.assertEquals(b, watchlistData.getDayHigh());
    }

    @Test
    public void getVolume() {
        WatchlistData watchlistData = new WatchlistData();
        Long vol = 53434L;
        watchlistData.setVolume(vol);
        Assertions.assertEquals(vol, watchlistData.getVolume());
    }

    @Test
    public void getChangeInPercent() {
        WatchlistData watchlistData = new WatchlistData();
        BigDecimal b = BigDecimal.valueOf(5.2);
        watchlistData.setChangeInPercent(b);
        Assertions.assertEquals(b, watchlistData.getChangeInPercent());
    }
}