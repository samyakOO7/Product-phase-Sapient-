package com.sapient.entity;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;


@DisplayName("price data test")
public class PriceDataTest {
    private PriceData priceData;

    @BeforeEach
    public void loadPricedata() {
    }

    @Test
    public void testEquals() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        PriceData priceData1 = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        Boolean expected = true;
        Boolean actual = priceData1.equals(priceData);
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testReferenceEquals() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        PriceData priceData1 = priceData;
        Assertions.assertEquals(true, priceData.equals(priceData1));
    }

    @Test
    public void testForNullClass() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        Assertions.assertEquals(false, priceData.equals(null));
    }

    @Test
    public void testForDifferentClass() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        TickerData tickerData = new TickerData();
        Assertions.assertEquals(false, priceData.equals(tickerData));
    }

    @Test
    public void testHashCode() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        PriceData priceData1 = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        Boolean expected = true;
        Boolean actual = priceData1.hashCode() == priceData.hashCode();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    public void testToString() {
        priceData = new PriceData("HDFC.NS", Timestamp.from(Instant.now()), Timestamp.from(Instant.now()), BigDecimal.valueOf(2328.8));
        String expected = "PriceData{" +
                "symbol='" + priceData.getSymbol() + '\'' +
                ", generationTime=" + priceData.getGenerationTime() +
                ", expirationTime=" + priceData.getExpirationTime() +
                ", price=" + priceData.getPrice() +
                '}';
        Assertions.assertEquals(expected, priceData.toString());
    }

    @Test
    public void getSymbol() {
        priceData = new PriceData();
        priceData.setSymbol("INFY.NS");
        Assertions.assertEquals("INFY.NS", priceData.getSymbol());
    }

    @Test
    public void getGenerationTime() {
        priceData = new PriceData();
        priceData.setGenerationTime(Timestamp.from(Instant.now()));
        Assertions.assertNotNull(priceData.getGenerationTime());
    }

    @Test
    public void getExpirationTime() {
        priceData = new PriceData();
        priceData.setExpirationTime(Timestamp.from(Instant.now()));
        Assertions.assertNotNull(priceData.getExpirationTime());
    }

    @Test
    public void getPrice() {
        priceData = new PriceData();
        priceData.setPrice(BigDecimal.TEN);
        Assertions.assertNotNull(priceData.getPrice());
    }
}