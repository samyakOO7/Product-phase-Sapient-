package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WatchlistData {
    String symbol;
    BigDecimal price;
    BigDecimal open;
    BigDecimal previousClose;
    BigDecimal dayLow;
    BigDecimal dayHigh;
    Long volume;
    BigDecimal changeInPercent;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WatchlistData that = (WatchlistData) o;
        return symbol.equals(that.symbol);
    }

    @Override
    public int hashCode() {
        return Objects.hash(symbol);
    }

    @Override
    public String toString() {
        return "WatchlistData{" +
                "symbol='" + symbol + '\'' +
                ", price=" + price +
                ", open=" + open +
                ", previousClose=" + previousClose +
                ", dayLow=" + dayLow +
                ", dayHigh=" + dayHigh +
                ", volume=" + volume +
                ", changeInPercent=" + changeInPercent +
                '}';
    }


}
