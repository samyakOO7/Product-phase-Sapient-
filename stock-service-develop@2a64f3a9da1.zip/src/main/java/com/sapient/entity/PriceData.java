package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

@Data
@Entity(name = "current_price_data")
@AllArgsConstructor
@NoArgsConstructor
public class PriceData {
    @Id
    private String symbol;
    private Timestamp generationTime;
    private Timestamp expirationTime;
    private BigDecimal price;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        var priceData = (PriceData) o;
        return symbol.equals(priceData.symbol);
    }

    @Override
    public int hashCode() {
        return Objects.hash(symbol);
    }

    @Override
    public String toString() {
        return "PriceData{" +
                "symbol='" + symbol + '\'' +
                ", generationTime=" + generationTime +
                ", expirationTime=" + expirationTime +
                ", price=" + price +
                '}';
    }
}
