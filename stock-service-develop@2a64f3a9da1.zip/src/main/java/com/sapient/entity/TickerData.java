package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Objects;

@Data
@Entity(name = "stock_historical_data")
@AllArgsConstructor
@NoArgsConstructor
public class TickerData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stock_generator")
    @SequenceGenerator(name = "stock_generator", sequenceName = "stock_id_gen", allocationSize = 1)
    private BigInteger stockHistoricalDataId;
    private Timestamp dated;
    private String tickerId;
    private BigDecimal high;
    private BigDecimal close;
    private BigDecimal low;
    private BigDecimal open;
    private BigInteger volume;

    @Override
    public String toString() {
        return "TickerData{" +
                "stockHistoricalDataId=" + stockHistoricalDataId +
                ", dated=" + dated +
                ", tickerId='" + tickerId + '\'' +
                ", high=" + high +
                ", close=" + close +
                ", low=" + low +
                ", open=" + open +
                ", volume=" + volume +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TickerData that = (TickerData) o;
        return tickerId.equals(that.tickerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerId);
    }
}
