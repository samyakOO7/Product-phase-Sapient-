package com.sapient.config;

import brave.sampler.Sampler;
import com.sapient.util.CalendarService;
import com.sapient.util.CalendarServiceImpl;
import lombok.Generated;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.text.SimpleDateFormat;

@Configuration
@Generated
public class DateConfiguration {

    @Bean
    public SimpleDateFormat dateFormat() {
        return new SimpleDateFormat("yyyy-MM-dd");
    }

    @Bean
    @Generated
    public CalendarService getCalendar() {
        return new CalendarServiceImpl();
    }

    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }
}
