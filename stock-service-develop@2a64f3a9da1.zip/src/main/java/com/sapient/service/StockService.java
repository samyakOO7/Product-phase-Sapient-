package com.sapient.service;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.WatchlistData;
import org.hibernate.JDBCException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface StockService {
    List<TickerDataDto> getHistoricalData(String tickerSymbol) throws IOException, JDBCException;

    BigDecimal getCurrentPrice(String tickerSymbol) throws IOException;

    WatchlistData getUpdatedWatchlistForStock(String tickerSymbol) throws IOException;

    List<TickerDataDto> getFiveDaysData(String tickerSymbol) throws IOException;
}
