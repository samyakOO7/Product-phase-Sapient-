package com.sapient.service;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.PriceData;
import com.sapient.entity.TickerData;
import com.sapient.entity.WatchlistData;
import com.sapient.mapper.TickerMapper;
import com.sapient.repository.PriceRepository;
import com.sapient.repository.StockRepository;
import com.sapient.util.CalendarService;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;
import yahoofinance.quotes.stock.StockQuote;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
@Generated
public class StockServiceImpl implements StockService {

    List<TickerData> tickerData;
    List<TickerDataDto> tickerDataDto;
    TickerData dto;

    @Autowired
    CalendarService calendarService;
    @Autowired
    TickerMapper tickerMapper;
    @Autowired
    StockRepository stockRepository;
    @Autowired
    PriceRepository priceRepository;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Retry(name = "myRetry", fallbackMethod = "fallback")
    public List<TickerDataDto> getHistoricalData(String tickerSymbol) throws IOException {
        tickerData = new ArrayList<>();
        tickerDataDto = new ArrayList<>();
        if (!stockRepository.findByTickerId(tickerSymbol).isEmpty()) {
            tickerData = stockRepository.findByTickerId(tickerSymbol);
            log.info("ticker fetched for {} from stock-database", tickerSymbol);
            try {
                dto = getCurrentMetricsUpdated(calendarService.getToDate(), calendarService.getToDate(), tickerSymbol);
                tickerData.add(dto);
                return mapTickerListToDto(tickerData.stream().filter(tickerData1 -> tickerData1.getOpen() != null).collect(Collectors.toList()));
            } catch (IOException e) {
                return mapTickerListToDto(tickerData.stream().filter(tickerData2 -> tickerData2.getOpen() != null).collect(Collectors.toList()));
            }
        }
        var to = calendarService.getToDate();
        to.add(Calendar.DAY_OF_MONTH, -1);
        var from = calendarService.getFromDate(25);
        List<HistoricalQuote> stockHistQuotes = getStockHistory(from, to, tickerSymbol);
        for (HistoricalQuote hs : stockHistQuotes) {
            var t = tickerMapper.getTickerMapper(hs);
            tickerDataDto.add(t);
            stockRepository.save(tickerMapper.mappingTickerClass(t));
        }
        try {
            dto = getCurrentMetricsUpdated(calendarService.getToDate(), calendarService.getToDate(), tickerSymbol);
            tickerDataDto.add(tickerMapper.getDtoMapper(dto));
            log.info("fetched for tickerId {} from yahoo_finance_API", tickerSymbol);
            return tickerDataDto.stream().filter(tickerDataDto1 -> tickerDataDto1.getOpen() != null).collect(Collectors.toList());
        } catch (IOException e) {
            return tickerDataDto.stream().filter(tickerDataDto1 -> tickerDataDto1.getOpen() != null).collect(Collectors.toList());
        }
    }

    private TickerData getCurrentMetricsUpdated(Calendar toDate, Calendar toDate1, String tickerSymbol) throws IOException {
        List<HistoricalQuote> stockHistQuotes = getStockHistory(toDate, toDate1, tickerSymbol);
        var hsQuotes = stockHistQuotes.get(0);
        var t = tickerMapper.getTickerMapper(hsQuotes);
        return tickerMapper.mappingTickerClass(t);
    }

    private List<TickerDataDto> mapTickerListToDto(List<TickerData> tickerData) {
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>();
        for (TickerData t : tickerData) {
            tickerDataDtoList.add(tickerMapper.getDtoMapper(t));
        }
        return tickerDataDtoList;
    }

    private List<HistoricalQuote> getStockHistory(Calendar from, Calendar to, String tickerSymbol) throws IOException {
        var stock = YahooFinance.get(tickerSymbol);
        return stock.getHistory(from, to, Interval.DAILY);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Retry(name = "priceRetry", fallbackMethod = "fallbackCurrent")
    @Generated
    public BigDecimal getCurrentPrice(String tickerSymbol) throws IOException {
        Optional<PriceData> priceData = priceRepository.findById(tickerSymbol);
        if (priceData.isPresent() && !checkExpirationTime(priceData.get().getExpirationTime())) {
            if (priceData.get().getPrice() != null) {
                return priceData.get().getPrice();
            }
            return BigDecimal.valueOf(0);
        }
        var stock = YahooFinance.get(tickerSymbol);
        var priceData1 = new PriceData();
        priceData1.setSymbol(tickerSymbol);
        priceData1.setPrice(stock.getQuote(true).getPrice());
        priceData1.setGenerationTime(Timestamp.from(Instant.now()));
        priceData1.setExpirationTime(new Timestamp(priceData1.getGenerationTime().getTime() + 300000));
        priceRepository.save(priceData1);
        log.info("ticker symbol saved {}", tickerSymbol);
        if (priceData1.getPrice() != null) {
            return priceData1.getPrice();
        }
        return BigDecimal.valueOf(0);
    }

    private boolean checkExpirationTime(Timestamp expirationTime) {
        return expirationTime.before(Timestamp.from(Instant.now()));
    }

    public StockQuote getQuote(String tickerSymbol) throws IOException {
        var stock = YahooFinance.get(tickerSymbol);
        return stock.getQuote();
    }

    @Retry(name = "watchlistRetry", fallbackMethod = "fallbackQuote")
    public WatchlistData getUpdatedWatchlistForStock(String tickerSymbol) throws IOException {
        var stockQuote = getQuote(tickerSymbol);
        log.info("Stock Quote for {} fetched for Updated Watchlist", tickerSymbol);
        return tickerMapper.getCurrentQuote(stockQuote);
    }

    @Override
    @Generated
    @Retry(name = "latestRetry", fallbackMethod = "fallbackLatestData")
    public List<TickerDataDto> getFiveDaysData(String tickerSymbol) throws IOException {
        tickerDataDto = new ArrayList<>();
        var to = calendarService.getToDate();
        var from = calendarService.getFromDate(5);
        List<HistoricalQuote> stockHistQuotes = getStockHistory(from, to, tickerSymbol);
        for (HistoricalQuote hs : stockHistQuotes) {
            TickerDataDto t = tickerMapper.getTickerMapper(hs);
            tickerDataDto.add(t);
        }
        return tickerDataDto;
    }

    //Handling fallback methods
    @Generated
    public List<TickerDataDto> fallback(String tickerSymbol, Throwable e) {
        log.error("exception in getHistoricalData()", e);
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>();
        for (var i = 0; i < 25; i++) {
            tickerDataDtoList.add(new TickerDataDto(Timestamp.from(Instant.now()), tickerSymbol, BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigInteger.valueOf(0)));
        }
        return tickerDataDtoList;
    }

    @Generated
    public BigDecimal fallbackCurrent(String tickerSymbol, Throwable t) {
        log.error("exception in getCurrentPrice()", t);
        Optional<PriceData> priceData = priceRepository.findById(tickerSymbol);
        if (priceData.isPresent()) {
            return priceData.get().getPrice(); //return old price if present in table already for the case, time expires
        }
        return BigDecimal.valueOf(0);
    }

    @Generated
    public WatchlistData fallbackQuote(String tickerSymbol, Throwable t) {
        log.error("exception in getUpdatedWatchlistForStock()", t);
        Optional<PriceData> priceData = priceRepository.findById(tickerSymbol);
        if (priceData.isPresent()) {
            var p = priceData.get();
            return new WatchlistData(tickerSymbol, p.getPrice(), p.getPrice(), p.getPrice(), p.getPrice(), p.getPrice(), 0L, BigDecimal.valueOf(0.0));
        }
        return new WatchlistData(tickerSymbol, BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), 0L, BigDecimal.valueOf(0));
    }

    @Generated
    public List<TickerDataDto> fallbackLatestData(String tickerSymbol, Throwable e) {
        log.error("exception in getFiveDaysData()", e);
        List<TickerDataDto> tickerDataDtoList = new ArrayList<>();
        for (var i = 0; i < 5; i++) {
            tickerDataDtoList.add(new TickerDataDto(new Timestamp(Timestamp.from(Instant.now()).getTime() + 604800000), tickerSymbol, BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigDecimal.valueOf(0), BigInteger.valueOf(0)));
        }
        return tickerDataDtoList;
    }
}
