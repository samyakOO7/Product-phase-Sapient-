package com.sapient.service;

import com.sapient.exception.EmptyListOfTickersException;

import java.io.IOException;

public interface DatabaseCronJobService {

    void getDatabaseScheduled() throws IOException, EmptyListOfTickersException;
}
