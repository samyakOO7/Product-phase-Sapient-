package com.sapient.service;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.TickerData;
import com.sapient.exception.EmptyListOfTickersException;
import com.sapient.mapper.TickerMapper;
import com.sapient.repository.StockRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class DatabaseCronJobServiceImpl implements DatabaseCronJobService {
    @Autowired
    StockRepository stockRepository;
    @Autowired
    StockService stockService;
    @Autowired
    SimpleDateFormat format;
    @Autowired
    TickerMapper mapper;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    @Scheduled(cron = "0 0 19 * * 1-5")
    public void getDatabaseScheduled() throws IOException, EmptyListOfTickersException {
        List<String> tickerIdList = stockRepository.findDistinctTickerId();
        if (tickerIdList.isEmpty()) {
            log.error("exception in getDatabaseScheduled() {}", EmptyListOfTickersException.class);
            throw new EmptyListOfTickersException("No tickers in the list");
        }
        for (String t : tickerIdList) {
            List<TickerDataDto> tickerDataDtoList = stockService.getFiveDaysData(t);
            if (testWithCurrentDate(tickerDataDtoList)) {
                List<TickerData> tickerData = stockRepository.findByTickerId(t);
                stockRepository.deleteById(tickerData.get(0).getStockHistoricalDataId());
                var dto = tickerDataDtoList.get(tickerDataDtoList.size() - 1);
                stockRepository.save(mapper.mappingTickerClass(dto));
                log.info("updated in stock database for {}", t);
            }
        }
    }


    private boolean testWithCurrentDate(List<TickerDataDto> tickerDataDtoList) {
        var dataDto = tickerDataDtoList.get(tickerDataDtoList.size() - 1);
        format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(dataDto.getDated().getTime());
        var current = new Timestamp(new Date().getTime());
        String dateCurrent = format.format(current);
        boolean anotherCheck = (stockRepository.findByTickerId(dataDto.getTickerId()).stream().anyMatch(tickerData -> format.format(tickerData.getDated().getTime()).equals(dateCurrent)));
        return dateCurrent.equals(date) && (!anotherCheck);
    }
}
