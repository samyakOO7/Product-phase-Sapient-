package com.sapient.mapper;

import com.sapient.dto.TickerDataDto;
import com.sapient.entity.TickerData;
import com.sapient.entity.WatchlistData;
import lombok.Generated;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.quotes.stock.StockQuote;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

@Component
@Generated
public class TickerMapper {

    @Autowired
    SimpleDateFormat format1;

    public TickerDataDto getTickerMapper(HistoricalQuote hs) {
        var stockData = new TickerDataDto();
        stockData.setTickerId(hs.getSymbol());
        stockData.setClose(hs.getClose());
        stockData.setHigh(hs.getHigh());
        stockData.setLow(hs.getLow());
        stockData.setOpen(hs.getOpen());
        stockData.setVolume(BigInteger.valueOf(hs.getVolume()));
        Calendar date = hs.getDate();
        stockData.setDated(new Timestamp(date.getTimeInMillis()));
        return stockData;
    }

    public TickerDataDto getDtoMapper(TickerData tickerData) {
        var stockData = new TickerDataDto();
        stockData.setTickerId(tickerData.getTickerId());
        stockData.setClose(tickerData.getClose());
        stockData.setHigh(tickerData.getHigh());
        stockData.setLow(tickerData.getLow());
        stockData.setOpen(tickerData.getOpen());
        stockData.setVolume(tickerData.getVolume());
        stockData.setDated(tickerData.getDated());
        return stockData;
    }

    public TickerData mappingTickerClass(TickerDataDto tickerDataDto) {
        var modelMapper = new ModelMapper();
        return modelMapper.map(tickerDataDto, TickerData.class);

    }

    public WatchlistData getCurrentQuote(StockQuote s) {
        var watchlistData = new WatchlistData();
        watchlistData.setOpen(s.getOpen());
        watchlistData.setSymbol(s.getSymbol());
        watchlistData.setChangeInPercent(s.getChangeInPercent());
        watchlistData.setVolume(s.getVolume());
        watchlistData.setDayHigh(s.getDayHigh());
        watchlistData.setDayLow(s.getDayLow());
        watchlistData.setPreviousClose(s.getPreviousClose());
        watchlistData.setPrice(s.getPrice());
        return watchlistData;
    }
}
