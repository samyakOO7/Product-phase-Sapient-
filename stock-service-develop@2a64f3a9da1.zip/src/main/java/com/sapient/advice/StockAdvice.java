package com.sapient.advice;

import com.sapient.util.JsonResponse;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.TransactionException;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.MethodNotAllowedException;

import java.io.IOException;
import java.net.ProtocolException;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

@RestControllerAdvice
@Slf4j
public class StockAdvice {

    private static final String MESSAGE = "message";
    private static final String SERVERMESSAGE="INTERNAL_SERVER_ERROR";
    Map<String, String> mp;


    @ExceptionHandler(IOException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Map<String, String> returnErrorAboutIOException(IOException ex) {
        log.error("IO exception occured", ex);
        return JsonResponse.setErrors("IO_EXCEPTION", "Failed to get data from ticker symbol");

    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @Generated
    public Map<String, String> handleExceptions(Exception ex) {
        return getMessage(ex.getMessage());
    }

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @Generated
    public Map<String, String> elementNotPresent(NoSuchElementException ex) {
        log.error("NoSuchElementException", ex);
        return JsonResponse.setErrors(SERVERMESSAGE, "Element not exists");
    }

    @Generated
    public Map<String, String> getMessage(String message) {
        mp = new HashMap<>();
        mp.put(MESSAGE, message);
        return mp;
    }

    @ExceptionHandler(JDBCConnectionException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @Generated
    public Map<String, String> handleJdbcConnectionFailure(JDBCConnectionException ex) {
        log.error("JDBC Connection exception occured", ex);
        return JsonResponse.setErrors(SERVERMESSAGE, "Database Connection Failed");
    }

    @ExceptionHandler(MethodNotAllowedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ResponseBody
    @Generated
    public Map<String, String> returnMethodNotAllowed(MethodNotAllowedException ex) {
        return JsonResponse.setErrors("METHOD_NOT_ALLOWED", "Method is not allowed");
    }

    @ExceptionHandler(ProtocolException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ResponseBody
    @Generated
    public Map<String, String> returnInvalidHttpMethod(ProtocolException ex) {
        return JsonResponse.setErrors("METHOD_NOT_ALLOWED", "Http Method is invalid");
    }

    @ExceptionHandler(TransactionException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @Generated
    public Map<String, String> returnTransactionFailed(TransactionException ex) {
        log.error("Transaction exception occured", ex);
        return JsonResponse.setErrors(SERVERMESSAGE, "Inconsistency or Transactional failure encountered");
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    @Generated
    public Map<String, String> returnIllegalArguments(IllegalArgumentException ex) {
        return JsonResponse.setErrors("Bad_Request", "Illegal Arguments provided");
    }
}