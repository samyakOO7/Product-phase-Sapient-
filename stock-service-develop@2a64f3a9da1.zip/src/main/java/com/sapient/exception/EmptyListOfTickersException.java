package com.sapient.exception;

public class EmptyListOfTickersException extends Exception {

    public EmptyListOfTickersException(String tickersMessage) {
        super(tickersMessage);
    }
}
