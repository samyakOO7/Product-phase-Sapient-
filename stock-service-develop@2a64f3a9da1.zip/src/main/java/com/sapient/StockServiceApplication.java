package com.sapient;

import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.TimeZone;

@SpringBootApplication
@EnableScheduling
@EnableAutoConfiguration
@Slf4j
@Generated
public class StockServiceApplication {

	@Generated
	public static void main(String[] args) {
		System.setProperty("user.timezone", "Asia/Kolkata");
		TimeZone.setDefault(null);
		log.debug("Current timestamp {}",Timestamp.from(Instant.now()));
		SpringApplication.run(StockServiceApplication.class, args);
	}

}
