package com.sapient.util;

import java.util.Calendar;

public interface CalendarService {

    Calendar getFromDate(int i);
    Calendar getToDate();
}
