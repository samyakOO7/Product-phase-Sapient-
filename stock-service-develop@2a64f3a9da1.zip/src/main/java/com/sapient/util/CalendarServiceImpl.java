package com.sapient.util;

import lombok.Generated;
import lombok.extern.slf4j.Slf4j;

import java.util.Calendar;

@Slf4j
public class CalendarServiceImpl implements CalendarService {

    @Generated
    public Calendar getFromDate(int i) {
        var from = Calendar.getInstance();
        var workDays = 0;
        do {
            from.add(Calendar.DAY_OF_MONTH, -1);
            if (from.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
                    && from.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                ++workDays;
            }
        } while (workDays <= i-1);
        return from;
    }

    public Calendar getToDate() {
        return Calendar.getInstance();
    }

}
