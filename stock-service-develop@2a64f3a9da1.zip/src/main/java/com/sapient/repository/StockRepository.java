package com.sapient.repository;

import com.sapient.entity.TickerData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface StockRepository extends JpaRepository<TickerData, BigInteger> {

    public List<TickerData> findByTickerId(String tickerSymbol);

    @Query(value = "select distinct ticker_id from stock_historical_data", nativeQuery = true)
    public List<String> findDistinctTickerId();
}
