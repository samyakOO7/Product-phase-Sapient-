package com.sapient.controller;

import com.sapient.dto.TickerDataDto;
import com.sapient.service.StockService;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class StockController {

    @Autowired
    StockService stockService;

    @GetMapping(value = "/{tickerId}", produces = "application/json")
    @ResponseBody
    public ResponseEntity<Map<String, BigDecimal>> getCurrentPrice(@PathVariable("tickerId") String tickerSymbol) throws IOException {
        BigDecimal price = stockService.getCurrentPrice(tickerSymbol);
        Map<String, BigDecimal> map = new HashMap<>();
        map.put("price_per_stock", price);
        return ResponseEntity.ok(map);
    }

    @Generated
    @GetMapping(value = "/watchlist/{tickerId}", produces = "application/json")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getStockValues(@PathVariable("tickerId") String tickerSymbol) throws IOException {
        var watchlistData = stockService.getUpdatedWatchlistForStock(tickerSymbol);
        Map<String, Object> map = new HashMap<>();
        map.put("watchlist", watchlistData);
        return ResponseEntity.ok(map);
    }

    @GetMapping(value = "/history/{tickerId}", produces = "application/json")
    @ResponseBody
    public ResponseEntity<Map<String, List<TickerDataDto>>> getHistoricalValues(@PathVariable("tickerId") String tickerSymbol) throws IOException {
        List<TickerDataDto> tickerDataDtoList = stockService.getHistoricalData(tickerSymbol);
        Map<String, List<TickerDataDto>> map = new HashMap<>();
        map.put("historical", tickerDataDtoList);
        return ResponseEntity.ok(map);
    }
}
