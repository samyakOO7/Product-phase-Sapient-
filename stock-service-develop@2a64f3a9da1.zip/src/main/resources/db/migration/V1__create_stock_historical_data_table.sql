create table stock_historical_data(
    stock_historical_data_id bigint primary key,
    dated timestamp not null,
    ticker_id varchar(50) not null,
    high numeric(19,4),
    close numeric(19,4),
    low numeric(19,4),
    open numeric(19,4),
    volume bigint
);
