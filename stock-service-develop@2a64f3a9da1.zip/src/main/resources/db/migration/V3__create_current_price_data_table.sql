create table current_price_data(
    symbol varchar(50) primary key,
    generation_time timestamp not null,
    expiration_time timestamp not null,
    price numeric(19,4)
)