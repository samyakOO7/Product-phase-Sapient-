package com.sapient.config;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource("classpath:application.properties")
class MailDtoConfigurationTest {
    ApplicationContextRunner context = new ApplicationContextRunner().withUserConfiguration(MailConfiguration.class).withPropertyValues("cloud.aws.region.static=us-east-1", "cloud.aws.credentials.secret-key=test12345", "cloud.aws.credentials.access-key=test123456");

    @Test
    void checkBean() {
        context.run(it -> {
            Assertions.assertThat(it).hasBean("amazonSimpleEmailService").hasBean("javaMailSender");
        });
    }

}