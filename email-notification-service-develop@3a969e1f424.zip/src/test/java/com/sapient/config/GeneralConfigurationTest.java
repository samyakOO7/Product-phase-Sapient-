package com.sapient.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;


class GeneralConfigurationTest {
    ApplicationContextRunner context=new ApplicationContextRunner().withUserConfiguration(GeneralConfiguration.class);
    @Test
     void checkBean()
    {
        context.run(it->{
            Assertions.assertThat(it).hasSingleBean(ObjectMapper.class);
        });
    }

}