package com.sapient.config;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class KafkaConsumerConfigurationTest {
    ApplicationContextRunner context=new ApplicationContextRunner().withUserConfiguration(KafkaConsumerConfiguration.class).withPropertyValues("spring.kafka.bootstrap-servers=localhost:9901");
    @Test
    void checkBean()
    {
        context.run(it->{
            Assertions.assertThat(it).hasBean("consumerConfigs").hasBean("consumerFactory").hasBean("kafkaListenerContainerFactory");
        });
    }
}