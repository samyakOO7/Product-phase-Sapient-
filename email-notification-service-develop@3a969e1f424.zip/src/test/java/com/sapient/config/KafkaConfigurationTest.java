package com.sapient.config;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource("classpath:application.properties")
class KafkaConfigurationTest {
    ApplicationContextRunner context=new ApplicationContextRunner().withUserConfiguration(KafkaConfiguration.class).withPropertyValues("kafka.partitions=1");
    @Test void checkBean()
    {
        context.run(it->{
            Assertions.assertThat(it).hasBean("getSignUpTopic").hasBean("getResetPasswordTopic").hasBean("getTradeAlertsTopic").hasBean("getSellConfirmationTopic");
        });
    }

}