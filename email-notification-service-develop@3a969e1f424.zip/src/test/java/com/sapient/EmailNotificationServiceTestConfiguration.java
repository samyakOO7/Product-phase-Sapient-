package com.sapient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.service.*;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.thymeleaf.spring5.SpringTemplateEngine;

@TestConfiguration
public class EmailNotificationServiceTestConfiguration {

    @Bean
    public ObjectMapper getObjectMapper()
    {
        return new ObjectMapper();
    }
    @Bean
    public ConversionService getConversionService(){
        return new ConversionServiceImpl();
    }
    @Bean
    public KafkaConsumerService getKafkaConsumerService(){
        return new KafkaConsumerServiceImpl();
    }
    @Bean
    public JavaMailSender getJavaMailSender(){
        return new JavaMailSenderImpl();
    }
    @Bean
    public SpringTemplateEngine getSpringTemplateEngine(){
        return new SpringTemplateEngine();
    }
    @Bean
    public MessageService getMessageService(){
        return new MessageServiceImpl();
    }
}
