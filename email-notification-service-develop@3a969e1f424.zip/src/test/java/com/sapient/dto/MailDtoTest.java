package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

@ExtendWith(SpringExtension.class)
class MailDtoTest {

    MailDto mailDto;

    @BeforeEach
    void setup() {
        mailDto = new MailDto();
    }

    @Test
    @DisplayName("Test get email from")
    void getFrom() {
        String emailFrom = "test@test.com";
        ReflectionTestUtils.setField(mailDto, "from", emailFrom);
        Assertions.assertEquals(emailFrom, mailDto.getFrom());
    }

    @Test
    @DisplayName("Test get email to")
    void getTo() {
        String emailTo = "test@test.com";
        ReflectionTestUtils.setField(mailDto, "to", emailTo);
        Assertions.assertEquals(emailTo, mailDto.getTo());
    }

    @Test
    @DisplayName("Test get email subject")
    void getSubject() {
        String subject = "Sign Up Verification";
        ReflectionTestUtils.setField(mailDto, "subject", subject);
        Assertions.assertEquals(subject, mailDto.getSubject());
    }

    @Test
    @DisplayName("Test get model to be passed into html template")
    void getModel() {
        Map<String, Object> model = new HashMap<>();
        model.put("name", "sapient");
        ReflectionTestUtils.setField(mailDto, "model", model);
        Assertions.assertEquals(model, mailDto.getModel());
    }

    @Test
    @DisplayName("Test set email from")
    void setFrom() {
        String expected = "test2@test.com";
        mailDto.setFrom(expected);
        String actual = (String) ReflectionTestUtils.getField(mailDto, "from");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test set email to")
    void setTo() {
        String expected = "test2@test.com";
        mailDto.setTo(expected);
        String actual = (String) ReflectionTestUtils.getField(mailDto, "to");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test set email subject")
    void setSubject() {
        String expected = "Tradezy";
        mailDto.setSubject(expected);
        String actual = (String) ReflectionTestUtils.getField(mailDto, "subject");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    @DisplayName("Test set model to be passed into html template")
    void setModel() {
        Map<String, Object> modelExp = new HashMap<>();
        modelExp.put("name", "sapient");
        mailDto.setModel(modelExp);
        Map<String, Object> modelAct = (HashMap<String, Object>) ReflectionTestUtils.getField(mailDto, "model");
        Assertions.assertEquals(modelExp, modelAct);
    }
}