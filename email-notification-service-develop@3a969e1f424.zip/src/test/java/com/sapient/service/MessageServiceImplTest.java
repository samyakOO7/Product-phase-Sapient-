package com.sapient.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.EmailNotificationServiceTestConfiguration;
import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.MailDto;
import com.sapient.dto.SellConfirmDto;
import com.sapient.dto.TradeAlertDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@Import(EmailNotificationServiceTestConfiguration.class)
@TestPropertySource("classpath:application.properties")
class MessageServiceImplTest {

    @Autowired
    MessageServiceImpl messageService;
    @MockBean
    JavaMailSender javaMailSender;
    @MockBean
    SpringTemplateEngine templateEngine;
    @MockBean
    ObjectMapper objectMapper;

    @Test
    @DisplayName("sign up email sent success")
    void sendSignUpMailSuccess() {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "singup mail");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        impl.sendSignUpMail(dto);
        verify(impl).sendSignUpMail(dto);
    }

    @Test
    @DisplayName("sell confirmation email sent success")
    void sendSellConfirmationMailSuccess() {
        SellConfirmDto dto = new SellConfirmDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "sell mail");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        impl.sendSellConfirmationMail(dto);
        verify(impl).sendSellConfirmationMail(dto);
    }

    @Test
    @DisplayName("reset password email sent success")
    void sendResetPasswordMailSuccess() {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "reset password");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        impl.sendResetPasswordMail(dto);
        verify(impl).sendResetPasswordMail(dto);
    }

    @Test
    @DisplayName("trade alert email sent success")
    void sendTradeAlertMailSuccess() {
        TradeAlertDto dto = new TradeAlertDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "trade alert");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        impl.sendTradeAlertMail(dto);
        verify(impl).sendTradeAlertMail(dto);
    }

    @Test
    @DisplayName("sign up email sent failure")
    void sendSignUpMailFailure() {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "singup mail");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        verify(impl, never()).sendSignUpMail(dto);
    }

    @Test
    @DisplayName("sell confirmation email sent success")
    void sendSellConfirmationMailFailure() {
        SellConfirmDto dto = new SellConfirmDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "sell mail");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        verify(impl, never()).sendSellConfirmationMail(dto);
    }

    @Test
    @DisplayName("reset password email sent failure")
    void sendResetPasswordMailFailure() {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "reset password");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        verify(impl, never()).sendResetPasswordMail(dto);
    }


    @Test
    @DisplayName("trade alert email sent failure")
    void sendTradeAlertMailFailure() {
        TradeAlertDto dto = new TradeAlertDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMail(dto, "trade alert");
        doNothing().when(impl).sendEmail(any(MailDto.class), anyString());
        verify(impl, never()).sendTradeAlertMail(dto);
    }

    @Test
    @DisplayName("Get mail success")
    void getMailSuccess() throws JsonProcessingException {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        String subject = "testing";
        when(objectMapper.writeValueAsString(dto)).thenReturn("{ \"email\":\"Test1\" }");
        Map<String, Object> model = new HashMap<>();
        model.put("email", "Test1");
        when(objectMapper.readValue("{ \"email\":\"Test1\" }", Map.class)).thenReturn(model);
        MailDto mailDto = messageService.getMail(dto, subject);
        assertEquals(model, mailDto.getModel());
    }

    @Test
    @DisplayName("Get mail eception when object is converted to jsonString")
    void getMailException1() throws JsonProcessingException {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        String subject = "testing";
        when(objectMapper.writeValueAsString(dto)).thenThrow(new JsonProcessingException("json expection") {
        });
        Map<String, Object> model = new HashMap<>();
        model.put("email", "Test1");
        when(objectMapper.readValue("{ \"email\":\"Test1\" }", Map.class)).thenReturn(model);
        MailDto mailDto = messageService.getMail(dto, subject);
        assertNull(mailDto.getModel());
    }

    @Test
    @DisplayName("Get mail Exception when jsonString is converted to jsonObject")
    void getMailExeception2() throws JsonProcessingException {
        AuthDetailsDto dto = new AuthDetailsDto();
        dto.setEmail("Test1");
        dto.setFirstName("Hii");
        dto.setUrl("www.test.com");
        String subject = "testing";
        when(objectMapper.writeValueAsString(dto)).thenReturn("{ \"email\":\"Test1\" }");
        Map<String, Object> model = new HashMap<>();
        model.put("email", "Test1");
        when(objectMapper.readValue("{ \"email\":\"Test1\" }", Map.class)).thenThrow(new JsonProcessingException("json expection") {
        });
        MailDto mailDto = messageService.getMail(dto, subject);
        assertNull(mailDto.getModel());
    }

    @Test
    @DisplayName("send email success")
    void sendEmailSuccess() throws MessagingException {
        MailDto mailDto = new MailDto();
        mailDto.setTo("tets1@gmail.com");
        mailDto.setFrom("test2@gmail.com");
        mailDto.setSubject("Hii");
        Map<String, Object> model = new HashMap<>();
        model.put("url", "www.test.com");
        mailDto.setModel(model);
        String template = "template";
        MessageServiceImpl impl = Mockito.spy(messageService);
        doReturn(null).when(impl).getMimeMessage(mailDto, template);
        doNothing().when(javaMailSender).send(any(MimeMessage.class));
        impl.sendEmail(mailDto, template);
        verify(impl).sendEmail(mailDto, template);
    }

    @Test
    @DisplayName("send mail exception")
    void sendEmailException() throws MessagingException {
        MailDto mailDto = new MailDto();
        mailDto.setTo("tets1@gmail.com");
        mailDto.setFrom("test2@gmail.com");
        mailDto.setSubject("Hii");
        Map<String, Object> model = new HashMap<>();
        model.put("url", "www.test.com");
        mailDto.setModel(model);
        String template = "template";
        MessageServiceImpl impl = Mockito.spy(messageService);
        doThrow(new MessagingException("invalid mime message")).when(impl).getMimeMessage(any(MailDto.class), anyString());
        impl.sendEmail(mailDto, template);
        String expected = "true";
        String actual = "true";
        assertEquals(expected, actual);

    }
}