package com.sapient.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sapient.EmailNotificationServiceTestConfiguration;
import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.TradeAlertDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@Import(EmailNotificationServiceTestConfiguration.class)
class ConversionServiceImplTest {
    @Autowired
    ConversionService conversionService;
    @Test
    void convertSuccessAuth() throws JSONException, JsonProcessingException {
        String key="abc@hotmail.com";
        JSONObject value= new JSONObject();
        String firstName="george";
        String url="www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email",key);
        value.put("firstName",firstName);
        value.put("url",url);
        AuthDetailsDto expected=new AuthDetailsDto(key,firstName,url);
        AuthDetailsDto actual=conversionService.convert(value.toString(), AuthDetailsDto.class);
        Assertions.assertEquals(expected.toString(),actual.toString());
    }

    @Test
    void convertFailureAuth() throws JSONException {
        String value="dadcdss";
        Assertions.assertThrows(JsonProcessingException.class,()->conversionService.convert(value, AuthDetailsDto.class));
    }
    @Test
    void convertSuccessTradeAlert() throws JSONException,JsonProcessingException{
        String key="abc@hotmail.com";
        JSONObject value= new JSONObject();
        String firstName="george";
        String url="www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        String tickerSymbol="PS";
        String tickerName="Publicis Sapient";
        String direction="BUY";
        String timeframe="1 day";
        String confidenceScore="88";
        String timestamp="24/8/2021 7:00";
        value.put("email",key);
        value.put("firstName",firstName);
        value.put("url",url);
        value.put("tickerSymbol",tickerSymbol);
        value.put("tickerName",tickerName);
        value.put("direction",direction);
        value.put("timeframe",timeframe);
        value.put("confidenceScore",confidenceScore);
        value.put("timestamp",timestamp);
        TradeAlertDto expected=new TradeAlertDto(key,firstName,url,tickerSymbol,tickerName,direction,timeframe,confidenceScore,timestamp);
        TradeAlertDto actual=conversionService.convert(value.toString(), TradeAlertDto.class);
        System.out.println(actual);
        Assertions.assertEquals(actual.toString(),expected.toString());
    }
    @Test
    void convertTradeALertFail() throws JSONException {
        String value="dadcdss";
        Assertions.assertThrows(JsonProcessingException.class,()->conversionService.convert(value, TradeAlertDto.class));
    }
}