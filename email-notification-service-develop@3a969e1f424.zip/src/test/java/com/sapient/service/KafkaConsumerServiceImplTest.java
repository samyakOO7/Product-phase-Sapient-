package com.sapient.service;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.sapient.EmailNotificationServiceTestConfiguration;
import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.SellConfirmDto;
import com.sapient.dto.TradeAlertDto;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
@Import({EmailNotificationServiceTestConfiguration.class})
class KafkaConsumerServiceImplTest {

    @Autowired
    KafkaConsumerService kafkaConsumerService;

    @Autowired
    ConversionService conversionService;

    @MockBean
    MessageService messageService;

    MemoryAppender memoryAppender;

    @BeforeEach
    public void setUpLogger() {
        Logger logger = (Logger) LoggerFactory.getLogger(KafkaConsumerServiceImpl.class);
        memoryAppender = new MemoryAppender();
        memoryAppender.setContext((LoggerContext) LoggerFactory.getILoggerFactory());
        logger.setLevel(Level.TRACE);
        logger.addAppender(memoryAppender);
        memoryAppender.start();
    }

    @Test
    void consumeSignUpSuccess() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSignUp(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
    }

    @Test
    void consumeSellConfirmationSuccess() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/sell-confirmation";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("price", 400.0);
        value.put("timestamp", "2022/10/10 14:58:25");
        value.put("tickerSymbol", "INFY");
        value.put("gain", 5000.05);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSellConfirmation(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
    }

    @Test
    void consumeSellConfirmationFailure() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        String value = "ndfksfnkea";
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value);
        kafkaConsumerService.consumeSellConfirmation(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.contains("com.fasterxml.jackson.core.JsonParseException", Level.ERROR));
        Mockito.verify(messageService, Mockito.times(0)).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
    }

    @Test
    void consumeSignUpConversionFailure() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        String value = "djvnsvdjnvd";
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value);
        kafkaConsumerService.consumeSignUp(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.contains("com.fasterxml.jackson.core.JsonParseException", Level.ERROR));
        //check if mail called or not
        Mockito.verify(messageService, Mockito.times(0)).sendSignUpMail(Mockito.any(AuthDetailsDto.class));

    }

    @Test
    void consumeSignUpMessagingException() throws JsonProcessingException {
        Mockito.doThrow(new AmazonSimpleEmailServiceException("exception")).when(messageService).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSignUp(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
        Assertions.assertEquals(true, memoryAppender.contains("com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException", Level.ERROR));
    }

    @Test
    void consumeSellConfirmationMessagingException() throws JsonProcessingException {
        Mockito.doThrow(new AmazonSimpleEmailServiceException("exception")).when(messageService).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/sell-confirmation";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("price", 400.0);
        value.put("timestamp", "2022/10/10 14:58:25");
        value.put("tickerSymbol", "INFY");
        value.put("gain", 5000.05);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSellConfirmation(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.contains("com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException", Level.ERROR));
    }

    @Test
    void consumeSellConfirmationException() throws JsonProcessingException {
        Mockito.doThrow(new RuntimeException()).when(messageService).sendSellConfirmationMail(Mockito.any(SellConfirmDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/sell-confirmation";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("price", 400.0);
        value.put("timestamp", "2022/10/10 14:58:25");
        value.put("tickerSymbol", "INFY");
        value.put("gain", 5000.05);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSellConfirmation(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.countEventsForLogger("com.sapient") == 2);
    }

    @Test
    void consumeSignUpException() throws JsonProcessingException {
        Mockito.doThrow(new RuntimeException()).when(messageService).sendSignUpMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeSignUp(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.countEventsForLogger("com.sapient") == 2);
    }

    @Test
    void consumeResetPasswordSuccess() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeResetPassword(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
    }

    @Test
    void ResetPasswordConversionFailure() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        String value = "djvnsvdjnvd";
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value);
        kafkaConsumerService.consumeResetPassword(consumerRecord);
        //check if mail called or not
        Mockito.verify(messageService, Mockito.times(0)).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));

    }

    @Test
    void consumeResetPasswordMessagingException() throws JsonProcessingException {
        Mockito.doThrow(new AmazonSimpleEmailServiceException("exception")).when(messageService).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeResetPassword(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
        Assertions.assertEquals(true, memoryAppender.contains("com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException", Level.ERROR));

    }

    @Test
    void consumeResetPasswordException() throws JsonProcessingException {
        Mockito.doThrow(new RuntimeException()).when(messageService).sendResetPasswordMail(Mockito.any(AuthDetailsDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeResetPassword(consumerRecord);
        Assertions.assertEquals(true, memoryAppender.countEventsForLogger("com.sapient") == 2);
    }

    @Test
    void consumeTradeAlertSuccess() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/tradeinfo";
        String tickerSymbol = "INFY";
        String tickerName = "Publicis Sapient";
        String direction = "buy";
        String timeframe = "1440";
        String confidenceScore = "23";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("tickerSymbol", tickerSymbol);
        value.put("tickerName", tickerName);
        value.put("direction", direction);
        value.put("timeframe", timeframe);
        value.put("confidenceScore", confidenceScore);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeTradeAlert(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        Assertions.assertEquals(true, memoryAppender.countEventsForLogger("com.sapient") == 1);
    }

    @Test
    void consumeTradeAlertConversionFailure() throws JsonProcessingException {
        Mockito.doNothing().when(messageService).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        String value = "djvnsvdjnvd";
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value);
        kafkaConsumerService.consumeTradeAlert(consumerRecord);
        //check if mail called or not
        Mockito.verify(messageService, Mockito.times(0)).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));

    }

    @Test
    void consumeTradeAlertMessagingException() throws JsonProcessingException {
        Mockito.doThrow(new AmazonSimpleEmailServiceException("exception")).when(messageService).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        String tickerSymbol = "INFY";
        String tickerName = "Publicis Sapient";
        String direction = "buy";
        String timeframe = "1440";
        String confidenceScore = "23";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("tickerSymbol", tickerSymbol);
        value.put("tickerName", tickerName);
        value.put("direction", direction);
        value.put("timeframe", timeframe);
        value.put("confidenceScore", confidenceScore);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeTradeAlert(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        Assertions.assertEquals(true, memoryAppender.contains("com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException", Level.ERROR));

    }

    @Test
    void consumeTradeAlertException() throws JsonProcessingException {
        Mockito.doThrow(new RuntimeException()).when(messageService).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        String topic = "example";
        int partition = 1;
        long offset = 1;
        String key = "abc@hotmail.com";
        JSONObject value = new JSONObject();
        String firstName = "george";
        String url = "www.tradesy.com/reset_password/ufubfjwbfjebfuebfuebcubduc.com";
        String tickerSymbol = "INFY";
        String tickerName = "Publicis Sapient";
        String direction = "buy";
        String timeframe = "1440";
        String confidenceScore = "23";
        value.put("email", key);
        value.put("firstName", firstName);
        value.put("url", url);
        value.put("tickerSymbol", tickerSymbol);
        value.put("tickerName", tickerName);
        value.put("direction", direction);
        value.put("timeframe", timeframe);
        value.put("confidenceScore", confidenceScore);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>(topic, partition, offset, key, value.toString());
        kafkaConsumerService.consumeTradeAlert(consumerRecord);
        Mockito.verify(messageService, Mockito.times(1)).sendTradeAlertMail(Mockito.any(TradeAlertDto.class));
        Assertions.assertEquals(true, memoryAppender.countEventsForLogger("com.sapient") == 2);
    }
}