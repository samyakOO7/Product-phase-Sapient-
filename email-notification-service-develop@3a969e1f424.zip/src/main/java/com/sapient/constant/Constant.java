package com.sapient.constant;

public enum Constant {

    SIGN_UP_EMAIL_SUBJECT("Tradezy: Complete your registration with one click!"), RESET_PASSWORD_EMAIL_SUBJECT("Tradezy: Reset your password"), TRADE_ALERT_EMAIL_SUBJECT("Tradezy: Alert triggered"),

    SELL_CONFIRMATION_EMAIL_SUBJECT("Tradezy: Sell order executed");
    private final String message;

    Constant(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}

