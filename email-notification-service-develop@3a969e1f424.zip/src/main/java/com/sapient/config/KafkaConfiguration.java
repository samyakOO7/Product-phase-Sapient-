package com.sapient.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
@Slf4j
public class KafkaConfiguration {

    @Value("${kafka.partitions:1}")
    private int partitions;
    @Bean

    //Topic for user sign up emails
    public NewTopic getSignUpTopic()
    {
        log.info("Building Topic for user Sign Up");
        return TopicBuilder.name("user_signup")
                .partitions(partitions)
                .build();

    }
    @Bean
    //Topic for User_reset_password
    public NewTopic getResetPasswordTopic()
    {
        log.info("Building Topic for user reset password");
        return TopicBuilder.name("user_reset_password")
                .partitions(partitions)
                .build();
    }
    @Bean
    //Topic for trade alerts
    public NewTopic getTradeAlertsTopic()
    {
        log.info("Building Topic for Trade Alerts");
        return TopicBuilder.name("user_trade_alerts")
                .partitions(partitions)
                .build();
    }
    @Bean
    //Topic for sell_confirmation
    public NewTopic getSellConfirmationTopic()
    {
        log.info("Building Topic for Sell confirmation");
        return TopicBuilder.name("user_sell_confirmation")
                .partitions(partitions)
                .build();
    }

}
