package com.sapient.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;

public interface KafkaConsumerService {
    void consumeSignUp(ConsumerRecord<String, String> kafkaMessage);

    void consumeTradeAlert(ConsumerRecord<String, String> rec);

    void consumeResetPassword(ConsumerRecord<String, String> rec);

    @KafkaListener(topics = "user_sell_confirmation", groupId = "notification-service")
    void consumeSellConfirmation(ConsumerRecord<String, String> kafkaMessage);
}
