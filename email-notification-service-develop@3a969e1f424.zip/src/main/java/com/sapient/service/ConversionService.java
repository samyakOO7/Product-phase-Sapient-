package com.sapient.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.json.JSONException;

public interface ConversionService {
    public <T> T convert(String jsonString,Class<T> toClass) throws JSONException, JsonProcessingException;
}
