package com.sapient.service;

import com.amazonaws.services.simpleemail.model.AmazonSimpleEmailServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.SellConfirmDto;
import com.sapient.dto.TradeAlertDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
@Slf4j
public class KafkaConsumerServiceImpl implements KafkaConsumerService {

    @Autowired
    ConversionService conversionService;
    @Autowired
    MessageService messageService;

    @Override
    @KafkaListener(topics = "user_signup", groupId = "notification-microservice")
    public void consumeSignUp(ConsumerRecord<String, String> kafkaMessage) {
        String payload = kafkaMessage.value();
        log.debug("received kafka message {} at the consumer for topic user_signup", kafkaMessage);
        try {
            var authDetailsDto = conversionService.convert(payload, AuthDetailsDto.class);
            //This triggers Email send
            messageService.sendSignUpMail(authDetailsDto);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due to string: {} received in kafka Message:{} for topic user_signup", e.getClass(), payload, kafkaMessage);
        } catch (AmazonSimpleEmailServiceException e) {
            log.error("Error {} in sending signup message {} in topic user_signup", e.getClass(), payload);
        } catch (Exception e) {
            log.trace("Exception in sending consumer {}", Arrays.toString(e.getStackTrace()));
        }
    }

    @Override
    @KafkaListener(topics = "user_reset_password", groupId = "notification-service")
    public void consumeResetPassword(ConsumerRecord<String, String> kafkaMessage) {
        String payload = kafkaMessage.value();
        log.debug("received kafka message {} at the consumer for topic user_reset_password", kafkaMessage);
        try {
            var resetPassword = conversionService.convert(payload, AuthDetailsDto.class);
            messageService.sendResetPasswordMail(resetPassword);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due to string: {} received in kafka Message:{} for topic user_reset_password", e.getClass(), payload, kafkaMessage);
        } catch (AmazonSimpleEmailServiceException e) {
            log.error("Error {} in sending reset password message {} in topic user_reset_password", e.getClass(), payload);
        } catch (Exception e) {
            log.trace("Exception in sending consumer {}", Arrays.toString(e.getStackTrace()));
        }
    }

    @Override
    @KafkaListener(topics = "user_trade_alerts", groupId = "notification-service")
    public void consumeTradeAlert(ConsumerRecord<String, String> kafkaMessage) {
        String payload = kafkaMessage.value();
        log.debug("received kafka message {} at the consumer for topic user_trade_alerts", kafkaMessage);
        try {
            var tradeAlertDto = conversionService.convert(payload, TradeAlertDto.class);
            messageService.sendTradeAlertMail(tradeAlertDto);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due to string: {} received in kafka Message:{} for topic user_trade_alerts", e.getClass(), payload, kafkaMessage);
        } catch (AmazonSimpleEmailServiceException e) {
            log.error("Error {} in sending trade-alert message {} in topic user_trade_alerts", e.getClass(), payload);
        } catch (Exception e) {
            log.trace(Arrays.toString(e.getStackTrace()));
        }

    }

    @Override
    @KafkaListener(topics = "user_sell_confirmation", groupId = "notification-service")
    public void consumeSellConfirmation(ConsumerRecord<String, String> kafkaMessage) {
        String payload = kafkaMessage.value();
        log.debug("received kafka message {} at the consumer for topic user_sell_confirmation", kafkaMessage);
        try {
            var sellConfirmDto = conversionService.convert(payload, SellConfirmDto.class);
            messageService.sendSellConfirmationMail(sellConfirmDto);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due to string: {} received in kafka Message:{} for topic user_sell_confirmation", e.getClass(), payload, kafkaMessage);
        } catch (AmazonSimpleEmailServiceException e) {
            log.error("Error {} in sending sell-confirmation message {} in topic user_sell_confirmation", e.getClass(), payload);
        } catch (Exception e) {
            log.trace(Arrays.toString(e.getStackTrace()));
        }

    }
}
