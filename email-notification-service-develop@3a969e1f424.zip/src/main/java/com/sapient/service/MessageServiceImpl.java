package com.sapient.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.constant.Constant;
import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.MailDto;
import com.sapient.dto.SellConfirmDto;
import com.sapient.dto.TradeAlertDto;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
@Slf4j
public class MessageServiceImpl implements MessageService {

    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private SpringTemplateEngine templateEngine;
    @Autowired
    private ObjectMapper objectMapper;
    @Value("${mail.from}")
    private String from;

    @Override
    public void sendSignUpMail(AuthDetailsDto authDetailsDto) {
        var mail = getMail(authDetailsDto, Constant.SIGN_UP_EMAIL_SUBJECT.toString());
        sendEmail(mail, "SignUpVerification");
        log.debug("SignUp Email sent successfully to user with id {} and subject- {}", mail.getTo(), Constant.SIGN_UP_EMAIL_SUBJECT);
    }

    @Override
    public void sendResetPasswordMail(AuthDetailsDto authDetailsDto) {
        var mail = getMail(authDetailsDto, Constant.RESET_PASSWORD_EMAIL_SUBJECT.toString());
        sendEmail(mail, "ResetPasswordVerification");
        log.debug("Reset Password Email sent successfully to user with id {} and subject- {}", mail.getTo(), Constant.RESET_PASSWORD_EMAIL_SUBJECT);
    }

    @Override
    public void sendTradeAlertMail(TradeAlertDto tradeAlertDto) {
        var mail = getMail(tradeAlertDto, Constant.TRADE_ALERT_EMAIL_SUBJECT.toString());
        sendEmail(mail, "TradeAlert");
        log.debug("Trade alert email sent successfully to user with id {} and subject- {}", mail.getTo(), Constant.TRADE_ALERT_EMAIL_SUBJECT);
    }

    @Override
    public void sendSellConfirmationMail(SellConfirmDto sellConfirmDto) {
        var mail = getMail(sellConfirmDto, Constant.SELL_CONFIRMATION_EMAIL_SUBJECT.toString());
        sendEmail(mail, "SellConfirmation");
        log.debug("Sell confirmation email sent successfully to user with id {} and subject- {}", mail.getTo(), Constant.SELL_CONFIRMATION_EMAIL_SUBJECT);
    }

    public <T extends AuthDetailsDto> MailDto getMail(T dto, String subject) {
        var mail = new MailDto();
        mail.setFrom(from);
        mail.setTo(dto.getEmail());
        mail.setSubject(subject);
        String jsonStr = null;
        try {
            jsonStr = objectMapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due, to converting dto to json string", e.getClass());
        }
        Map<String, Object> model = null;
        try {
            model = objectMapper.readValue(jsonStr, Map.class);
        } catch (JsonProcessingException e) {
            log.error("Error :{} due to string generated from dto: {} received from kafka producer", e.getClass(), jsonStr);
        }
        mail.setModel(model);
        return mail;
    }

    @Async
    public void sendEmail(MailDto mailDto, String template) {
        log.debug("Sending email to user {}", mailDto.getTo());
        MimeMessage message = null;
        try {
            message = getMimeMessage(mailDto, template);
            javaMailSender.send(message);
        } catch (MessagingException messagingException) {
            log.error("Error: {} in sending email to user with email_id {} ", messagingException.getClass(), mailDto.getTo());
        }
    }

    @Generated
    public MimeMessage getMimeMessage(MailDto mailDto, String template) throws MessagingException {
        var message = javaMailSender.createMimeMessage();
        var helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
        var context = new Context();
        context.setVariables(mailDto.getModel());
        log.debug("Generating email template to be sent");
        String html = templateEngine.process(template, context);
        helper.setTo(mailDto.getTo());
        helper.setText(html, true);
        helper.setSubject(mailDto.getSubject());
        helper.setFrom(mailDto.getFrom());
        return message;
    }

}
