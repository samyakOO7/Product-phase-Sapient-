package com.sapient.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ConversionServiceImpl implements ConversionService {
    @Autowired
    ObjectMapper objectMapper;

    @Override
    public <T> T convert(String jsonString, Class<T> toClass) throws JsonProcessingException {
        return objectMapper.readValue(jsonString, toClass);
    }
}
