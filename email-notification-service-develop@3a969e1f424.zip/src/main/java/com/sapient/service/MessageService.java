package com.sapient.service;

import com.sapient.dto.AuthDetailsDto;
import com.sapient.dto.SellConfirmDto;
import com.sapient.dto.TradeAlertDto;

public interface MessageService {

    void sendSignUpMail(AuthDetailsDto authDetailsDto);

    void sendResetPasswordMail(AuthDetailsDto authDetailsDto);

    void sendTradeAlertMail(TradeAlertDto tradeAlertDto);

    void sendSellConfirmationMail(SellConfirmDto sellConfirmDto);
}
