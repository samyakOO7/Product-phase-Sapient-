package com.sapient.dto;

import lombok.*;

@Generated
@Data
@AllArgsConstructor
@ToString(callSuper = true)
@NoArgsConstructor
public class TradeAlertDto extends AuthDetailsDto {
    String tickerSymbol;
    String tickerName;
    String direction;
    String timeframe;
    String confidenceScore;
    String timestamp;

    @SuppressWarnings("java:S107")
    public TradeAlertDto(String email, String firstName, String url, String tickerSymbol, String tickerName, String direction, String timeframe, String confidenceScore, String timestamp) {
        super(email, firstName, url);
        this.tickerSymbol = tickerSymbol;
        this.tickerName = tickerName;
        this.direction = direction;
        this.timeframe = timeframe;
        this.confidenceScore = confidenceScore;
        this.timestamp = timestamp;
    }
}
