package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

@Generated
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SellConfirmDto extends AuthDetailsDto{

    private String tickerSymbol;
    private String timestamp;
    private Double price;
    private Double gain;
    private Integer quantity;
}
