package com.sapient.dto;

import lombok.*;

@Generated
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthDetailsDto {
    String email;
    String firstName;
    String url;
}
