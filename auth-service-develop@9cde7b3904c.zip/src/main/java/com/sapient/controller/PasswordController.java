package com.sapient.controller;

import com.sapient.constant.Constant;
import com.sapient.dto.ListErrorDto;
import com.sapient.dto.ResetPasswordRequestDto;
import com.sapient.dto.ResetPasswordResponseDto;
import com.sapient.dto.ResetWithNewPasswordRequestDto;
import com.sapient.exception.BadCredentialsException;
import com.sapient.exception.EmailNotFoundException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.service.PasswordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.validation.Valid;

@RestController
@Slf4j
public class PasswordController {
    @Autowired
    PasswordService passwordService;

    @Value("${reset_password.url}")
    String resetPasswordURL;

    @PostMapping(path = "/reset-password")
    public ResponseEntity<ResetPasswordResponseDto> generatePasswordChangeLink(@RequestBody @Valid ResetPasswordRequestDto resetPasswordRequestDto) throws EmailNotFoundException
    {
       passwordService.sendLinkForResetPassword(resetPasswordRequestDto.getEmail().toLowerCase(),resetPasswordURL);
        return ResponseEntity.ok(new ResetPasswordResponseDto(Constant.EMAIL_SUCCESS_MESSAGE.toString()));
    }
    @GetMapping(path="/reset-password/{code}")
    public ResponseEntity<ResetPasswordResponseDto> verifyPasswordResetCode(@PathVariable("code") String code) throws InvalidVerificationCodeException
    {
        log.info("Validate reset password code request received");
        passwordService.validatePasswordResetCode(code);
        log.info("code is validated successfully.");
        return ResponseEntity.ok(new ResetPasswordResponseDto(Constant.RESET_PASSWORD_CODE_VALID_MESSAGE.toString()));
    }

    @PostMapping(path = "/reset-password/{code}")
    public ResponseEntity<ResetPasswordResponseDto> updatePassword(@PathVariable("code") String code, @RequestBody @Valid ResetWithNewPasswordRequestDto dto) throws InvalidVerificationCodeException, IllegalBlockSizeException, BadPaddingException
    {
        log.info("update password request is received");
        passwordService.updatePassword(code, dto.getPassword());
        log.info("password updated successfully");
        return ResponseEntity.ok(new ResetPasswordResponseDto(Constant.RESET_PASSWORD_SUCCESS_MESSAGE.toString()));
    }

    @ExceptionHandler(InvalidVerificationCodeException.class)
    public ResponseEntity<ListErrorDto> restPasswordResponseDto(InvalidVerificationCodeException exp){
        log.info(exp.getMessage());
        return ResponseEntity.status(400).body(new ListErrorDto(Constant.RESET_PASSWORD_CODE_INVALID_RESPONSE_MESSAGE));
    }

    @ExceptionHandler({BadCredentialsException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ListErrorDto handleEncryptionException(Exception exp)
    {
        log.info("Invalid credentials {}",exp.getMessage());
        return new ListErrorDto(Constant.BAD_CREDENTIALS_MESSAGE);
    }
}
