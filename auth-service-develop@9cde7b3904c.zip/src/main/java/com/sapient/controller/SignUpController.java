package com.sapient.controller;

import com.sapient.constant.Constant;
import com.sapient.dto.UserDto;
import com.sapient.exception.AccountAlreadyExistsException;
import com.sapient.exception.AlreadyVerifiedException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.UserDoesNotExistException;
import com.sapient.service.SignUpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
public class SignUpController {
    @Autowired
    SignUpService signUpService;
    static final String MESSAGE = "message";

    @PostMapping(value = "/signup", produces = "application/json", consumes = "application/json")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> signupUser(@RequestBody @Valid UserDto userDto, HttpServletRequest request) throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException {
        Map<String, Object> map = new HashMap<>();
        String response = signUpService.register(userDto, request.getRequestURL().toString().replace(request.getServletPath(), ""));
        map.put(MESSAGE, response);
        return ResponseEntity.ok(map);
    }

    @GetMapping("/verify")
    public ResponseEntity<Map<String, Object>> verifyUser(@Param("code") String code) throws InvalidVerificationCodeException, UserDoesNotExistException, AlreadyVerifiedException {
        Map<String, Object> map = new HashMap<>();
        String msg = signUpService.verify(code);
        map.put(MESSAGE, msg);
        if ((msg.equals(Constant.LINK_EXPIRED_SENT_ANOTHER_EMAIL.toString()))) {
            return ResponseEntity.status(400).body(map);
        }
        return ResponseEntity.ok(map);
    }
}

