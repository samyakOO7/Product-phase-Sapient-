package com.sapient.controller;

import com.sapient.dto.LoginRequestDto;
import com.sapient.dto.LoginResponseDto;
import com.sapient.dto.RefreshResponseDto;
import com.sapient.dto.ValidateResponseDto;
import com.sapient.exception.EmailNotVerifiedException;
import com.sapient.exception.InvalidAccessTokenException;
import com.sapient.exception.InvalidCredentialsException;
import com.sapient.exception.InvalidRefreshTokenException;
import com.sapient.service.SignInService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

@RestController
@Slf4j
public class SignInController {

    @Autowired
    SignInService signInService;


    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto> userSignIn(@RequestBody LoginRequestDto loginRequestDto) throws InvalidCredentialsException, IllegalBlockSizeException, BadPaddingException, EmailNotVerifiedException {
        log.debug(loginRequestDto.getEmail() + " - from SignIn Controller");
        return ResponseEntity.ok().body(signInService.signIn(loginRequestDto.getEmail(), loginRequestDto.getPassword()));
    }

    @PostMapping(path = "/validate", produces = "application/json")
    public ResponseEntity<ValidateResponseDto> validateToken(@RequestHeader("Authorization") String token) throws InvalidAccessTokenException {
        return ResponseEntity.ok().body(signInService.validateAccessToken(token));
    }

    @PostMapping(path = "/refreshtoken")
    public ResponseEntity<RefreshResponseDto> refreshToken(@RequestHeader("Authorization") String refreshToken) throws InvalidRefreshTokenException {
        var refreshResponseDto = signInService.getNewAccessToken(refreshToken);
        log.info("Access Token generated - Sign In Controller");
        return ResponseEntity.ok().body(refreshResponseDto);
    }


}
