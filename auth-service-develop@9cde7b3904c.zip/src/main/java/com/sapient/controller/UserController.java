package com.sapient.controller;

import com.sapient.dto.UserUpdateDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;

@Slf4j
@RestController
public class UserController {

    @Autowired
    UserService userService;


    /**
     * This API is used to get user details.
     *
     * @param userId used as a path variable.
     * @return status code 200.
     */
    @GetMapping(value = "/user/{userId}", produces = {"application/json"})
    public ResponseEntity<ViewUserDto> getUserById(@PathVariable("userId") BigInteger userId) {
        log.info("View User Profile Requested");
        return new ResponseEntity<>(userService.getUserById(userId), HttpStatus.OK);
    }

    @PutMapping(path = "/user/update", produces = "application/json", consumes = "application/json")
    public ResponseEntity<String> updateUser(@RequestBody UserUpdateDto data) throws IllegalBlockSizeException, BadPaddingException {
        log.info("Update User Profile Requested");
        return userService.updateData(data);
    }
}
