package com.sapient.exception;

public class AlreadyVerifiedException extends Exception {
}
