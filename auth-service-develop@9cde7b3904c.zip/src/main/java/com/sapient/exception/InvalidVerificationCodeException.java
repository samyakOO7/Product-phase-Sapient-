package com.sapient.exception;

public class InvalidVerificationCodeException extends Exception {
    public InvalidVerificationCodeException() {
    }

    public InvalidVerificationCodeException(String message) {
        super(message);
    }
}
