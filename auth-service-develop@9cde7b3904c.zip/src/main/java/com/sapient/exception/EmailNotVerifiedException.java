package com.sapient.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class EmailNotVerifiedException extends Exception {

    public EmailNotVerifiedException(String message) {
        super(message);
    }
}
