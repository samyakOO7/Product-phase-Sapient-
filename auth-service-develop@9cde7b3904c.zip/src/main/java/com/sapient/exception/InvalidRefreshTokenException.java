package com.sapient.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class InvalidRefreshTokenException extends Exception {

    public InvalidRefreshTokenException(String msg) {
        super((msg));
    }

}
