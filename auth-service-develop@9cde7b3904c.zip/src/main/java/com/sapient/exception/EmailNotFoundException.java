package com.sapient.exception;

import lombok.Generated;

@Generated
public class EmailNotFoundException extends Exception {
}
