package com.sapient.exception;

public class VerificationCodeExpiredException extends Exception {

    public VerificationCodeExpiredException(String s) {
        super(s);
    }
}
