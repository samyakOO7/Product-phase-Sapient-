package com.sapient.exception;

import lombok.Generated;

@Generated
public class NoUserException extends RuntimeException{
}
