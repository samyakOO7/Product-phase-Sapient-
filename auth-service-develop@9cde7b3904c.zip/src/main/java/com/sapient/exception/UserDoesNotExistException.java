package com.sapient.exception;

public class UserDoesNotExistException extends Exception {
    public UserDoesNotExistException() {
    }

    public UserDoesNotExistException(String message) {
        super(message);
    }
}
