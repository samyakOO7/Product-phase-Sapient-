package com.sapient.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class InvalidAccessTokenException extends Exception {

    public InvalidAccessTokenException(String msg) {
        super(msg);
    }

}
