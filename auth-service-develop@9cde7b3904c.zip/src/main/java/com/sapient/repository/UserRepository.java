package com.sapient.repository;

import com.sapient.entity.User;
import lombok.Generated;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
@Generated
public interface UserRepository extends JpaRepository<User, BigInteger> {

    List<User> findByUserNameOrEmail(String userName, String email);

    User findByUserName(String userName);

    User findByEmail(String email);
}
