package com.sapient.repository;

import com.sapient.entity.VerificationCodes;
import lombok.Generated;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;

@Repository
@Generated
public interface VerificationCodesRepository extends JpaRepository<VerificationCodes, String> {
    VerificationCodes findByUserId(BigInteger userId);
    Optional<VerificationCodes> findByCode(String verificationCode);
    Optional<VerificationCodes> findByCodeAndType(String verificationCode, String type);
    Optional<VerificationCodes> findByTypeAndUserId(String type,BigInteger userId);
}
