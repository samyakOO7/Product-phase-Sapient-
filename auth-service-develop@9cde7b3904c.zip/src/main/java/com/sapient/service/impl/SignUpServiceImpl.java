package com.sapient.service.impl;

import com.sapient.constant.Constant;
import com.sapient.dto.UserDto;
import com.sapient.entity.User;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.AccountAlreadyExistsException;
import com.sapient.exception.AlreadyVerifiedException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.UserDoesNotExistException;
import com.sapient.payload.EmailVerification;
import com.sapient.repository.UserRepository;
import com.sapient.repository.VerificationCodesRepository;
import com.sapient.service.SignUpService;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.KafkaClientService;
import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.utility.RandomString;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class SignUpServiceImpl implements SignUpService {
    @Autowired
    KafkaClientService kafkaClientService;
    @Autowired
    CryptoService cryptoService;
    @Autowired
    HashService hashService;
    @Autowired
    VerificationCodesRepository verificationCodesRepository;
    @Autowired
    UserRepository userRepository;
    @Value("${requestUrl}")
    String requestUrl;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public String register(UserDto userDto, String requestURL) throws IllegalBlockSizeException, BadPaddingException, AccountAlreadyExistsException {
        dtoValidator(userDto);
        var user = mappingUser(userDto);
        var verificationCodes = new VerificationCodes();
        List<User> userList = userRepository.findByUserNameOrEmail(user.getUserName(), user.getEmail());
        var userByUserName = userRepository.findByUserName(user.getUserName());
        if (userList.isEmpty()) {
            String password = cryptoService.decrypt(user.getPassword());
            String hashedPassword = hashService.hash(password);
            user.setPassword(hashedPassword);
            user.setVerified(false);
            userRepository.save(user);//Session added
            var randomCode = RandomString.make(32);
            verificationCodes.setCode(randomCode);
            verificationCodes.setType("user_verification");
            verificationCodes.setUserId(user.getUserId());
            var tscurrent = Timestamp.from(Instant.now());
            var ts = new Timestamp(tscurrent.getTime() + 604800000);//1 week in ms
            verificationCodes.setExpiryTime(ts);
            verificationCodesRepository.save(verificationCodes);
            log.info("Saved the code for user {} in the Repository", user);
            String url = getSiteUrl(requestUrl, verificationCodes.getCode());
            var emailVerification = new EmailVerification(user.getEmail(), user.getFirstName(), url);
            kafkaClientService.publishJson(emailVerification, "user_signup");//topic name added
            return Constant.REGISTRATION_SUCCESS_MSG.toString();
        } else if(userByUserName!=null) {
            log.error("User Account already registered with same username");
            throw new AccountAlreadyExistsException("Username already exists!");
        }
        else {
            log.error("User Account already registered with same email");
            throw new AccountAlreadyExistsException("Email already exists!");
        }

    }

    private User mappingUser(UserDto userDto) {
        var modelMapper = new ModelMapper();
        return modelMapper.map(userDto, User.class);
    }

    private void dtoValidator(UserDto userDto) {
        userDto.setUserName(userDto.getUserName().trim());
        userDto.setEmail(userDto.getEmail().trim());
        userDto.setFirstName(userDto.getFirstName().trim());
        userDto.setPassword(userDto.getPassword().trim());
    }

    private boolean checkExpirationTimeForUser(Timestamp expirationTime) {
        return expirationTime.before(Timestamp.from(Instant.now()));
    }

    private String getSiteUrl(String requestURL, String verificationCode) {
        return requestURL + "/" + verificationCode;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public String verify(String verificationCode) throws InvalidVerificationCodeException, UserDoesNotExistException, AlreadyVerifiedException {

        Optional<VerificationCodes> verificationDetailsOptional = verificationCodesRepository.findByCode(verificationCode);
        if (verificationDetailsOptional.isEmpty()) {
            log.error("Invalid Verification Code");
            throw new InvalidVerificationCodeException();
        }
        var verificationCodes = verificationDetailsOptional.get();
        BigInteger userId = verificationCodes.getUserId();
        Optional<User> user = userRepository.findById(userId);
        if (user.isEmpty()) {
            log.error("User does not exist");
            throw new UserDoesNotExistException();
        }

        var newUser = user.get();
        if (newUser.isVerified()) {
            log.error("User already verified, can't verify again");
            throw new AlreadyVerifiedException();
        }
        if (checkExpirationTimeForUser(verificationCodes.getExpiryTime())) {
            var randomCode = RandomString.make(32);
            verificationCodes.setCode(randomCode);
            String url = getSiteUrl(requestUrl, verificationCodes.getCode());
            var emailVerification = new EmailVerification(user.get().getEmail(), verificationCodes.getCode(), url);
            kafkaClientService.publishJson(emailVerification, "user_signup");
            return Constant.LINK_EXPIRED_SENT_ANOTHER_EMAIL.toString();
        }
        newUser.setVerified(true);
        userRepository.save(newUser);
        log.info("Saved the user {} in the database with verification done", user);
        return Constant.VERIFICATION_SUCCESS_MSG.toString();
    }
}

