package com.sapient.service.impl;

import com.sapient.config.Constant;
import com.sapient.dto.UserUpdateDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.entity.User;
import com.sapient.exception.UserNotFoundException;
import com.sapient.exception.WrongPasswordException;
import com.sapient.repository.UserRepository;
import com.sapient.service.UserService;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.transaction.Transactional;
import java.math.BigInteger;
import java.util.Optional;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepository userRepo;
    @Autowired
    HashService hashService;
    @Autowired
    CryptoService cryptoService;

    @Override
    public ViewUserDto getUserById(BigInteger userId) {
        try {
            Optional<User> user = userRepo.findById(userId);
            var userDto = new ViewUserDto();
            if (user.isPresent()) {
                userDto.setUserId(user.get().getUserId());
                userDto.setUserName(user.get().getUserName());
                userDto.setEmail(user.get().getEmail());
                userDto.setAlternateEmail(user.get().getAlternateEmail());
                userDto.setFirstName(user.get().getFirstName());
                userDto.setLastName(user.get().getLastName());
                userDto.setPhoneNumber(user.get().getPhoneNumber());
                log.info("Request successful. Returned User Details");
                return userDto;
            } else
                throw new UserNotFoundException();
        } catch (UserNotFoundException exception) {
            log.error(Constant.USER_NOT_FOUND_EXCEPTION, exception.getMessage());
            throw exception;
        }
    }

    @Transactional
    @Override
    public ResponseEntity<String> updateData(UserUpdateDto data) throws IllegalBlockSizeException, BadPaddingException {
        try {
            BigInteger id = data.getUserId();
            String oldPassword = data.getOldPassword();
            String newPassword = data.getNewPassword();
            String decryptedOldPassword = cryptoService.decrypt(oldPassword);
            String decryptedNewPassword = cryptoService.decrypt(newPassword);
            Optional<User> userOptional = userRepo.findById(id);

            if (userOptional.isEmpty()) {
                throw new UserNotFoundException();
            } else {
                String hashedPassword = hashService.hash(decryptedOldPassword);
                var user = userOptional.get();
                if (!user.getPassword().equals(hashedPassword)) {
                    throw new WrongPasswordException();
                } else {
                    user.setPassword(hashService.hash(decryptedNewPassword));
                    userRepo.save(user);
                    log.info("Password is Updated Successfully");
                    return new ResponseEntity<>("User password is updated successfully", HttpStatus.OK);
                }
            }
        } catch (UserNotFoundException exception) {
            log.error(Constant.USER_NOT_FOUND_EXCEPTION, exception.getMessage());
            throw exception;
        } catch (WrongPasswordException exception) {
            log.error(Constant.WRONG_PASSWORD_EXCEPTION, exception.getMessage());
            throw exception;
        }
    }
}
