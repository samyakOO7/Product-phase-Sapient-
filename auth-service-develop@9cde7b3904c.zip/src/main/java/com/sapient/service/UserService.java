package com.sapient.service;

import com.sapient.dto.UserUpdateDto;
import com.sapient.dto.ViewUserDto;
import org.springframework.http.ResponseEntity;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;

public interface UserService {
    ViewUserDto getUserById(BigInteger userId);
    ResponseEntity<String> updateData(UserUpdateDto data) throws IllegalBlockSizeException, BadPaddingException;

}
