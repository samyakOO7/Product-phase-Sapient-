package com.sapient.service;

import com.sapient.dto.LoginResponseDto;
import com.sapient.dto.RefreshResponseDto;
import com.sapient.dto.ValidateResponseDto;
import com.sapient.exception.EmailNotVerifiedException;
import com.sapient.exception.InvalidAccessTokenException;
import com.sapient.exception.InvalidCredentialsException;
import com.sapient.exception.InvalidRefreshTokenException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public interface SignInService {

    public LoginResponseDto signIn(String email, String password) throws InvalidCredentialsException, IllegalBlockSizeException, BadPaddingException, EmailNotVerifiedException;

    public ValidateResponseDto validateAccessToken(String token) throws InvalidAccessTokenException;

    public RefreshResponseDto getNewAccessToken(String refreshToken) throws InvalidRefreshTokenException;

}
