package com.sapient.service;

import com.sapient.dto.UserDto;
import com.sapient.exception.AccountAlreadyExistsException;
import com.sapient.exception.AlreadyVerifiedException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.UserDoesNotExistException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public interface SignUpService {
    String register(UserDto userDto, String requestURL) throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException;

    String verify(String code) throws InvalidVerificationCodeException, UserDoesNotExistException, AlreadyVerifiedException;
}
