package com.sapient.service;

import com.sapient.constant.Constant;
import com.sapient.entity.User;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.EmailNotFoundException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.NoUserException;
import com.sapient.payload.EmailVerification;
import com.sapient.repository.UserRepository;
import com.sapient.repository.VerificationCodesRepository;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.KafkaClientService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutorService;

@Service
@Slf4j
public class PasswordServiceImpl implements PasswordService {
    @Autowired
    private HashService hashService;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VerificationCodesRepository codesRepository;

    @Autowired
    private ExecutorService executorService;

    @Autowired
    private KafkaClientService kafkaClientService;

    private String type="reset_password";

    private String topic="user_reset_password";

    public void sendLinkForResetPassword(String email,String prefix) throws EmailNotFoundException
    {
        var user=fetchUserByEmail(email);
        VerificationCodes code=generatePasswordResetCode(user);
        sendLink(user,prefix,code);
    }
    //finds the users by email. if not valid sends error or else returns user
    public User fetchUserByEmail(String email) throws EmailNotFoundException
    {
        var user=userRepository.findByEmail(email);
        log.debug("Finding user with email {}",email);
        if(user==null) {
            log.debug("User not found for email {}",email);
            throw new EmailNotFoundException();
        }
        log.debug("Found user with email {}",email);
        return user;
    }
    //generate the password reset link. Uses UUID as the code generation tool
    public VerificationCodes generatePasswordResetCode(User user)
    {
        log.debug("generate reset code for user {}",user);
        if(user==null){
            log.info("Null user value");
            throw new NoUserException();
        }
        var code=UUID.randomUUID().toString();
        log.debug("Generated the code for user {}",user);
        //See if record already exist, update it or else make new record
        Optional<VerificationCodes> fetchRecord=codesRepository.findByTypeAndUserId(type,user.getUserId());
        var currentTime=Timestamp.from(Instant.now());
        //expiry of 1 hr in ms
        var duration=36_00_000l;
        var expiryTime=new Timestamp(currentTime.getTime()+duration);
        VerificationCodes verificationCode;
        if(fetchRecord.isEmpty())
        {
            verificationCode=new VerificationCodes(null,user.getUserId(),code,expiryTime,type);
        }
        else{
            verificationCode=fetchRecord.get();
            verificationCode.setCode(code);
            verificationCode.setExpiryTime(expiryTime);
        }
        codesRepository.save(verificationCode);
        log.debug("Saved the code for user {} in the DB",user);
        log.info("Code generated for password for user {}",user);
        return verificationCode;
    }

    //sends link using message service
    public String sendLink(User user,String prefix,VerificationCodes verificationCodes)
    {
        log.debug("Sending the password reset URL to email {}",user.getEmail());
        String url=prefix+"/"+verificationCodes.getCode();
        var emailInfo=new EmailVerification(user.getEmail(),user.getFirstName(),url);
        log.debug("Executing kafka publish for {}",emailInfo);
        executorService.execute(()->kafkaClientService.publishJson(emailInfo,topic));
        return url;
    }



    @Override
    public VerificationCodes validatePasswordResetCode(String code) throws InvalidVerificationCodeException
    {
        log.debug("Validate update password code received {}", code);
        Optional<VerificationCodes> details = codesRepository.findByCodeAndType(code, "reset_password");
        if(details.isEmpty())
        {
            log.debug("Invalid code or expired");
            throw new InvalidVerificationCodeException(Constant.INVALID_RESET_CODE_MESSAGE.toString());
        }
        VerificationCodes verificationDetails = details.get();
        // assuming that the expiry time stamp is the actual time after which the code expires
        if( Timestamp.from(Instant.now()).after(verificationDetails.getExpiryTime()))
        {
            log.debug("Token expired");
            throw new InvalidVerificationCodeException(Constant.RESET_PASSWORD_CODE_EXPIRED_MESSAGE.toString());
        }
        Optional<User> user = userRepository.findById( verificationDetails.getUserId());
        if(user.isEmpty())
        {
            log.debug("Invalid code no such User exists");
            throw new InvalidVerificationCodeException(Constant.USER_DOES_NOT_EXIST.toString());
        }
        log.debug("Code is successfully validated");
        return details.get();
    }
    @Override
    @Transactional
    public void updatePassword(String code, String password) throws InvalidVerificationCodeException, IllegalBlockSizeException, BadPaddingException
    {
        log.debug("got the string code and password {}", code);
        VerificationCodes codes = validatePasswordResetCode(code);
        var user = userRepository.getById(codes.getUserId());//because validation has already checked if thu user here skipping the is validUser test
        String decryptedPassword = cryptoService.decrypt(password);
        String hashedPassword = hashService.hash(decryptedPassword);
        log.trace("successfully hashed password.");
        user.setPassword(hashedPassword);
        log.debug("updated password successfully");
        codesRepository.delete(codes);
        log.debug("verification code deleted successfully");
    }
}
