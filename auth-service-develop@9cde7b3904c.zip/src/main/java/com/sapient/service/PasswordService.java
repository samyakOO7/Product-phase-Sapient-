package com.sapient.service;

import com.sapient.entity.User;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.EmailNotFoundException;
import com.sapient.exception.InvalidVerificationCodeException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public interface PasswordService {
    public User fetchUserByEmail(String email) throws EmailNotFoundException;
    public VerificationCodes generatePasswordResetCode(User user);
    public String sendLink(User user,String prefix,VerificationCodes verificationCodes);
    public void sendLinkForResetPassword(String email,String prefix) throws EmailNotFoundException;
    public VerificationCodes validatePasswordResetCode(String code) throws InvalidVerificationCodeException;
    public void updatePassword(String code, String password) throws InvalidVerificationCodeException, IllegalBlockSizeException, BadPaddingException;
}
