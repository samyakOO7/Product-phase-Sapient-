package com.sapient.service;

import com.sapient.constant.Constant;
import com.sapient.dto.LoginResponseDto;
import com.sapient.dto.RefreshResponseDto;
import com.sapient.dto.ValidateResponseDto;
import com.sapient.exception.EmailNotVerifiedException;
import com.sapient.exception.InvalidAccessTokenException;
import com.sapient.exception.InvalidCredentialsException;
import com.sapient.exception.InvalidRefreshTokenException;
import com.sapient.repository.UserRepository;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.JWTService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class SignInServiceImpl implements SignInService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    JWTService jwtService;

    @Autowired
    HashService hashService;

    @Autowired
    CryptoService cryptoService;

    private static final String USER_ID = "userId";


    @Override
    public LoginResponseDto signIn(String email, String password) throws InvalidCredentialsException, IllegalBlockSizeException, BadPaddingException, EmailNotVerifiedException {

        var user = userRepository.findByEmail(email);

        if (user != null) {
            if (!user.isVerified()) {
                log.error(Constant.EMAIL_NOT_VERIFIED + " - from sign in service ");
                log.debug(Constant.EMAIL_NOT_VERIFIED + "for {} ", email);
                throw new EmailNotVerifiedException(Constant.EMAIL_NOT_VERIFIED.toString());
            }
            String hashedPwd = hashService.hash(cryptoService.decrypt(password));
            if (user.getPassword().equals(hashedPwd)) {
                Map<String, Object> claims = new HashMap<>();
                claims.put(USER_ID, user.getUserId());
                String accessToken = jwtService.generateAccessToken(claims, user.getUserName());
                String refreshToken = jwtService.generateRefreshToken(claims, user.getUserName());
                log.info(Constant.VALID_CREDENTIALS + " - from sign in service");

                return new LoginResponseDto(user.getUserId(), user.getUserName(), accessToken, refreshToken);
            }
        }

        log.error(Constant.INVALID_CREDENTIALS + " - from sign in service ");
        log.debug(Constant.INVALID_CREDENTIALS + "for {} ", email);
        throw new InvalidCredentialsException(Constant.INVALID_CREDENTIALS.toString());
    }

    @Override
    public ValidateResponseDto validateAccessToken(String token) throws InvalidAccessTokenException {
        if (jwtService.validateToken(token)) {
            var claims = jwtService.getClaims(token);
            Object userId = claims.get(USER_ID);
            return new ValidateResponseDto(userId, true);
        } else {
            log.error(Constant.INVALID_ACCESS_TOKEN + " - from SignIn controller");
            throw new InvalidAccessTokenException(Constant.INVALID_ACCESS_TOKEN.toString());
        }
    }

    @Override
    public RefreshResponseDto getNewAccessToken(String refreshToken) throws InvalidRefreshTokenException {
        if (!jwtService.validateToken(refreshToken)) {
            throw new InvalidRefreshTokenException(Constant.INVALID_REFRESH_TOKEN.toString());
        }
        var claims = jwtService.getClaims(refreshToken);
        String subject = claims.getSubject();
        Map<String, Object> claim = new HashMap<>();
        claim.put(USER_ID, claims.get(USER_ID));
        String accessToken = jwtService.generateAccessToken(claim, subject);
        log.info(accessToken);
        return new RefreshResponseDto(accessToken);
    }

}
