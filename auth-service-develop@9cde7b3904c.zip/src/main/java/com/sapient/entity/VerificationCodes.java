package com.sapient.entity;

import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Timestamp;


@Entity
@Table(name = "verification_codes")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class VerificationCodes {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "code_generator")
    @SequenceGenerator(name="code_generator", sequenceName = "code_id_gen", allocationSize = 1)
    @Column(name = "verification_codes", updatable = false, nullable = false)
    private BigInteger verificationCode;
    private BigInteger userId;
    private String code;
    private Timestamp expiryTime;
    private String type;

    @Override
    @Generated
    public String toString() {
        return "VerificationCodes{" +
                "verificationCodes=" + verificationCode +
                ", userId=" + userId +
                ", code='" + code + '\'' +
                ", expiryTime=" + expiryTime +
                ", type='" + type + '\'' +
                '}';
    }

    @Override
    @Generated
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VerificationCodes that = (VerificationCodes) o;

        if (!code.equals(that.code)) return false;
        if (!userId.equals(that.userId)) return false;
        return userId.equals(that.userId);
    }

    @Override
    @Generated
    public int hashCode() {
        int result = code.hashCode();
        result = 31 * result + userId.hashCode();
        return result;
    }

}
