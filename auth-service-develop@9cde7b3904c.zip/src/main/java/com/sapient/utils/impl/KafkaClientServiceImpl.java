package com.sapient.utils.impl;

import com.sapient.payload.EmailVerification;
import com.sapient.utils.KafkaClientService;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Slf4j
@Component
@Generated
public class KafkaClientServiceImpl implements KafkaClientService {
    @Autowired
    private KafkaTemplate<String, EmailVerification> kafkaTemplate;

    @Generated
    public void publishJson(EmailVerification emailVerification, String topic) {
        ListenableFutureCallback<SendResult<String, EmailVerification>> callback = new ListenableFutureCallback<>() {
            @Override
            @Generated
            public void onSuccess(SendResult<String, EmailVerification> result) {
                log.info(result.getRecordMetadata().toString());
            }

            @Override
            @Generated
            public void onFailure(Throwable ex) {
                ProducerRecord<?, ?> producerRecord = ((KafkaProducerException) ex).getFailedProducerRecord();
                log.error("Failed; " + producerRecord, ex);
            }
        };
        try {
            ListenableFuture<SendResult<String, EmailVerification>> future = kafkaTemplate.send(topic, emailVerification.getEmail(), emailVerification);
            future.addCallback(callback);
        } catch (TimeoutException e) {
            log.error("{} for message {}", e.getClass(), emailVerification);
        }
    }
}
