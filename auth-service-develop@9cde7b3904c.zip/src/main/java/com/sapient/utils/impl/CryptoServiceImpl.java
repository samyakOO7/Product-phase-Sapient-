package com.sapient.utils.impl;

import com.sapient.utils.CryptoService;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class CryptoServiceImpl implements CryptoService {


    Cipher encryptCipher;
    Cipher decryptCipher;
    KeyFactory keyFactory;

    public void loadAlgorithm(String algorithm) throws NoSuchPaddingException, NoSuchAlgorithmException {
        encryptCipher = Cipher.getInstance(algorithm);
        decryptCipher = Cipher.getInstance(algorithm);
        keyFactory = KeyFactory.getInstance(algorithm);
    }

    public  void initializeEncryptCipher(String publicKey) throws InvalidKeySpecException, InvalidKeyException {
        byte[] decodedBytes = Base64.getDecoder().decode(publicKey);
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(decodedBytes);
        encryptCipher.init(Cipher.ENCRYPT_MODE,keyFactory.generatePublic(publicKeySpec));
    }
    public  void initializeDecryptCipher(String privateKey) throws InvalidKeySpecException, InvalidKeyException {
        byte[] decodedBytes = Base64.getDecoder().decode(privateKey);
        EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(decodedBytes);
        decryptCipher.init(Cipher.DECRYPT_MODE,keyFactory.generatePrivate(privateKeySpec));
    }

    @Override
    public void loadKeyPair(String publicKey, String privateKey) throws InvalidKeySpecException, InvalidKeyException {
        initializeEncryptCipher(publicKey);
        initializeDecryptCipher(privateKey);
    }

    @Override
    public String encrypt(String plainText) throws IllegalBlockSizeException, BadPaddingException {
        byte[] encryptBytes = encryptCipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return  Base64.getEncoder().encodeToString(encryptBytes);
    }

    @Override
    public String decrypt(String cipherText) throws IllegalBlockSizeException, BadPaddingException {
        byte[] cipherBytes = Base64.getDecoder().decode(cipherText);
        byte[] decryptedBytes = decryptCipher.doFinal(cipherBytes);
        return new String(decryptedBytes);
    }

}
