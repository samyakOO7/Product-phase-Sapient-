package com.sapient.utils.impl;

import com.sapient.utils.HashService;
import lombok.extern.slf4j.Slf4j;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
@Slf4j
public class HashServiceImpl implements HashService {
    MessageDigest md;
    String salt;
    @Override
    public void loadAlgorithm(String algo) throws NoSuchAlgorithmException {
        md = MessageDigest.getInstance(algo);
    }

    @Override
    public void loadSalt(String salt) {
       this.salt=salt;
    }

    @Override
    public String hash(String message) {
        byte[] messageBytes = message.getBytes();
        byte[] saltBytes = Base64.getDecoder().decode(salt);
        md.update(saltBytes);
        byte[] digestBytes = md.digest(messageBytes);
        return Base64.getEncoder().encodeToString(digestBytes);
    }
}
