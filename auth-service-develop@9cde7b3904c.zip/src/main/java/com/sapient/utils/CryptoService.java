package com.sapient.utils;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public interface CryptoService {

    void loadAlgorithm(String algorithm) throws NoSuchPaddingException, NoSuchAlgorithmException;
    void loadKeyPair(String publicKey, String privateKey) throws InvalidKeySpecException, InvalidKeyException;
    String encrypt(String plainText) throws IllegalBlockSizeException, BadPaddingException;
    String decrypt(String cipherText) throws IllegalBlockSizeException, BadPaddingException;

}