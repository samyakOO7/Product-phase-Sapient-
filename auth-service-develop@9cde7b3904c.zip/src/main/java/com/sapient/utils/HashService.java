package com.sapient.utils;

import java.security.NoSuchAlgorithmException;

public interface HashService {
    void loadAlgorithm(String algo) throws NoSuchAlgorithmException;
    void loadSalt(String salt);
    String hash(String message);
}
