package com.sapient.utils;

import com.sapient.payload.EmailVerification;

public interface KafkaClientService {
  void publishJson(EmailVerification emailVerification,String topic);

}
