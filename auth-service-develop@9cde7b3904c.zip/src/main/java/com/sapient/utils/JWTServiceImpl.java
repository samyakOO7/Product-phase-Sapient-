package com.sapient.utils;

import com.sapient.constant.Constant;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.Map;

@Slf4j
public class JWTServiceImpl implements JWTService {

    private String secretKey;

    private long expTimeAccessToken;

    private long expTimeRefreshToken;

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public void setExpirationTimeForAccessToken(long expTime) {
        this.expTimeAccessToken = expTime;
    }

    public void setExpirationTimeForRefreshToken(long expTime) {
        this.expTimeRefreshToken = expTime;
    }


    @Override
    public String generateAccessToken(Map<String, Object> claims, String username) {

        String token = Jwts.builder().setClaims(claims)
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expTimeAccessToken))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
        log.debug("token = {}", token);
        return token;
    }

    @Override
    public String generateRefreshToken(Map<String, Object> claims, String username) {
        String token = Jwts.builder().setClaims(claims).setSubject(username).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expTimeRefreshToken))
                .signWith(SignatureAlgorithm.HS512, secretKey).compact();
        log.debug("token = {}", token);
        return token;
    }

    public Claims getClaims(String token) {
        String jwt = token.split(" ")[1];
        var claims = Jwts.parser().setSigningKey(secretKey)
                .parseClaimsJws(jwt).getBody();
        log.debug("claims = {}", claims);
        return claims;
    }


    public boolean validateToken(String token) {
        String jwt;
        try {
            // Separating jwt token (token = Bearer + actual jwt token)
            jwt = token.split(" ")[1];

            if (!token.split(" ")[0].equals("Bearer")) {
                throw new JwtException(Constant.INVALID_TOKEN.toString());
            }
        } catch (Exception e) {
            log.error("Bearer keyword is missing in token");
            return false;
        }
        try {
            Jwts.parser().setSigningKey(secretKey).parseClaimsJws(jwt);
            return true;
        } catch (Exception e) {
            log.error(jwt + " " + Constant.INVALID_TOKEN.toString() + " " + e.getMessage());
        }
        return false;
    }


}
