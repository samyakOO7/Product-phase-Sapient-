package com.sapient.utils;

import io.jsonwebtoken.Claims;

import java.util.Map;

public interface JWTService {

    public void setSecretKey(String secretKey);

    public void setExpirationTimeForAccessToken(long expTime);

    public void setExpirationTimeForRefreshToken(long expTime);

    public String generateAccessToken(Map<String, Object> claims, String username);

    public String generateRefreshToken(Map<String, Object> claims, String username);

    public boolean validateToken(String token);

    public Claims getClaims(String token);


}
