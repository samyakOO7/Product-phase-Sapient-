package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.dto.ListErrorDto;
import com.sapient.exception.*;
import com.sapient.utils.JsonResponse;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.TransactionException;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.MethodNotAllowedException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.net.ProtocolException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.*;

@RestControllerAdvice
@Slf4j
public class AuthAdvice {


    public Map<String, List<Object>> getMessage(List<Object> messages) {
        HashMap<String, List<Object>> map = new HashMap<>();
        map.put("errors", messages);
        return map;
    }

    Map<String, String> mp;
    private static final String MESSAGE = "message";


    @ExceptionHandler(value = UserNotFoundException.class)
    public ResponseEntity<ListErrorDto> handleEntityNotFound(UserNotFoundException ex) {
        var responseDto = new ListErrorDto(Constant.USER_NOT_FOUND_EXCEPTION);
        return new ResponseEntity<>(responseDto, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = WrongPasswordException.class)
    public ResponseEntity<ListErrorDto> handleWrongPassword(WrongPasswordException ex) {
        var responseDto = new ListErrorDto(Constant.WRONG_PASSWORD_EXCEPTION);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Map<String, String> returnErrorAboutWrongInput(HttpMessageNotReadableException ex) {

        return JsonResponse.setErrors("BAD_REQUEST", "Wrong Input given by User");
    }

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Map<String, String> elementNotPresent(NoSuchElementException ex) {
        return JsonResponse.setErrors("BAD_REQUEST", "Element not exists");
    }

    @ExceptionHandler(JDBCConnectionException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Map<String, String> handleJdbcConnectionFailure(JDBCConnectionException ex) {
        return JsonResponse.setErrors("INTERNAL_SERVER_ERROR", "Database Connection Failed");
    }

    @ExceptionHandler(InvalidVerificationCodeException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, List<Map<String, String>>> returnInvalidCodeException(InvalidVerificationCodeException ex) {
        return JsonResponse.setError("EMAIL_VERIFICATION_ERROR", Constant.VERIFICATION_FAILED_MSG.toString());
    }

    @ExceptionHandler(UserDoesNotExistException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, List<Map<String, String>>> returnInvalidUserException(UserDoesNotExistException ex) {
        return JsonResponse.setError("USER_NOT_FOUND", Constant.USER_DOES_NOT_EXIST.toString());
    }


    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, List<Map<String, String>>> invalidFieldsException(MethodArgumentNotValidException ex) {
        List<Map<String, String>> errorList = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String errorMessage = error.getDefaultMessage();
            errorList.add(JsonResponse.setErrors("VALIDATION_ERROR", ((FieldError) error).getField() + ": " + errorMessage));
        });
        return JsonResponse.setErrorResponse(errorList);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(AccountAlreadyExistsException.class)
    @ResponseBody
    public Map<String, List<Map<String, String>>> returnAccountAlreadyExistsException(AccountAlreadyExistsException ex) {
        return JsonResponse.setError("ACCOUNT_ALREADY_EXISTS", ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(AlreadyVerifiedException.class)
    @ResponseBody
    public Map<String, List<Map<String, String>>> returnEmailAlreadyVerifiedException(AlreadyVerifiedException ex) {
        return JsonResponse.setError("EMAIL_VERIFICATION_ERROR", Constant.ALREADY_VERIFIED_MSG.toString());
    }


    public Map<String, String> getMessage(String message) {
        mp = new HashMap<>();
        mp.put(MESSAGE, message);
        return mp;
    }

    @ExceptionHandler(InvalidCredentialsException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Map<String, List<Object>> invalidCredentials(InvalidCredentialsException ex) {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_CREDENTIALS.name());
        message.put(MESSAGE, ex.getMessage());
        messages.add(message);
        return getMessage(messages);
    }

    @ExceptionHandler(InvalidAccessTokenException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    public Map<String, List<Object>> invalidAccessToken(InvalidAccessTokenException ex) {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_ACCESS_TOKEN.name());
        message.put(MESSAGE, ex.getMessage());
        messages.add(message);
        return getMessage(messages);
    }

    @ExceptionHandler(InvalidRefreshTokenException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    public Map<String, List<Object>> invalidRefreshToken(InvalidRefreshTokenException ex) {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_REFRESH_TOKEN.name());
        message.put(MESSAGE, ex.getMessage());
        messages.add(message);
        return getMessage(messages);
    }

    // Return not Found with relevant error message if email doesn't exists in system
    @ExceptionHandler(EmailNotFoundException.class)
    public ResponseEntity<ListErrorDto> returnEmailNotFoundException(EmailNotFoundException emailNotFoundException) {
        var responseDto = new ListErrorDto(Constant.NO_ACCOUNT_MESSAGE);
        return new ResponseEntity<>(responseDto, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({IllegalBlockSizeException.class, BadPaddingException.class, BadCredentialsException.class})
    @ResponseBody
    public Map<String, List<Object>> emailNotVerified(EmailNotVerifiedException ex) {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.EMAIL_NOT_VERIFIED.name());
        message.put(MESSAGE, ex.getMessage());
        messages.add(message);
        return getMessage(messages);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ListErrorDto handleEncryptionException(Exception exp) {
        log.info("Invalid credentials {}", exp.getMessage());
        return new ListErrorDto(Constant.BAD_CREDENTIALS_MESSAGE);
    }


    @ExceptionHandler({NoSuchPaddingException.class, NoSuchAlgorithmException.class, InvalidKeySpecException.class, InvalidKeyException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ListErrorDto handleAlgoLoadFailedException(Exception exp) {
        log.error("failed to load the credentials {} {}", exp.getClass(), exp.getMessage());
        return new ListErrorDto(Constant.SERVER_ERROR_MESSAGE);
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Map<String, String> handleExceptions(Exception ex) {
        return getMessage(ex.getMessage());
    }

    @ExceptionHandler(MethodNotAllowedException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ResponseBody
    @Generated
    public Map<String, String> returnMethodNotAllowed(MethodNotAllowedException ex) {
        return JsonResponse.setErrors("METHOD_NOT_ALLOWED", "Method is not allowed");
    }

    @ExceptionHandler(ProtocolException.class)
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ResponseBody
    @Generated
    public Map<String, String> returnInvalidHttpMethod(ProtocolException ex) {
        return JsonResponse.setErrors("METHOD_NOT_ALLOWED", "Http Method is invalid");
    }

    @ExceptionHandler(TransactionException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @Generated
    public Map<String, String> returnTransactionFailed(TransactionException ex) {
        return JsonResponse.setErrors("INTERNAL_SERVER_ERROR", "Inconsistency or Transactional failure encountered");
    }

}
