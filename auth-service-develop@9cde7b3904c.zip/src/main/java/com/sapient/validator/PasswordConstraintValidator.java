package com.sapient.validator;

import com.sapient.exception.BadCredentialsException;
import com.sapient.utils.CryptoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

@Component
@Slf4j
public class PasswordConstraintValidator implements ConstraintValidator<PasswordConstraint,String> {

    @Autowired
    CryptoService service;
    @Override
    public void initialize(PasswordConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }
    @Override
    public boolean isValid(String password, ConstraintValidatorContext constraintValidatorContext) {
        String newPassword;
        try {
            newPassword = service.decrypt(password);
        } catch (IllegalBlockSizeException |BadPaddingException e) {
            log.trace("can't decrypt the password");
            throw new BadCredentialsException("Bad Credentials received");
        }


        var rule="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\\s).{8,15}$";
        var pattern=Pattern.compile(rule);
        var matcher=pattern.matcher(newPassword);
        log.trace("password is validity {}", matcher.matches());
        return matcher.matches();
    }
}
