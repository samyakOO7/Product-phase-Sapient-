package com.sapient.validator;

import lombok.Generated;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.constraints.Email;
import java.util.regex.Pattern;

@Generated
public class EmailConstraintValidator implements ConstraintValidator<EmailConstraint,String> {
    @Override
    public void initialize(EmailConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Email
    @Override
    @Generated
    public boolean isValid(String email, ConstraintValidatorContext constraintValidatorContext) {
        //decrypt email before this
        
        //using the owasp rule
        var rule="(\\S+@\\w+\\.)[\\w]{2,7}$";
        var pattern=Pattern.compile(rule,Pattern.CASE_INSENSITIVE);
        var matcher=pattern.matcher(email);
        return matcher.find();
    }
}
