package com.sapient.payload;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmailVerification {
    private String email;
    private String firstName;
    private String url;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmailVerification that = (EmailVerification) o;
        return email.equals(that.email);
    }

    @Override
    public String toString() {
        return "EmailVerification{" +
                "email='" + email + '\'' +
                ", firstName='" + firstName + '\'' +
                ", url='" + url + '\'' +
                '}';
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }

}
