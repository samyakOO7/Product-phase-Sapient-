package com.sapient.config;

import brave.sampler.Sampler;
import lombok.Generated;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
@Generated
public class ThreadConfig {

    @Bean
    public ExecutorService getExecutorService() {
        //Creating thread pool to send messages.
        //Temporary solution, will be replaced later on with kafka
        return Executors.newFixedThreadPool(200);
    }

    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }
}
