package com.sapient.config;

public class Constant {
    private Constant() {
    }

    public static final String USER_NOT_FOUND_EXCEPTION = "User Not Found Exception Occurred : {}";
    public static final String WRONG_PASSWORD_EXCEPTION = "Incorrect Password Exception Occurred : {}";

}
