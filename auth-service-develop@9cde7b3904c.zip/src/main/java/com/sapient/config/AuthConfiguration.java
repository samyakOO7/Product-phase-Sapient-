package com.sapient.config;

import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.JWTService;
import com.sapient.utils.JWTServiceImpl;
import com.sapient.utils.impl.CryptoServiceImpl;
import com.sapient.utils.impl.HashServiceImpl;
import lombok.Generated;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

@Generated
@Configuration
public class AuthConfiguration {

    @Value("${auth.asymmetric.algo-name}")
    String algorithm;
    @Value("${auth.asymmetric.public-key}")
    String publicKey;

    @Value("${auth.asymmetric.private-key}")
    String privateKey;


    @Value("${auth.hash.algo-name}")
    String hashAlgo;

    @Value("${auth.hash.salt}")
    String salt;

    @Generated
    @Bean
    public CryptoService cryptoService() throws InvalidKeySpecException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        CryptoService service = new CryptoServiceImpl();
        service.loadAlgorithm(algorithm);
        service.loadKeyPair(publicKey, privateKey);
        return service;
    }

    @Bean
    @Generated
    public HashService hashService() throws NoSuchAlgorithmException {
        HashService service = new HashServiceImpl();
        service.loadAlgorithm(hashAlgo);
        service.loadSalt(salt);
        return service;
    }

    @Value("${authToken.secretKey}")
    public String secretKey;

    @Value("${authToken.accessExpirationMs}")
    public long accessExpTime;

    @Value("${authToken.refreshExpirationMs}")
    public long refreshExpTime;

    @Bean
    public JWTService jwtService() {
        JWTService jwtService = new JWTServiceImpl();
        jwtService.setSecretKey(secretKey);
        jwtService.setExpirationTimeForAccessToken(accessExpTime);
        jwtService.setExpirationTimeForRefreshToken(refreshExpTime);
        return jwtService;
    }



}
