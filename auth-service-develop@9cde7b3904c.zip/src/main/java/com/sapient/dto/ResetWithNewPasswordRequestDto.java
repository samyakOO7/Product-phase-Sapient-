package com.sapient.dto;

import com.sapient.validator.PasswordConstraint;
import lombok.Data;

@Data
public class ResetWithNewPasswordRequestDto {

    @PasswordConstraint
    String password;
}
