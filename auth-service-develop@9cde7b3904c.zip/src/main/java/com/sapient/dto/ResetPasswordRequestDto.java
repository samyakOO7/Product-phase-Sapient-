package com.sapient.dto;

import com.sapient.validator.EmailConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;


//data to be sent to the controller for reset password
@Data
@NoArgsConstructor
@AllArgsConstructor
@Generated
public class ResetPasswordRequestDto {

    @EmailConstraint
    String email;
}
