package com.sapient.dto;

import com.sapient.constant.Constant;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
public class ListErrorDto {
    List<ErrorDto> errors;

    public ListErrorDto() {
        errors =  new ArrayList<>();
    }

    public ListErrorDto(Constant cnt) {
        errors =  new ArrayList<>();
        add(cnt);
    }

    public void add(Constant cnt){
        errors.add(new ErrorDto(cnt));
    }
}
