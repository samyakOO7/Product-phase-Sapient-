package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

//data which will be sent to client after he has requested for reset password URL
@Data
@NoArgsConstructor
@AllArgsConstructor
@Generated
public class ResetPasswordResponseDto {

    //return message which you want to display on front end
    String message;
}
