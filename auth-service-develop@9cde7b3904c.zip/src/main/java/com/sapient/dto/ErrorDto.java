package com.sapient.dto;

import com.sapient.constant.Constant;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ErrorDto {

    String code;
    String message;

    public ErrorDto(Constant error){
         this.code = error.name();
         this.message = error.toString();
    }

}
