package com.sapient.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserDto {

    @NotBlank(message = "Username can not be null or empty")
    @Column(unique = true, nullable = false)
    private String userName;
    @NotBlank(message = "Password can not be null or empty")
    @Column(nullable = false)
    private String password;
    @NotBlank(message = "Email can not be null or empty")
    @Pattern(regexp = "(\\S+@\\w+\\.)[\\w]{2,7}(\\s)*$", message = "Email is invalid")
    @Column(unique = true, nullable = false)
    private String email;
    private String alternateEmail;
    @Pattern(regexp = "^([\\d]{10}(\\s)*)", message ="Phone number is invalid")
    private String phoneNumber;
    @NotBlank(message = "firstName can not be null or empty")
    private String firstName;
    private String lastName;

    @Override
    public String toString() {
        return "UserDto{" +
                "userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", email='" + email + '\'' +
                ", alternateEmail='" + alternateEmail + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        var userDto = (UserDto) o;
        return userName.equals(userDto.userName);
    }

    @Override
    public int hashCode() {
        return userName.hashCode();
    }
}
