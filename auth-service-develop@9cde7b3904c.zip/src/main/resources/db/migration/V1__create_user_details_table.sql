--creating the user details table

create table user_details(
	user_id bigint primary key,
	user_name varchar(255) unique,
	password varchar(255) not null,
	email varchar(255) not null,
	alternate_email varchar(255),
	phone_number varchar(255)
);