--adding a unique key constraint on email field
ALTER TABLE user_details ADD CONSTRAINT user_details_email_unique UNIQUE(email);