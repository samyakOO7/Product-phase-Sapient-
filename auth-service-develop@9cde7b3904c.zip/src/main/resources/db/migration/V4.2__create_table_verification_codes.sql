create table verification_codes(
     verification_codes bigint primary key,
     user_id bigint references user_details(user_id) not null,
     code varchar(255) not null unique,
     expiry_time timestamp not null,
     type varchar(30) not null check(type in ('user_verification','reset_password'))
);


create index verification_codes_type_code_index on verification_codes(type,code);

alter table verification_codes add constraint verification_codes_user_id_type_unique unique(user_id,type);