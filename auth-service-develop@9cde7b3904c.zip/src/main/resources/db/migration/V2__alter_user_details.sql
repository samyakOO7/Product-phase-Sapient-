--adding the first name and last name fields

ALTER TABLE user_details ADD first_name varchar(255);

ALTER TABLE user_details ADD last_name varchar(255);