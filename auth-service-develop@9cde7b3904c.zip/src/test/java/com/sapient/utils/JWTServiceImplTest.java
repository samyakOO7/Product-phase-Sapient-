package com.sapient.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = JWTServiceImpl.class)
class JWTServiceImplTest {

    @Autowired
    JWTService testJwtService;

    @BeforeEach
    void setUp() {
        testJwtService.setSecretKey("secret");
        testJwtService.setExpirationTimeForRefreshToken(12000);
        testJwtService.setExpirationTimeForAccessToken(12000);
    }

    @Test
    @DisplayName("Returns an access token")
    void generateAccessTokenReturnsTokenIfClaimsAndUsernameIsPassed() {

        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", 1);
        String username = "rajini12";
        Assertions.assertThat(testJwtService.generateAccessToken(claims, username)).isNotEmpty();
    }

    @Test
    @DisplayName("Returns an access token")
    void generateRefreshTokenReturnsTokenIfClaimsAndUsernameIsPassed() {

        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", 1);
        String username = "rajini12";
        Assertions.assertThat(testJwtService.generateRefreshToken(claims, username)).isNotEmpty();
    }

    @Test
    @DisplayName("Returns claims when token passed")
    void getClaimsReturnsCalims() {

        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", 1);
        String username = "rajini12";
        String token = testJwtService.generateAccessToken(claims, username);

        Claims claim = Jwts.parser().setSigningKey("secret")
                .parseClaimsJws(token).getBody();
        token = "Bearer " + token;
        Assertions.assertThat(testJwtService.getClaims(token)).isEqualTo(claim);
    }

    @Test
    @DisplayName("Returns True if token is valid")
    void validateTokenReturnsTrueIfTokenIsValid() {

        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", 1);
        String username = "rajini12";
        String token = testJwtService.generateAccessToken(claims, username);

        assertTrue(testJwtService.validateToken("Bearer " + token));

    }

    @Test
    @DisplayName("Returns false if token is invalid")
    void validateTokenReturnsFalseIfTokenIsInvalid() {

        assertFalse(testJwtService.validateToken("Bearer invalid token"));

    }

    @Test
    @DisplayName("Returns false if Bearer keyword is misspelt or missing")
    void validateTokenReturnsFalseIfBearerKeywordIsMissing() {

        assertFalse(testJwtService.validateToken("invalid token"));

    }


}