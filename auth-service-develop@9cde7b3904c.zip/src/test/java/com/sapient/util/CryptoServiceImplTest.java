package com.sapient.util;

import com.sapient.utils.CryptoService;
import com.sapient.utils.impl.CryptoServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import static org.junit.jupiter.api.Assertions.assertEquals;


class CryptoServiceImplTest {


    CryptoServiceImpl impl;

    @Autowired
    CryptoService cryptoService;

    String ALGORITHM = "RSA";

    String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsh2sdqlS6kJxTEx+5wxDELHQGt9fADvLOSI1yRbpVFVgh1CRn6lajRbn9N2IDqirkQIOM2ZToePVhSTCbDEb6/QHxOal+mPFaDgcLF1zxi5MhEcNDBVnuk3UHOnGmcqKMxLi+x6sz6zlsTaiU8AygWkqH/LIZAHQSHLICJ7Vf5KDCOvq2y+3sy9zpERJ8UzLoqWQJ+Epe58/C4jKRPSN5tH9h5fMhuiBoOuW6M80X8+ir0Q26a9mlasAI3qtyF/zZiR6RhxZDhcaNRcruD7Jy12jVIWNG9jl+LttWyZvnB8VkAs6OYACdUChxnAbJg8guP5B0OebFZyVCVojm/9w1wIDAQAB";

    String PRIVATE_KEY = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyHax2qVLqQnFMTH7nDEMQsdAa318AO8s5IjXJFulUVWCHUJGfqVqNFuf03YgOqKuRAg4zZlOh49WFJMJsMRvr9AfE5qX6Y8VoOBwsXXPGLkyERw0MFWe6TdQc6caZyoozEuL7HqzPrOWxNqJTwDKBaSof8shkAdBIcsgIntV/koMI6+rbL7ezL3OkREnxTMuipZAn4Sl7nz8LiMpE9I3m0f2Hl8yG6IGg65bozzRfz6KvRDbpr2aVqwAjeq3IX/NmJHpGHFkOFxo1Fyu4PsnLXaNUhY0b2OX4u21bJm+cHxWQCzo5gAJ1QKHGcBsmDyC4/kHQ55sVnJUJWiOb/3DXAgMBAAECggEAUmUxu+7WYXH9EWutpNpiR93JxDSisOv4NeTidrS3mYCpV89onjBsqCn5gafdYdKbE0idIx/p/lD0HFSF8CDDpuJLmcWM8Iio8G5MciWFAh+229Y2bemVA3Uvc3Sdn9U3GytYfwyQqr1zwAfjDdUyR/VLPF5GXyULoggfCwXXA90QSn7jaeZdwwQRbuiYvYYl/8vBtfoKHL8JqYsLoti5NnZWLwbH2A15lk/SnPETE5mD54A8eHBTOsTJlbkOMlsy1JZabupdzLqGxC+n1wFZhhUet1Wxa+zNyZ9tFpC7JfuimZJRmz21oWzl6wRUg36lrK1UIAVzrdd6LcV7U1WXSQKBgQDa+OKHxaTj2GZ7iLZlAcA/hvD2fUeTxKid7Natm939GpgLpbobYOjb3c1WOwiD8gvWwUAf+WTeZAeqX8hGseiIctbPi2OQwEAQ16Xh1HeaYNxonmGtw9gZP+p13Y/2VVfAOUu+Bfp+LdJWFFNYRYf6vBeeZqwGPOMJ2s37DmoHywKBgQDQPCfWVu1HvyybGJLAqtLH7T+AZTvUQxNAXvDkcvEFyg9dPNOCbbhdiqHP/oNL7gRy6W38xelxyE5b5iS4PZfXcS2avg8VaAoPZYL0F5Bt3XDIK/lkZpngfGns/p+r+jFCf5FHCnawoFfDj4Gc+RLWe9/8bgcYa5EFLiDOwo3hpQKBgBQslgJYTUbIqzh6cgOAU8wGjLDI/g05MyfJqEW6dItbJeL809at6QZIuyBUtAYkCL8ycsv/WDG9GY+y32rT/U6E9hGNEBFIBR8IHzpdLt/ESMpCvVEbGA/Lebh+P0M8vabyIG5Tcq6pXhWcLcmWLl8FcU+gufyhI3HG/O9CdrZdAoGAS51sgeKy6xi6o986ewgM3liCdKdOIHfy568SHoK2jvmetqa9z2D0T9NlitfK6amWp/un2uArMwwfmDNsJhMHrk4E12oopAdRj+G2udhMs/hzWdzOBO1U9zV2aX7UkGibtqAIKxnbm6u98t+Lm2q+sm/tGAcEQJPe51imxS3Uw5kCgYEAoCX7ObivFdj8Swx2RsDhxs/cR4H1qkawpSc5TQaocamEgZxanZACSq98M+bPxjYvQjAqNhic3MmfwvJqDXoKogmoDQzjufNDKMfXF3sSuj1wBcfDq9R8ehBFahzyzvThl+bG1l4T8ITI3IlVtFU01NjvCT9yf4puyDlbJtXg7fo=";



    @BeforeEach
    public void cryptoService() throws InvalidKeySpecException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        CryptoServiceImpl service  = new CryptoServiceImpl();
        service.loadAlgorithm(ALGORITHM);
        service.loadKeyPair(PUBLIC_KEY,PRIVATE_KEY);
        this.impl = service;
    }

    @Test
    void testCryptoService() throws IllegalBlockSizeException, BadPaddingException {
        String msg = "this is my message";
        String cipher = impl.encrypt(msg);
        String newMsg = impl.decrypt(cipher);
        assertEquals(msg, newMsg);
    }
}