package com.sapient.util;

import com.sapient.utils.impl.HashServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HashServiceImplTest {

    String HASH_ALGO="MD5";

    String SALT="zDROCLp0HpoHLBd6X2WcPg==";

    HashServiceImpl impl;

    @BeforeEach
    public void hashService() throws NoSuchAlgorithmException {
        HashServiceImpl service = new HashServiceImpl();
        service.loadAlgorithm(HASH_ALGO);
        service.loadSalt(SALT);
        this.impl = service;

    }
    @Test
    void hash() {
        String message = "this is a message";
        String hashedMsg = impl.hash(message);
        String newHashedMsg  = impl.hash(message);
        assertEquals(hashedMsg,newHashedMsg);
    }
}