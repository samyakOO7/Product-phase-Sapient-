package com.sapient.entity;

import com.sapient.dto.UserDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;

@DisplayName("User Test")
class UserTest {

    private User user;

    @BeforeEach
    public void loadUser() {
        user = new User();
    }

    @Test
    @DisplayName("First Name Test")
    void getFirstName() {

        String S = "Ritik";
        user.setFirstName("Ritik");
        Assertions.assertEquals(S, user.getFirstName());
    }

    @Test
    @DisplayName("User Name Test")
    void getUserName() {
        String S = "RS";
        user.setUserName("RS");
        Assertions.assertEquals(S, user.getUserName());
    }

    @Test
    @DisplayName("last Name Test")
    void getLastName() {
        String S = "Ritik";
        user.setLastName("Shrivastav");
        Assertions.assertNotEquals(S, user.getLastName());
    }

    @Test
    @DisplayName("Password Test in entity user")
    void getPassword() {
        user.setPassword("1234");
        Assertions.assertEquals("1234", user.getPassword());
    }

    @Test
    @DisplayName("Phone Number Test should return false here")
    void getPhoneNumber() {
        user.setPhoneNumber("9438393");
        Assertions.assertNotEquals(("912332244"), user.getPhoneNumber());
    }
    @Test
    @DisplayName("Verified test")
    void getVerified(){
        user.setVerified(false);
        Assertions.assertEquals(false,user.isVerified());
    }

    @Test
    @DisplayName("Userid test")
    void getUserId() {
        user.setUserId(BigInteger.ONE);
        Assertions.assertEquals((BigInteger.ONE), user.getUserId());
    }

    @Test
    @DisplayName("Email test")
    void getEmail() {
        user.setEmail("rs@gmail.com");
        Assertions.assertEquals(("rs@gmail.com"), user.getEmail());
    }

    @Test
    @DisplayName("alternate email test")
    void getAlternateEmail() {
        user.setAlternateEmail("pk@gmail.com");
        Assertions.assertNotEquals(("ab@gmail.com"), user.getAlternateEmail());
    }

    @Test
    void testToString() {
        User user = new User(BigInteger.ONE, "RitikShrivastav", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "Ritik", "Shrivastav", false);
        String expectedUser = "User{" +
                "userId=" + user.getUserId() +
                ", userName='" + user.getUserName() + '\'' +
                ", password='" + user.getPassword() + '\'' +
                ", email='" + user.getEmail() + '\'' +
                ", alternateEmail='" + user.getAlternateEmail() + '\'' +
                ", phoneNumber='" + user.getPhoneNumber() + '\'' +
                ", firstName='" + user.getFirstName() + '\'' +
                ", lastName='" + user.getLastName() + '\'' +
                ", verified=" + user.isVerified() +
                '}';
        Assertions.assertEquals(expectedUser, user.toString());
    }

    @Test
    void testEquals() {
        User user1 = new User(BigInteger.ONE, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        User user2 = new User(BigInteger.ONE, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        Boolean actual = user1.equals(user2);
        Boolean expected = true;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testNotEquals() {
        User user1 = new User(BigInteger.ONE, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        User user2 = new User(BigInteger.TWO, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        Boolean actual = user1.equals(user2);
        Boolean expected = false;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testHashCodeEquals() {
        User user1 = new User(BigInteger.ONE, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        User user2 = new User(BigInteger.ONE, "Ritik", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        int user1Hashcode = user1.hashCode();
        int user2Hashcode = user2.hashCode();
        Boolean actual = (user1Hashcode == user2Hashcode);
        Boolean expected = true;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testHashCodeNotEquals() {
        User user1 = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        User user2 = new User(BigInteger.TWO, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        int user1Hashcode = user1.hashCode();
        int user2Hashcode = user2.hashCode();
        Boolean actual = (user1Hashcode == user2Hashcode);
        Boolean expected = false;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testEqualUserReferences() {
        User user1 = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        User user2 = user1;
        Assertions.assertEquals(true, user2.equals(user1));
    }

    @Test
    void testUserNull() {
        User user2 = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        Assertions.assertEquals(false, user2.equals(null));
    }

    @Test
    void testUserClass() {
        UserDto userdto1 = new UserDto("RST", "fgbbfbSSfg", "abcd@domain.com", "xyzf@domain.com", "343342342", "Geordge", "Stuartd");
        User user = new User(BigInteger.ONE, "RST", "fgbbfbSSfg", "abcd@domain.com", "xyzf@domain.com", "343342342", "Geordge", "Stuartd", false);
        Assertions.assertEquals(false, user.equals(userdto1));
    }
}

