package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.EmailNotVerifiedException;
import com.sapient.exception.InvalidAccessTokenException;
import com.sapient.exception.InvalidCredentialsException;
import com.sapient.exception.InvalidRefreshTokenException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AuthAdvice.class)
class AuthAdviceTest {

    @Autowired
    AuthAdvice testAuthAdvice;

    @Test
    void getMessageShouldReturnAMapWhenAMessageIsPassed() {
        String message = "Test message";
        Map<String, String> expectedResult = new HashMap<>();
        expectedResult.put("message", message);
        assertEquals(expectedResult, testAuthAdvice.getMessage(message));

    }

    @Test
    void getMessageShouldReturnAMapWhenAListIsPassed() {
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", "error_code");
        messages.add(message);
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, testAuthAdvice.getMessage(messages));

    }

    @Test
    void invalidCredentialsShouldReturnMapWhenInvalidCredentialsExceptionPassed() {
        String msg = "Invalid credentials";
        InvalidCredentialsException ex = new InvalidCredentialsException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_CREDENTIALS.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, testAuthAdvice.invalidCredentials(ex));
    }

    @Test
    void invalidAccessTokenShouldReturnMapWhenInvalidAccessTokenExceptionPassed() {
        String msg = "Invalid access token";
        InvalidAccessTokenException ex = new InvalidAccessTokenException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_ACCESS_TOKEN.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, testAuthAdvice.invalidAccessToken(ex));

    }

    @Test
    void invalidRefreshTokenShouldReturnMapWhenInvalidRefreshTokenExceptionPassed() {
        String msg = "Invalid refresh token";
        InvalidRefreshTokenException ex = new InvalidRefreshTokenException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.INVALID_REFRESH_TOKEN.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, testAuthAdvice.invalidRefreshToken(ex));

    }

    @Test
    void emailNotVerified() {
        String msg = "Email is not verified";
        EmailNotVerifiedException ex = new EmailNotVerifiedException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.EMAIL_NOT_VERIFIED.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, testAuthAdvice.emailNotVerified(ex));
    }


    @Test
    void handleExceptions() {
        String message = "Generic exception";
        Exception ex = new Exception(message);
        Map<String, String> expectedResult = new HashMap<>();
        expectedResult.put("message", message);
        assertEquals(expectedResult, testAuthAdvice.handleExceptions(ex));
    }
}