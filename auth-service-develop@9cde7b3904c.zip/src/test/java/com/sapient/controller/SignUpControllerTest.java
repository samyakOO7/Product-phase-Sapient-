package com.sapient.controller;

import com.sapient.advice.AuthAdvice;
import com.sapient.constant.Constant;
import com.sapient.dto.UserDto;
import com.sapient.exception.AccountAlreadyExistsException;
import com.sapient.exception.AlreadyVerifiedException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.UserDoesNotExistException;
import com.sapient.repository.UserRepository;
import com.sapient.repository.VerificationCodesRepository;
import com.sapient.service.SignUpService;
import org.hibernate.exception.JDBCConnectionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.NoSuchElementException;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {SignUpController.class, SignUpService.class, AuthAdvice.class})
@WebMvcTest(SignUpController.class)
public class SignUpControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private SignUpService service;
    @MockBean
    UserRepository userRepository;
    @MockBean
    VerificationCodesRepository verficationCodesRepository;

    @Test
    public void signupUser() throws Exception {
        Mockito.when(service.register(any(UserDto.class), anyString())).thenReturn(String.valueOf(Constant.REGISTRATION_SUCCESS_MSG));
        mvc.perform(post("/signup").contentType(MediaType.APPLICATION_JSON).content("{ \"userName\":\"Ritik\",\"password\" :\"ABCDE\",\"email\": \"rs@gmail.com\",\"firstName\":\"Ritik\",\"lastName\":\"Shrivasstav\",\"phoneNumber\":\"1234567890\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",is(Constant.REGISTRATION_SUCCESS_MSG.toString())));
    }
    @Test
    public void signupUseNotReadable() throws Exception {
        Mockito.when(service.register(any(UserDto.class), anyString())).thenThrow(HttpMessageNotReadableException.class);
        mvc.perform(post("/signup").contentType(MediaType.APPLICATION_JSON).content("{ \"userName\":\"Ritik\",\"password\" :\"ABCDE\",\"email\": \"rs@gmail.com\",\"firstName\":\"Ritik\",\"lastName\":\"Shrivasstav\",\"phoneNumber\":\"1234567890\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message",is("Wrong Input given by User")));
    }
    @Test
    public void elementNotPresent() throws Exception, AlreadyVerifiedException {
        Mockito.when(service.verify("1234")).thenThrow(NoSuchElementException.class);
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON).content("{ \"userName\":\"Ritik\",\"password\" :\"ABCDE\",\"email\": \"rs@gmail.com\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message",is("Element not exists")));
    }

    @Test
    public void jdbcConnectionFailed() throws Exception, AlreadyVerifiedException {
        Mockito.when(service.verify("1234")).thenThrow(JDBCConnectionException.class);
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON).content("{ \"userName\":\"Ritik\",\"password\" :\"ABCDE\",\"email\": \"rs@gmail.com\"}"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.message",is("Database Connection Failed")));
    }


    @Test
    public void verifyUser() throws Exception, AlreadyVerifiedException {
        given(service.verify("1234")).willReturn(Constant.VERIFICATION_SUCCESS_MSG.toString());
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",is(Constant.VERIFICATION_SUCCESS_MSG.toString())));
    }
    @Test
    public void expiredLinkResentMsg() throws Exception, AlreadyVerifiedException {
        given(service.verify("1234")).willReturn(Constant.LINK_EXPIRED_SENT_ANOTHER_EMAIL.toString());
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message",is(Constant.LINK_EXPIRED_SENT_ANOTHER_EMAIL.toString())));
    }
    @Test
    public void invalidateUser() throws Exception, AlreadyVerifiedException {
        given(service.verify("1234")).willThrow(InvalidVerificationCodeException.class);
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message",is(Constant.VERIFICATION_FAILED_MSG.toString())));
    }
    @Test
    public void invalidEmailFormat() throws Exception{
        mvc.perform(post("/signup")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"userName\":\"Ritik\",\"firstName\":\"Raj\",\"password\" :\"ABCDE\",\"email\": \"rs@.com\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message",is(Constant.WRONG_EMAIL_FORMAT.toString())));
    }
    @Test
    public void alreadyVerifiedUser() throws Exception, AlreadyVerifiedException {
        given(service.verify("1234")).willThrow(AlreadyVerifiedException.class);
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message",is(Constant.ALREADY_VERIFIED_MSG.toString())));
    }
    @Test
    public void existingUser() throws Exception {
       given(service.register(any(UserDto.class), anyString())).willThrow(AccountAlreadyExistsException.class);
        mvc.perform(post("/signup").contentType(MediaType.APPLICATION_JSON).content("{ \"userName\":\"Ritik\",\"password\" :\"ABCDE\",\"email\": \"rs@gmail.com\",\"firstName\":\"Ritik\",\"lastName\":\"Shrivasstav\",\"phoneNumber\":\"1234567890\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code",is("ACCOUNT_ALREADY_EXISTS")));
    }
    @Test
    public void notPresentUser() throws Exception, AlreadyVerifiedException {
        given(service.verify("1234")).willThrow(UserDoesNotExistException.class);
        mvc.perform(get("/verify?code=1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.errors[0].message",is(Constant.USER_DOES_NOT_EXIST.toString())));
    }
}