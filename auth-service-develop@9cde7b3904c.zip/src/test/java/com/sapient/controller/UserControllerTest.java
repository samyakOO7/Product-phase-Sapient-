package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.advice.AuthAdvice;
import com.sapient.dto.UserUpdateDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.exception.UserNotFoundException;
import com.sapient.exception.WrongPasswordException;
import com.sapient.repository.UserRepository;
import com.sapient.service.UserService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;

import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={UserController.class, AuthAdvice.class})
@WebMvcTest(UserController.class)
class UserControllerTest {

    @MockBean
    UserService userService;

    @MockBean
    UserRepository userRepository;

    @Autowired
    private MockMvc mockMvc;

    ObjectMapper objectMapper = new ObjectMapper();

    ObjectWriter objectWriter = objectMapper.writer();

    @InjectMocks
    private UserController userController;

    static ViewUserDto userDto;
    static ViewUserDto userDto2;

    static UserUpdateDto userUpdateDto;

    @BeforeAll
    static void setUp() {
        userDto = new ViewUserDto(BigInteger.ONE, "username", "email@gmail.com", "alemail@gmial.com", "123321231", "fname", "lname");
        userDto2 = new ViewUserDto(BigInteger.ZERO, "username", "email@gmail.com", "alemail@gmial.com", "123321231", "fname", "lname");
        userUpdateDto = new UserUpdateDto(BigInteger.ONE, "ollpass", "newpass");
    }

    @Test
    void getUserById() throws Exception {
        String responseJson = objectWriter.writeValueAsString(userDto);
        System.out.println(responseJson);
        when(userService.getUserById(userDto.getUserId())).thenReturn(userDto);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/user/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content()
                        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseJson));
    }

    @Test
    void getUserByIdUserNotFoundException() throws Exception {
        when(userService.getUserById(userDto2.getUserId())).thenThrow(new UserNotFoundException());
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/user/0")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }


    @Test
    void updateUser() throws Exception {
        ResponseEntity responseEntity = new ResponseEntity<>("User password is updated successfully", HttpStatus.OK);
        String requestJson = objectWriter.writeValueAsString(userUpdateDto);
        when(userService.updateData(userUpdateDto)).thenReturn(responseEntity);
        mockMvc.perform(MockMvcRequestBuilders
                        .put("/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content()
                        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content().string("User password is updated successfully"));

    }

    @Test
    void updateUserWithWrongUserid() throws Exception {
        String requestJson = objectWriter.writeValueAsString(userUpdateDto);
        when(userService.updateData(userUpdateDto)).thenThrow(new UserNotFoundException());

        mockMvc.perform(MockMvcRequestBuilders
                        .put("/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content().json("{\"errors\":[{\"code\":\"USER_NOT_FOUND_EXCEPTION\",\"message\":\"User Not Found Exception Occurred : {}\"}]}"));




    }

    @Test
    void updateUserWhenPasswordIsWrong() throws Exception {
        ResponseEntity responseEntity = new ResponseEntity<Object>("User not Found", HttpStatus.NOT_FOUND);
        String requestJson = objectWriter.writeValueAsString(userUpdateDto);

        when(userService.updateData(userUpdateDto)).thenThrow(new WrongPasswordException());

        mockMvc.perform(MockMvcRequestBuilders
                        .put("/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content().json("{\"errors\":[{\"code\":\"WRONG_PASSWORD_EXCEPTION\",\"message\":\"Incorrect Password Exception Occurred : {}\"}]}"));



    }

}