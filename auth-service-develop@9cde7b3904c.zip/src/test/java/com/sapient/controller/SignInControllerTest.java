package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.dto.LoginRequestDto;
import com.sapient.dto.LoginResponseDto;
import com.sapient.dto.RefreshResponseDto;
import com.sapient.dto.ValidateResponseDto;
import com.sapient.service.SignInService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigInteger;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {SignInController.class})
@ExtendWith(SpringExtension.class)
class SignInControllerTest {

    @MockBean
    SignInService signInService;


    @Autowired
    SignInController signInController;


    String accessToken = "access token";
    String refreshToken = "refresh token";

    @Test
    @DisplayName("For valid credentials a token should be generated")
    void userSignInReturnsTokenForValidCredentials() throws Exception {
        LoginRequestDto loginRequestDto = new LoginRequestDto("test@gmail.com", "hashed_password");

        String content = (new ObjectMapper()).writeValueAsString(loginRequestDto);


        when(signInService.signIn(loginRequestDto.getEmail(), loginRequestDto.getPassword()))
                .thenReturn(new LoginResponseDto(BigInteger.ONE, "khansaif", accessToken, refreshToken));

        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);


        MockMvcBuilders.standaloneSetup(signInController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.jsonPath("$").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.userId").value(BigInteger.ONE))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("khansaif"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.accessToken").value(accessToken))
                .andExpect(MockMvcResultMatchers.jsonPath("$.refreshToken").value(refreshToken));
    }

    @Test
    @DisplayName("Valid token return success response")
    void validateTokenVerificationSuccess() throws Exception {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", accessToken);

        ValidateResponseDto validateResponseDto = new ValidateResponseDto(BigInteger.ONE, true);
        when(signInService.validateAccessToken(accessToken))
                .thenReturn(validateResponseDto);

        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/validate")
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders);

        MockMvcBuilders.standaloneSetup(signInController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.jsonPath("$").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.userId").value(BigInteger.ONE))
                .andExpect(MockMvcResultMatchers.jsonPath("$.valid").value(true));
    }

    @Test
    @DisplayName("Refresh token return new access token response")
    void refreshTokenReturnsNewAccessToken() throws Exception {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", refreshToken);

        String newAccessToken = "new access token";

        RefreshResponseDto refreshResponseDto = new RefreshResponseDto(newAccessToken);
        when(signInService.getNewAccessToken(refreshToken))
                .thenReturn(refreshResponseDto);

        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/refreshtoken")
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders);

        MockMvcBuilders.standaloneSetup(signInController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.jsonPath("$").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.accessToken").value(newAccessToken));
    }

}