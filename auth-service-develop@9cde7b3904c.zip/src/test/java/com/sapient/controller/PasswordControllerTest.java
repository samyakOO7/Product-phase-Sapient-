package com.sapient.controller;

import com.sapient.advice.AuthAdvice;
import com.sapient.constant.Constant;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.EmailNotFoundException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.service.PasswordService;
import com.sapient.utils.CryptoService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import javax.crypto.BadPaddingException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {PasswordController.class, AuthAdvice.class})
@WebMvcTest(PasswordController.class)
class PasswordControllerTest {

    @Autowired
    MockMvc mvc;
    @MockBean
    PasswordService passwordService;

    @Test
    void generatePasswordChangeLinkWhenEmailPresent() throws Exception {
        doNothing().when(passwordService).sendLinkForResetPassword(anyString(), anyString());

        String email = "abc@domain.com";
        mvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"email\":\"%s\"}", email)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message", is(Constant.EMAIL_SUCCESS_MESSAGE.toString())));
    }

    @Test
    void noPasswordChangeLinkWhenEmailNotPresentInDatabase() throws Exception {
        Mockito.doThrow(new EmailNotFoundException()).when(passwordService).sendLinkForResetPassword(anyString(),anyString());
        String email = "abc@domain.com";
        mvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"email\":\"%s\"}", email)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code", is(Constant.NO_ACCOUNT_MESSAGE.name())))
                .andExpect(jsonPath("$.errors[0].message", is(Constant.NO_ACCOUNT_MESSAGE.toString())));

    }

    @Test
    void userNameMissingBeforeDomain() throws Exception {
        mvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"email\":\".co.in\"}")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message", is(Constant.WRONG_EMAIL_FORMAT.toString())));
    }

    @Test
    void invalidEmailFormat() throws Exception {
        mvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"email\":\"abc\"}")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message", is(Constant.WRONG_EMAIL_FORMAT.toString())));
    }

    @Test
    void missingDomain() throws Exception {
        mvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"email\":\"abc@abc\"}")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message", is(Constant.WRONG_EMAIL_FORMAT.toString())));
    }
    @MockBean
    CryptoService service;


    @Test
    @DisplayName("Verify reset password code return success response")
    void verifyPasswordResetCode_returnSuccessResponse() throws Exception
    {
        given(passwordService.validatePasswordResetCode("1234")).willReturn(new VerificationCodes());
        mvc.perform(get("/reset-password/1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",is(Constant.RESET_PASSWORD_CODE_VALID_MESSAGE.toString())));
    }

    @Test
    @DisplayName("verify reset password code returns bad request")
    void verifyPasswordResetCode_whenCodeIsNotValid_returnBadRequestResponse() throws Exception
    {
        given(passwordService.validatePasswordResetCode(anyString())).willThrow(new InvalidVerificationCodeException(Constant.INVALID_RESET_CODE_MESSAGE.toString()));
        mvc.perform(get("/reset-password/1234").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code",is(Constant.RESET_PASSWORD_CODE_INVALID_RESPONSE_MESSAGE.name())))
                .andExpect(jsonPath("$.errors[0].message",is(Constant.RESET_PASSWORD_CODE_INVALID_RESPONSE_MESSAGE.toString())));
    }

    @Test
    @DisplayName("update password should update when code is valid")
    void updatePassword_whenCodeMatch_returnSuccessResponse() throws Exception {
        String password = "Harish@mad45";
        ArgumentCaptor<String> argCapCode = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> argCapPwd = ArgumentCaptor.forClass(String.class);
        when(service.decrypt(password)).thenReturn(password);
        doNothing().when(passwordService).updatePassword(anyString(),anyString());

        mvc.perform(post("/reset-password/1234").contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"password\" :\"Harish@mad45\"}")
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",is(Constant.RESET_PASSWORD_SUCCESS_MESSAGE.toString() )));
        verify(passwordService).updatePassword(argCapCode.capture(),argCapPwd.capture());
        assertThat(argCapCode.getValue()).isEqualTo("1234");
        assertThat(argCapPwd.getValue()).isEqualTo(password);
    }

    @Test
    @DisplayName("update password should fail when code is invalid")
    void updatePassword_whenCodeMisMath_returnBadResponse() throws Exception {
        String password = "Harish@mad45";
        when(service.decrypt(password)).thenReturn(password);
        doThrow(new InvalidVerificationCodeException(Constant.INVALID_RESET_CODE_MESSAGE.toString())).when(passwordService).updatePassword(anyString(),anyString());
        mvc.perform(post("/reset-password/1234").contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"password\" :\"Harish@mad45\" }")
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code",is(Constant.RESET_PASSWORD_CODE_INVALID_RESPONSE_MESSAGE.name())))
                .andExpect(jsonPath("$.errors[0].message",is(Constant.RESET_PASSWORD_CODE_INVALID_RESPONSE_MESSAGE.toString() )));
        verify(passwordService).updatePassword(anyString(),anyString());

    }

    @Test
    @DisplayName("update password should fail when password is not strong")
    void updatePassword_whenPasswordIsNotStrong_returnBadResponse() throws Exception {
        String password = "Haris45";
        when(service.decrypt(password)).thenReturn(password);
        mvc.perform(post("/reset-password/1234").contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"password\" :\"Haris45\" }")
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].message",is(Constant.BAD_FIELDS_RESPONSE_MESSAGE.toString() )));
        verify(service).decrypt(password);
    }
    @Test
    @DisplayName("update password should fail when password is bad")
    void updatePassword_whenPasswordIsNotDecryptable_returnBadResponse() throws Exception {
        String password = "Harish@45ssn";
        when(service.decrypt(password)).thenThrow(new BadPaddingException());
        mvc.perform(post("/reset-password/1234").contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"password\" :\"Harish@45ssn\" }")
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code",is(Constant.BAD_CREDENTIALS_MESSAGE.name())))
                .andExpect(jsonPath("$.errors[0].message",is(Constant.BAD_CREDENTIALS_MESSAGE.toString() )));
        verify(service).decrypt(password);
    }

}