package com.sapient.service.impl;

import com.sapient.dto.UserUpdateDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.entity.User;
import com.sapient.exception.UserNotFoundException;
import com.sapient.exception.WrongPasswordException;
import com.sapient.repository.UserRepository;
import com.sapient.service.UserService;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = UserServiceImpl.class)
@TestPropertySource("classpath:application.properties")
class UserServiceImplTest {


    @TestConfiguration
    static class UserServiceImplTestContextConfiguration {

        @Bean
        public UserService userService() {
            return new UserServiceImpl();
        }

    }
    @MockBean
    UserRepository userRepository;

    @MockBean
    HashService hashService;
    @MockBean
    CryptoService cryptoService;


    @Autowired
    private UserService userService;

    User dummyUser = new User(new BigInteger(String.valueOf("1")), "sanjay", "oldpass", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com",false);
    ViewUserDto dummyUserDto = new ViewUserDto(new BigInteger(String.valueOf("1")), "sanjay", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com", "test123@gmail.com");
    UserUpdateDto userUpdateDto = new UserUpdateDto(BigInteger.ONE, "oldpass", "newpass");

    @Test
    void getUserById() throws Exception {
        when(userRepository.findById(dummyUser.getUserId())).thenReturn(Optional.of(dummyUser));

        ViewUserDto userDto = userService.getUserById(dummyUser.getUserId());
        assertNotNull(userDto);
        assertEquals(dummyUserDto, userDto);
    }

    @Test
    void getUserByIdUserNotFoundException() {
        BigInteger id = dummyUserDto.getUserId();
        UserNotFoundException userNotFoundException = assertThrows(UserNotFoundException.class,
                () -> userService.getUserById(id));
        assertEquals("User Not Found", userNotFoundException.getMessage());
    }

    @Test
    void updateData() throws IllegalBlockSizeException, BadPaddingException {

        String oldPassword = userUpdateDto.getOldPassword();

        when(cryptoService.decrypt(oldPassword)).thenReturn(oldPassword);
        when(userRepository.findById(userUpdateDto.getUserId())).thenReturn(Optional.ofNullable(dummyUser));
        when(hashService.hash(oldPassword)).thenReturn(oldPassword);
        when(userRepository.save(dummyUser)).thenReturn(dummyUser);
//     actual
        ResponseEntity actualResponse = userService.updateData(userUpdateDto);
        //expected
        ResponseEntity expectedResponse = new ResponseEntity<>("User password is updated successfully", HttpStatus.OK);
        assertNotNull(actualResponse);
        assertEquals("User password is updated successfully", actualResponse.getBody());
        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
    }

    @Test
    void updateDataUserNotFoundException() {

        UserNotFoundException userNotFoundException = assertThrows(UserNotFoundException.class,
                () -> userService.updateData(userUpdateDto));
        assertEquals("User Not Found", userNotFoundException.getMessage());
    }

    @Test
    void updateDataWrongPasswordException() throws IllegalBlockSizeException, BadPaddingException {
        when(userRepository.findById(dummyUser.getUserId())).thenReturn(Optional.of(dummyUser));

        WrongPasswordException wrongPasswordException = assertThrows(WrongPasswordException.class,
                () -> userService.updateData(userUpdateDto));
        assertEquals("Your old password is incorrect", wrongPasswordException.getMessage());

    }


}
