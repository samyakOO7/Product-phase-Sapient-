package com.sapient.service.impl;

import com.sapient.dto.UserDto;
import com.sapient.entity.User;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.AccountAlreadyExistsException;
import com.sapient.exception.AlreadyVerifiedException;
import com.sapient.exception.InvalidVerificationCodeException;
import com.sapient.exception.UserDoesNotExistException;
import com.sapient.payload.EmailVerification;
import com.sapient.repository.UserRepository;
import com.sapient.repository.VerificationCodesRepository;
import com.sapient.service.SignUpService;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.KafkaClientService;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {SignUpServiceImpl.class})
@WebMvcTest(SignUpServiceImpl.class)
public class SignUpServiceImplTest {

    @MockBean
    UserRepository userRepository;
    @MockBean
    VerificationCodesRepository verficationCodesRepository;
    @MockBean
    CryptoService cryptoService;
    @MockBean
    HashService hashService;
    @MockBean
    KafkaClientService kafkaClientService;
    @Autowired
    SignUpService signUpService;

    @Test
    @DisplayName("User Registration test before verification")
    public void register() throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException {
        String code = "adsfksfda";
        VerificationCodes verificationCodes = new VerificationCodes();
        UserDto expectedUserDto = new UserDto("RS", "ritik==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav");
        verificationCodes.setCode("hskakslal");
        verificationCodes.setType("user_verification");
        verificationCodes.setUserId(BigInteger.TEN);
        Timestamp ts = new Timestamp(604800000);//1 week in ms
        verificationCodes.setExpiryTime(ts);
        Mockito.when(verficationCodesRepository.save(any(VerificationCodes.class))).thenReturn(verificationCodes);
        Mockito.when(cryptoService.decrypt(any(String.class))).thenReturn("1234");
        Mockito.when(hashService.hash(any(String.class))).thenReturn("12345");
        Mockito.doNothing().when(kafkaClientService).publishJson(any(EmailVerification.class), any(String.class));
        Mockito.when(userRepository.findByUserNameOrEmail(any(String.class), any(String.class))).thenReturn(new ArrayList<User>());
        Assertions.assertEquals("register success", signUpService.register(expectedUserDto, "www.google.com"));
    }

    @Test
    public void verify() throws InvalidVerificationCodeException, UserDoesNotExistException, AlreadyVerifiedException {
        String code = "adsfksfda";
        String str = "2018-09-01 09:01:15";
        Timestamp timestamp = Timestamp.valueOf(str);
        User expecteduser = new User(BigInteger.ONE, "RS", "harish==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav", false);
        Mockito.when(verficationCodesRepository.findByCode(code)).thenReturn(Optional.of(new VerificationCodes(BigInteger.ONE, BigInteger.ONE, code, timestamp, "user_verification")));
        Mockito.when(userRepository.save(any(User.class))).thenReturn(expecteduser);
        Mockito.when(userRepository.findById(any(BigInteger.class))).thenReturn(Optional.of(expecteduser));
        Assertions.assertNotNull(signUpService.verify(code));
    }

    @Test
    public void verifyWhenInvalidCode() throws InvalidVerificationCodeException {
        String code = "adsfksfda";
        Mockito.when(verficationCodesRepository.findById(code)).thenReturn(Optional.empty());
        Assertions.assertThrows(InvalidVerificationCodeException.class, () -> signUpService.verify(code));
    }

    @Test
    public void checkUserNotFound() throws UserDoesNotExistException {
        String code = "adsfksfda";
        String str = "2018-09-01 09:01:15";
        Timestamp timestamp = Timestamp.valueOf(str);
        User expecteduser = new User(BigInteger.ONE, "RS", "harish==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav", false);
        Mockito.when(verficationCodesRepository.findByCode(code)).thenReturn(Optional.of(new VerificationCodes(BigInteger.ONE, BigInteger.ONE, code, timestamp, "user_verification")));
        Mockito.when(userRepository.save(any(User.class))).thenReturn(expecteduser);
        Mockito.when(userRepository.findById(any(BigInteger.class))).thenReturn(Optional.empty());
        Assertions.assertThrows(UserDoesNotExistException.class, () -> signUpService.verify(code));
    }
    @Test
    @DisplayName("User Registration test before verification")
    public void registerAccountExists() throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException {
        String code = "adsfksfda";
        VerificationCodes verificationCodes = new VerificationCodes();
        UserDto expectedUserDto = new UserDto("RS", "ritik==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav");
        User expectedUser = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        List<User> userList=new ArrayList<User>(){
            {
                add(expectedUser);
            }
        };
        verificationCodes.setCode("hskakslal");
        verificationCodes.setType("user_verification");
        verificationCodes.setUserId(expectedUser.getUserId());
        Timestamp ts = new Timestamp(604800000);//1 week in ms
        verificationCodes.setExpiryTime(ts);
        Mockito.when(verficationCodesRepository.save(any(VerificationCodes.class))).thenReturn(verificationCodes);
        Mockito.when(cryptoService.decrypt(any(String.class))).thenReturn("1234");
        Mockito.when(hashService.hash(any(String.class))).thenReturn("12345");
        Mockito.doNothing().when(kafkaClientService).publishJson(any(EmailVerification.class), any(String.class));
        Mockito.when(userRepository.findByUserNameOrEmail(any(String.class), any(String.class))).thenReturn(userList);
        Assertions.assertThrows(AccountAlreadyExistsException.class, ()->signUpService.register(expectedUserDto, "www.google.com"));
    }
    @Test
    @DisplayName("User Registration test before verification")
    public void registerUserNameExists() throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException {
        String code = "adsfksfda";
        VerificationCodes verificationCodes = new VerificationCodes();
        UserDto expectedUserDto = new UserDto("RS", "ritik==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav");
        User expectedUser = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart", false);
        List<User> userList=new ArrayList<User>(){
            {
                add(expectedUser);
            }
        };
        verificationCodes.setCode("hskakslal");
        verificationCodes.setType("user_verification");
        verificationCodes.setUserId(expectedUser.getUserId());
        Timestamp ts = new Timestamp(604800000);//1 week in ms
        verificationCodes.setExpiryTime(ts);
        Mockito.when(verficationCodesRepository.save(any(VerificationCodes.class))).thenReturn(verificationCodes);
        Mockito.when(cryptoService.decrypt(any(String.class))).thenReturn("1234");
        Mockito.when(hashService.hash(any(String.class))).thenReturn("12345");
        Mockito.doNothing().when(kafkaClientService).publishJson(any(EmailVerification.class), any(String.class));
        Mockito.when(userRepository.findByUserNameOrEmail(any(String.class), any(String.class))).thenReturn(userList);
        Mockito.when(userRepository.findByUserName(any(String.class))).thenReturn(expectedUser);
        Assertions.assertThrows(AccountAlreadyExistsException.class, ()->signUpService.register(expectedUserDto, "www.google.com"));
    }
    @Test
    @DisplayName("User verification test")
    public void emailAlreadyVerified() throws IllegalBlockSizeException, BadPaddingException, UserDoesNotExistException, AccountAlreadyExistsException {
        String code = "adsfksfda";
        String str = "2018-09-01 09:01:15";
        Timestamp timestamp = Timestamp.valueOf(str);
        User expecteduser = new User(BigInteger.ONE, "RS", "harish==/+", "rs@gmail.com", "ab@gmail.com", "8239828", "Ritik", "Shrivastav", true);
        Mockito.when(verficationCodesRepository.findByCode(code)).thenReturn(Optional.of(new VerificationCodes(BigInteger.ONE, BigInteger.ONE, code, timestamp, "user_verification")));
        Mockito.when(userRepository.save(any(User.class))).thenReturn(expecteduser);
        Mockito.when(userRepository.findById(any(BigInteger.class))).thenReturn(Optional.of(expecteduser));
        Assertions.assertThrows(AlreadyVerifiedException.class, () -> signUpService.verify(code));
    }
}