package com.sapient.service;

import com.sapient.dto.LoginResponseDto;
import com.sapient.dto.RefreshResponseDto;
import com.sapient.dto.ValidateResponseDto;
import com.sapient.entity.User;
import com.sapient.exception.EmailNotVerifiedException;
import com.sapient.exception.InvalidAccessTokenException;
import com.sapient.exception.InvalidCredentialsException;
import com.sapient.exception.InvalidRefreshTokenException;
import com.sapient.repository.UserRepository;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.JWTService;
import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = SignInServiceImpl.class)
class SignInServiceImplTest {

    @MockBean
    private UserRepository userRepository;
    @MockBean
    JWTService mockJwtService;
    @MockBean
    HashService mockHashService;

    @MockBean
    CryptoService mockCryptoService;

    @MockBean
    Claims claims;

    @Autowired
    private SignInService testSignInService;


    @Test
    @DisplayName("Returns login dto for valid credentials")
    void signInReturnsLoginDtoIfCredentialsAreValid() throws InvalidCredentialsException, IllegalBlockSizeException, BadPaddingException, EmailNotVerifiedException {

        String email = "rajini@sap.com";
        String encryptPwd = "encrypted password";
        String decryptPwd = "decrypted password";
        String hashPwd = "hashed password";
        String accessToken = "access token";
        String refreshToken = "refresh token";

        User user = new User();
        user.setUserId(BigInteger.TWO);
        user.setUserName("rajini12");
        user.setPassword(hashPwd);
        user.setEmail("rajini@sap.com");
        user.setPhoneNumber("8765432109");
        user.setFirstName("Rajini");
        user.setLastName("G");
        user.setVerified(true);

        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getUserId());

        LoginResponseDto expectedDto = new LoginResponseDto(user.getUserId(), user.getUserName(), accessToken, refreshToken);

        when(userRepository.findByEmail(email)).thenReturn(user);

        when(mockCryptoService.decrypt(encryptPwd)).thenReturn(decryptPwd);
        when(mockHashService.hash(decryptPwd)).thenReturn(hashPwd);

        when(mockJwtService.generateAccessToken(claims, user.getUserName())).thenReturn(accessToken);
        when(mockJwtService.generateRefreshToken(claims, user.getUserName())).thenReturn(refreshToken);

        LoginResponseDto actualDto = testSignInService.signIn(email, encryptPwd);

        assertThat(actualDto).isEqualTo(expectedDto);
        verify(userRepository).findByEmail(email);


    }

    @Test
    @DisplayName("Throws exception for invalid credentials")
    void signInThrowsExceptionIfCredentialsAreInvalid() throws IllegalBlockSizeException, BadPaddingException {

        String email = "rajini@sap.com";
        String encryptPwd = "encrypted password";
        String decryptPwd = "decrypted password";
        String hashPwd = "hashed password";
        String jwtToken = "JWT token";

        User user = new User();
        user.setUserId(BigInteger.TWO);
        user.setUserName("rajini12");
        user.setPassword(hashPwd);
        user.setEmail("rajini@sap.com");
        user.setPhoneNumber("8765432109");
        user.setFirstName("Rajini");
        user.setLastName("G");
        user.setVerified(true);

        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", user.getUserId());

        when(userRepository.findByEmail(email)).thenReturn(user);

        when(mockCryptoService.decrypt(encryptPwd)).thenReturn(decryptPwd);

        when(mockHashService.hash(decryptPwd)).thenReturn(hashPwd);

        when(mockJwtService.generateAccessToken(claims, user.getUserName())).thenReturn(jwtToken);

        assertThrows(InvalidCredentialsException.class, () -> testSignInService.signIn(email, "invalid pwd"));

    }

    @Test
    @DisplayName("Throws exception if email is not verified")
    void signInThrowsExceptionIfEmailIsNotVerified() throws IllegalBlockSizeException, BadPaddingException {

        String email = "rajini@sap.com";
        String encryptPwd = "encrypted password";
        String decryptPwd = "decrypted password";
        String hashPwd = "hashed password";
        String jwtToken = "JWT token";

        User user = new User();
        user.setUserId(BigInteger.TWO);
        user.setUserName("rajini12");
        user.setPassword(hashPwd);
        user.setEmail("rajini@sap.com");
        user.setPhoneNumber("8765432109");
        user.setFirstName("Rajini");
        user.setLastName("G");
        user.setVerified(false);


        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", user.getUserId());

        when(userRepository.findByEmail(email)).thenReturn(user);

        when(mockCryptoService.decrypt(encryptPwd)).thenReturn(decryptPwd);

        when(mockHashService.hash(decryptPwd)).thenReturn(hashPwd);

        when(mockJwtService.generateAccessToken(claims, user.getUserName())).thenReturn(jwtToken);

        assertThrows(EmailNotVerifiedException.class, () -> testSignInService.signIn(email, encryptPwd));
    }

    @Test
    @DisplayName("Returns ValidResponseDto for valid access token")
    void validateAccessTokenReturnsValidResponseDtoIfTokenIsValid() throws InvalidAccessTokenException {

        String accessToken = "access token";

        when(mockJwtService.validateToken(accessToken)).thenReturn(true);
        when(mockJwtService.getClaims(accessToken)).thenReturn(claims);
        when(claims.get(anyString())).thenReturn(BigInteger.TWO);

        ValidateResponseDto validateResponseDto = new ValidateResponseDto(BigInteger.TWO, true);

        assertThat(testSignInService.validateAccessToken(accessToken)).isEqualTo(validateResponseDto);

    }

    @Test
    @DisplayName("Throws InvalidAccessTokenException for invalid access token")
    void validateAccessTokenThrowsExceptionForInvalidToken() throws InvalidAccessTokenException {

        String accessToken = "access token";

        when(mockJwtService.validateToken(accessToken)).thenReturn(false);


        assertThrows(InvalidAccessTokenException.class, () -> testSignInService.validateAccessToken(accessToken));

    }

    @Test
    @DisplayName("Returns RefreshResponseDto for valid refresh token")
    void getNewAccessTokenReturnsRefreshResponseDtoIfTokenIsValid() throws InvalidRefreshTokenException {

        String accessToken = "access token";
        String refreshToken = "refresh token";

        when(mockJwtService.validateToken(refreshToken)).thenReturn(true);
        when(mockJwtService.getClaims(refreshToken)).thenReturn(claims);
        when(claims.get(anyString())).thenReturn(BigInteger.TWO);
        when(claims.getSubject()).thenReturn("username");
        when(mockJwtService.generateAccessToken(anyMap(), anyString())).thenReturn(accessToken);
        RefreshResponseDto refreshResponseDto = new RefreshResponseDto(accessToken);

        assertThat(testSignInService.getNewAccessToken(refreshToken)).isEqualTo(refreshResponseDto);
    }

    @Test
    @DisplayName("Throws InvalidRefreshException for invalid refresh token")
    void getNewAccessTokenThrowsExceptionForInvalidToken() throws InvalidRefreshTokenException {

        String refreshToken = "refresh token";

        when(mockJwtService.validateToken(refreshToken)).thenReturn(false);


        assertThrows(InvalidRefreshTokenException.class, () -> testSignInService.getNewAccessToken(refreshToken));

    }

}