package com.sapient.service;

import com.sapient.constant.Constant;
import com.sapient.entity.User;
import com.sapient.entity.VerificationCodes;
import com.sapient.exception.*;
import com.sapient.repository.UserRepository;
import com.sapient.repository.VerificationCodesRepository;
import com.sapient.utils.CryptoService;
import com.sapient.utils.HashService;
import com.sapient.utils.KafkaClientService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.Optional;
import java.util.concurrent.ExecutorService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = PasswordServiceImpl.class)
class PasswordServiceImplTest {

    @MockBean
    ExecutorService executorService;
    @MockBean
    UserRepository userRepository;
    @MockBean
    VerificationCodesRepository verificationCodesRepository;
    @Autowired
    PasswordService passwordService;

    @MockBean
    CryptoService cryptoService;
    @MockBean
    HashService hashService;
    @MockBean
    KafkaClientService kafkaClientService;

    @Test
    @DisplayName("Email present in Repository")
    void fetchUserByEmailNotNull() throws EmailNotFoundException {
        when(userRepository.findByEmail(anyString())).thenReturn(new User());
        User user=passwordService.fetchUserByEmail("abc@domain.com");
        Assertions.assertNotEquals(null,user);
    }
    @Test
    @DisplayName("Email not present in Repository")
    void fetchUserByEmailNull()
    {
        when(userRepository.findByEmail(anyString())).thenReturn(null);
        assertThrows(EmailNotFoundException.class,()->passwordService.fetchUserByEmail("zyx@domain.com"));
    }
    @DisplayName("User is null, no link generated")
    @Test
    void generatePasswordResetLinkNull()
    {
        assertThrows(NoUserException.class,()->passwordService.generatePasswordResetCode(null));
    }
    @DisplayName("Generate code if user is given and present in db")
    @Test
    void generatePasswordResetLinkNotNullPreesentInDB()
    {
        VerificationCodes code=new VerificationCodes(BigInteger.ONE,BigInteger.ONE,"nfnvfjvnjsvnf",new Timestamp(6000000l),"reset_password");
        HashMap<BigInteger, VerificationCodes> map=new HashMap<>();
        when(verificationCodesRepository.findByTypeAndUserId(anyString(),Mockito.any(BigInteger.class))).thenReturn(Optional.of(code));
        when(verificationCodesRepository.save(Mockito.any(VerificationCodes.class))).then(invocationOnMock->{
            VerificationCodes details=invocationOnMock.getArgument(0);
            map.put(details.getVerificationCode(),details);
            return details;
        });
        User user=new User(BigInteger.valueOf(1),"Abdul","dedcd","abc@domain.com","","234234234","Abdul","Basit",true);
        VerificationCodes actual=passwordService.generatePasswordResetCode(user);
        assertEquals(map.get(BigInteger.ONE),actual);
    }
    @DisplayName("User not present in verification codes table")
    @Test
    void generatePasswordResetLinkNotNullPresentNotInDB()
    {
        HashMap<BigInteger, VerificationCodes> map=new HashMap<>();
        when(verificationCodesRepository.findByTypeAndUserId(anyString(),Mockito.any(BigInteger.class))).thenReturn(Optional.empty());
        when(verificationCodesRepository.save(Mockito.any(VerificationCodes.class))).then(invocationOnMock->{
            VerificationCodes details=invocationOnMock.getArgument(0);
            details.setVerificationCode(BigInteger.ONE);
            map.put(details.getVerificationCode(),details);
            return details;
        });
        User user=new User(BigInteger.valueOf(1),"Abdul","dedcd","abc@domain.com","","234234234","Abdul","Basit",true);
        VerificationCodes actual=passwordService.generatePasswordResetCode(user);
        VerificationCodes verificationCodes=new VerificationCodes(BigInteger.ONE,user.getUserId(),map.get(BigInteger.ONE).getCode(),map.get(BigInteger.ONE).getExpiryTime(),"reset_password");
        assertEquals(verificationCodes,actual);
    }
    @DisplayName("Check send link being called")
    @Test
    void callSendLink()
    {
        User user=new User(BigInteger.valueOf(1),"Abdul","dedcd","abc@domain.com","","234234234","Abdul","Basit",true);
        VerificationCodes code=new VerificationCodes(BigInteger.ONE,BigInteger.ONE,"nfnvfjvnjsvnf",new Timestamp(Timestamp.from(Instant.now()).getTime()+6000000),"reset_password");
        Mockito.doNothing().when(executorService).execute(Mockito.any());
        String actual=passwordService.sendLink(user,"some url",code);
        verify(executorService,Mockito.times(1)).execute(Mockito.any());
        assertEquals("some url/"+code.getCode(),actual);
    }
    @Test
    @DisplayName("send lnk for reset password fail")
    void sendLinkForResetPasswordFailure() throws EmailNotFoundException
    {
        when(userRepository.findByEmail(anyString())).thenReturn(null);

        String email="abc@hotmail.com";
        String prefix="url";
        assertThrows(EmailNotFoundException.class,()->passwordService.sendLinkForResetPassword(email,prefix));
    }
    @Test
    @DisplayName("send lnk for reset password success")
    void sendLinkForResetPasswordSuccess() throws EmailNotFoundException {
        when(userRepository.findByEmail(anyString())).thenReturn(new User());
        HashMap<BigInteger, VerificationCodes> map = new HashMap<>();
        when(verificationCodesRepository.findByTypeAndUserId(anyString(), Mockito.any(BigInteger.class))).thenReturn(Optional.empty());
        when(verificationCodesRepository.save(Mockito.any(VerificationCodes.class))).then(invocationOnMock -> {
            VerificationCodes details = invocationOnMock.getArgument(0);
            details.setVerificationCode(BigInteger.ONE);
            map.put(details.getVerificationCode(), details);
            return details;
        });
        Mockito.doNothing().when(executorService).execute(Mockito.any());
        String email = "abc@hotmail.com";
        String prefix = "url";
        passwordService.sendLinkForResetPassword(email, prefix);
        verify(verificationCodesRepository, times(1)).save(any(VerificationCodes.class));
    }
    @Test
    void validatePasswordResetCode_shouldThrowException_whenCodeDoesNotExists()
    {
        when(verificationCodesRepository.findByCodeAndType(anyString(), anyString())).thenReturn(Optional.empty());
        Exception exception = assertThrows(InvalidVerificationCodeException.class, ()->passwordService.validatePasswordResetCode("somecode"));
        assertEquals(exception.getMessage(), Constant.INVALID_RESET_CODE_MESSAGE.toString());
    }
    @Test
    void validatePasswordResetCode_shouldThrowException_whenCodeIsExpired()
    {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().minusSeconds(5)), "reset_password");
        when(verificationCodesRepository.findByCodeAndType(anyString(), anyString())).thenReturn(Optional.of(codes));
        Exception exception = assertThrows(InvalidVerificationCodeException.class, ()->passwordService.validatePasswordResetCode("somecode"));
        assertEquals(exception.getMessage(), Constant.RESET_PASSWORD_CODE_EXPIRED_MESSAGE.toString());
    }
    @Test
    void validatePasswordResetCode_shouldThrowException_whenUserDoesNotExists()
    {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().plusSeconds(60 * 5)), "reset_password");
        when(verificationCodesRepository.findByCodeAndType(anyString(), anyString())).thenReturn(Optional.of(codes));
        when(userRepository.findById(BigInteger.ONE)).thenReturn(Optional.empty());
        Exception exception = assertThrows(InvalidVerificationCodeException.class, ()->passwordService.validatePasswordResetCode("somecode"));
        assertEquals(exception.getMessage(), Constant.USER_DOES_NOT_EXIST.toString());
    }
    @Test
    void validatePasswordResetCode_shouldReturnVerificationCode_whenCodeIsValid() throws InvalidVerificationCodeException, UserDoesNotExistException, VerificationCodeExpiredException
    {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().plusSeconds(60 * 5)), "reset_password");
        User user = new User(BigInteger.TWO,"HARISH","HARISHPASSWORD","ash@pokemon.com","harley@davidson.com", "8989888989","Harish","S", false);
        when(verificationCodesRepository.findByCodeAndType(anyString(), anyString())).thenReturn(Optional.of(codes));
        when(userRepository.findById(BigInteger.TWO)).thenReturn(Optional.of(user));
        VerificationCodes actualCode = passwordService.validatePasswordResetCode("somecode");
        assertEquals(codes, actualCode);
    }
    @Test
    void updatePassword_shouldThrowException_whenVerificationCodeIsInvalid() throws InvalidVerificationCodeException
    {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().plusSeconds(60 * 5)), "reset_password");
        User user = new User(BigInteger.TWO,"HARISH","HARISHPASSWORD","ash@pokemon.com","harley@davidson.com", "8989888989","Harish","S", false);
        PasswordService newPasswordService = Mockito.spy(passwordService);//could use spy bean as well.
        doThrow(new InvalidVerificationCodeException()).when(newPasswordService).validatePasswordResetCode(anyString());
        assertThrows(InvalidVerificationCodeException.class, ()->newPasswordService.updatePassword("adfa","password"));
    }
    @Test
    void updatePassword_shouldThrowException_whenItCantDecryptThePassword() throws InvalidVerificationCodeException, IllegalBlockSizeException, BadPaddingException {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().plusSeconds(60 * 5)), "reset_password");
        User user = new User(BigInteger.TWO,"HARISH","HARISHPASSWORD","ash@pokemon.com","harley@davidson.com", "8989888989","Harish","S", false);
        PasswordService newPasswordService = Mockito.spy(passwordService);//could use spy bean as well.
        doReturn(codes).when(newPasswordService).validatePasswordResetCode(anyString());
        when(userRepository.getById(BigInteger.TWO)).thenReturn(user);
        when(cryptoService.decrypt("password")).thenThrow(new BadPaddingException()) ;
        assertThrows(BadPaddingException.class, ()->newPasswordService.updatePassword("adfa","password"));
    }
    @Test
    void updatePassword_shouldUpdatePassword_whenCodeAndPasswordIsValid() throws InvalidVerificationCodeException, IllegalBlockSizeException, BadPaddingException {
        VerificationCodes codes = new VerificationCodes(BigInteger.ONE, BigInteger.TWO, "somecode", Timestamp.from(Instant.now().plusSeconds(60 * 5)), "reset_password");
        User user = Mockito.spy(new User(BigInteger.TWO,"HARISH","HARISHPASSWORD","ash@pokemon.com","harley@davidson.com", "8989888989","Harish","S", false));
        PasswordService newPasswordService = Mockito.spy(passwordService);//could use spy bean as well.
        doReturn(codes).when(newPasswordService).validatePasswordResetCode(anyString());
        when(userRepository.getById(BigInteger.TWO)).thenReturn(user);
        when(cryptoService.decrypt("password")).thenReturn("decryptPassword");
        when(hashService.hash("decryptPassword")).thenReturn("hashedPassword");
        doNothing().when(verificationCodesRepository).delete(codes);
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        newPasswordService.updatePassword("somecode", "password");
        verify(user).setPassword(captor.capture());
        assertEquals("hashedPassword", captor.getValue());
    }
}