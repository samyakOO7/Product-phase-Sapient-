package com.sapient.payload;

import com.sapient.dto.UserDto;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class EmailVerificationTest {

    @Test
    public void testEquals() {
        EmailVerification emailVerification=new EmailVerification();
        emailVerification.setEmail("ab@gmail.com");
        emailVerification.setFirstName("Ritik");
        emailVerification.setUrl("abc.com");
        EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","Ritik","abc.com");
        Boolean actual = (emailVerification1.equals(emailVerification));
        Boolean expected=true;
        Assertions.assertEquals(expected,actual);
    }

    @Test
    public void testToString() {
        EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","Ritik","abc.com");
        String expected= "EmailVerification{" +
        "email='" + emailVerification1.getEmail() + '\'' +
        ", firstName='" + emailVerification1.getFirstName() + '\'' +
        ", url='" + emailVerification1.getUrl() + '\'' +
        '}';
        Assertions.assertEquals(expected,emailVerification1.toString());
    }
    @Test
    public void testPaylodEqualReferences(){
        EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","Ritik","abc.com");
        EmailVerification emailVerification2=emailVerification1;
        Assertions.assertEquals(true,emailVerification2.equals(emailVerification1));
    }
   @Test
   public void testPayloadNull(){
       EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","Ritik","abc.com");
        Assertions.assertEquals(false, emailVerification1.equals(null));
    }

    @Test
    public void testHashCode() {
        EmailVerification emailVerification=new EmailVerification();
        emailVerification.setEmail("ab@gmail.com");
        emailVerification.setFirstName("abc");
        emailVerification.setUrl("abc.com");
        EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","abc","abc.com");
        int e1=emailVerification.hashCode();
        int e2=emailVerification1.hashCode();
        Boolean actual = (e1==e2);
        Boolean expected=true;
        Assertions.assertEquals(expected,actual);
    }

    @Test
    public void getVerification() {
        EmailVerification emailVerification=new EmailVerification();
        emailVerification.setFirstName("Ritik");
        Assertions.assertEquals("Ritik", emailVerification.getFirstName());
    }

    @Test
    public void getEmail() {
        EmailVerification emailVerification=new EmailVerification();
        emailVerification.setEmail("ab@gmail.com");
        Assertions.assertEquals("ab@gmail.com",emailVerification.getEmail());
    }

    @Test
    public void getUrl() {
        EmailVerification emailVerification=new EmailVerification();
        emailVerification.setUrl("www.aws.com");
        Assertions.assertEquals("www.aws.com", emailVerification.getUrl());
    }
    @Test
    public void testPayloadClass(){
        UserDto userdto1=new UserDto("RS","fgbbfbfg","abc@domain.com","xyz@domain.com","34342342","George","Stuart");
        EmailVerification emailVerification1=new EmailVerification("ab@gmail.com","Ritik","abc.com");
        Assertions.assertEquals(false, emailVerification1.equals(userdto1));
    }
}