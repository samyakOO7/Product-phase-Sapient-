package com.sapient.Dto;

import com.sapient.dto.UserDto;
import com.sapient.entity.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;


@DisplayName("UserDto testing")
 class UserDtoTest {

    private UserDto userDto;

    @BeforeEach
    public void loadUser() {
        userDto = new UserDto();
    }

    @Test
    @DisplayName("First Name Test")
    void getFirstName() {

        String S = "Ritik";
        userDto.setFirstName("Ritik");
        Assertions.assertEquals(S, userDto.getFirstName());
    }

    @Test
    @DisplayName("User Name Test")
    void getUserName() {
        String S = "RS";
        userDto.setUserName("RS");
        Assertions.assertEquals(S, userDto.getUserName());
    }

    @Test
    @DisplayName("last Name Test")
    void getLastName() {
        String S = "Ritik";
        userDto.setLastName("Shrivastav");
        Assertions.assertNotEquals(S, userDto.getLastName());
    }

    @Test
    @DisplayName("Password Test in entity user")
    void getPassword() {
        userDto.setPassword("1234");
        Assertions.assertEquals("1234", userDto.getPassword());
    }

    @Test
    @DisplayName("Phone Number Test should return false here")
    void getPhoneNumber() {
        userDto.setPhoneNumber("9438393");
        Assertions.assertNotEquals(("912332244"), userDto.getPhoneNumber());
    }

    @Test
    @DisplayName("Email test")
    void getEmail() {
        userDto.setEmail("rs@gmail.com");
        Assertions.assertEquals(("rs@gmail.com"), userDto.getEmail());
    }

    @Test
    @DisplayName("alternate email test")
    void getAlternateEmail() {
        userDto.setAlternateEmail("pk@gmail.com");
        Assertions.assertNotEquals(("ab@gmail.com"), userDto.getAlternateEmail());
    }

    @Test
    void testToString() {
        UserDto userDto1 = new UserDto("RitikShrivastav", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "Ritik", "Shrivastav");
        String expected = "UserDto{" +
                "userName='" + userDto1.getUserName() + '\'' +
                ", password='" + userDto1.getPassword() + '\'' +
                ", email='" + userDto1.getEmail() + '\'' +
                ", alternateEmail='" + userDto1.getAlternateEmail() + '\'' +
                ", phoneNumber='" + userDto1.getPhoneNumber() + '\'' +
                ", firstName='" + userDto1.getFirstName() + '\'' +
                ", lastName='" + userDto1.getLastName() + '\'' +
                '}';
        Assertions.assertEquals(expected, userDto1.toString());
    }

    @Test
    void testEquals() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        UserDto userdto2 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        Boolean actual = userdto1.equals(userdto2);
        Boolean expected = true;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testNotEquals() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        UserDto userdto2 = new UserDto("RST", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        Boolean actual = userdto1.equals(userdto2);
        Boolean expected = false;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testHashCodeEquals() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        UserDto userdto2 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        int user1Hashcode = userdto1.hashCode();
        int user2Hashcode = userdto2.hashCode();
        Boolean actual = (user1Hashcode == user2Hashcode);
        Boolean expected = true;
        Assertions.assertEquals(expected, actual);

    }

    @Test
    void testHashCodeNotEquals() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        UserDto userdto2 = new UserDto("RST", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        int user1Hashcode = userdto1.hashCode();
        int user2Hashcode = userdto2.hashCode();
        Boolean actual = (user1Hashcode == user2Hashcode);
        Boolean expected = false;
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void testEqualUserReference() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        UserDto userDto2 = userdto1;
        Assertions.assertEquals(true, userDto2.equals(userdto1));
    }

    @Test
    void testUserDtoNull() {
        UserDto userdto2 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        Assertions.assertEquals(false, userdto2.equals(null));
    }

    @Test
    void testUserDtoClass() {
        UserDto userdto1 = new UserDto("RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart");
        User user = new User(BigInteger.ONE, "RS", "fgbbfbfg", "abc@domain.com", "xyz@domain.com", "34342342", "George", "Stuart",false);
        Assertions.assertEquals(false, userdto1.equals(user));
    }

}
