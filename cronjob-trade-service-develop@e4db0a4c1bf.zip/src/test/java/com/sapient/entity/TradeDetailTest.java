package com.sapient.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TradeDetailTest {

    TradeDetail tradeDetail;

    @BeforeEach
    void setUp() {
        tradeDetail = new TradeDetail();
    }

    @Test
    void testToString() {
        TradeDetail tradeDetail1 = new TradeDetail(UUID.randomUUID(),BigInteger.ONE,new Tickers(), 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);
        String expected = "TradeDetail{"+
                "tradeDetailId=" + tradeDetail1.getTradeDetailId()+
                ", userId=" + tradeDetail1.getUserId()+
                ", ticker=" + tradeDetail1.getTicker()+
                ", timeframe=" + tradeDetail1.getTimeframe()+
                ", tradeDirection='" + tradeDetail1.getTradeDirection()+"'"+
                ", createdAt=" + tradeDetail1.getCreatedAt()+
                ", pricePerTicker=" + tradeDetail1.getPricePerTicker()+
                ", quantity=" + tradeDetail1.getQuantity()+
                ", totalCost=" + tradeDetail1.getTotalCost()+
                ", stopLoss=" + tradeDetail1.getStopLoss()+
                ", profitTarget=" + tradeDetail1.getProfitTarget()+
                ", status='" + tradeDetail1.getStatus()+"'"+
                ", tradeAlert=" + tradeDetail1.getTradeAlert()+
                ", gain="+ tradeDetail1.getGain()+
                ", riskToRewardRatio=" + tradeDetail1.getRiskToRewardRatio()+
                "}";
        assertEquals(expected, tradeDetail1.toString());
    }

    @Test
    void getTradeDetailId() {
        UUID expected = UUID.randomUUID();
        tradeDetail.setTradeDetailId(expected);
        assertEquals(expected,tradeDetail.getTradeDetailId());
    }

    @Test
    void getUserId() {
        BigInteger expected = BigInteger.ONE;
        tradeDetail.setUserId(expected);
        assertEquals(expected, tradeDetail.getUserId());
    }

    @Test
    void getTicker() {
        Tickers tickers = new Tickers();
        tradeDetail.setTicker(tickers);
        assertEquals(tickers,tradeDetail.getTicker());
    }

    @Test
    void getTimeframe() {
        Integer expected = 1440;
        tradeDetail.setTimeframe(expected);
        assertEquals(expected, tradeDetail.getTimeframe());
    }

    @Test
    void getTradeDirection() {
        String expected = "buy";
        tradeDetail.setTradeDirection(expected);
        assertEquals(expected, tradeDetail.getTradeDirection());
    }

    @Test
    void getCreatedAt() {

        Timestamp expected = new Timestamp(1234678);
        tradeDetail.setCreatedAt(expected);
        assertEquals(expected,tradeDetail.getCreatedAt());
    }

    @Test
    void getPricePerTicker() {
        Double expected = 100.00;
        tradeDetail.setPricePerTicker(expected);
        assertEquals(expected, tradeDetail.getPricePerTicker());
    }

    @Test
    void getQuantity() {
        Integer expected = 5;
        tradeDetail.setQuantity(expected);
        assertEquals(expected,tradeDetail.getQuantity());
    }

    @Test
    void getTotalCost() {
        Double expected = 1000.00;
        tradeDetail.setTotalCost(expected);
        assertEquals(expected, tradeDetail.getTotalCost());
    }

    @Test
    void getStopLoss() {
        Double expected = 98.00;
        tradeDetail.setStopLoss(expected);
        assertEquals(expected,tradeDetail.getStopLoss());
    }

    @Test
    void getProfitTarget() {
        Double expected  = 1200.00;
        tradeDetail.setProfitTarget(expected);
        assertEquals(expected, tradeDetail.getProfitTarget());
    }

    @Test
    void getStatus() {
        String expected = "pending";
        tradeDetail.setStatus(expected);
        assertEquals(expected, tradeDetail.getStatus());
    }

    @Test
    void getTradeAlert() {
        TradeAlert tradeAlert = new TradeAlert();
        tradeDetail.setTradeAlert(tradeAlert);
        assertEquals(tradeAlert, tradeDetail.getTradeAlert());
    }

    @Test
    void getGain() {
        Double expected = 10.00;
        tradeDetail.setGain(expected);
        assertEquals(expected, tradeDetail.getGain());
    }

    @Test
    void getRiskToRewardRatio() {
        Double expected = 10.00;
        tradeDetail.setRiskToRewardRatio(expected);
        assertEquals(expected, tradeDetail.getRiskToRewardRatio());
    }
}