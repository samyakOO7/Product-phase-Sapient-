package com.sapient.utils;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.sapient.message.SellConfirmation;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.concurrent.ListenableFuture;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {KafkaClientUtilImpl.class})
class KafkaClientUtilImplTest {


    @Autowired
    KafkaClientUtilImpl util;
    @MockBean
    KafkaTemplate<String, SellConfirmation> template;
    List<ILoggingEvent> listOfLogs;

    @BeforeEach
    void setUpListAppender() {
        Logger logger = (Logger) LoggerFactory.getLogger(KafkaClientUtilImpl.class);
        logger.setLevel(ch.qos.logback.classic.Level.TRACE);
        ListAppender<ILoggingEvent> listAppender = new ListAppender<>();
        listAppender.start();
        logger.addAppender(listAppender);
        listOfLogs = listAppender.list;
    }

    @Test
    @DisplayName("Send alert should show success in logs")
    void testSellConfirmationAlertSentSuccessfully() {
        SellConfirmation alert = new SellConfirmation();
        alert.setEmail("ash@gmail.com");
        alert.setFirstName("ashu");
        alert.setGain(400.0);
        alert.setTickerSymbol("INFY");
        alert.setPrice(100.0);
        alert.setTimestamp(Timestamp.from(Instant.now()).toString());
        Message<SellConfirmation> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, "sell-trade")
                .build();
        ProducerRecord<String, SellConfirmation> record = new ProducerRecord<>("sell-trade", alert);
        RecordMetadata metadata = new RecordMetadata(new TopicPartition("sell-trade", 0), 0, 0, System.currentTimeMillis(), 12, 12);
        ListenableFuture<SendResult<String, SellConfirmation>> alertFuture = Mockito.spy(new AsyncResult<>(new SendResult<>(record, metadata)));
        when(template.send(any(userMessage.getClass()))).thenReturn(alertFuture);
        //act
        util.sendSellConfirmation(alert);
        //assert
        verify(template).send(any(userMessage.getClass()));
        assertThat(listOfLogs).isNotNull().hasSize(2);
        assertThat(listOfLogs.get(0).toString())
                .contains("[DEBUG]")
                .contains("received request to send alert ");
        assertThat(listOfLogs.get(1).toString())
                .contains("[INFO]")
                .contains("Record sent successfully");
    }

    @Test
    @DisplayName("Send alert failed should log error")
    void testSendAlert_whenSellConfirmationAlertSentFailed() {
        SellConfirmation alert = new SellConfirmation();
        alert.setEmail("ash@gmail.com");
        alert.setFirstName("ashu");
        alert.setGain(400.0);
        alert.setTickerSymbol("INFY");
        alert.setPrice(100.0);
        alert.setTimestamp(Timestamp.from(Instant.now()).toString());

        Message<SellConfirmation> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, "sell-trade")
                .build();
        ProducerRecord<String, SellConfirmation> record = new ProducerRecord<>("sell-trade", alert);
        RecordMetadata metadata = new RecordMetadata(new TopicPartition("sell-trade", 0), 0, 0, System.currentTimeMillis(), 12, 12);
        AsyncResult<SendResult<String, SellConfirmation>> alertFutur = new AsyncResult<>(new SendResult<>(record, metadata));
        ListenableFuture<SendResult<String, SellConfirmation>> alertFuture = AsyncResult.forExecutionException(new KafkaProducerException(record, "kafka failed", new Exception()));
        when(template.send(any(userMessage.getClass()))).thenReturn(alertFuture);
        //act
        util.sendSellConfirmation(alert);
        //assert
        verify(template).send(any(userMessage.getClass()));
        assertThat(listOfLogs).isNotNull().hasSize(2);
        assertThat(listOfLogs.get(0).toString())
                .contains("[DEBUG]")
                .contains("received request to send alert ");
        assertThat(listOfLogs.get(1).toString())
                .contains("[ERROR]")
                .contains("Failed to send the record ");
    }
}