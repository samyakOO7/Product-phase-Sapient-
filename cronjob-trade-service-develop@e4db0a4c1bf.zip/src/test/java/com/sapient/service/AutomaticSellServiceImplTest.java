package com.sapient.service;

import com.sapient.client.AuthServiceFeignClient;
import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.TradeServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.dto.PortfolioUserIdsDto;
import com.sapient.dto.SellTradeDetailRequestDto;
import com.sapient.dto.UserPortfolioDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeDetail;
import com.sapient.message.SellConfirmation;
import com.sapient.service.impl.AutomaticSellServiceImpl;
import com.sapient.utils.KafkaClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = AutomaticSellServiceImpl.class)
class AutomaticSellServiceImplTest {

    @Autowired
    AutomaticSellService automaticSellService;
    @MockBean
    UserServiceFeignClient userServiceFeignClient;
    @MockBean
    StockServiceFeignClient stockServiceFeignClient;
    @MockBean
    TradeServiceFeignClient tradeServiceFeignClient;
    @MockBean
    KafkaClientUtil kafkaClientUtil;
    @MockBean
    AuthServiceFeignClient authServiceFeignClient;
    @MockBean
    SimpleDateFormat simpleDateFormat;

    @Test
    void executeSell() {
        List<BigInteger> userIds = new ArrayList<>();
        List<UserPortfolioDto> openTrades = new ArrayList<>();
        userIds.add(BigInteger.ONE);

        UserPortfolioDto userPortfolioDto = new UserPortfolioDto(BigInteger.ONE, "HDFC", 100.0, 95.0, 98.0);
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.TWO, "PNB", 45.0, 39.0, 41.0);
        openTrades.add(userPortfolioDto);
        openTrades.add(userPortfolioDto1);
        Tickers tickers = new Tickers(1, "HDFC", "HDFC Bank", "stock");
        Tickers tickers1 = new Tickers(2, "PNB", "PNBank", "stock");
        SellTradeDetailRequestDto sellTradeDetailRequestDto = new SellTradeDetailRequestDto(BigInteger.ONE);
        SellTradeDetailRequestDto sellTradeDetailRequestDto1 = new SellTradeDetailRequestDto(BigInteger.TWO);
        TradeDetail tradeDetail = new TradeDetail(UUID.randomUUID(), BigInteger.ONE, tickers, 1140, "sell", new Timestamp(1), 90.0, 10, 900.0, null, null, "no action", null, -80.0, null);
        TradeDetail tradeDetail1 = new TradeDetail(UUID.randomUUID(), BigInteger.ONE, tickers1, 1140, "sell", new Timestamp(1), 45.0, 10, 450.0, null, null, "no action", null, 40.0, null);


        Map<String, BigDecimal> currentPrice = new HashMap<>();
        currentPrice.put("price_per_stock", BigDecimal.valueOf(90.0));
        Map<String, BigDecimal> currentPrice1 = new HashMap<>();
        currentPrice1.put("price_per_stock", BigDecimal.valueOf(46.0));
        Map<String, List<UserPortfolioDto>> userPortfolio = new HashMap<>();
        userPortfolio.put("userPortfolio", openTrades);
        Set<BigInteger> expected = new HashSet<>();
        expected.add(BigInteger.ONE);
        when(userServiceFeignClient.getAllUserIds()).thenReturn(new PortfolioUserIdsDto(userIds));

        ViewUserDto viewUserDto = new ViewUserDto(BigInteger.ONE, "ashu", "ashu123@gmail.com", "ashu123@gmail.com", "1234567890", "ashu", "kumar");
        when(authServiceFeignClient.getUserEmailAndName(BigInteger.ONE)).thenReturn(viewUserDto);
        when(userServiceFeignClient.getUserPortfolio(BigInteger.ONE)).thenReturn(userPortfolio);

        when(stockServiceFeignClient.getTickerPrice("HDFC")).thenReturn(ResponseEntity.ok().body(currentPrice));
        when(stockServiceFeignClient.getTickerPrice("PNB")).thenReturn(ResponseEntity.ok().body(currentPrice));
        when(tradeServiceFeignClient.generateSellTradeDetail(sellTradeDetailRequestDto)).thenReturn(tradeDetail);
        when(tradeServiceFeignClient.generateSellTradeDetail(sellTradeDetailRequestDto1)).thenReturn(tradeDetail1);

        SellConfirmation alert = new SellConfirmation();
        alert.setEmail("ash@gmail.com");
        alert.setFirstName("ashu");
        alert.setGain(400.0);
        alert.setTickerSymbol("INFY");
        alert.setPrice(100.0);
        alert.setQuantity(5);
        alert.setTimestamp("2022-10-15 10:51");
        doNothing().when(kafkaClientUtil).sendSellConfirmation(alert);
        Set<BigInteger> actual = automaticSellService.executeSell();
        assertEquals(expected, actual);

    }
}