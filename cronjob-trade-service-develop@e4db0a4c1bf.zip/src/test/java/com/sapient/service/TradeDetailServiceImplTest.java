package com.sapient.service;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.constant.TradeDetailStatus;
import com.sapient.dto.*;
import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.impl.TradeDetailServiceImpl;
import com.sapient.utils.CurrentTimeUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TradeDetailServiceImpl.class)
@TestPropertySource("classpath:application.properties")
class TradeDetailServiceImplTest {

    @MockBean
    TradeDetailRepository tradeDetailRepository;

    @Autowired
    TradeDetailServiceImpl tradeDetailService;
    @MockBean
    StockServiceFeignClient stockServiceFeignClient;
    @MockBean
    UserServiceFeignClient userServiceFeignClient;


    @MockBean
    ExecutedTradeRepository executedTradeRepository;


    @MockBean
    CurrentTimeUtil currentTimeUtil;

    @MockBean
    ModelMapper modelMapper;
    static TradeDetail tradeDetail;
    static TradeDetail tradeDetail0;
    static TradeDetail tradeDetailUpdated;
    static UserTradingDetailsDto userTradingDetailsDto;
    static Tickers tickerDetails;
    static UUID tradeDetailId;
    static Timestamp timestamp;
    static TradeDetail dummyUserTradeDetail;
    static TradeAlert tradeAlert;
    static Tickers ticker;

    static Map<String,BigDecimal> tickerPrice;

    static UserTradingDetailsDto userTradeDetailDto;
    @BeforeEach
    void setup(){
        tickerPrice=new HashMap<>();
        tickerPrice.put("price_per_stock", BigDecimal.valueOf(15.0));

        timestamp=Timestamp.from(Instant.now());
        ticker = new Tickers(1,"hdfc","h","stock");
        tradeAlert = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),ticker,1,"buy",timestamp,timestamp,94.5,10.5 );
        dummyUserTradeDetail = new TradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7"),BigInteger.valueOf(1),ticker,12,"buy",timestamp,20.0,2,90.0,12.0,15.0,"pending",tradeAlert,23.0,6.0);
        tradeDetailId = UUID.randomUUID();
        tickerDetails = new Tickers(1, "Infosys", "INFY", "stock");

        userTradingDetailsDto = new UserTradingDetailsDto(BigInteger.ONE, 1000.0, 10.0, 5.0, BigInteger.ONE, 20.0);

        tradeDetail = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10.0, 10, 100.0, 2.0, 2.0, "pending", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailUpdated = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 20.0, 5, 100.0, 2.0, 2.0, "pending", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

        userTradeDetailUpdateDto=new UserTradeDetailUpdateDto(UUID.randomUUID(),5,10.0,10.0);
        tickers=new Tickers(101,"hdfc","hdfc","stock");
        tradeDetail0= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);
        tradeDetailZero = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10.0, 0, 100.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

        tradeDetail1= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "sell", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);

        tradeDetail2= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "executed", new TradeAlert(), 10.00, 10.00);

        userTradeDetailDto=new UserTradingDetailsDto(BigInteger.ONE,200.0,30.0,10.0,BigInteger.ONE,1000.0);
        userTradeDetailUpdateDtoNew=new UserTradeDetailUpdateDto(UUID.randomUUID(),0,10.0,10.0);

        tradeExecutionResponseDto1=new TradeExecutionResponseDto("pending");
        tradeExecutionResponseDto2=new TradeExecutionResponseDto("executed");

        executedTrade1=new ExecutedTrade(UUID.randomUUID(),BigInteger.valueOf(1),tickers,tradeDetail,null,1,Timestamp.from(Instant.now()),null,0.0,15.0,null);


        userTradeDetailUpdateDto2=new UserTradeDetailUpdateDto(UUID.randomUUID(),500,10.0,10.0);
        userTradeDetailUpdateDto3=new UserTradeDetailUpdateDto(UUID.randomUUID(),18,10.0,10.0);
        tradeDetailList=new ArrayList<>();
        tradeDetailList.add(tradeDetail2);

    }
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto;
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto2;
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto3;
    static TradeDetail tradeDetail2;

    static TradeDetail tradeDetail1;

    static Tickers tickers;

    static TradeExecutionResponseDto tradeExecutionResponseDto1;
    static TradeExecutionResponseDto tradeExecutionResponseDto2;

    static List<TradeDetail> tradeDetailList;


    static ExecutedTrade executedTrade1;
    static TradeDetail tradeDetailQuantity;
    static TradeDetail tradeDetailUpdatedQuantity;
    static UserTradeDetailDto tradeDetailDtoUpdatedQuantity;
    static TradeDetail tradeDetailZero;
    private UserTradeDetailUpdateDto userTradeDetailUpdateDtoNew;


    @Test
    void PendingStatusTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, ZeroQuantityException, QuantityMismatchException, NoHoldingException {
        when(tradeDetailRepository.findById(any(UUID.class))).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getUserDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        Timestamp timeStamp=Timestamp.valueOf("2022-10-10 08:45:15");
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when(currentTimeUtil.getCurrentTime()).thenReturn(timeStamp);
        when(tradeDetailRepository.getById(any())).thenReturn(tradeDetail0);

        TradeExecutionResponseDto actual=tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto);
        assertEquals(tradeExecutionResponseDto1.toString(),actual.toString());
    }

    @Test
    void TradeDetailNotFoundExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.empty() );
        assertThrows(TradeDetailNotFoundException.class, () -> {
            tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto);
        });

    }

    @Test
    void TradeAlreadyExecutedExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail2) );
        assertThrows(TradeAlreadyExecutedException.class, () -> {
            tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto);
        });

    }

    @Test
    void ExceedingAmountPerTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getUserDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.of(Optional.of(tickerPrice )));




        assertThrows(ExceedingAmountPerTradeException.class, () -> {
            tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto2);
        });

    }

    @Test
    void InsufficientFundsTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getUserDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.of(Optional.of(tickerPrice )));



        assertThrows(InsufficientFundsException.class, () -> {
            tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto3);
        });

    }


    @Test
    void ZeroQuantityExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetailZero));
        assertThrows(ZeroQuantityException.class, () -> {
            tradeDetailService.executeTradeDetail(userTradeDetailUpdateDtoNew);
        });

    }


    @Test
    void ExecutedStatusTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, ZeroQuantityException, QuantityMismatchException, NoHoldingException {



        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getUserDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        Timestamp timeStamp=Timestamp.valueOf("2022-10-10 09:45:15");
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when( executedTradeRepository.save(any())).thenReturn(executedTrade1);
        when(tradeDetailRepository.getById(any())).thenReturn(tradeDetail0);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.of(Optional.empty()));
        when(currentTimeUtil.getCurrentTime()).thenReturn(timeStamp);
        TradeExecutionResponseDto actual=tradeDetailService.executeTradeDetail(userTradeDetailUpdateDto);
        assertEquals(tradeExecutionResponseDto2.toString(),actual.toString());
    }


    @Test
    void executeAutomatic() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, ZeroQuantityException, QuantityMismatchException, NoHoldingException {
        List<TradeDetail> tradeDetailList = new ArrayList<>();
        tradeDetailList.add(tradeDetail);
        UserTradeDetailUpdateDto userTradeDetailUpdateDto1 = new UserTradeDetailUpdateDto();
        TradeDetailService tradeDetailService1 = Mockito.spy(tradeDetailService);
        when(tradeDetailRepository.findPendingTradeDetail()).thenReturn(tradeDetailList);
        doReturn(null).when(tradeDetailService1).executeTradeDetail(any(UserTradeDetailUpdateDto.class));
        TradeExecutionResponseDto actual = tradeDetailService1.executeAutomatic();
        TradeExecutionResponseDto expected = new TradeExecutionResponseDto("Success");
        assertEquals(expected.toString(), actual.toString());

    }
    boolean canBeExecutedTest(Timestamp timestamp) {
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        boolean actual=tradeDetailService.canBeExecuted(timestamp);
        return actual;
    }
    @ParameterizedTest
    @ValueSource(ints={0,1,2,3,4})
    void canBeExecuted(int index) {

        Timestamp timeStamp[]={Timestamp.valueOf("2022-10-10 23:45:15"),Timestamp.valueOf("2022-10-10 09:45:15"),
                Timestamp.valueOf("2022-10-10 08:45:15"),Timestamp.valueOf("2022-10-09 09:45:15"),
                Timestamp.valueOf("2022-10-08 13:45:15")};
        boolean expected[]={false,true,false,false,false};
        Assertions.assertEquals(expected[index],canBeExecutedTest(timeStamp[index]));

    }
    @ParameterizedTest
    @ValueSource(ints={0,1,2})
    void executeSellTradeExecuted(int index) throws Exception {
        int userQuantity[]={10,10,1};
        int tradeQuantity[]={10,10,5};
        TradeDetailStatus tradeDetailStatus[]={TradeDetailStatus.EXECUTED_STATUS,TradeDetailStatus.PENDING_STATUS,TradeDetailStatus.PENDING_STATUS};
        String status[]={"no_action","no_action","quantity_mismatch"};
        String []time={"2022-10-10 14:01:15","2022-10-10 21:01:15","2022-10-10 21:01:15"};
        //Set up for test
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDtoSell userPortfolioDto=new UserPortfolioDtoSell(BigInteger.ONE,userQuantity[index],345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.ok("Updated"));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf(time[index]));
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        ExecutedTrade trade=new ExecutedTrade();
        trade.setPricePerTicker(1231.0);
        when(executedTradeRepository.findByUserIdAndTickerAndTradeClosedAtIsNull(any(),any())).thenReturn(List.of(trade));
        when(executedTradeRepository.saveAll(any())).thenReturn(null);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(tradeQuantity[index]);
        tradeDetail.setStatus(status[index]);
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        TradeDetailStatus expected=tradeDetailStatus[index];
        TradeDetailStatus actual=tradeDetailService.executeSellTrade(tradeDetail);
        Assertions.assertEquals(expected,actual);
    }

    @Test
    void executeSellQuantityMisMatch() throws NoHoldingException {
        UserPortfolioDtoSell userPortfolioDto=new UserPortfolioDtoSell(BigInteger.ONE,10,345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(4);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        Assertions.assertThrows(QuantityMismatchException.class,()->tradeDetailService.executeSellTrade(tradeDetail));
    }
    @Test
    void executeSellQuantityNoHolding() throws NoHoldingException {
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenThrow(NoHoldingException.class);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(4);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(BigInteger.ONE);
        Assertions.assertThrows(NoHoldingException.class,()->tradeDetailService.executeSellTrade(tradeDetail));
    }
    @ParameterizedTest
    @ValueSource(ints = {0,1,2})
    void executeTradeDetailForSell(int index) throws Exception {
        int userQuantity[]={10,10,1};
        int tradeQuantity[]={10,10,5};
        TradeDetailStatus tradeDetailStatus[]={TradeDetailStatus.EXECUTED_STATUS,TradeDetailStatus.PENDING_STATUS,TradeDetailStatus.PENDING_STATUS};
        String status[]={"no_action","no_action","quantity_mismatch"};
        String []time={"2022-10-10 14:01:15","2022-10-10 21:01:15","2022-10-10 21:01:15"};
        TradeExecutionResponseDto expected[]={new TradeExecutionResponseDto(Constant.EXECUTED_MESSAGE.toString()),new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString()),new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString())};
        //Set up for test
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDtoSell userPortfolioDto=new UserPortfolioDtoSell(BigInteger.ONE,userQuantity[index],345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.ok("Updated"));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));

        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf(time[index]));
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when(executedTradeRepository.findByUserIdAndTickerAndTradeClosedAtIsNull(any(),any())).thenReturn(new ArrayList<>());
        when(executedTradeRepository.saveAll(any())).thenReturn(null);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(tradeQuantity[index]);
        tradeDetail.setStatus(status[index]);
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        Mockito.when((tradeDetailRepository.findById(Mockito.any()))).thenReturn(Optional.of(tradeDetail));
        TradeExecutionResponseDto expectedResult=expected[index];
        TradeExecutionResponseDto actual=tradeDetailService.executeTradeDetail(new UserTradeDetailUpdateDto());
        Assertions.assertEquals(expectedResult,actual);
    }


}