package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PortfolioUserIdsDtoTest {

    PortfolioUserIdsDto portfolioUserIdsDto;

    @BeforeEach
    void setup() {
        portfolioUserIdsDto = new PortfolioUserIdsDto();
    }


    @Test
    void getUserIds() {

        final List<BigInteger> userIds = new ArrayList<>() {
            {
                add(BigInteger.ONE);
                add(BigInteger.TWO);
            }
        };
        ReflectionTestUtils.setField(portfolioUserIdsDto, "userIds", userIds);
        assertEquals(userIds, portfolioUserIdsDto.getUserIds());

    }

    @Test
    void setUserIds() {
        final List<BigInteger> userIds = new ArrayList<>() {
            {
                add(BigInteger.ONE);
                add(BigInteger.TWO);
            }
        };
        portfolioUserIdsDto.setUserIds(userIds);
        assertEquals(userIds, portfolioUserIdsDto.getUserIds());

    }
}