package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserPortfolioDtoTest {

    UserPortfolioDto userPortfolioDto;

    @BeforeEach
    void setup() {
        userPortfolioDto = new UserPortfolioDto();
    }

    @Test
    void getUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        ReflectionTestUtils.setField(userPortfolioDto, "userPortfolioId", userPortfolioId);
        assertEquals(userPortfolioId, userPortfolioDto.getUserPortfolioId());
    }

    @Test
    void getTickerId() {
        String tickerId = "HDFC";
        ReflectionTestUtils.setField(userPortfolioDto, "tickerId", tickerId);
        assertEquals(tickerId, userPortfolioDto.getTickerId());
    }

    @Test
    void getProfitTarget() {
        Double profitTarget = 10.0;
        ReflectionTestUtils.setField(userPortfolioDto, "profitTarget", profitTarget);
        assertEquals(profitTarget, userPortfolioDto.getProfitTarget());
    }

    @Test
    void getStopLoss() {
        Double stopLoss = 10.0;
        ReflectionTestUtils.setField(userPortfolioDto, "stopLoss", stopLoss);
        assertEquals(stopLoss, userPortfolioDto.getStopLoss());
    }

    @Test
    void getAveragePrice() {
        Double averagePrice = 10.0;
        ReflectionTestUtils.setField(userPortfolioDto, "averagePrice", averagePrice);
        assertEquals(averagePrice, userPortfolioDto.getAveragePrice());
    }

    @Test
    void setUserPortfolioId() {
        BigInteger userPortfolioId = BigInteger.ONE;
        userPortfolioDto.setUserPortfolioId(userPortfolioId);
        assertEquals(userPortfolioId, userPortfolioDto.getUserPortfolioId());
    }

    @Test
    void setTickerId() {
        String tickerId = "HDFC";
        userPortfolioDto.setTickerId(tickerId);
        assertEquals(tickerId, userPortfolioDto.getTickerId());
    }

    @Test
    void setProfitTarget() {
        Double profitTarget = 10.0;
        userPortfolioDto.setProfitTarget(profitTarget);
        assertEquals(profitTarget, userPortfolioDto.getProfitTarget());
    }

    @Test
    void setStopLoss() {
        Double stopLoss = 10.0;
        userPortfolioDto.setStopLoss(stopLoss);
        assertEquals(stopLoss, userPortfolioDto.getStopLoss());
    }

    @Test
    void setAveragePrice() {
        Double averagePrice = 10.0;
        userPortfolioDto.setAveragePrice(averagePrice);
        assertEquals(averagePrice, userPortfolioDto.getAveragePrice());
    }

    @Test
    void testEquals() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = true;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsObj() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Integer userPortfolioDto2 = 2;
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForSameObj() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = userPortfolioDto1;
        Boolean expected = true;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsObject() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Object userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = true;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForNull() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = null;
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsPorfolioId() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.TWO, "abc", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTickerId() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abcd", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsProfitTarget() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.56, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsStopLoss() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.31, 100.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsAveragePrice() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 101.0);
        Boolean expected = false;
        Boolean actual = userPortfolioDto1.equals(userPortfolioDto2);
        assertEquals(expected, actual);
    }


    @Test
    void testHashCode() {
        UserPortfolioDto userPortfolioDto1 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        UserPortfolioDto userPortfolioDto2 = new UserPortfolioDto(BigInteger.ONE, "abc", 0.5, 0.3, 100.0);
        assertEquals(userPortfolioDto1.hashCode(), userPortfolioDto2.hashCode());
    }
}