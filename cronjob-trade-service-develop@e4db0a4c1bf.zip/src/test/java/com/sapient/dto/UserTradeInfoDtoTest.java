package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradeInfoDtoTest {

    UserTradeInfoDto userTradeInfoDto;

    @BeforeEach
    void setUp() {
        userTradeInfoDto = new UserTradeInfoDto();
    }


    @Test
    void getOpenTrades() {
        int number = 1;
        userTradeInfoDto.setOpenTrades(number);
        assertEquals(number,userTradeInfoDto.getOpenTrades());
    }

    @Test
    void getClosedTrades() {
        int number = 1;
        userTradeInfoDto.setClosedTrades(number);
        assertEquals(number,userTradeInfoDto.getClosedTrades());
    }

    @Test
    void getWinningTrades() {
        int number = 1;
        userTradeInfoDto.setWinningTrades(number);
        assertEquals(number,userTradeInfoDto.getWinningTrades());
    }

    @Test
    void getLosingTrades() {
        int number = 1;
        userTradeInfoDto.setLosingTrades(number);
        assertEquals(number,userTradeInfoDto.getLosingTrades());
    }
    @Test
    void getAlertsConvertedToTrades() {
        int number = 1;
        userTradeInfoDto.setAlertsConvertedToTrades(number);
        assertEquals(number,userTradeInfoDto.getAlertsConvertedToTrades());
    }

    @Test
    void geGain() {
        double number = 1.2;
        userTradeInfoDto.setGain(number);
        assertEquals(number,userTradeInfoDto.getGain());
    }

    @Test
    void getTradeAlertsGenerated() {
        int number = 1;
        userTradeInfoDto.setTradeAlertsGenerated(number);
        assertEquals(number,userTradeInfoDto.getTradeAlertsGenerated());
    }

    @Test
    void getEquity() {
        double number = 1000.0;
        userTradeInfoDto.setEquity(number);
        assertEquals(number,userTradeInfoDto.getEquity());
    }



    @Test
    void testToString() {
        UserTradeInfoDto userTradeInfoDto1 = new UserTradeInfoDto(1,1,1,1,1,20.0,1,1000.0);
        String expected = "UserTradeInfoDto{" +
                "openTrades=" + userTradeInfoDto1.getOpenTrades() +
                ", closedTrades=" + userTradeInfoDto1.getClosedTrades() +
                ", winningTrades=" + userTradeInfoDto1.getWinningTrades() +
                ", losingTrades=" + userTradeInfoDto1.getLosingTrades() +
                ", alertsConvertedToTrades=" + userTradeInfoDto1.getAlertsConvertedToTrades() +
                ", gain=" + userTradeInfoDto1.getGain() +
                ", tradeAlertsGenerated=" + userTradeInfoDto1.getTradeAlertsGenerated() +
                ", equity=" + userTradeInfoDto1.getEquity() +
                '}';
        Assertions.assertEquals(expected, userTradeInfoDto1.toString());
    }

}
