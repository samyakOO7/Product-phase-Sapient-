package com.sapient.scheduler;

import com.sapient.exception.*;
import com.sapient.service.AutomaticSellService;
import com.sapient.service.TradeDetailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ExecuteCronJob.class)
@TestPropertySource("classpath:application.properties")
class ExecuteCronJobTest {
    @MockBean
    TradeDetailService tradeDetailService;

    @MockBean
    AutomaticSellService automaticSellService;

    @Autowired
    ExecuteCronJob executeCronJob;

    @Test
    void execute() throws TradeDetailNotFoundException, UserNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailService.executeAutomatic()).thenReturn(null);
        String expected = "true";
        executeCronJob.execute();
        String actual = "true";
        assertEquals(expected,actual);
    }

    @Test
    void testExecuteSell()  {
        when(automaticSellService.executeSell()).thenReturn(null);
        String expected = "true";
        executeCronJob.executeSell();
        String actual = "true";
        assertEquals(expected,actual);
    }

}