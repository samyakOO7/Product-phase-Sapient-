create table tickers(
	ticker_number integer primary key,  --54636
	ticker_name varchar(150) unique not null,   --HDFC Bank Pvt Ltd
	ticker_id varchar(40) unique not null,  --HDFCBANK.NS
	ticker_type varchar(10) not null    --forex/stock
)