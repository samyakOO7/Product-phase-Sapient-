package com.sapient.service;

import java.math.BigInteger;
import java.util.Set;

public interface AutomaticSellService {

    Set<BigInteger> executeSell();

}
