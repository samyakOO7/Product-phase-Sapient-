package com.sapient.service;

import com.sapient.dto.TradeExecutionResponseDto;
import com.sapient.dto.UserTradeDetailUpdateDto;
import com.sapient.exception.*;

public interface TradeDetailService {
      TradeExecutionResponseDto executeTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, ZeroQuantityException, QuantityMismatchException, NoHoldingException;

      TradeExecutionResponseDto executeAutomatic() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException;
}
