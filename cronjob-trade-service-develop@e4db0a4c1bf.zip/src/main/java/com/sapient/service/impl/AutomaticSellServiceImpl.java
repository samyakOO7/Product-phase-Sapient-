package com.sapient.service.impl;

import com.sapient.client.AuthServiceFeignClient;
import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.TradeServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.dto.SellTradeDetailRequestDto;
import com.sapient.dto.UserPortfolioDto;
import com.sapient.dto.UserTradeDetailUpdateDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.message.SellConfirmation;
import com.sapient.service.AutomaticSellService;
import com.sapient.utils.KafkaClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
public class AutomaticSellServiceImpl implements AutomaticSellService {

    @Autowired
    UserServiceFeignClient userServiceFeignClient;
    @Autowired
    StockServiceFeignClient stockServiceFeignClient;
    @Autowired
    TradeServiceFeignClient tradeServiceFeignClient;
    @Autowired
    AuthServiceFeignClient authServiceFeignClient;
    @Autowired
    KafkaClientUtil kafkaClientUtil;

    @Override
    public Set<BigInteger> executeSell() {
        log.info("Sell cron job started");
        Set<BigInteger> automaticSell = new HashSet<>();
        List<BigInteger> userIds = userServiceFeignClient.getAllUserIds().getUserIds();
        for (BigInteger userId : userIds) {
            List<UserPortfolioDto> openTrades = userServiceFeignClient.getUserPortfolio(userId).get("userPortfolio");
            ViewUserDto userDetails = authServiceFeignClient.getUserEmailAndName(userId);
            for (UserPortfolioDto openTrade : openTrades) {
                ResponseEntity<Map<String, BigDecimal>> tickerResponse = stockServiceFeignClient.getTickerPrice(openTrade.getTickerId());
                var currentPrice = Objects.requireNonNull(tickerResponse.getBody()).get(Constant.PRICE_PER_STOCK.toString()).doubleValue();
                double profitTarget = ((openTrade.getProfitTarget() / 100) * openTrade.getAveragePrice()) + openTrade.getAveragePrice();
                double stopLoss = openTrade.getAveragePrice() - ((openTrade.getStopLoss() / 100) * openTrade.getAveragePrice());
                if (currentPrice >= profitTarget || currentPrice <= stopLoss) {
                    var sellTradeDetailRequestDto = new SellTradeDetailRequestDto(openTrade.getUserPortfolioId());
                    var tradeDetail = tradeServiceFeignClient.generateSellTradeDetail(sellTradeDetailRequestDto);
                    var userTradeDetailUpdateDto = new UserTradeDetailUpdateDto(tradeDetail.getTradeDetailId(), tradeDetail.getQuantity(), null, null);
                    tradeServiceFeignClient.executeTradeDetail(userTradeDetailUpdateDto);
                    var sellConfirmation = new SellConfirmation();
                    sellConfirmation.setEmail(userDetails.getEmail());
                    sellConfirmation.setFirstName(userDetails.getFirstName());
                    sellConfirmation.setPrice(currentPrice);
                    sellConfirmation.setTickerSymbol(openTrade.getTickerId());
                    sellConfirmation.setGain((currentPrice - openTrade.getAveragePrice()) * tradeDetail.getQuantity());
                    sellConfirmation.setQuantity(tradeDetail.getQuantity());
                    var simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                    sellConfirmation.setTimestamp(simpleDateFormat.format(tradeDetail.getCreatedAt()));
                    kafkaClientUtil.sendSellConfirmation(sellConfirmation);
                    automaticSell.add(userId);
                    log.debug("Sell automatically executed for userId - " + userId + " with portfolioId - " + openTrade.getUserPortfolioId());
                }
            }
        }
        return automaticSell;
    }
}
