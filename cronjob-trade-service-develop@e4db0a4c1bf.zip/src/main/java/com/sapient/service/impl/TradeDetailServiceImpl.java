package com.sapient.service.impl;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.constant.TradeDetailStatus;
import com.sapient.dto.TradeExecutionResponseDto;
import com.sapient.dto.UserPortfolioUpdateDto;
import com.sapient.dto.UserTradeDetailUpdateDto;
import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.TradeDetailService;
import com.sapient.utils.CurrentTimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

@Service
@Slf4j
public class TradeDetailServiceImpl implements TradeDetailService {

    @Autowired
    TradeDetailRepository tradeDetailRepository;

    @Autowired
    ExecutedTradeRepository executedTradeRepository;

    @Autowired
    UserServiceFeignClient userServiceFeignClient;

    @Autowired
    CurrentTimeUtil currentTimeUtil;

    @Autowired
    StockServiceFeignClient stockServiceFeignClient;



    @Value("${market-opening-time-hour}")
    Integer marketOpeningTimeHour;
    @Value("${market-closing-time-hour}")
    Integer marketClosingTimeHour;
    @Value("${market-opening-time-minute}")
    Integer marketOpeningTimeMinute;
    @Value("${market-closing-time-minute}")
    Integer marketClosingTimeMinute;



    public boolean canBeExecuted(Timestamp currentTime){
        var calendar1= currentTimeUtil.getCalendarInstance();
        var calendar2=currentTimeUtil.getCalendarInstance();
        calendar1.set(Calendar.HOUR_OF_DAY,marketOpeningTimeHour);
        calendar1.set(Calendar.MINUTE,marketOpeningTimeMinute);
        calendar1.set(Calendar.SECOND,0);
        calendar1.set(Calendar.MILLISECOND,0);
        calendar2.set(Calendar.HOUR_OF_DAY,marketClosingTimeHour);
        calendar2.set(Calendar.MINUTE,marketClosingTimeMinute);
        calendar2.set(Calendar.SECOND,0);
        calendar2.set(Calendar.MILLISECOND,0);
        log.info("opening {}",calendar1);
        log.info("closing {}",calendar2);
        int day=currentTime.toLocalDateTime().getDayOfWeek().getValue();
        log.info("day {}",day);
        boolean isPossible;
        if(currentTime.after(Timestamp.from(calendar2.toInstant())) ||
                currentTime.before(Timestamp.from(calendar1.toInstant()))||day==6 || day==7)
            isPossible=false;
        else
            isPossible=true;
        return isPossible;
    }

    public ExecutedTrade executeBuyTrade(TradeDetail userTradeDetail) throws ExceedingAmountPerTradeException, InsufficientFundsException, UserNotFoundException {
        ResponseEntity<UserTradingDetailsDto> userTradingDetailsDto = userServiceFeignClient.getUserDetails(userTradeDetail.getUserId());
        var userTradeDetailDto = userTradingDetailsDto.getBody();
        if(userTradeDetailDto==null){
            log.error("Unable to fetch user details");
            throw new UserNotFoundException(Constant.USER_NOT_FOUND.toString());

        }
        log.info("User Trade details fetched");
        double amountPerTrade= (userTradeDetailDto.getTotalEquity()* userTradeDetailDto.getAmountPerTrade())/100;
        ResponseEntity<Map<String, BigDecimal>> tickerResponse = stockServiceFeignClient.getTickerPrice(userTradeDetail.getTicker().getTickerId());
        BigDecimal cmp = Objects.requireNonNull(tickerResponse.getBody()).get(Constant.PRICE_PER_STOCK.toString());

        log.info("stock price fetched");
        double totalCost= cmp.doubleValue()*userTradeDetail.getQuantity();
        userTradeDetail.setCreatedAt(Timestamp.from(Instant.now()));
        userTradeDetail.setPricePerTicker(cmp.doubleValue());
        userTradeDetail.setTotalCost(totalCost);
        if(totalCost> amountPerTrade){
            userTradeDetail.setStatus("insufficient_funds");
            tradeDetailRepository.save(userTradeDetail);
            log.error("exceeding amount per trade");
            throw new ExceedingAmountPerTradeException(Constant.EXCEEDING_AMOUNT_PER_TRADE.toString());
        }

        if(totalCost > userTradeDetailDto.getTotalAmount()){

            userTradeDetail.setStatus("insufficient_funds");
            tradeDetailRepository.save(userTradeDetail);
            log.error("Insufficient Funds");
            throw new InsufficientFundsException(Constant.INSUFFICIENT_FUNDS.toString());
        }

        Timestamp currentTime=currentTimeUtil.getCurrentTime();
        log.info("trade detail :{} ",userTradeDetail);
        log.info("user trade detail:{}",userTradeDetailDto);
        log.info("current time {}",currentTime);
        if(!canBeExecuted(currentTime)){
            userTradeDetail.setStatus("pending");
            log.info("pending status updated");
            tradeDetailRepository.save(userTradeDetail);
            log.info("trade details saved");
            return null;
        }
        else {

            var executedTrade = new ExecutedTrade();
            executedTrade.setTradeOpenedAt(Timestamp.from(Instant.now()));
            executedTrade.setBuyTradeDetail(userTradeDetail);
            executedTrade.setTimeframe(userTradeDetail.getTimeframe());
            executedTrade.setPricePerTicker(cmp.doubleValue());
            executedTrade.setUserId(userTradeDetail.getUserId());
            executedTrade.setTicker(userTradeDetail.getTicker());
            log.info("The trade saved in executed trades {}",executedTrade);
            return executedTradeRepository.save(executedTrade);
        }

    }

    @Override
    public TradeExecutionResponseDto executeTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, ZeroQuantityException, QuantityMismatchException, NoHoldingException {
        var userTradeDetail=checkTradeDetail(userTradeDetailUpdateDto);
        if(userTradeDetail.getTradeDirection().equals("buy")){
            ExecutedTrade executedBuyTrade=executeBuyTrade(userTradeDetail);
            UUID tradeDetailId=userTradeDetail.getTradeDetailId();
            var userTradeDetailUpdated=tradeDetailRepository.getById(tradeDetailId);
            if(executedBuyTrade!=null){
            userTradeDetailUpdated.setStatus("executed");
            userTradeDetailUpdated.setPricePerTicker(executedBuyTrade.getPricePerTicker());
            userTradeDetailUpdated.setTotalCost(executedBuyTrade.getPricePerTicker()* userTradeDetail.getQuantity());
            tradeDetailRepository.save(userTradeDetailUpdated);
            log.info("trade details updated after execution");

            var userPortfolioUpdateDto=new UserPortfolioUpdateDto();
            userPortfolioUpdateDto.setUserId(userTradeDetailUpdated.getUserId());
            userPortfolioUpdateDto.setQuantity(userTradeDetailUpdated.getQuantity());
            userPortfolioUpdateDto.setTickerNumber(userTradeDetailUpdated.getTicker().getTickerNumber());
            userPortfolioUpdateDto.setPrice(userTradeDetailUpdated.getPricePerTicker());
            userPortfolioUpdateDto.setStopLoss(userTradeDetailUpdated.getStopLoss());
            userPortfolioUpdateDto.setProfitTarget(userTradeDetailUpdated.getProfitTarget());
            userPortfolioUpdateDto.setType("buy");

            userServiceFeignClient.updateUserPortfolio(userPortfolioUpdateDto);
            log.info("user portfolio data updated");
            return new TradeExecutionResponseDto(userTradeDetailUpdated.getStatus());
            }
            return new TradeExecutionResponseDto(userTradeDetailUpdated.getStatus());
       }
        else{
            TradeDetailStatus status=executeSellTrade(userTradeDetail);
            if(status==TradeDetailStatus.PENDING_STATUS)
                return new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString());
            else
                return new TradeExecutionResponseDto(Constant.EXECUTED_MESSAGE.toString());
        }


    }
    public TradeDetailStatus executeSellTrade(TradeDetail tradeDetail) throws QuantityMismatchException,NoHoldingException {
        try {
            //get user portfolio dto
            var userPortfolioDto = userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(tradeDetail.getUserId(), tradeDetail.getTicker().getTickerNumber());
            if(tradeDetail.getStatus().equals(TradeDetailStatus.QUANTITY_MISMATCH_STATUS.toString())){
                tradeDetail.setQuantity(userPortfolioDto.getQuantity());
            }
            else{
                if(!tradeDetail.getQuantity().equals(userPortfolioDto.getQuantity())){
                    tradeDetail.setStatus(TradeDetailStatus.QUANTITY_MISMATCH_STATUS.toString());
                    log.debug("Quantity mismatch for trade details {}",tradeDetail);
                    throw new QuantityMismatchException();
                }
            }
            tradeDetail.setStatus(TradeDetailStatus.PENDING_STATUS.toString());
            //get current price
            Map<String, BigDecimal> stockQuote= Objects.requireNonNull(stockServiceFeignClient.getTickerPrice(tradeDetail.getTicker().getTickerId()).getBody());
            log.debug("fetched price for stock {} +result:{}" ,tradeDetail.getTicker(),stockQuote);
            var currentPrice=stockQuote.get(Constant.PRICE_PER_STOCK.toString()).doubleValue();
            //update trade detail
            tradeDetail.setPricePerTicker(currentPrice);
            tradeDetail.setTotalCost(tradeDetail.getQuantity()*currentPrice);
            tradeDetail.setGain(currentPrice-userPortfolioDto.getAveragePrice());
            //if time within market hour execute it, set all open trades for that ticker for user closed
            Timestamp currentTime=currentTimeUtil.getCurrentTime();
            if(canBeExecuted(currentTime)){
                //in market hour execute it
                setClosedTrade(tradeDetail,currentTime);
                tradeDetail.setStatus(TradeDetailStatus.EXECUTED_STATUS.toString());
                //update the user portfolio
                var userPortfolioUpdateDto =setUserPortfolioUpdateDto(tradeDetail);
                userServiceFeignClient.updateUserPortfolio(userPortfolioUpdateDto);
                log.debug("trade executed and user portfolio updated for trade details {}",tradeDetail);
                return TradeDetailStatus.EXECUTED_STATUS;
            }
            return TradeDetailStatus.PENDING_STATUS;
        }
        catch(NoHoldingException e){
            tradeDetail.setStatus(TradeDetailStatus.NO_HOLDING_STATUS.toString());
            log.debug("The trade details {} has no holding exception",tradeDetail);
            throw new NoHoldingException();
        }
        finally {
            tradeDetailRepository.save(tradeDetail);
        }
    }
    public UserPortfolioUpdateDto setUserPortfolioUpdateDto(TradeDetail tradeDetail)
    {
        var userPortfolioUpdateDto=new UserPortfolioUpdateDto();
        userPortfolioUpdateDto.setUserId(tradeDetail.getUserId());
        userPortfolioUpdateDto.setQuantity(tradeDetail.getQuantity());
        userPortfolioUpdateDto.setPrice(tradeDetail.getPricePerTicker());
        userPortfolioUpdateDto.setTickerNumber(tradeDetail.getTicker().getTickerNumber());
        userPortfolioUpdateDto.setType(tradeDetail.getTradeDirection());
        return  userPortfolioUpdateDto;
    }
    public void setClosedTrade(TradeDetail tradeDetail,Timestamp currentTime){
        List<ExecutedTrade> openTradesForUser=executedTradeRepository.findByUserIdAndTickerAndTradeClosedAtIsNull(tradeDetail.getUserId(),tradeDetail.getTicker());
        for(var trade:openTradesForUser){
            trade.setSellTradeDetail(tradeDetail);
            trade.setTradeClosedAt(currentTime);
            trade.setSoldPricePerTicker(tradeDetail.getPricePerTicker());
            trade.setGain(trade.getSoldPricePerTicker()- trade.getPricePerTicker());
        }
        log.debug("Updated the closed trades trades for the trade detail {} at time {}",tradeDetail,currentTime);
        executedTradeRepository.saveAll(openTradesForUser);
    }
    @Override
    public TradeExecutionResponseDto executeAutomatic() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException {
        List<TradeDetail> tradeDetailList=tradeDetailRepository.findPendingTradeDetail();
        for(TradeDetail x: tradeDetailList){
            var userTradeDetailUpdateDto=new UserTradeDetailUpdateDto();
            userTradeDetailUpdateDto.setTradeDetailId(x.getTradeDetailId());
            userTradeDetailUpdateDto.setQuantity(x.getQuantity());
            userTradeDetailUpdateDto.setStopLoss(x.getStopLoss());
            userTradeDetailUpdateDto.setProfitTarget(x.getProfitTarget());

            try {
                executeTradeDetail(userTradeDetailUpdateDto);
            }
            catch (InsufficientFundsException ex) {
                log.info("Cannot execute trade detail due to insufficient funds");
            }
            catch (ExceedingAmountPerTradeException ex) {
                log.info("Cannot execute trade detail because amount exceeded");
            }
            catch (ZeroQuantityException ex) {
                log.info("Cannot execute zero quantity exception");
            }
            catch (QuantityMismatchException ex){
                    log.info("Cannot execute xero quantity exception");
            }
            catch (NoHoldingException ex){
                log.info("Cannot execute trade No holding exception");
            }
            catch(Exception e){
                log.error("exception occurred{}",e.getStackTrace());
            }
        }
        return new TradeExecutionResponseDto("Success");
    }


    public  TradeDetail checkTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws ZeroQuantityException,TradeDetailNotFoundException, TradeAlreadyExecutedException {

        Optional<TradeDetail> tradeDetail = tradeDetailRepository.findById(userTradeDetailUpdateDto.getTradeDetailId());
        if (tradeDetail.isEmpty()) {
            log.error("trade detail not found");
            throw new TradeDetailNotFoundException(userTradeDetailUpdateDto.getTradeDetailId().toString() + Constant.TRADE_DETAIL_NOT_FOUND.toString());
        }
        var userTradeDetail=tradeDetail.get();
        log.info("trade detail fetched");
        if(userTradeDetail.getStatus().equals(Constant.EXECUTED.toString())){
            log.error("trade is already executed");
            throw new TradeAlreadyExecutedException(Constant.TRADE_ALREADY_EXECUTED.toString());
        }
        userTradeDetail.setProfitTarget(userTradeDetailUpdateDto.getProfitTarget());
        userTradeDetail.setStopLoss(userTradeDetailUpdateDto.getStopLoss());
        if(userTradeDetail.getProfitTarget()!=null && userTradeDetail.getStopLoss()!=null)
            userTradeDetail.setRiskToRewardRatio(userTradeDetail.getStopLoss()/ userTradeDetail.getProfitTarget());
        if(userTradeDetailUpdateDto.getQuantity()!=null) {
            userTradeDetail.setQuantity(userTradeDetailUpdateDto.getQuantity());
        }
        if(userTradeDetail.getQuantity()==0){
            log.debug("trying to execute 0 quantity for",tradeDetail);
            throw new ZeroQuantityException(Constant.ZERO_QUANTITY_EXCEPTION.toString());
        }
        tradeDetailRepository.save(userTradeDetail);
        return userTradeDetail;
        }

}
