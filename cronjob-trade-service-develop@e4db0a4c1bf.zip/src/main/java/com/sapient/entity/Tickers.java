package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


@Entity
@Getter
@Setter
@Table(name = "tickers" )
@AllArgsConstructor
@NoArgsConstructor
public class Tickers {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ticker_number")
    private Integer  tickerNumber;

    @Column(name="ticker_name")
    private String tickerName;

    @Column(name="ticker_id")
    private String tickerId;

    @Column(name="ticker_type")
    private String tickerType;

    @Override
    public String toString() {
        return "Tickers{" +
                "tickerNumber=" + tickerNumber +
                ", tickerName='" + tickerName + '\'' +
                ", tickerId='" + tickerId + '\'' +
                ", tickerType='" + tickerType + '\'' +
                '}';
    }
}
