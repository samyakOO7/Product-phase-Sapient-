package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "trade_details" )
@AllArgsConstructor
@NoArgsConstructor
public class TradeDetail {

    @Id
    @Column(name="trade_detail_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID tradeDetailId;

    @Column(name="user_id")
    private BigInteger userId;

    @ManyToOne
    @JoinColumn(name="ticker_number")
    private Tickers ticker;

    @Column(name="timeframe")
    private Integer timeframe ;

    @Column(name="trade_direction")
    private String tradeDirection;

    @Column(name="created_at")
    private Timestamp createdAt;

    @Column(name="price_per_ticker")
    private Double pricePerTicker;

    @Column(name="quantity")
    private Integer quantity;

    @Column(name="total_cost")
    private Double totalCost;

    @Column(name="stop_loss")
    private Double stopLoss;

    @Column(name="profit_target")
    private Double profitTarget;

    @Column(name="status", columnDefinition = "default 'pending'")
    private String status;

    @ManyToOne
    @JoinColumn(name="trade_alert_id")
    private TradeAlert tradeAlert;

    @Column(name="gain")
    private Double gain;

    @Column(name="risk_to_reward_ratio")
    private Double riskToRewardRatio;

    @Override
    public String toString() {
        return "TradeDetail{" +
                "tradeDetailId=" + tradeDetailId +
                ", userId=" + userId +
                ", ticker=" + ticker +
                ", timeframe=" + timeframe +
                ", tradeDirection='" + tradeDirection + '\'' +
                ", createdAt=" + createdAt +
                ", pricePerTicker=" + pricePerTicker +
                ", quantity=" + quantity +
                ", totalCost=" + totalCost +
                ", stopLoss=" + stopLoss +
                ", profitTarget=" + profitTarget +
                ", status='" + status + '\'' +
                ", tradeAlert=" + tradeAlert +
                ", gain=" + gain +
                ", riskToRewardRatio=" + riskToRewardRatio +
                '}';
    }
}
