package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.UUID;


@Entity
@Getter
@Setter

@Table(name = "user_trade_alerts" )
@AllArgsConstructor
@NoArgsConstructor
public class UserTradeAlert {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="user_trade_alert_id")
    private UUID userTradeAlertId;

    @Column(name="user_id")
    private BigInteger userId;

    @ManyToOne
    @JoinColumn(name="trade_alert_id")
    private TradeAlert tradeAlert;
    @Override
    public String toString() {
        return "UserTradeAlert{" +
                "userTradeAlertId=" + userTradeAlertId +
                ", userId=" + userId +
                ", tradeAlert=" + tradeAlert +
                '}';
    }
}
