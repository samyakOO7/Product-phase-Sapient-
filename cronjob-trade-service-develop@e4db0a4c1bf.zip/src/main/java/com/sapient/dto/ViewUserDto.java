package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ViewUserDto {
    private BigInteger userId;

    private String userName;

    private String email;

    private String alternateEmail;

    private String phoneNumber;

    private String firstName;

    private String lastName;
}