package com.sapient.dto;


import lombok.*;

import java.math.BigInteger;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class UserTradingDetailsDto {

    private BigInteger userId;

    private Double totalAmount;


    private Double amountPerTrade;


    private Double riskPerTrade;

    private BigInteger totalAlertsGenerated;
    private Double totalEquity;

    @Override
    public String toString() {
        return "UserTradingDetailsDto{" +
                "userId=" + userId +
                ", totalAmount=" + totalAmount +
                ", amountPerTrade=" + amountPerTrade +
                ", riskPerTrade=" + riskPerTrade +
                ", totalAlertsGenerated=" + totalAlertsGenerated +
                ", totalEquity=" + totalEquity +
                '}';
    }
}