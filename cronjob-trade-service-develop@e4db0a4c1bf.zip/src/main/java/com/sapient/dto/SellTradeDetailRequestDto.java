package com.sapient.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;

import java.math.BigInteger;

@Data
@Generated
@AllArgsConstructor
public class SellTradeDetailRequestDto {
    BigInteger userPortfolioId;
}
