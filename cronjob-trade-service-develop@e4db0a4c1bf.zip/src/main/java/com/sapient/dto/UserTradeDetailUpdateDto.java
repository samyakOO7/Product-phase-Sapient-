package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserTradeDetailUpdateDto {
    private UUID tradeDetailId;



    private Integer quantity;

    private Double stopLoss;

    private Double profitTarget;

    @Override
    public String toString() {
        return "UserTradeDetailUpdateDto{" +
                "tradeDetailId=" + tradeDetailId +
                ", quantity=" + quantity +
                ", stopLoss=" + stopLoss +
                ", profitTarget=" + profitTarget +
                '}';
    }
}
