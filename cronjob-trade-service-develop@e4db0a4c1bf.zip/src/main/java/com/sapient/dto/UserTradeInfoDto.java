package com.sapient.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class UserTradeInfoDto {
    private int openTrades;
    private int closedTrades;
    private int winningTrades;
    private int losingTrades;
    private int alertsConvertedToTrades;
    private double gain;
    private int tradeAlertsGenerated;

    private double equity;

    @Override
    public String toString() {
        return "UserTradeInfoDto{" +
                "openTrades=" + openTrades +
                ", closedTrades=" + closedTrades +
                ", winningTrades=" + winningTrades +
                ", losingTrades=" + losingTrades +
                ", alertsConvertedToTrades=" + alertsConvertedToTrades +
                ", gain=" + gain +
                ", tradeAlertsGenerated=" + tradeAlertsGenerated +
                ", equity=" + equity +
                '}';
    }
}
