package com.sapient.dto;

import lombok.*;
@Generated

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class TradeExecutionResponseDto {
     private String message;

     @Override
     public String toString() {
          return "TradeExecutionResponse{" +
                  "message='" + message + '\'' +
                  '}';
     }
}
