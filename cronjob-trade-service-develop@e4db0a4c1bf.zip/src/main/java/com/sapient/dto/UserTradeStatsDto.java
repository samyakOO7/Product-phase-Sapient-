package com.sapient.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserTradeStatsDto {
    private double gain;
    private Integer winning;
    private Integer losing;
    private double totalEquity;

    @Override
    public String toString() {
        return "UserTradeStatsDto{" +
                "gain=" + gain +
                ", winning=" + winning +
                ", losing=" + losing +
                ", totalEquity=" + totalEquity +
                '}';
    }
}
