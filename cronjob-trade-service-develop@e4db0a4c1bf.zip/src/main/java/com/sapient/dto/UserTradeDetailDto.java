package com.sapient.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Generated
public class UserTradeDetailDto {
    private double totalAmount;
    private double amountPerTrade;

    private double totalEquity;

    private double riskPerTrade;

    @Override
    public String toString() {
        return "UserTradeDetailDto{" +
                "totalAmount=" + totalAmount +
                ", amountPerTrade=" + amountPerTrade +
                ", totalEquity=" + totalEquity +
                ", riskPerTrade=" + riskPerTrade +
                '}';
    }

}
