package com.sapient.dto;

import com.sapient.entity.Tickers;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Generated
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPortfolioDtoSell {
    private BigInteger userPortfolioId;
    private Integer quantity;

    private Double averagePrice;

    private BigInteger userId;


    private Tickers ticker;
}