package com.sapient.message;


import lombok.*;

@ToString
@NoArgsConstructor
@Setter
@Getter
@Generated
public class SellConfirmation {
    private String email;
    private String firstName;
    private String tickerSymbol;
    private String timestamp;
    private Double price;
    private Double gain;
    private Integer quantity;
}
