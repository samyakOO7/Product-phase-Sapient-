package com.sapient.utils;

import com.sapient.message.SellConfirmation;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Component
@Slf4j
public class KafkaClientUtilImpl implements KafkaClientUtil {

    @Autowired
    KafkaTemplate<String, SellConfirmation> template;

    String topicName = "user_sell_confirmation";

    public void sendSellConfirmation(SellConfirmation alert) {
        log.debug("received request to send alert : {}", alert);
        ListenableFutureCallback<SendResult<String, SellConfirmation>> callback = new ListenableFutureCallback<>() {
            @Override
            @Generated
            public void onSuccess(SendResult<String, SellConfirmation> result) {
                log.info("Record sent successfully {}", result.getRecordMetadata().toString());
            }

            @Override
            @Generated
            public void onFailure(Throwable ex) {
                ProducerRecord<?, ?> producerRecord = ((KafkaProducerException) ex).getFailedProducerRecord();
                log.error("Failed to send the record " + producerRecord, ex);
            }
        };
        Message<SellConfirmation> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, topicName)
                .build();
        ListenableFuture<SendResult<String, SellConfirmation>> future = template.send(userMessage);
        future.addCallback(callback);
    }
}
