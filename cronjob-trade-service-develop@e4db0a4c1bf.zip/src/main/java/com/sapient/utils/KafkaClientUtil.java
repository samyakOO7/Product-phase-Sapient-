package com.sapient.utils;

import com.sapient.message.SellConfirmation;

public interface KafkaClientUtil {
    void sendSellConfirmation(SellConfirmation alert);
}
