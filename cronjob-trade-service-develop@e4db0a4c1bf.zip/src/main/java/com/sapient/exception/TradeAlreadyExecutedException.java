package com.sapient.exception;

import lombok.Generated;

@Generated
public class TradeAlreadyExecutedException extends Exception{
    public TradeAlreadyExecutedException(String message) {
        super(message);
    }
}
