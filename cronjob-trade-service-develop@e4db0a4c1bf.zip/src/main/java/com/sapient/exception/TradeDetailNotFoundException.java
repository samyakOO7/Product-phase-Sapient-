package com.sapient.exception;

import lombok.Generated;

@Generated
public class TradeDetailNotFoundException extends Exception{


    public TradeDetailNotFoundException(String message) {
        super(message);
    }
}
