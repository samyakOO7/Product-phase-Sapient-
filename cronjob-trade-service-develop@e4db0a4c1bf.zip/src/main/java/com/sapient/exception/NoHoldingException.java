package com.sapient.exception;

public class NoHoldingException extends Exception{
}
