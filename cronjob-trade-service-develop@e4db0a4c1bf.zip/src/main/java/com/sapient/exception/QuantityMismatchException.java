package com.sapient.exception;

public class QuantityMismatchException extends Exception{
}
