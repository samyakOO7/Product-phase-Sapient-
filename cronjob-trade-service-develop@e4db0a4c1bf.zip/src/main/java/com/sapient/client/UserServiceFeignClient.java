package com.sapient.client;

import com.sapient.config.UserServiceFeignErrorConfig;
import com.sapient.dto.*;
import com.sapient.exception.NoHoldingException;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;


@FeignClient(url="${user.service.feign.url}", name="user-microservice", configuration = {UserServiceFeignErrorConfig.class})
public interface UserServiceFeignClient {

    @PostMapping("portfolio/update")
    ResponseEntity<Object> updateUserPortfolio(@RequestBody UserPortfolioUpdateDto userPortfolioUpdateDto);
    @GetMapping("/get-user-trading-details/{userId}")
    ResponseEntity<UserTradingDetailsDto> getUserDetails(@PathVariable("userId") BigInteger userId);

    @GetMapping("/all-users")
    PortfolioUserIdsDto getAllUserIds();

    @GetMapping("/user-portfolio")
    public Map<String, List<UserPortfolioDto>> getUserPortfolio(@RequestParam("userId") BigInteger userId);
    @GetMapping("/user-portfolio/{portfolio-id}")
    UserPortfolioDtoSell getUserPortfolioSell(@PathVariable("portfolio-id") BigInteger portfolioId);

    @GetMapping("/user-portfolio/{user-id}/ticker/{ticker-number}")
    UserPortfolioDtoSell getUserPortfolioByUserIdAndTickerNumber(@PathVariable("user-id") BigInteger userId,@PathVariable("ticker-number")Integer tickerNumber) throws NoHoldingException;

}
