package com.sapient.client;

import com.sapient.dto.SellTradeDetailRequestDto;
import com.sapient.dto.TradeExecutionResponseDto;
import com.sapient.dto.UserTradeDetailUpdateDto;
import com.sapient.entity.TradeDetail;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(url="${trade.service.feign.url}", name="trade-microservice")
public interface TradeServiceFeignClient {



    @PostMapping("trade-details/sell")
    public TradeDetail generateSellTradeDetail(@RequestBody SellTradeDetailRequestDto sellTradeDetailRequestDto);

    @PostMapping("/trade-detail/execute")
    public TradeExecutionResponseDto executeTradeDetail(@RequestBody UserTradeDetailUpdateDto userTradeDetailUpdateDto);

}
