package com.sapient.client;

import com.sapient.dto.ViewUserDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigInteger;

@FeignClient(url = "${auth.service.feign.url}", name = "authentication-microservice")
public interface AuthServiceFeignClient {

    @GetMapping("/user/{userId}")
    ViewUserDto getUserEmailAndName(@PathVariable BigInteger userId);
}