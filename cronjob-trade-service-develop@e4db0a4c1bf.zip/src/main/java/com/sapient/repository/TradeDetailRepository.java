package com.sapient.repository;


import com.sapient.entity.TradeDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.UUID;

public interface TradeDetailRepository extends JpaRepository<TradeDetail, UUID> {

   @Query("select t from TradeDetail t where t.status='pending'")
    List<TradeDetail> findPendingTradeDetail();
}
