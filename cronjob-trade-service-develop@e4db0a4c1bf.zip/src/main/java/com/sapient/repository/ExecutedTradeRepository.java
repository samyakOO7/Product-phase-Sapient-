package com.sapient.repository;

import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface ExecutedTradeRepository extends JpaRepository<ExecutedTrade, UUID> {
    List<ExecutedTrade> findByUserIdAndTickerAndTradeClosedAtIsNull(BigInteger userId, Tickers tickers);

}
