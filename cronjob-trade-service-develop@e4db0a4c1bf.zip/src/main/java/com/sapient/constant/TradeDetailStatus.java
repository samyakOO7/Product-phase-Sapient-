package com.sapient.constant;

public enum TradeDetailStatus {
    PENDING_STATUS("pending"),
    EXECUTED_STATUS("executed"),
    NO_HOLDING_STATUS("no_holding"),
    QUANTITY_MISMATCH_STATUS("quantity_mismatch"),
    NO_ACTION("no_action"),
    INSUFFICIENT_FUNDS("insufficient_funds");
    private final String message;

    TradeDetailStatus(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
