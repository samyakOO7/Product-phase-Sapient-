package com.sapient.constant;

import lombok.Generated;

@Generated
public enum Constant {

    EXCEEDING_AMOUNT_PER_TRADE("Trade Amount is Exceeding Amount per trade"),
    INSUFFICIENT_FUNDS("Insufficient Balance"),
    USER_NOT_FOUND("User does not exist"),
    PRICE_PER_STOCK("price_per_stock"),

    TRADE_ALREADY_EXECUTED("Trade Already Executed"),
    TRADE_DETAIL_NOT_FOUND("Trade Detail Not Found"),
    ZERO_QUANTITY_EXCEPTION("Cannot execute trade for 0 quantity"),
    TRADE_DETAILS_NOT_FOUND("Trade details not found"),
    PORTFOLIO_DETAIL_NOT_FOUND("PORTFOLIO_DETAIL_NOT_FOUND"),
    QUANTITY_MISMATCH("Quantity in user portfolio and sell don't match"),
    NO_HOLDINGS("You don't have the stock in your portfolio"),
    EXECUTED_MESSAGE("The trade has been executed"),
    TRADE_ALERT_NOT_FOUND("No trade alert found"),
    PENDING_MESSAGE("The trade is in pending state"),
    EXECUTED("executed"),
    INTERNAL_SERVER_ERROR("Internal Server Error");

    private final String message;

    Constant(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
