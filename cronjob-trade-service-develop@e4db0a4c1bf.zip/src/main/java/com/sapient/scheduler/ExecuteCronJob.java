package com.sapient.scheduler;

import com.sapient.exception.*;
import com.sapient.service.AutomaticSellService;
import com.sapient.service.TradeDetailService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;

import com.sapient.exception.ExceedingAmountPerTradeException;
import com.sapient.exception.InsufficientFundsException;
import com.sapient.exception.TradeAlreadyExecutedException;
import com.sapient.exception.TradeDetailNotFoundException;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Slf4j
@Transactional
public class ExecuteCronJob {

    @Autowired
    TradeDetailService tradeDetailService;

    @Autowired
    AutomaticSellService automaticSellService;

    @Scheduled(cron = "0 0 10 * * 1-5")
    public void execute() throws TradeDetailNotFoundException, TradeAlreadyExecutedException,
            InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException {
        log.debug("executing buy details");
        tradeDetailService.executeAutomatic();
    }

    @Scheduled(cron = "0 0 15 * * ?")
    public void executeSell() {
        log.debug("executing sell details");
        automaticSellService.executeSell();
    }

}
