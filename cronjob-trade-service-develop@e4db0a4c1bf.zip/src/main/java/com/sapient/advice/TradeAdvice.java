package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.ExceedingAmountPerTradeException;
import com.sapient.exception.InsufficientFundsException;
import com.sapient.exception.TradeAlreadyExecutedException;
import com.sapient.exception.TradeDetailNotFoundException;
import com.sapient.utils.JsonResponse;
import lombok.Generated;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;
import java.util.Map;

@Generated
@RestControllerAdvice
public class TradeAdvice {
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(TradeDetailNotFoundException.class)
    public  Map<String, List<Map<String, String>>>  tradeDetailNotFoundHandler(TradeDetailNotFoundException tradeDetailNotFoundException) {
        return JsonResponse.setError(Constant.TRADE_DETAIL_NOT_FOUND.name(), tradeDetailNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(InsufficientFundsException.class)
    public Map<String, List<Map<String, String>>> insufficientFundsExceptionHandler(InsufficientFundsException insufficientFundsException) {
        return JsonResponse.setError(Constant.INSUFFICIENT_FUNDS.name(), insufficientFundsException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ExceedingAmountPerTradeException.class)
    public Map<String, List<Map<String, String>>> exceedingAmountHandler(ExceedingAmountPerTradeException exceedingAmountPerTradeException) {
        return JsonResponse.setError(Constant.EXCEEDING_AMOUNT_PER_TRADE.name(), exceedingAmountPerTradeException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(TradeAlreadyExecutedException.class)
    public Map<String, List<Map<String, String>>> tradeAlreadyExecutedHandler(TradeAlreadyExecutedException tradeAlreadyExecutedException) {
        return JsonResponse.setError(Constant.TRADE_ALREADY_EXECUTED.name(), tradeAlreadyExecutedException.getMessage());
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public Map<String, List<Map<String, String>>> genericExceptionHandler(Exception e) {
        return JsonResponse.setError(Constant.INTERNAL_SERVER_ERROR.name(), e.getMessage());
    }

}
