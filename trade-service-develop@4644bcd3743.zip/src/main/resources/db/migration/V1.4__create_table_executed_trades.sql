create table executed_trades(
    executed_trades_id uuid primary key,
    user_id bigint not null,
    ticker_number integer references tickers(ticker_number) not null,
    buy_trade_detail_id uuid references trade_details(trade_detail_id),
    sell_trade_detail_id uuid references trade_details(trade_detail_id),
    timeframe integer,
    trade_opened_at timestamp,  --trade opening time
    trade_closed_at timestamp,  --trade closing time
    gain numeric,    --profit(+)/loss(-) made
    price_per_ticker numeric not null,  --price of 1 stock
    sold_price_per_ticker numeric default null --sold price per ticker
);

create index executed_trades_user_id on executed_trades(user_id);