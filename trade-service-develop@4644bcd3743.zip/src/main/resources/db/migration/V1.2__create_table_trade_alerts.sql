create table trade_alerts(
    trade_alert_id uuid primary key,
    ticker_number integer references tickers(ticker_number) not null,
    timeframe integer default 1440,  -- 1 day i.e. 24x60 minutes
    trade_direction varchar(7)  check(trade_direction in ('buy','sell')),  --either value is buy or sell
    generation_time timestamp not null, --the day on which alert is generated
    expiry_time timestamp, --to be set by application based on when it generated the alerts and wants the alerts to expire
    confidence numeric not null check(confidence between 0 and 100), --confidence percentage of trade
    ATR numeric not null --ATR for profit target calculation
);
create index trade_alerts_time_index on trade_alerts(generation_time);
