create table user_trade_alerts(
    user_trade_alert_id uuid primary key,
    user_id bigint not null,
    trade_alert_id uuid not null,
    constraint user_trade_alerts_fk foreign key (trade_alert_id) references trade_alerts(trade_alert_id),
    constraint user_id_trade_alert_id_unique unique(user_id,trade_alert_id)
);