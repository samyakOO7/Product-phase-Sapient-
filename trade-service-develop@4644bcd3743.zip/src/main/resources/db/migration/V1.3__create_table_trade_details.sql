create table trade_details(
    trade_detail_id uuid primary key,
    user_id bigint not null,  --user id of user table
    ticker_number integer references tickers(ticker_number) not null,  --sample values: 5609873
    timeframe integer default 1440,  --1440 mins = 1day ; in minutes
    trade_direction varchar(7) check(trade_direction in ('buy','sell')),
    created_at timestamp not null, --time stamp of creation
    price_per_ticker numeric not null,  -- price of every ticker
    quantity integer not null,  --number of stocks that can be bought
    total_cost numeric,  --quantity * price per ticker
    stop_loss numeric, --stop loss of the particular trade detail ,should be percentage
    profit_target numeric, --profit target , sell when reaches here, should be percentage
    status varchar(30) not null default 'pending' ,--status of the specific trade detail
    trade_alert_id uuid references trade_alerts(trade_alert_id), --corresponding trade alert
    gain numeric , --gain from the trade
    risk_to_reward_ratio real --risk to reward ratio  stop loss/profit target
   );

create index trade_details_user_id_ticker_number on trade_details(user_id,ticker_number);

alter table trade_details add constraint trade_details_status_check check(status in ('pending','executed','no_action','insufficient_funds'));  --status field values

alter table trade_details add constraint profit_target_percent check(profit_target between 0 and 100);

alter table trade_details add constraint stop_loss_percent check(stop_loss between 0 and 100);