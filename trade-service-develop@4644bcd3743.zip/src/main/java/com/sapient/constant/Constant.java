package com.sapient.constant;

import lombok.Generated;

@Generated
public enum Constant {

    EXCEEDING_AMOUNT_PER_TRADE("Trade Amount is Exceeding Amount per trade"),
    INSUFFICIENT_FUNDS("Insufficient Balance"),

    PRICE_PER_STOCK("price_per_stock"),
    TRADE_ALREADY_EXECUTED("Trade Already Executed"),
    TRADE_DETAIL_NOT_FOUND("Trade Detail Not Found"),
    USER_NOT_FOUND("User does not exist"),
    REFRESH_NOT_SUPPORTED("Trade details refresh not supported"),
    TICKER_NOT_FOUND("Ticker does not exist"),
    TICKER_PRICE_NOT_FOUND("Unable to fetch ticker price currently"),
    RISK_PER_TRADE_FIELD_ERROR("Invalid value for riskPerTrade. Allowed range: 0-100"),
    AMOUNT_PER_TRADE_FIELD_ERROR("Invalid value for amountPerTrade. Allowed range: 0-100"),
    INTERNAL_SERVER_ERROR("Internal Server Error Occurred"),
    PARAMETER_FOR_SEARCH_NOT_FOUND("Parameter for search not found"),
    WATCHLIST_NOT_FOUND("Empty Watchlist"),
    EMPTY_BODY_ERROR("Body cannot be null or empty"),
    NO_CLOSED_TRADES("No closed trades found"),
    MESSAGE("message"),
    EXECUTED("executed"),
    CODE("code"),
    ERRORS("errors"),
    LIST_NOT_FOUND("No list found"),
    PARAMETER_NOT_FOUND("Parameter for userId not found"),
    ZERO_QUANTITY_EXCEPTION("Cannot execute trade for 0 quantity"),
    TRADE_DETAILS_NOT_FOUND("Trade details not found"),
    PORTFOLIO_DETAIL_NOT_FOUND("PORTFOLIO_DETAIL_NOT_FOUND"),
    QUANTITY_MISMATCH("Quantity in user portfolio and sell don't match"),
    NO_HOLDINGS("You don't have the stock in your portfolio"),
    EXECUTED_MESSAGE("The trade has been executed"),
    TRADE_ALERT_NOT_FOUND("No trade alert found"),
    PENDING_MESSAGE("The trade is in pending state");


    private final String message;

    Constant(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
