package com.sapient.repository;

import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface ExecutedTradeRepository extends JpaRepository<ExecutedTrade, UUID> {

    @Query("select count(distinct(e.ticker)) from ExecutedTrade e where e.userId=:userId and e.tradeClosedAt is null ")
    int findOpenTrades(BigInteger userId);

    @Query("select count(e.ticker) from ExecutedTrade e where e.userId=:userId and e.tradeClosedAt is not null ")
    int findClosedTrades(BigInteger userId);

    @Query("select e from ExecutedTrade e where e.userId = :userId and e.tradeClosedAt is null")
    List<ExecutedTrade> findAllOpenTrades(BigInteger userId);

    @Query("select e from ExecutedTrade e where e.userId = :userId and e.tradeClosedAt is not null")
    List<ExecutedTrade> findAllClosedTrades(BigInteger userId, PageRequest pageRequest);
    @Query("select count(e) from ExecutedTrade e where e.userId = :userId and e.tradeClosedAt is not null")
    Long countOfClosedTrades(BigInteger userId);

    List<ExecutedTrade> findByUserIdAndTickerAndTradeClosedAtIsNull(BigInteger userId, Tickers tickers);

}
