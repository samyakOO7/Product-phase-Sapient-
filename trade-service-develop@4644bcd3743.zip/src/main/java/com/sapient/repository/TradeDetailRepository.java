package com.sapient.repository;


import com.sapient.entity.TradeDetail;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface TradeDetailRepository extends JpaRepository<TradeDetail, UUID> {

    @Query("select count(t) from TradeDetail t where t.userId=:userId and t.status='executed' and t.tradeAlert is not null and extract (month FROM t.createdAt) = extract (month FROM CURRENT_DATE) " +
           "and extract (year FROM t.createdAt) = extract (year FROM CURRENT_DATE)")
    int findTradeConverted(BigInteger userId);

    List<TradeDetail> findByUserId(BigInteger userId, PageRequest pageRequest);

    Long countByUserId(BigInteger userId);

    @Query("SELECT t FROM TradeDetail t where t.tradeDetailId = :tradeDetailId")
    TradeDetail findByUserTradeDetail(UUID tradeDetailId);

    @Query("UPDATE TradeDetail t SET t.status='pending' WHERE t.tradeDetailId = :tradeDetailId")
    TradeDetail setTradeStatus(UUID tradeDetailId);
    //find with userId stock number and tradeDirection and status(no_Action)
    Optional<TradeDetail> findFirstByUserIdAndTicker_TickerNumberAndTradeDirectionAndStatus(BigInteger userId,Integer tickerNumber,String tradeDirection,String status);
}
