package com.sapient.repository;

import com.sapient.entity.UserTradeAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface UserTradeAlertRepository extends JpaRepository<UserTradeAlert, UUID> {

    List<UserTradeAlert> findByUserId(BigInteger userId);

    @Query("SELECT u FROM UserTradeAlert u where u.userId = :userId AND u.tradeAlert.tradeAlertId = :tradeAlertId")
    UserTradeAlert findUserTradeAlert(BigInteger userId, UUID tradeAlertId);

    @Query ("select u from UserTradeAlert u where u.userId =:userId order by u.tradeAlert.generationTime desc")
    List<UserTradeAlert> getUserTradeAlert(BigInteger userId);

}
