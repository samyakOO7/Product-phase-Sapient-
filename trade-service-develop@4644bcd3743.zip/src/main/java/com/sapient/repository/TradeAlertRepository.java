package com.sapient.repository;

import com.sapient.entity.TradeAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.UUID;

@Repository
public interface TradeAlertRepository extends JpaRepository<TradeAlert, UUID> {

    @Query("select count(t) from TradeAlert t left join UserTradeAlert u on t.tradeAlertId = u.tradeAlert where u.userId= :userId and " +
            "extract (month FROM t.generationTime) = extract (month FROM CURRENT_DATE) " +
            "and extract (year FROM t.generationTime) = extract (year FROM CURRENT_DATE)")
    int findAllAlertByMonth(@Param("userId") BigInteger userId);


}

