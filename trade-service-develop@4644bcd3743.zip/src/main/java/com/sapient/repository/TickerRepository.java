package com.sapient.repository;

import com.sapient.entity.Tickers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TickerRepository extends JpaRepository<Tickers,Integer> {


}
