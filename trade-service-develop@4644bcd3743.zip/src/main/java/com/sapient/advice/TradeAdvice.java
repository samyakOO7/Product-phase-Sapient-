package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.*;
import com.sapient.util.JsonResponse;
import lombok.Generated;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
@Generated
public class TradeAdvice {
    Map<String, List<Map<String, String>>> map;
    ArrayList<Map<String, String>> list;
    Map<String, String> errorDetailMap;

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(TradeDetailNotFoundException.class)
    public Map<String, List<Map<String, String>>> tradeDetailNotFoundHandler(TradeDetailNotFoundException tradeDetailNotFoundException) {
        return JsonResponse.setError(Constant.TRADE_DETAIL_NOT_FOUND.name(), tradeDetailNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(InsufficientFundsException.class)
    public Map<String, List<Map<String, String>>> insufficientFundsExceptionHandler(InsufficientFundsException insufficientFundsException) {
        return JsonResponse.setError(Constant.INSUFFICIENT_FUNDS.name(), insufficientFundsException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ExceedingAmountPerTradeException.class)
    public Map<String, List<Map<String, String>>> exceedingAmountHandler(ExceedingAmountPerTradeException exceedingAmountPerTradeException) {
        return JsonResponse.setError(Constant.EXCEEDING_AMOUNT_PER_TRADE.name(), exceedingAmountPerTradeException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(TradeAlreadyExecutedException.class)
    public Map<String, List<Map<String, String>>> tradeAlreadyExecutedHandler(TradeAlreadyExecutedException tradeAlreadyExecutedException) {
        return JsonResponse.setError(Constant.TRADE_ALREADY_EXECUTED.name(), tradeAlreadyExecutedException.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = TradeAlertNotFoundException.class)
    public Map<String, List<Map<String, String>>> handleEntityNotFound(TradeAlertNotFoundException ex) {
        map = new HashMap<>();
        list = new ArrayList<>();
        errorDetailMap = new HashMap<>();
        errorDetailMap.put(Constant.CODE.toString(), "NOT_FOUND");
        errorDetailMap.put(Constant.MESSAGE.toString(), ex.getMessage());
        list.add(errorDetailMap);
        map.put(Constant.ERRORS.toString(), list);
        return map;
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(UserNotFoundException.class)
    public Map<String, List<Map<String, String>>> userNotFound(UserNotFoundException userNotFoundException) {
        return JsonResponse.setError(Constant.USER_NOT_FOUND.name(), userNotFoundException.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(RefreshNotSupportedException.class)
    public Map<String, List<Map<String, String>>> refreshNotSupported(RefreshNotSupportedException refreshNotSupportedException) {
        return JsonResponse.setError(Constant.REFRESH_NOT_SUPPORTED.name(), refreshNotSupportedException.getMessage());
    }


    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ParameterNotFoundException.class)
    public Map<String, List<Map<String, String>>> parameterNotFound(ParameterNotFoundException parameterNotFoundException) {
        return JsonResponse.setError(Constant.PARAMETER_NOT_FOUND.name(), parameterNotFoundException.getMessage());

    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(ListOfAlertNotFoundException.class)
    public Map<String, List<Map<String, String>>> listNotFound(ListOfAlertNotFoundException listOfAlertNotFoundException) {
        return JsonResponse.setError(Constant.LIST_NOT_FOUND.name(), listOfAlertNotFoundException.getMessage());

    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoClosedTradesException.class)
    public Map<String, List<Map<String, String>>> emptyClosedTrade(NoClosedTradesException closedTradeException) {
        return JsonResponse.setError(Constant.NO_CLOSED_TRADES.name(), closedTradeException.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = TradeDetailsNotFoundException.class)
    public Map<String, List<Map<String, String>>> handleEntityNotFound(TradeDetailsNotFoundException ex) {
        return JsonResponse.setError("TRADE_DETAILS_NOT_FOUND", ex.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = TickerNotFoundException.class)
    public Map<String, List<Map<String, String>>> handleTickerNotFound(TickerNotFoundException ex) {
        return JsonResponse.setError("TICKER_NOT_FOUND", ex.getMessage());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = TickerPriceNotFoundException.class)
    public Map<String, List<Map<String, String>>> handleTickerPriceNotFound(TickerPriceNotFoundException ex) {
        return JsonResponse.setError("PRICE_NOT_FOUND", ex.getMessage());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = QuantityMismatchException.class)
    public Map<String, List<Map<String, String>>> handleQuantityMismatch(QuantityMismatchException exception) {
        return JsonResponse.setError(Constant.QUANTITY_MISMATCH.name(), Constant.QUANTITY_MISMATCH.toString());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = NoHoldingException.class)
    public Map<String, List<Map<String, String>>> handleNoHoldingException(NoHoldingException exception) {
        return JsonResponse.setError(Constant.NO_HOLDINGS.name(), Constant.NO_HOLDINGS.toString());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoTradeAlertFoundException.class)
    public Map<String, List<Map<String, String>>> noTradeAlertFound(NoTradeAlertFoundException noTradeAlertFoundException) {
        return JsonResponse.setError(Constant.TRADE_ALERT_NOT_FOUND.name(), noTradeAlertFoundException.getMessage());
    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = ZeroQuantityException.class)
    public Map<String, List<Map<String, String>>> handleZeroQuantityException(ZeroQuantityException exception) {
        return JsonResponse.setError(Constant.ZERO_QUANTITY_EXCEPTION.name(), Constant.ZERO_QUANTITY_EXCEPTION.toString());
    }
}
