package com.sapient.controller;

import com.sapient.dto.*;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.service.ExecutedTradeService;
import com.sapient.service.TradeAlertService;
import com.sapient.service.TradeDetailsService;
import com.sapient.service.UserTradeAlertService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RestController
public class TradeController {

    @Autowired
    ExecutedTradeService executedTradeService;

    @Autowired
    TradeDetailsService tradeDetailsService;

    @Autowired
    UserTradeAlertService userTradeAlertService;

    @Autowired
    TradeAlertService tradeAlertService;

    @PostMapping("/trade/alert")
    public ResponseEntity<TradeAlert> setTradeAlert(@RequestBody TradeAlertDto tradeAlertDto)
    {
        log.info("alert received for ticker number: " + tradeAlertDto.getTickerNumber());
        var tradeAlert = tradeAlertService.handleTradeAlert(tradeAlertDto);

        return new ResponseEntity<>(tradeAlert,HttpStatus.OK);
    }

    @GetMapping("/dashboard/{userId}")
    public ResponseEntity<UserTradeInfoDto> getTradeInfo(@PathVariable("userId") BigInteger userId) {
        log.info("Dashboard Info Requested for " + userId);
        return new ResponseEntity<>(executedTradeService.findUserTradeInfo(userId), HttpStatus.OK);

    }

    @PostMapping("/trade-detail/execute")
    public ResponseEntity<TradeExecutionResponseDto> executeTradeDetail(@RequestBody UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, QuantityMismatchException, NoHoldingException,ZeroQuantityException {
        log.info("Trade Execution requested ");
        return new ResponseEntity<>(tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto), HttpStatus.OK);

    }



    @GetMapping("/trade-details/fetch")
    public ResponseEntity<Map<Object,Object>> fetchTradeDetails(@RequestParam(name = "userId") BigInteger userId, @RequestParam(name = "page") Integer page, @RequestParam(name = "limit") Integer limit) throws TradeDetailsNotFoundException {
        log.info("UserId for trade-service " + userId);
        Map<Object,Object> tradeDetails = tradeDetailsService.findTradeDetails(userId, page,limit);

        return new ResponseEntity<>(tradeDetails, HttpStatus.OK);

    }


    /**
     * This API is used to delete a trade alert.
     *
     * @param userId used to get user.
     * @param tradeAlertId used to get trade alert.
     * @return status code 204.
     */
    @CrossOrigin
    @DeleteMapping("/alert/{userId}/{tradeAlertId}")
    public ResponseEntity<HttpStatus> deleteTradeAlert(@PathVariable("userId") BigInteger userId, @PathVariable("tradeAlertId") UUID tradeAlertId) {
        log.info("Delete Trade Alert Requested By - " + userId);
        userTradeAlertService.deleteTradeAlert(userId,tradeAlertId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    /**
     * This API is used to get trade details & populate that details for manual buy.
     *
     * @param userId used to get user.
     * @param tickerNumber used to get ticker details.
     * @return status code 200.
     */
    @GetMapping("/trade-detail/{userId}/{tickerNumber}")
    public ResponseEntity<TradeDetailDto> addTradeDetail(@PathVariable("userId") BigInteger userId, @PathVariable("tickerNumber") int tickerNumber) throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        log.info("Get Trade Details For Manual Buy Requested By : "+ userId);
        return new ResponseEntity<>(tradeDetailsService.addTradeDetail(userId,tickerNumber),HttpStatus.OK);
    }

    @CrossOrigin
    @DeleteMapping("/trade-detail/delete/{tradeDetailId}")
    public ResponseEntity<HttpStatus> deleteTradeDetail(@PathVariable("tradeDetailId") UUID tradeDetailId) {
        log.info("Delete Trade Detail Requested By - " + tradeDetailId);
        tradeDetailsService.deleteTradeDetail(tradeDetailId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public String paramsMissing(MissingServletRequestParameterException ex) {
        String param = ex.getParameterName();
        var errors= new JSONObject();
        var errParams=new JSONObject();
        errParams.put("code",HttpStatus.BAD_REQUEST);
        errParams.put("message","Parameter "+param+ " is missing");
        var jsonArray=new JSONArray();
        jsonArray.put(errParams);

        errors.put("errors",jsonArray);

        return String.valueOf(errors);

    }

    @GetMapping("/trade-alert/{userId}")
    public ResponseEntity <List<UserTradeAlertDto>> getTradeAlertInfo(@PathVariable ("userId")BigInteger userId) throws UserNotFoundException, ListOfAlertNotFoundException, NoTradeAlertFoundException {
        log.info("List of Alert Requested for "+ userId);
        return new ResponseEntity<>(userTradeAlertService.findByAlert(userId), HttpStatus.OK);

    }

    @GetMapping(value = "/trade-alert")
    public ResponseEntity<String> exceptionUserId() throws ParameterNotFoundException {
        log.error("Inside alert exception Controller if userId parameter is not received from frontend");
        throw new ParameterNotFoundException("Parameter for userId not found");
    }

    @GetMapping(value = "/update/{userId}/{tradeDetailId}", produces = {"application/json"})
    public ResponseEntity<TradeDetailDto> updateTradeInfo(@PathVariable ("userId") BigInteger userId, @PathVariable ("tradeDetailId") UUID tradeDetailId) throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        log.info("Dashboard Update Requested for "+ tradeDetailId);
        return  new ResponseEntity<>(tradeDetailsService.updateTradeDetails(userId,tradeDetailId),HttpStatus.OK);

    }

    @PostMapping("/user/trade-details")
    public ResponseEntity<TradeDetail> handleTradeAlertToDetails(@RequestBody TradeAlertUserIdDto tradeAlertUserIdDto)
            throws TickerNotFoundException, TickerPriceNotFoundException {
        log.info("Trade alert to details controller");
        var tradeDetail = tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        return new ResponseEntity<>(tradeDetail, HttpStatus.OK);
    }
}
