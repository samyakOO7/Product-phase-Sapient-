package com.sapient.controller;

import com.sapient.dto.SellTradeDetailRequestDto;
import com.sapient.entity.TradeDetail;
import com.sapient.service.TradeDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class TradeDetailController {

    @Autowired
    TradeDetailsService tradeDetailsService;

    @PostMapping("trade-details/sell")
    public TradeDetail generateSellTradeDetail(@RequestBody SellTradeDetailRequestDto sellTradeDetailRequestDto){
        log.debug("Received request for generation of sell trade details for portfolio Id:"+sellTradeDetailRequestDto.getUserPortfolioId());
        return tradeDetailsService.generateSellTradeDetail(sellTradeDetailRequestDto.getUserPortfolioId());
    }
}
