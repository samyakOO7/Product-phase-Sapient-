package com.sapient.controller;

import com.sapient.exception.NoClosedTradesException;
import com.sapient.service.ExecutedTradeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.Map;

@RestController
@Slf4j
public class ExecutedTradeController {

    @Autowired
    ExecutedTradeService executedTradeService;

    @GetMapping("/closed-trades")
    public ResponseEntity<Map<Object, Object>> getAllClosedTrades(@RequestParam(name = "userId") BigInteger userId, @RequestParam(name = "page") Integer page, @RequestParam(name = "limit") Integer limit) throws NoClosedTradesException {
        log.info("Inside getAllClosedTrades() - ExecutedTradeController");
        return ResponseEntity.ok().body(executedTradeService.findAllClosed(userId, page, limit));
    }

}
