package com.sapient.exception;

public class ListOfAlertNotFoundException extends Exception{
    public ListOfAlertNotFoundException(String message)
    {
        super(message);
    }
}
