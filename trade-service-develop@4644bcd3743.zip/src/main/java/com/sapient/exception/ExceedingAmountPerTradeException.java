package com.sapient.exception;

import lombok.Generated;

@Generated
public class ExceedingAmountPerTradeException extends Exception{


    public ExceedingAmountPerTradeException(String message) {
        super(message);

    }

}
