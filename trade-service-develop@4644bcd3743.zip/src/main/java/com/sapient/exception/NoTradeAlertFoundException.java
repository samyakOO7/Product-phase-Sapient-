package com.sapient.exception;

public class NoTradeAlertFoundException extends Exception {

    public NoTradeAlertFoundException(String message) {
        super(message);
    }
}
