package com.sapient.exception;

public class UnableRefreshException extends RuntimeException {
}
