package com.sapient.exception;

public class ZeroQuantityException extends Exception{
    public ZeroQuantityException(String msg){
        super(msg);
    }
}
