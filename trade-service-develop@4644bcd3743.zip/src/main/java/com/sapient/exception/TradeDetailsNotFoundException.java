package com.sapient.exception;

public class TradeDetailsNotFoundException extends RuntimeException {
    public TradeDetailsNotFoundException(String message) {
        super(message);
    }
}
