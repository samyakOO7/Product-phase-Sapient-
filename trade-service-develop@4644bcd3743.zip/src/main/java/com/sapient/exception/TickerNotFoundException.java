package com.sapient.exception;

public class TickerNotFoundException  extends Exception{

    public TickerNotFoundException(String message) {
        super(message);
    }
}