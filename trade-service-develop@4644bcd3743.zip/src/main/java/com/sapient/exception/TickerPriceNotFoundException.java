package com.sapient.exception;

public class TickerPriceNotFoundException extends Exception{

    public TickerPriceNotFoundException(String message) {
        super(message);
    }
}