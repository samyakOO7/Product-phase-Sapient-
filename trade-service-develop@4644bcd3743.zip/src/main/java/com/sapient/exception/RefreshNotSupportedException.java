package com.sapient.exception;

public class RefreshNotSupportedException extends RuntimeException {
    public RefreshNotSupportedException(String message) {
        super(message);
    }
}
