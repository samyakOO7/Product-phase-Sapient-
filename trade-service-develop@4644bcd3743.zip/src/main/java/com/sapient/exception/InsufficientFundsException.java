package com.sapient.exception;

import lombok.Generated;

@Generated
public class InsufficientFundsException extends Exception{
    public InsufficientFundsException(String message) {
        super(message);
    }
}
