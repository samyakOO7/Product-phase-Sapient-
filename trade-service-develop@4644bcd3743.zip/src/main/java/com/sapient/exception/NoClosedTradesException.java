package com.sapient.exception;

public class NoClosedTradesException extends Exception{

    public NoClosedTradesException(String msg)
    {
        super(msg);
    }

}
