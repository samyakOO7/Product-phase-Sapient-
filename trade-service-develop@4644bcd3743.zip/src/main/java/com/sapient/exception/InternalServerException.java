package com.sapient.exception;

public class InternalServerException extends Exception {

    public InternalServerException(String message) {
        super(message);
    }
}