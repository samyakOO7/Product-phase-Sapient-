package com.sapient.exception;

import java.util.UUID;

public class TradeAlertNotFoundException extends RuntimeException {

    final UUID tradeAlertId;

    public TradeAlertNotFoundException(UUID tradeAlertId) {
        this.tradeAlertId = tradeAlertId;
    }
    @Override
    public String getMessage() {
        return "Trade Alert Not Found For : " + tradeAlertId;
    }
}



