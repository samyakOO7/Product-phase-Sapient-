package com.sapient.util;

import com.sapient.message.TradeAlertMessage;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Component
@Slf4j
public class KafkaClientUtilImpl implements KafkaClientUtil {

    @Autowired
    KafkaTemplate<String, TradeAlertMessage> template;

    String topicName = "user_trade_alerts";

    public void sendAlert(TradeAlertMessage alert) {
        log.debug("received request to send alert : {}", alert);
        ListenableFutureCallback<SendResult<String, TradeAlertMessage>> callback = new ListenableFutureCallback<>() {
            @Override
            @Generated
            public void onSuccess(SendResult<String, TradeAlertMessage> result) {
                log.info("Record sent successfully {}", result.getRecordMetadata().toString());
            }

            @Override
            @Generated
            public void onFailure(Throwable ex) {
                ProducerRecord<?, ?> producerRecord = ((KafkaProducerException) ex).getFailedProducerRecord();
                log.error("Failed to send the record " + producerRecord, ex);
            }
        };
        Message<TradeAlertMessage> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, topicName)
                .build();
        ListenableFuture<SendResult<String, TradeAlertMessage>> future = template.send(userMessage);
        future.addCallback(callback);
    }
}
