package com.sapient.util;

import lombok.Generated;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;

@Component
@Generated
public class CurrentTimeUtil {


    public Timestamp getCurrentTime(){
        return Timestamp.from(Instant.now());
    }

    public Calendar getCalendarInstance(){return Calendar.getInstance();}
}
