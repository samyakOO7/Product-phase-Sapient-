package com.sapient.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.constant.Constant;
import com.sapient.exception.NoHoldingException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.Generated;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Generated
public class UserServiceFeignErrorDecoder implements ErrorDecoder {
    private final ErrorDecoder errorDecoder = new Default();
    @Override
    public Exception decode(String methodKey, Response response) {
        Map<String, List<Map<Object,Object>>> message = null;
        try (var bodyIs = response.body().asInputStream()) {
            var mapper = new ObjectMapper();
            message = mapper.readValue(bodyIs, Map.class);
        } catch (IOException e) {
            return new Exception(e.getMessage());
        }
        if (response.status() == 404  && (Constant.valueOf((String)message.get("errors").get(0).get("code")) == Constant.PORTFOLIO_DETAIL_NOT_FOUND)){
                return new NoHoldingException();
        }
        return errorDecoder.decode(methodKey, response);
    }
}