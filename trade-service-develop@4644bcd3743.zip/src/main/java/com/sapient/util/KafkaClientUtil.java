package com.sapient.util;

import com.sapient.message.TradeAlertMessage;

public interface KafkaClientUtil {
    void sendAlert(TradeAlertMessage alert);
}
