package com.sapient.message;

import lombok.*;

@ToString
@NoArgsConstructor
@Setter
@Getter
@Generated
public class TradeAlertMessage {
    String email;
    String firstName;
    String url;
    String tickerSymbol;
    String tickerName;
    String direction;
    String timeframe;
    String confidenceScore;
    String timestamp;
}
