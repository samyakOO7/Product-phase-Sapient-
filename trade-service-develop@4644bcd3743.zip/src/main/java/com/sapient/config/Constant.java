package com.sapient.config;

public class Constant {
    private Constant() {
    }

    public static final String MESSAGE = "message";
    public static final String CODE = "code";
    public static final String ERRORS = "errors";
}
