package com.sapient.config;

import com.sapient.util.UserServiceFeignErrorDecoder;
import org.springframework.context.annotation.Bean;

public class UserServiceFeignErrorConfig {
    @Bean
    public UserServiceFeignErrorDecoder getErroDecoder()
    {
        return new UserServiceFeignErrorDecoder();
    }
}
