package com.sapient.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "trade_alerts" )
@AllArgsConstructor
@NoArgsConstructor
public class TradeAlert {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="trade_alert_id")
    private UUID tradeAlertId;

    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    @ManyToOne
    @JoinColumn(name="ticker_number")
    private Tickers ticker;

    @Column(name="timeframe")
    private Integer timeframe;

    @Column(name="trade_direction")
    private String tradeDirection;

    @Column(name="generation_time")
    private Timestamp generationTime;

    @Column(name="expiry_time")
    private Timestamp expiryTime;

    @Column(name="confidence")
    private Double confidence;

    @Column(name="ATR")
    private Double atr;

    @Override
    public String toString() {
        return "TradeAlert{" +
                "tradeAlertId=" + tradeAlertId +
                ", ticker=" + ticker +
                ", timeframe=" + timeframe +
                ", tradeDirection='" + tradeDirection + '\'' +
                ", generationTime=" + generationTime +
                ", expiryTime=" + expiryTime +
                ", confidence=" + confidence +
                ", atr=" + atr +
                '}';
    }
}
