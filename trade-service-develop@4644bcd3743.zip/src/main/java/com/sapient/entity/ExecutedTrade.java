package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.UUID;
@Entity
@Getter
@Setter
@Table(name = "executed_trades" )
@AllArgsConstructor
@NoArgsConstructor
public class ExecutedTrade {

    @Id
    @Column(name="executed_trades_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID executedTradesId;
    @Column(name="user_id")
    private BigInteger userId;

    @ManyToOne
    @JoinColumn(name="ticker_number")
    private Tickers ticker;

    @ManyToOne
    @JoinColumn(name="buy_trade_detail_id")
    private TradeDetail buyTradeDetail;

    @ManyToOne
    @JoinColumn(name="sell_trade_detail_id")
    private TradeDetail sellTradeDetail;

    @Column(name="timeframe")
    private Integer timeframe ;

    @Column(name="trade_opened_at")
    private Timestamp tradeOpenedAt;
    @Column(name="trade_closed_at")
    private Timestamp tradeClosedAt;
    @Column(name="gain")
    private Double gain;
    @Column(name="price_per_ticker")
    private Double pricePerTicker;
    @Column(name="sold_price_per_ticker")
    private Double soldPricePerTicker;

    @Override
    public String toString() {
        return "ExecutedTrade{" +
                "executedTradesId=" + executedTradesId +
                ", userId=" + userId +
                ", ticker=" + ticker +
                ", buyTradeDetail=" + buyTradeDetail +
                ", sellTradeDetail=" + sellTradeDetail +
                ", timeframe=" + timeframe +
                ", tradeOpenedAt=" + tradeOpenedAt +
                ", tradeClosedAt=" + tradeClosedAt +
                ", gain=" + gain +
                ", pricePerTicker=" + pricePerTicker +
                ", soldPricePerTicker=" + soldPricePerTicker +
                '}';
    }
}