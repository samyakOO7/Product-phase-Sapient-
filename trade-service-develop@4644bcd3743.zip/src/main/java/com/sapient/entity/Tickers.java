package com.sapient.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "tickers" )
@AllArgsConstructor
@NoArgsConstructor
public class Tickers {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ticker_number")
    private Integer  tickerNumber;

    @Column(name="ticker_name")
    private String tickerName;

    @Column(name="ticker_id")
    private String tickerId;

    @Column(name="ticker_type")
    private String tickerType;

    @Override
    public String toString() {
        return "Tickers{" +
                "tickerNumber=" + tickerNumber +
                ", tickerName='" + tickerName + '\'' +
                ", tickerId='" + tickerId + '\'' +
                ", tickerType='" + tickerType + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        var tickers = (Tickers) o;
        return Objects.equals(tickerNumber, tickers.tickerNumber) && Objects.equals(tickerName, tickers.tickerName) && Objects.equals(tickerId, tickers.tickerId) && Objects.equals(tickerType, tickers.tickerType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerNumber, tickerName, tickerId, tickerType);
    }
}
