package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.UUID;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserTradeAlertDto {
    private UUID tradeAlertId;
    private Integer tickerNumber;
    private Integer timeframe;
    private String tradeDirection;
    private Timestamp timestamp;
    private Double confidence;
    private String tickerName;

    @Override
    public String toString() {
        return "UserTradeAlertDto{" +
                "tradeAlertId=" + tradeAlertId +
                ", tickerNumber=" + tickerNumber +
                ", timeframe=" + timeframe +
                ", tradeDirection='" + tradeDirection + '\'' +
                ", timestamp=" + timestamp +
                ", confidence=" + confidence +
                ", tickerName='" + tickerName + '\'' +
                '}';
    }
}
