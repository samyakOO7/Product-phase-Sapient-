package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;


@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TradeAlertDto {
    private  Integer tickerNumber;

    private Integer timeframe;

    private String tradeDirection;

    private Timestamp generationTime;

    private Timestamp expiryTime;

    private Double confidence;

    private Double atr;
}
