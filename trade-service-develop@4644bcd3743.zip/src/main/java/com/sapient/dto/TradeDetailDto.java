package com.sapient.dto;

import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TradeDetailDto {

    private UUID tradeDetailId;


    private BigInteger userId;


    private Tickers ticker;


    private Integer timeframe ;


    private String tradeDirection;


    private Timestamp createdAt;


    private Double pricePerTicker;

    private Integer quantity;


    private Double totalCost;


    private Double stopLoss;


    private Double profitTarget;


    private String status;


    private TradeAlert tradeAlert;


    private Double gain;


    private Double riskToRewardRatio;

    @Override
    public String toString() {
        return "TradeDetailDto{" +
                "tradeDetailId=" + tradeDetailId +
                ", userId=" + userId +
                ", ticker=" + ticker +
                ", timeframe=" + timeframe +
                ", tradeDirection='" + tradeDirection + '\'' +
                ", createdAt=" + createdAt +
                ", pricePerTicker=" + pricePerTicker +
                ", quantity=" + quantity +
                ", totalCost=" + totalCost +
                ", stopLoss=" + stopLoss +
                ", profitTarget=" + profitTarget +
                ", status='" + status + '\'' +
                ", tradeAlert=" + tradeAlert +
                ", gain=" + gain +
                ", riskToRewardRatio=" + riskToRewardRatio +
                '}';
    }
}
