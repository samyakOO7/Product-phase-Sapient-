package com.sapient.dto;


import lombok.Data;
import lombok.Generated;

import java.math.BigInteger;

@Data
@Generated
public class SellTradeDetailRequestDto {
    BigInteger userPortfolioId;
}
