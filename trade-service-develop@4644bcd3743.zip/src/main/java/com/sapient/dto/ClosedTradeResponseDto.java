package com.sapient.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClosedTradeResponseDto {

    private String tickerId;
    private String tickerName;
    private Timestamp tradeOpenedAt;
    private Timestamp tradeClosedAt;
    private Double gain;
    private Double pricePerTicker;
    private Double soldPricePerTicker;
    private Integer quantity;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClosedTradeResponseDto that = (ClosedTradeResponseDto) o;
        return Objects.equals(tickerId, that.tickerId) && Objects.equals(tickerName, that.tickerName) && Objects.equals(tradeOpenedAt, that.tradeOpenedAt) && Objects.equals(tradeClosedAt, that.tradeClosedAt) && Objects.equals(gain, that.gain) && Objects.equals(pricePerTicker, that.pricePerTicker) && Objects.equals(soldPricePerTicker, that.soldPricePerTicker) && Objects.equals(quantity, that.quantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker, quantity);
    }
}
