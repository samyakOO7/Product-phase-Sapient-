package com.sapient.client;


import com.sapient.config.UserServiceFeignErrorConfig;
import com.sapient.dto.UserPortfolioDto;
import com.sapient.dto.UserPortfolioUpdateDto;
import com.sapient.dto.UserTradeStatsDto;
import com.sapient.dto.UserTradingDetailsDto;
import com.sapient.exception.NoHoldingException;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigInteger;
import java.util.List;



@FeignClient(url = "${user.service.feign.url}", name = "user-microservice",configuration = {UserServiceFeignErrorConfig.class})
public interface UserServiceFeignClient {

    @PostMapping("portfolio/update")
    ResponseEntity<Object> updateUserPortfolio(@RequestBody UserPortfolioUpdateDto userPortfolioUpdateDto);

    @GetMapping("user-stats/{userId}")
    ResponseEntity<UserTradeStatsDto> findUserTradeStats(@PathVariable("userId") BigInteger userId);

    @GetMapping("/watchlist/ticker/{tickerNumber}")
    List<BigInteger> getUserIdsFromTickerNumber(@PathVariable("tickerNumber") Integer tickerNumber);


    @GetMapping("/get-user-trading-details/{userId}")
    ResponseEntity<UserTradingDetailsDto> getTradingDetails(@PathVariable("userId") BigInteger userId);

    @GetMapping("/portfolio/total-amount/")
    double findTotalAmount(BigInteger userId);

    @GetMapping("/user-portfolio/{portfolio-id}")
    UserPortfolioDto getUserPortfolio(@PathVariable("portfolio-id") BigInteger portfolioId);

    @GetMapping("/user-portfolio/{user-id}/ticker/{ticker-number}")
    UserPortfolioDto getUserPortfolioByUserIdAndTickerNumber(@PathVariable("user-id") BigInteger userId,@PathVariable("ticker-number")Integer tickerNumber) throws NoHoldingException;
}
