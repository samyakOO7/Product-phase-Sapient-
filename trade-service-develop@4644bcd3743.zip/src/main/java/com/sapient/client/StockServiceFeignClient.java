package com.sapient.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.Map;

@FeignClient(url = "${stock.service.feign.url}", name = "stock-microservice")
public interface StockServiceFeignClient {
    @GetMapping("/{tickerId}")
    ResponseEntity<Map<String, BigDecimal>> getTickerPrice(@PathVariable String tickerId);

}
