package com.sapient.service;

import com.sapient.constant.TradeDetailStatus;
import com.sapient.dto.TradeAlertUserIdDto;
import com.sapient.dto.TradeDetailDto;
import com.sapient.dto.TradeExecutionResponseDto;
import com.sapient.dto.UserTradeDetailUpdateDto;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;

import java.math.BigInteger;
import java.util.Map;
import java.util.UUID;

public interface TradeDetailsService {
    Map<Object, Object> findTradeDetails(BigInteger userId, Integer page,Integer limit) throws TradeDetailsNotFoundException;

    void deleteTradeDetail(UUID tradeDetailId);

    TradeDetailDto updateTradeDetails(BigInteger userId, UUID tradeDetailId) throws TradeDetailsNotFoundException, TickerNotFoundException, UserNotFoundException, TickerPriceNotFoundException;

    TradeDetail tradeAlertToDetails(TradeAlertUserIdDto tradeAlertUserIdDto) throws TickerNotFoundException, TickerPriceNotFoundException;

    TradeExecutionResponseDto executeTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws ZeroQuantityException,TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, QuantityMismatchException, NoHoldingException;

    TradeDetailDto addTradeDetail(BigInteger userId, int tickerNumber) throws TickerNotFoundException, UserNotFoundException, TickerPriceNotFoundException;

     TradeDetail generateSellTradeDetail(BigInteger userPortfolioId);

     TradeDetailStatus executeSellTrade(TradeDetail tradeDetail) throws NoHoldingException,QuantityMismatchException;
}
