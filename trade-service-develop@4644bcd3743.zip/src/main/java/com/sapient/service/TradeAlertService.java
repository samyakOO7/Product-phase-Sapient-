package com.sapient.service;


import com.sapient.dto.TradeAlertDto;
import com.sapient.entity.TradeAlert;

public interface TradeAlertService {
    public TradeAlert handleTradeAlert(TradeAlertDto tradeAlertDto);

}
