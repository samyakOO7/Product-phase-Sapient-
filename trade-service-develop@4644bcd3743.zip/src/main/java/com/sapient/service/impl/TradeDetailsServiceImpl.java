package com.sapient.service.impl;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.constant.TradeDetailStatus;
import com.sapient.dto.*;
import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TickerRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.TradeDetailsService;
import com.sapient.util.CurrentTimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.aspectj.runtime.internal.Conversions.doubleValue;


@Slf4j
@Service
public class TradeDetailsServiceImpl implements TradeDetailsService {
    @Autowired
    TradeDetailRepository tradeDetailRepository;


    @Autowired
    ExecutedTradeRepository executedTradeRepository;


    @Autowired
    CurrentTimeUtil currentTimeUtil;



    @Value("${market-opening-time-hour}")
    Integer marketOpeningTimeHour;
    @Value("${market-closing-time-hour}")
    Integer marketClosingTimeHour;
    @Value("${market-opening-time-minute}")
    Integer marketOpeningTimeMinute;
    @Value("${market-closing-time-minute}")
    Integer marketClosingTimeMinute;
    PageRequest pageRequest;

    @Autowired
    UserServiceFeignClient userServiceFeignClient;

    @Autowired
    TickerRepository tickerRepository;
    @Autowired
    StockServiceFeignClient stockServiceFeignClient;

    @Autowired
    TradeAlertRepository tradeAlertRepository;


    @Override
    public Map<Object, Object> findTradeDetails(BigInteger userId, Integer page,Integer limit) throws TradeDetailsNotFoundException {
        pageRequest = PageRequest.of(page, limit, Sort.by("createdAt").descending());
        Map<Object, Object> tradeDetailsMap = new HashMap<>();
        List<TradeDetail> tradeDetails = tradeDetailRepository.findByUserId(userId, pageRequest);
        if (tradeDetails.isEmpty()) {
            log.error("Trade Detail Not Found For User : "+userId);
            throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
        }
        log.info("Trade Details Fetched For User : "+userId);
        Long countTotalEntries = tradeDetailRepository.countByUserId(userId);
        Integer pageCount = (int) (Math.ceil((double) countTotalEntries / limit));
        tradeDetailsMap.put("data", tradeDetails);
        tradeDetailsMap.put("totalPageCount", pageCount);
        log.info("Trade Details With Pagination Returned Successfully");
        return tradeDetailsMap;

    }

    @Override
    public void deleteTradeDetail(UUID tradeDetailId) {
        try {
            var tradeDetail = tradeDetailRepository.findByUserTradeDetail(tradeDetailId);
            if (tradeDetail == null) {
                throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
            }
            tradeDetailRepository.delete(tradeDetail);
            log.info("Trade Detail " + tradeDetailId + " Deleted Successfully");
        } catch (TradeDetailsNotFoundException exception) {
            log.error("Trade Detail Not Found Exception Occurred in deleteTradeDetail method inside TradeDetailsServiceImpl : { " + tradeDetailId + " }");
            throw exception;
        }
    }

    public ResponseEntity<Map<String, BigDecimal>> getCurrentTickerPrice(String tickerId) throws TickerPriceNotFoundException {
        try {
            ResponseEntity<Map<String, BigDecimal>> tickerResponse =stockServiceFeignClient.getTickerPrice(tickerId) ;
            log.info("Ticker details fetched");
            return tickerResponse;
        }
        catch (Exception e) {
            log.error("Unable to fetch ticker price");
            throw new TickerPriceNotFoundException(Constant.TICKER_PRICE_NOT_FOUND.toString());
        }

    }

    public UserTradingDetailsDto getUserDetails(BigInteger userId) throws UserNotFoundException {
        try {
            ResponseEntity<UserTradingDetailsDto> res = userServiceFeignClient.getTradingDetails(userId);
            log.info("User details fetched");
            return res.getBody();
        }
        catch (Exception exception){
            log.error("Unable to fetch user details");
            throw new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
        }

    }

    @Override
    public TradeDetailDto updateTradeDetails(BigInteger userId, UUID tradeDetailId) throws TickerNotFoundException, UserNotFoundException, TickerPriceNotFoundException {
        var modelMapper = new ModelMapper();
        Optional<TradeDetail> tradeDetail = tradeDetailRepository.findById(tradeDetailId);
        try{
            if(tradeDetail.isEmpty()){
                throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
            }

            log.info("Trade details fetched");
            var td = tradeDetail.get();
            validateRefreshForTradeDetail(td);
            UserTradingDetailsDto userDto = getUserDetails(userId);
            Double totalEquity = userDto.getTotalEquity();
            Double amountPerTrade = userDto.getAmountPerTrade();
            Integer tickerNumber = td.getTicker().getTickerNumber();
            Optional<Tickers> tickerDetails = tickerRepository.findById(tickerNumber);
            if (tickerDetails.isEmpty()) {
                log.error("No ticker found");
                throw new TickerNotFoundException(Constant.TICKER_NOT_FOUND.toString());
            }
            Tickers ticker = tickerDetails.get();
            String tickerId = ticker.getTickerId();
            ResponseEntity<Map<String, BigDecimal>> tickerResponse = getCurrentTickerPrice(tickerId);
            log.info("Ticker details fetched");
            BigDecimal tickerPrice = Objects.requireNonNull(tickerResponse.getBody()).get(Constant.PRICE_PER_STOCK.toString());
            if(td.getTradeDirection().equals("sell")){
                return refreshForSell(td,(tickerPrice).doubleValue());
            }
            else {
                double availableAmountPerTrade=totalEquity*amountPerTrade;
                if(availableAmountPerTrade<userDto.getTotalAmount()){
                    availableAmountPerTrade=userDto.getTotalAmount();
                }
                Integer quantity = BigDecimal.valueOf(availableAmountPerTrade).divide(BigDecimal.valueOf(100).multiply(tickerPrice), MathContext.DECIMAL128).intValue();
                if(quantity.equals(0)){
                    td.setStatus(TradeDetailStatus.INSUFFICIENT_FUNDS.toString());
                    quantity=td.getQuantity();
                }else{
                    td.setStatus(TradeDetailStatus.NO_ACTION.toString());
                }
                var createdAt = Timestamp.from(Instant.now());
                double totalCost = quantity * (tickerPrice).doubleValue();

                td.setQuantity(quantity);
                td.setPricePerTicker((tickerPrice).doubleValue());
                td.setCreatedAt(createdAt);
                td.setTotalCost(totalCost);
                tradeDetailRepository.save(td);
                log.info("Ticker details updated in the database");
                log.info("Returning trade details dto");
                return modelMapper.map(td, TradeDetailDto.class);
            }

        }
        catch (TradeDetailsNotFoundException exception){
            log.error("No trade details found with id: "+tradeDetailId);
            throw exception;
        }
        catch (RefreshNotSupportedException exception){
            log.error("Trade Details refresh not supported for  "+tradeDetailId);
            throw exception;
        }
        catch (TickerNotFoundException exception){
            log.error("Ticker unavailabble for the trade detail with id "+tradeDetailId);
            throw exception;
        }

    }
    public void validateRefreshForTradeDetail(TradeDetail detail){
        log.debug("validating trade details");
        if (detail.getStatus().equals("pending") || detail.getStatus().equals(Constant.EXECUTED.toString())){
            log.debug("Refresh operation not supported exception");
            throw new RefreshNotSupportedException(Constant.REFRESH_NOT_SUPPORTED.toString());
        }
    }

    public TradeDetailDto refreshForSell(TradeDetail detail,Double tickerPrice){
        var modelMapper = new ModelMapper();
        log.debug("refreshing for sell");
        try{
            log.debug("fetching user portfolio");
            var userPortfolioDto =  userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(detail.getUserId(), detail.getTicker().getTickerNumber());
            Double newGain = tickerPrice - userPortfolioDto.getAveragePrice();
            detail.setQuantity(userPortfolioDto.getQuantity());
            detail.setPricePerTicker(tickerPrice);
            detail.setGain(newGain);
            detail.setStatus(TradeDetailStatus.NO_ACTION.toString());
            detail.setCreatedAt(Timestamp.from(Instant.now()));
            detail.setTotalCost(tickerPrice * userPortfolioDto.getQuantity());
            log.debug("updating the trade details");
            tradeDetailRepository.save(detail);
            return modelMapper.map(detail, TradeDetailDto.class);

        } catch (NoHoldingException exception){
            log.debug("portfolio not found setting to status no holdings");
            detail.setStatus(TradeDetailStatus.NO_HOLDING_STATUS.toString());
            detail.setCreatedAt(Timestamp.from(Instant.now()));
            log.debug("saving trade details ");
            tradeDetailRepository.save(detail);
            var dto = modelMapper.map(detail, TradeDetailDto.class);
            dto.setTradeDetailId(detail.getTradeDetailId());
            dto.setStatus(TradeDetailStatus.NO_HOLDING_STATUS.toString());
            return dto;
        }

    }

    @Override
    public TradeDetailDto addTradeDetail(BigInteger userId, int tickerNumber) throws TickerNotFoundException, UserNotFoundException, TickerPriceNotFoundException {
        try {
            var modelMapper = new ModelMapper();
            var tradeDetail = new TradeDetail();
            Optional<Tickers> optionalTicker = tickerRepository.findById(tickerNumber);
            if (optionalTicker.isEmpty()) {
                log.error("Ticker Not Found For : " + tickerNumber);
                throw new TickerNotFoundException(Constant.TICKER_NOT_FOUND.toString());
            }
            Tickers ticker = optionalTicker.get();
            UserTradingDetailsDto userDto = getUserDetails(userId);
            log.info("User Details Fetched For : " + userId);
            Double totalAmount = userDto.getTotalAmount();
            Double amountPerTrade = userDto.getAmountPerTrade();
            ResponseEntity<Map<String, BigDecimal>> tickerResponse = getCurrentTickerPrice(ticker.getTickerId());
            BigDecimal tickerPrice = Objects.requireNonNull(tickerResponse.getBody()).get(Constant.PRICE_PER_STOCK.toString());
            BigDecimal quantity = ((BigDecimal.valueOf(totalAmount).multiply(BigDecimal.valueOf(amountPerTrade))).divide(BigDecimal.valueOf(100).multiply(tickerPrice), MathContext.DECIMAL128));
            double totalCost = quantity.intValue() * (tickerPrice).doubleValue();
            tradeDetail.setUserId(userId);
            tradeDetail.setTicker(ticker);
            tradeDetail.setTradeDirection("buy");
            tradeDetail.setTimeframe(1440);
            tradeDetail.setCreatedAt(Timestamp.from(Instant.now()));
            tradeDetail.setPricePerTicker(tickerPrice.doubleValue());
            tradeDetail.setQuantity(quantity.intValue());
            tradeDetail.setTotalCost(totalCost);
            tradeDetail.setStopLoss(userDto.getRiskPerTrade());
            tradeDetail.setProfitTarget(userDto.getRiskPerTrade());
            tradeDetail.setStatus(TradeDetailStatus.NO_ACTION.toString());
            tradeDetail.setRiskToRewardRatio(1.0);
            Optional<TradeDetail> buy = tradeDetailRepository.findFirstByUserIdAndTicker_TickerNumberAndTradeDirectionAndStatus(userId, tickerNumber, "buy", TradeDetailStatus.NO_ACTION.toString());
            buy.ifPresent(detail -> tradeDetail.setTradeDetailId(detail.getTradeDetailId()));
            tradeDetailRepository.save(tradeDetail);
            return modelMapper.map(tradeDetail, TradeDetailDto.class);
        } catch (TickerNotFoundException exception) {
            log.error("Ticker Not Found For : " + tickerNumber);
            throw exception;
        }
    }

    @Override
    public TradeDetail tradeAlertToDetails(TradeAlertUserIdDto tradeAlertUserIdDto) throws TickerNotFoundException, TickerPriceNotFoundException {
        BigInteger userId = tradeAlertUserIdDto.getUserId();
        var userTradingDetailsResponse = userServiceFeignClient.getTradingDetails(userId);
        if(userTradingDetailsResponse==null)
        {
            throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
        }
        var userTradingDetails=userTradingDetailsResponse.getBody();
        if(userTradingDetails==null)
        {
            throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
        }
        Double equity = userTradingDetails.getTotalEquity();
        Double amountPerTrade = userTradingDetails.getAmountPerTrade();
        Double riskPerTrade = userTradingDetails.getRiskPerTrade();
        Optional<TradeAlert> optTradeAlert = tradeAlertRepository.findById(tradeAlertUserIdDto.getTradeAlertId());
        if (optTradeAlert.isEmpty()) {
            throw new TradeAlertNotFoundException(tradeAlertUserIdDto.getTradeAlertId());
        }
        var tradeAlert = optTradeAlert.get();
        Integer timeframe = tradeAlert.getTimeframe();
        String tradeDirection = tradeAlert.getTradeDirection();
        Integer tickerNumber = tradeAlert.getTicker().getTickerNumber();
        Optional<Tickers> optTicker = tickerRepository.findById(tickerNumber);
        if (optTicker.isEmpty()) {
            throw new TickerNotFoundException(Constant.TICKER_NOT_FOUND.toString());
        }
        Tickers ticker = optTicker.get();
        String tickerId = ticker.getTickerId();
        ResponseEntity<Map<String, BigDecimal>> responseTickerPrice = stockServiceFeignClient.getTickerPrice(tickerId);
        if(responseTickerPrice==null)
        {
            throw new TickerPriceNotFoundException(Constant.TICKER_PRICE_NOT_FOUND.toString());
        }
        Map<String, BigDecimal> mapTickerPrice=responseTickerPrice.getBody();
        if( mapTickerPrice==null)
        {
            throw new TickerPriceNotFoundException(Constant.TICKER_PRICE_NOT_FOUND.toString());

        }
        BigDecimal tickerPrice=mapTickerPrice.get(Constant.PRICE_PER_STOCK.toString());
        Integer quantity = (int) Math.round((equity * amountPerTrade) / (100 * doubleValue(tickerPrice)));
        var createdAt = new Timestamp(System.currentTimeMillis());
        Double totalCost = doubleValue(tickerPrice) * quantity;
        Double stopLoss = riskPerTrade;
        Double profitTarget = tradeAlert.getAtr();
        var status = "no_action";
        Double gain = null;
        Double riskToRewardRatio = stopLoss / profitTarget;
        var tradeDetail = new TradeDetail(null, userId, ticker, timeframe, tradeDirection,
                createdAt, doubleValue(tickerPrice), quantity, totalCost, stopLoss, profitTarget, status, tradeAlert, gain, riskToRewardRatio);
        tradeDetailRepository.save(tradeDetail);
        return tradeDetail;
    }


    @Override
    public TradeDetail generateSellTradeDetail(BigInteger userPortfolioId) {
            //get the User Portfolio
            UserPortfolioDto userPortfolio = userServiceFeignClient.getUserPortfolio(userPortfolioId);
            log.debug("fetched user portfolio for id:" + userPortfolioId + "=" + userPortfolio);
            //get current price of the stock
            Map<String, BigDecimal> currentPrice = Objects.requireNonNull(stockServiceFeignClient.getTickerPrice(userPortfolio.getTicker().getTickerId()).getBody());
            //create trade details
            var tradeDetail = populateTradeDetailsSell(userPortfolio, currentPrice.get(Constant.PRICE_PER_STOCK.toString()));
            //save the trade detail in db and return to user
            //check if trade detail for same stock for same user has been already created and is in no action state
            Optional<TradeDetail> savedTradeDetail = tradeDetailRepository.findFirstByUserIdAndTicker_TickerNumberAndTradeDirectionAndStatus(tradeDetail.getUserId(), tradeDetail.getTicker().getTickerNumber(), tradeDetail.getTradeDirection(), tradeDetail.getStatus());
            //If trade detail already exist update
            if (!savedTradeDetail.isEmpty()) {
                tradeDetail.setTradeDetailId(savedTradeDetail.get().getTradeDetailId());
            }
            tradeDetailRepository.save(tradeDetail);
            log.debug("returning generated trade detail {}", tradeDetail);
            return tradeDetail;
    }

    protected TradeDetail populateTradeDetailsSell(UserPortfolioDto userPortfolio,BigDecimal currentPrice)
    {
        var tradeDetail=new TradeDetail();
        tradeDetail.setCreatedAt(currentTimeUtil.getCurrentTime());
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(userPortfolio.getQuantity());
        tradeDetail.setGain(currentPrice.doubleValue()-userPortfolio.getAveragePrice());
        tradeDetail.setPricePerTicker(currentPrice.doubleValue());
        tradeDetail.setStatus(TradeDetailStatus.NO_ACTION.toString());
        tradeDetail.setTicker(userPortfolio.getTicker());
        tradeDetail.setTotalCost(currentPrice.doubleValue()*userPortfolio.getQuantity());
        tradeDetail.setUserId(userPortfolio.getUserId());
        return tradeDetail;
    }

    public ExecutedTrade executeBuyTrade(TradeDetail userTradeDetail) throws ExceedingAmountPerTradeException, InsufficientFundsException {
        var userTradeDetailDto = Objects.requireNonNull(userServiceFeignClient.getTradingDetails(userTradeDetail.getUserId()).getBody());
        double amountPerTrade= (userTradeDetailDto.getTotalEquity()* userTradeDetailDto.getAmountPerTrade())/100;
        BigDecimal cmp=Objects.requireNonNull(stockServiceFeignClient.getTickerPrice(userTradeDetail.getTicker().getTickerId()).getBody()).get(Constant.PRICE_PER_STOCK.toString());
            log.info("stock price fetched");
            double totalCost= cmp.doubleValue()*userTradeDetail.getQuantity();
        userTradeDetail.setCreatedAt(Timestamp.from(Instant.now()));
        userTradeDetail.setPricePerTicker(cmp.doubleValue());
        userTradeDetail.setTotalCost(totalCost);
        if(totalCost> amountPerTrade){
            userTradeDetail.setStatus("insufficient_funds");
            tradeDetailRepository.save(userTradeDetail);
            log.error("exceeding amount per trade");
            throw new ExceedingAmountPerTradeException(Constant.EXCEEDING_AMOUNT_PER_TRADE.toString());
        }

        if(totalCost > userTradeDetailDto.getTotalAmount()){

            userTradeDetail.setStatus("insufficient_funds");
            tradeDetailRepository.save(userTradeDetail);
            log.error("Insufficient Funds");
            throw new InsufficientFundsException(Constant.INSUFFICIENT_FUNDS.toString());
        }

        Timestamp currentTime=currentTimeUtil.getCurrentTime();
        if(!canBeExecuted(currentTime)){
            userTradeDetail.setStatus("pending");
            log.info("pending status updated");
            tradeDetailRepository.save(userTradeDetail);
            log.info("trade details saved");
            return null;
        }
        else {

            var executedTrade = new ExecutedTrade();
            executedTrade.setTradeOpenedAt(Timestamp.from(Instant.now()));
            executedTrade.setBuyTradeDetail(userTradeDetail);
            executedTrade.setTimeframe(userTradeDetail.getTimeframe());
            executedTrade.setPricePerTicker(cmp.doubleValue());
            executedTrade.setUserId(userTradeDetail.getUserId());
            executedTrade.setTicker(userTradeDetail.getTicker());

            return executedTradeRepository.save(executedTrade);
        }

    }
    public boolean canBeExecuted(Timestamp currentTime){
        var calendar1= currentTimeUtil.getCalendarInstance();
        var calendar2=currentTimeUtil.getCalendarInstance();
        calendar1.set(Calendar.HOUR_OF_DAY,marketOpeningTimeHour);
        calendar1.set(Calendar.MINUTE,marketOpeningTimeMinute);
        calendar1.set(Calendar.SECOND,0);
        calendar1.set(Calendar.MILLISECOND,0);
        calendar2.set(Calendar.HOUR_OF_DAY,marketClosingTimeHour);
        calendar2.set(Calendar.MINUTE,marketClosingTimeMinute);
        calendar2.set(Calendar.SECOND,0);
        calendar2.set(Calendar.MILLISECOND,0);
        int day=currentTime.toLocalDateTime().getDayOfWeek().getValue();
        boolean isPossible;
        if(currentTime.after(Timestamp.from(calendar2.toInstant())) ||
                currentTime.before(Timestamp.from(calendar1.toInstant()))||day==6 || day==7)
            isPossible=false;
        else
            isPossible=true;
        return isPossible;
    }
    @Override
    public TradeDetailStatus executeSellTrade(TradeDetail tradeDetail) throws QuantityMismatchException,NoHoldingException {
        try {
            //get user portfolio dto
            var userPortfolioDto = userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(tradeDetail.getUserId(), tradeDetail.getTicker().getTickerNumber());
            if(tradeDetail.getStatus().equals(TradeDetailStatus.QUANTITY_MISMATCH_STATUS.toString())){
                tradeDetail.setQuantity(userPortfolioDto.getQuantity());
            }
            else{
                if(!tradeDetail.getQuantity().equals(userPortfolioDto.getQuantity())){
                    tradeDetail.setStatus(TradeDetailStatus.QUANTITY_MISMATCH_STATUS.toString());
                    log.debug("Quantity mismatch for trade details {}",tradeDetail);
                    throw new QuantityMismatchException();
                }
            }
            tradeDetail.setStatus(TradeDetailStatus.PENDING_STATUS.toString());
            //get current price
            Map<String, BigDecimal> stockQuote= Objects.requireNonNull(stockServiceFeignClient.getTickerPrice(tradeDetail.getTicker().getTickerId()).getBody());
            log.debug("fetched price for stock {} +result:{}" ,tradeDetail.getTicker(),stockQuote);
            var currentPrice=stockQuote.get(Constant.PRICE_PER_STOCK.toString()).doubleValue();
            //update trade detail
            tradeDetail.setPricePerTicker(currentPrice);
            tradeDetail.setTotalCost(tradeDetail.getQuantity()*currentPrice);
            tradeDetail.setGain(currentPrice-userPortfolioDto.getAveragePrice());
            //if time within market hour execute it, set all open trades for that ticker for user closed
            Timestamp currentTime=currentTimeUtil.getCurrentTime();
            if(canBeExecuted(currentTime)){
                //in market hour execute it
                setClosedTrade(tradeDetail,currentTime);
                tradeDetail.setStatus(TradeDetailStatus.EXECUTED_STATUS.toString());
                //update the user portfolio
                var userPortfolioUpdateDto =setUserPortfolioUpdateDto(tradeDetail);
                userServiceFeignClient.updateUserPortfolio(userPortfolioUpdateDto);
                log.debug("trade executed and user portfolio updated for trade details {}",tradeDetail);
                return TradeDetailStatus.EXECUTED_STATUS;
            }
            return TradeDetailStatus.PENDING_STATUS;
        }
        catch(NoHoldingException e){
            tradeDetail.setStatus(TradeDetailStatus.NO_HOLDING_STATUS.toString());
            log.debug("The trade details {} has no holding exception",tradeDetail);
            throw new NoHoldingException();
        }
        finally {
            tradeDetailRepository.save(tradeDetail);
        }
    }

    public UserPortfolioUpdateDto setUserPortfolioUpdateDto(TradeDetail tradeDetail)
    {
        var userPortfolioUpdateDto=new UserPortfolioUpdateDto();
        userPortfolioUpdateDto.setUserId(tradeDetail.getUserId());
        userPortfolioUpdateDto.setQuantity(tradeDetail.getQuantity());
        userPortfolioUpdateDto.setPrice(tradeDetail.getPricePerTicker());
        userPortfolioUpdateDto.setTickerNumber(tradeDetail.getTicker().getTickerNumber());
        userPortfolioUpdateDto.setType(tradeDetail.getTradeDirection());
        return  userPortfolioUpdateDto;
    }
    public void setClosedTrade(TradeDetail tradeDetail,Timestamp currentTime){
        List<ExecutedTrade> openTradesForUser=executedTradeRepository. findByUserIdAndTickerAndTradeClosedAtIsNull(tradeDetail.getUserId(),tradeDetail.getTicker());
        for(var trade:openTradesForUser){
            trade.setSellTradeDetail(tradeDetail);
            trade.setTradeClosedAt(currentTime);
            trade.setSoldPricePerTicker(tradeDetail.getPricePerTicker());
            trade.setGain(trade.getSoldPricePerTicker()- trade.getPricePerTicker());
        }
        log.debug("Updated the closed trades trades for the trade detail {} at time {}",tradeDetail,currentTime);
        executedTradeRepository.saveAll(openTradesForUser);
    }
    @Override
    public TradeExecutionResponseDto executeTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws ZeroQuantityException,TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, QuantityMismatchException, NoHoldingException {
        var userTradeDetail=checkTradeDetail(userTradeDetailUpdateDto);

        if(userTradeDetail.getTradeDirection().equals("buy")){
            ExecutedTrade executedBuyTrade=executeBuyTrade(userTradeDetail);
            UUID tradeDetailId=userTradeDetail.getTradeDetailId();
            var userTradeDetailUpdated=tradeDetailRepository.getById(tradeDetailId);
            if(executedBuyTrade!=null){
                userTradeDetailUpdated.setStatus(Constant.EXECUTED.toString());
                userTradeDetailUpdated.setPricePerTicker(executedBuyTrade.getPricePerTicker());
                userTradeDetailUpdated.setTotalCost(executedBuyTrade.getPricePerTicker()* userTradeDetail.getQuantity());
                tradeDetailRepository.save(userTradeDetailUpdated);
                log.info("trade details updated after execution");

                var userPortfolioUpdateDto=new UserPortfolioUpdateDto();
                userPortfolioUpdateDto.setUserId(userTradeDetailUpdated.getUserId());
                userPortfolioUpdateDto.setQuantity(userTradeDetailUpdated.getQuantity());
                userPortfolioUpdateDto.setTickerNumber(userTradeDetailUpdated.getTicker().getTickerNumber());
                userPortfolioUpdateDto.setPrice(userTradeDetailUpdated.getPricePerTicker());
                userPortfolioUpdateDto.setStopLoss(userTradeDetailUpdated.getStopLoss());
                userPortfolioUpdateDto.setProfitTarget(userTradeDetailUpdated.getProfitTarget());
                userPortfolioUpdateDto.setType("buy");

                userServiceFeignClient.updateUserPortfolio(userPortfolioUpdateDto);
                log.info("user portfolio data updated");
                return new TradeExecutionResponseDto(userTradeDetailUpdated.getStatus());
            }
            return new TradeExecutionResponseDto(userTradeDetailUpdated.getStatus());
        }
        else{
            TradeDetailStatus status=executeSellTrade(userTradeDetail);
            if(status==TradeDetailStatus.PENDING_STATUS)
                return new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString());
            else
                return new TradeExecutionResponseDto(Constant.EXECUTED_MESSAGE.toString());
        }


    }




    public  TradeDetail checkTradeDetail(UserTradeDetailUpdateDto userTradeDetailUpdateDto) throws ZeroQuantityException,TradeDetailNotFoundException, TradeAlreadyExecutedException {

        Optional<TradeDetail> tradeDetail = tradeDetailRepository.findById(userTradeDetailUpdateDto.getTradeDetailId());
        if (tradeDetail.isEmpty()) {
            log.error("trade detail not found");
            throw new TradeDetailNotFoundException(userTradeDetailUpdateDto.getTradeDetailId().toString() + Constant.TRADE_DETAIL_NOT_FOUND.toString());
        }
        var userTradeDetail=tradeDetail.get();
        log.info("trade detail fetched");
        if(userTradeDetail.getStatus().equals(Constant.EXECUTED.toString())){
            log.error("trade is already executed");
            throw new TradeAlreadyExecutedException(Constant.TRADE_ALREADY_EXECUTED.toString());
        }
        userTradeDetail.setProfitTarget(userTradeDetailUpdateDto.getProfitTarget());
        userTradeDetail.setStopLoss(userTradeDetailUpdateDto.getStopLoss());
        if(userTradeDetail.getProfitTarget()!=null && userTradeDetail.getStopLoss()!=null)
            userTradeDetail.setRiskToRewardRatio(userTradeDetail.getStopLoss()/ userTradeDetail.getProfitTarget());
        if(userTradeDetailUpdateDto.getQuantity()!=null) {
            userTradeDetail.setQuantity(userTradeDetailUpdateDto.getQuantity());
        }
        if(userTradeDetail.getQuantity()==0){
            log.debug("trying to execute 0 quantity for",tradeDetail);
            throw new ZeroQuantityException(Constant.ZERO_QUANTITY_EXCEPTION.toString());
        }
        tradeDetailRepository.save(userTradeDetail);
        return userTradeDetail;
    }

}
