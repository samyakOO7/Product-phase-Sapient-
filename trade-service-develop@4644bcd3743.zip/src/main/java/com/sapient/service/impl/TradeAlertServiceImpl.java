package com.sapient.service.impl;

import com.sapient.client.AuthServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.dto.TradeAlertDto;
import com.sapient.dto.TradeAlertUserIdDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.UserTradeAlert;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.exception.TickerPriceNotFoundException;
import com.sapient.message.TradeAlertMessage;
import com.sapient.repository.TickerRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.repository.UserTradeAlertRepository;
import com.sapient.service.TradeAlertService;
import com.sapient.service.TradeDetailsService;
import com.sapient.util.KafkaClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.function.Predicate;


@Service
@Slf4j
public class TradeAlertServiceImpl implements TradeAlertService {

    @Autowired
    TradeAlertRepository tradeAlertRepository;

    @Autowired
    KafkaClientUtil kafkaClientUtil;

    @Autowired
    UserServiceFeignClient userServiceFeignClient;

    @Autowired
    AuthServiceFeignClient authServiceFeignClient;

    @Autowired
    UserTradeAlertRepository userTradeAlertRepository;

    @Autowired
    TickerRepository tickerRepository;

    @Autowired
    TradeDetailsService tradeDetailsService;

    @Autowired
    TradeDetailRepository tradeDetailRepository;

    @Override
    public TradeAlert handleTradeAlert(TradeAlertDto tradeAlertDto) {
        log.info("Trade alert post request recieved {}", tradeAlertDto);
        var modelMapper = new ModelMapper();
        var tradeAlert = modelMapper.map(tradeAlertDto,TradeAlert.class);
        log.info("Trade alert ticker number {}", tradeAlert);
        tradeAlert.setTicker(tickerRepository.getById(tradeAlertDto.getTickerNumber()));
        var savedTradeAlert = tradeAlertRepository.save(tradeAlert);
        List<BigInteger> userIds = listOfUserIdsFromTickerNumber(tradeAlertDto.getTickerNumber());
        Predicate<UserTradeAlert> checkConfidence = userTradeAlert1->(userTradeAlert1.getTradeAlert().getConfidence() >= 90.00);
        log.info("Trade alert received userIds from ticker number {}",tradeAlertDto.getTickerNumber());
        userIds.forEach(userId -> {
            log.info("Trade alert sending email alert to  {}", userId);
            var userTradeAlert = saveInUserTradeAlert(savedTradeAlert,userId);
            placeMessageInKafka(userTradeAlert);
            if(checkConfidence.test(userTradeAlert)) {
                log.info("Trade alert confidence greater than 90 {} ",userTradeAlert);
                var tradeAlertUserIdDto = new TradeAlertUserIdDto(userId, userTradeAlert.getTradeAlert().getTradeAlertId());
                try {
                    var tradeDetail = tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
                    tradeDetailRepository.setTradeStatus(tradeDetail.getTradeDetailId());
                } catch (TickerNotFoundException | TickerPriceNotFoundException e) {
                    log.error("Exception in handleTradeAlert() : ",e);
                }
            }

        });

        return savedTradeAlert;
    }

    public List<BigInteger> listOfUserIdsFromTickerNumber(Integer tickerNumber) {
        log.info("Call user service feign client");
         return userServiceFeignClient.getUserIdsFromTickerNumber(tickerNumber);

    }

    public UserTradeAlert saveInUserTradeAlert(TradeAlert tradeAlert, BigInteger userId) {
        var userTradeAlert = new UserTradeAlert();
        userTradeAlert.setTradeAlert(tradeAlert);
        userTradeAlert.setUserId(userId);
        return userTradeAlertRepository.save(userTradeAlert);
    }

    public void placeMessageInKafka(UserTradeAlert userTradeAlert) {
        var tradeAlert = userTradeAlert.getTradeAlert();
        ViewUserDto userDto = authServiceFeignClient.getUserEmailAndName(userTradeAlert.getUserId());
        var msg  = new TradeAlertMessage();
        msg.setEmail(userDto.getEmail());
        msg.setFirstName(userDto.getUserName());
        msg.setUrl("https://www.tradezy.org/alerts");
        msg.setTickerName(tradeAlert.getTicker().getTickerName());
        msg.setTimeframe(tradeAlert.getTimeframe().toString());
        msg.setDirection(tradeAlert.getTradeDirection());
        msg.setTickerSymbol(tradeAlert.getTicker().getTickerId());
        msg.setConfidenceScore(tradeAlert.getConfidence().toString());
        msg.setTimestamp(tradeAlert.getGenerationTime().toString());

        kafkaClientUtil.sendAlert(msg);


    }

}
