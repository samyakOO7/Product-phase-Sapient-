package com.sapient.service.impl;

import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.dto.ClosedTradeResponseDto;
import com.sapient.dto.UserTradeInfoDto;
import com.sapient.entity.ExecutedTrade;
import com.sapient.exception.NoClosedTradesException;
import com.sapient.exception.TradeDetailsNotFoundException;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.ExecutedTradeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ExecutedTradeServiceImpl implements ExecutedTradeService {

    @Autowired
    ExecutedTradeRepository executedTradesRepository;

    @Autowired
    TradeDetailRepository tradeDetailRepository;

    @Autowired
    TradeAlertRepository tradeAlertRepository;

    @Autowired
    UserServiceFeignClient userServiceFeignClient;



    @Override
    public UserTradeInfoDto findUserTradeInfo(BigInteger userId) {
        var userTradeInfoDto=new UserTradeInfoDto();

        userTradeInfoDto.setOpenTrades(executedTradesRepository.findOpenTrades(userId));
        userTradeInfoDto.setClosedTrades(executedTradesRepository.findClosedTrades(userId));
        userTradeInfoDto.setAlertsConvertedToTrades(tradeDetailRepository.findTradeConverted(userId));
        userTradeInfoDto.setTradeAlertsGenerated(tradeAlertRepository.findAllAlertByMonth(userId));

        var userTradeStatsDto=userServiceFeignClient.findUserTradeStats(userId).getBody();
        if(userTradeStatsDto==null)
        {
            throw new TradeDetailsNotFoundException(Constant.TRADE_DETAILS_NOT_FOUND.toString());
        }
        userTradeInfoDto.setEquity(userTradeStatsDto.getTotalEquity());
        userTradeInfoDto.setLosingTrades(userTradeStatsDto.getLoosing());
        userTradeInfoDto.setWinningTrades(userTradeStatsDto.getWinning());
        userTradeInfoDto.setGain(userTradeStatsDto.getGain());

        log.info("Dashboard Details Sent to Controller");
        return userTradeInfoDto;
    }

    @Override
    public Map<Object,Object> findAllClosed(BigInteger userId, Integer page, Integer limit) throws NoClosedTradesException {
        var pageRequest = PageRequest.of(page, limit);
        List<ExecutedTrade> allClosedTrades = executedTradesRepository.findAllClosedTrades(userId, pageRequest);

        if(allClosedTrades.isEmpty())
        {
            log.error(Constant.NO_CLOSED_TRADES.toString(), " - findAllClosedTrades()");
            log.info("No closed trades for the given user id " + userId + " - findAllClosedTrades()");
            throw new NoClosedTradesException(Constant.NO_CLOSED_TRADES.toString());
        }

        List<ClosedTradeResponseDto> closedTrades = new ArrayList<>();
        for (ExecutedTrade closed : allClosedTrades) {
                    var quantity =closed.getBuyTradeDetail().getQuantity();
                    var closedTradeResponseDto = new ClosedTradeResponseDto(
                    closed.getTicker().getTickerId(), closed.getTicker().getTickerName(),
                    closed.getTradeOpenedAt(), closed.getTradeClosedAt(), closed.getGain()*quantity,
                    closed.getPricePerTicker(), closed.getSoldPricePerTicker(),quantity
            );
            closedTrades.add(closedTradeResponseDto);
        }

        Long countTotalEntries = executedTradesRepository.countOfClosedTrades(userId);
        Integer pageCount = (int) (Math.ceil((double) countTotalEntries / limit));

        Map<Object,Object> response = new HashMap<>();
        response.put("closedTrades", closedTrades);
        response.put("pageCount",pageCount);

        return response;

    }



}
