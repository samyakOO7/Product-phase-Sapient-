package com.sapient.service.impl;

import com.sapient.constant.Constant;
import com.sapient.dto.UserTradeAlertDto;
import com.sapient.entity.UserTradeAlert;
import com.sapient.exception.ListOfAlertNotFoundException;
import com.sapient.exception.NoTradeAlertFoundException;
import com.sapient.exception.TradeAlertNotFoundException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.repository.UserTradeAlertRepository;
import com.sapient.service.UserTradeAlertService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
public class UserTradeAlertServiceImpl implements UserTradeAlertService {
    @Autowired
    UserTradeAlertRepository userTradeAlertRepository;

    @Override
    public void deleteTradeAlert(BigInteger userId, UUID tradeAlertId) {
        try {
            var userTradeAlert = userTradeAlertRepository.findUserTradeAlert(userId, tradeAlertId);
            if (userTradeAlert == null)
                throw new TradeAlertNotFoundException(tradeAlertId);
            userTradeAlertRepository.delete(userTradeAlert);
            log.info("Trade Alert " + tradeAlertId + " Deleted Successfully");
        } catch (TradeAlertNotFoundException exception) {
            log.error("Trade Alert Not Found Exception Occurred : { " + tradeAlertId + " }");
            throw exception;
        }
    }

    @Override
    public List<UserTradeAlertDto> findByAlert(BigInteger userId) throws UserNotFoundException, ListOfAlertNotFoundException, NoTradeAlertFoundException {
        List<UserTradeAlert> userTradeAlert = userTradeAlertRepository.getUserTradeAlert(userId);
        List<UserTradeAlertDto> dto = new ArrayList<>();
        if(userTradeAlert.isEmpty()) {
            log.debug(Constant.TRADE_ALERT_NOT_FOUND + "for {} ", userId);
            log.error(Constant.TRADE_ALERT_NOT_FOUND + " - from Trade service ");
            throw new NoTradeAlertFoundException(Constant.TRADE_ALERT_NOT_FOUND.toString()); }

        userTradeAlert.forEach(userTradeAlert1 -> {
            Timestamp expired = userTradeAlert1.getTradeAlert().getExpiryTime();
            var currentTimestamp=Timestamp.from(Instant.now());
            if (currentTimestamp.compareTo(expired) < 0) {

                var tradeAlertDto = new UserTradeAlertDto();
                tradeAlertDto.setTradeAlertId(userTradeAlert1.getTradeAlert().getTradeAlertId());
                tradeAlertDto.setTickerNumber(userTradeAlert1.getTradeAlert().getTicker().getTickerNumber());
                tradeAlertDto.setTickerName(userTradeAlert1.getTradeAlert().getTicker().getTickerName());
                tradeAlertDto.setTradeDirection(userTradeAlert1.getTradeAlert().getTradeDirection());
                tradeAlertDto.setConfidence(userTradeAlert1.getTradeAlert().getConfidence());
                tradeAlertDto.setTimestamp(userTradeAlert1.getTradeAlert().getGenerationTime());
                tradeAlertDto.setTimeframe(userTradeAlert1.getTradeAlert().getTimeframe());

                dto.add(tradeAlertDto);

            }
        });
        if(dto.isEmpty()) {

            throw new ListOfAlertNotFoundException(Constant.LIST_NOT_FOUND.toString());
        }


        return dto;
    }
}
