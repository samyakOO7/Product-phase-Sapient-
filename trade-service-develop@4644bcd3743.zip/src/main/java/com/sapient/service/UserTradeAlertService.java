package com.sapient.service;

import com.sapient.dto.UserTradeAlertDto;
import com.sapient.exception.ListOfAlertNotFoundException;
import com.sapient.exception.NoTradeAlertFoundException;
import com.sapient.exception.UserNotFoundException;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface UserTradeAlertService {
    void deleteTradeAlert(BigInteger userId, UUID tradeAlertId);
    List<UserTradeAlertDto> findByAlert (BigInteger userId) throws UserNotFoundException, ListOfAlertNotFoundException, NoTradeAlertFoundException;
}
