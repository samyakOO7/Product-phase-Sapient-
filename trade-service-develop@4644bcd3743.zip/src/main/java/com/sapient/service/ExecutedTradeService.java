package com.sapient.service;

import com.sapient.dto.UserTradeInfoDto;
import com.sapient.exception.NoClosedTradesException;

import java.math.BigInteger;
import java.util.Map;

public interface ExecutedTradeService {

    UserTradeInfoDto findUserTradeInfo(BigInteger userId);

    Map<Object, Object> findAllClosed(BigInteger userId, Integer page, Integer limit) throws NoClosedTradesException;



}
