package com.sapient.controller;

import com.sapient.entity.TradeDetail;
import com.sapient.service.TradeDetailsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TradeDetailController.class)
@WebMvcTest(TradeDetailController.class)
class TradeDetailControllerTest {

    @Autowired
    MockMvc mvc;

    @MockBean
    TradeDetailsService tradeDetailsService;

    @Test
    void generateSellTradeDetail() throws Exception {
        Mockito.when(tradeDetailsService.generateSellTradeDetail(Mockito.any())).thenReturn(new TradeDetail());
        mvc.perform(post(("/trade-details/sell"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"userPortfolioId\":\"%s\"}","64249")))
                .andExpect(status().isOk());
    }

}