package com.sapient.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.dto.ClosedTradeResponseDto;
import com.sapient.service.ExecutedTradeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ContextConfiguration(classes = {ExecutedTradeController.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(ExecutedTradeController.class)
class ExecutedTradeControllerTest {

    @MockBean
    ExecutedTradeService executedTradeService;

    ObjectMapper objectMapper = new ObjectMapper();

    ObjectWriter objectWriter = objectMapper.writer();

    @Autowired
    private MockMvc mockMvc;



    @Test
    void getAllClosedTrades() throws Exception {
        BigInteger userId = BigInteger.ONE;
        int page = 0;
        int limit = 7;
        final List<ClosedTradeResponseDto> closedTradeResponseDtos = new ArrayList<ClosedTradeResponseDto>() {
            {
                add(new ClosedTradeResponseDto("INFY","Infosys",new Timestamp(1234568),new Timestamp(1234578),100.0,50.0,60.0,10));
                add(new ClosedTradeResponseDto("TATA","Tata",new Timestamp(1234548),new Timestamp(1234588),-50.0,50.0,40.0,10));
            }
        };

        Map<Object,Object> expectedResult = new HashMap<>();
        expectedResult.put("closedTrades", closedTradeResponseDtos);
        expectedResult.put("pageCount",2);
        when(executedTradeService.findAllClosed(userId, page, limit)).thenReturn(expectedResult);
        String responseJson = objectWriter.writeValueAsString(expectedResult);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/closed-trades")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("userId", String.valueOf(userId))
                        .param("page",String.valueOf(page))
                        .param("limit",String.valueOf(limit))
                        .content(responseJson))
                .andExpect(status().isOk());
    }
}