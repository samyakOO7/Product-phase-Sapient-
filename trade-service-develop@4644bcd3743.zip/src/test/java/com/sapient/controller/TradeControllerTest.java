package com.sapient.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sapient.advice.TradeAdvice;
import com.sapient.constant.Constant;
import com.sapient.dto.*;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.service.ExecutedTradeService;
import com.sapient.service.TradeAlertService;
import com.sapient.service.TradeDetailsService;
import com.sapient.service.UserTradeAlertService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {TradeController.class, TradeAdvice.class})
@WebMvcTest(TradeController.class)
class TradeControllerTest {

    @Autowired
    private MockMvc mockMvc;



    @MockBean
    ExecutedTradeService executedTradesService;

    @MockBean
    TradeDetailsService tradeDetailsService;

    @MockBean
    TradeAlertService tradeAlertService;

    @MockBean
    UserTradeAlertService userTradeAlertService;

    ObjectMapper objectMapper = new ObjectMapper();

    ObjectWriter objectWriter = objectMapper.writer();

    ObjectReader objectReader = objectMapper.reader();

    static UserTradeInfoDto userTradeInfoDto;
    static UserTradeAlertDto userTradeAlertDto;
    static TradeDetailDto tradeDetailDto;
    static Tickers tickers;


    @Autowired
    TradeController tradeController;

    @BeforeAll
    static void setUp() {
        userTradeInfoDto = new UserTradeInfoDto(1, 1, 1, 1, 1, 50, 1, 1000.0);
        Timestamp timestamp = Timestamp.from(Instant.now());
        userTradeAlertDto = new UserTradeAlertDto(UUID.randomUUID(),1,1,"buy",timestamp,80.0,"stock");
        tickers = new Tickers(1,"Infosys","INFY","stock");
        tradeDetailDto = new TradeDetailDto(UUID.randomUUID(), BigInteger.ONE, tickers, 1, "Buy", Timestamp.from(Instant.now()), 10.0, 1, 10.0, 2.0, 2.0, "Pending", new TradeAlert(UUID.randomUUID(),tickers,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

    }

    @Test
    void getTradeInfo() throws Exception {
        String responseJson = objectWriter.writeValueAsString(userTradeInfoDto);
        when(executedTradesService.findUserTradeInfo(BigInteger.valueOf(1))).thenReturn(userTradeInfoDto);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/dashboard/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content()
                        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(content().json(responseJson));

    }

    @Test
    void executeTradeDetail() throws Exception {
        UserTradeDetailUpdateDto userTradeDetailUpdateDto = new UserTradeDetailUpdateDto();
        TradeExecutionResponseDto tradeExecutionResponseDto = new TradeExecutionResponseDto();
        String responseJson = objectWriter.writeValueAsString(tradeExecutionResponseDto);
        when(tradeDetailsService.executeTradeDetail(any(UserTradeDetailUpdateDto.class))).thenReturn(tradeExecutionResponseDto);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/trade-detail/execute")
                        .content(objectWriter.writeValueAsString(userTradeDetailUpdateDto))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(content().json(responseJson));


    }


    @Test
    void setTradeAlert() throws Exception {
        TradeAlertDto tradeAlertDto = new TradeAlertDto(1,1440, "buy", new Timestamp(12345678), new Timestamp(12345678),90.00,110.00);
        TradeAlert tradeAlert = new TradeAlert(UUID.randomUUID(),new Tickers(1,"tesla","TES","stock"),1440, "buy", Timestamp.valueOf("2007-09-23 10:10:10.0"), Timestamp.valueOf("2007-09-23 10:10:10.0"), 90.00,110.00 );
        String response = objectWriter.writeValueAsString(tradeAlertDto);
        when(tradeAlertService.handleTradeAlert(any())).thenReturn(tradeAlert);
        MvcResult mvcResult = mockMvc.perform(
            MockMvcRequestBuilders
                    .post("/trade/alert")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(response)
        ).andReturn();

        assertEquals(200,mvcResult.getResponse().getStatus());
    }

    @Test
    void fetchTradeDetails() throws Exception, TradeDetailsNotFoundException {
        TradeDetail tradeDetail = new TradeDetail(UUID.randomUUID(), BigInteger.ONE,new Tickers(),Integer.valueOf(1),"buy",new Timestamp(123456789),10.2,10,102.0,12.9,100.5,"pending",new TradeAlert(),2.0,3.0);
        List<TradeDetail> list = new ArrayList<>();
        list.add(tradeDetail);
        Map<Object,Object> expectedMap=new HashMap<>();
        expectedMap.put("data", list);
        expectedMap.put("totalPageCount", 1);
        when(tradeDetailsService.findTradeDetails(any(),any(),any())).thenReturn(expectedMap);
        String response = objectWriter.writeValueAsString(expectedMap);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/trade-details/fetch")
                        .contentType(MediaType.APPLICATION_JSON)
                        .param("userId","1")
                        .param("page", "1")
                        .param("limit","1"))
                .andExpect(content()
                        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }
    @ParameterizedTest
    @ValueSource(ints = {0,1})
    void generateSellTradeDetail(int index) throws Exception {
        Constant values[]={Constant.EXECUTED_MESSAGE, Constant.PENDING_MESSAGE};
        Mockito.when(tradeDetailsService.executeTradeDetail(Mockito.any())).thenReturn(new TradeExecutionResponseDto(values[index].toString()));
        mockMvc.perform(post(("/trade-detail/execute"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"tradeDetailId\":\"%s\"}","642c0e4b-ed07-48c2-8b41-7b7296db49ed")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message", is(values[index].toString())));
    }
    @ParameterizedTest
    @ValueSource(ints = {0,1})
    void generateSellTradeDetailFailure(int index) throws Exception {
        Exception exception[]={new QuantityMismatchException(),new NoHoldingException()};
        String code[]={Constant.QUANTITY_MISMATCH.name(),Constant.NO_HOLDINGS.name()};
        String message[]={Constant.QUANTITY_MISMATCH.toString(),Constant.NO_HOLDINGS.toString()};
        Mockito.when(tradeDetailsService.executeTradeDetail(Mockito.any())).thenThrow(exception[index]);
        mockMvc.perform(post(("/trade-detail/execute"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{\"tradeDetailId\":\"%s\"}","642c0e4b-ed07-48c2-8b41-7b7296db49ed")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code",is(code[index])))
                .andExpect(jsonPath("$.errors[0].message", is(message[index])));
    }
    @Test
    void fetchNullTradeDetails() throws Exception, TradeDetailsNotFoundException {
        Map<Object,Object> expectedMap=new HashMap<>();
        expectedMap.put("data", null);
        expectedMap.put("totalPageCount", 1);
        when(tradeDetailsService.findTradeDetails(any(),any(),any())).thenReturn(expectedMap);
        String response = objectWriter.writeValueAsString("No trade details found");
        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/trade-details/fetch")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(response)
        ).andReturn();

        assertEquals(200,mvcResult.getResponse().getStatus());

    }
    @Test
    @DisplayName("Delete Trade Alert Test")
    void deleteTradeAlert() throws Exception {
        UUID tradeAlertId = UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c");
        userTradeAlertService.deleteTradeAlert(BigInteger.ONE, tradeAlertId);
        this.mockMvc.perform(MockMvcRequestBuilders
                        .delete("/alert/1/0fc3705a-6b44-4371-8f23-6b77cef94c2c"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("Get Trade Detail for Manual Sell Test")
    void addTradeDetailTest() throws Exception {
        when(tradeDetailsService.addTradeDetail(BigInteger.ONE,1)).thenReturn(tradeDetailDto);
        mockMvc.perform(MockMvcRequestBuilders
                .get("/trade-detail/101/10")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void getTradeAlertInfo() throws Exception {
        List<UserTradeAlertDto> dummy = new ArrayList<>();
        dummy.add(userTradeAlertDto);
        when(userTradeAlertService.findByAlert(BigInteger.valueOf(1))).thenReturn(dummy);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/trade-alert/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    @DisplayName("method should throw parameter not found exception on empty string")
    void searchParameterNotFound()
    {
        assertThrows(ParameterNotFoundException.class, ()->tradeController.exceptionUserId());
    }




    @Test
    void getUserByIdUserNotFoundException() throws Exception {
        List<UserTradeAlertDto> dummy = new ArrayList<>();
        dummy.add(userTradeAlertDto);
        when(userTradeAlertService.findByAlert(BigInteger.valueOf(1))).thenThrow(new ListOfAlertNotFoundException("list of alert not found"));
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/trade-alert/0")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void getUserByIdWhenUrlParameterIsString() throws Exception {
        List<UserTradeAlertDto> dummy = new ArrayList<>();
        dummy.add(userTradeAlertDto);
        when(userTradeAlertService.findByAlert(BigInteger.valueOf(1))).thenThrow(new UserNotFoundException("User Not Found"));
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/trade-alert/aaaa")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Delete Trade Detail Test")
    void deleteTradeDetail() throws Exception {
        UUID tradeDetailId = UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7");
        tradeDetailsService.deleteTradeDetail(tradeDetailId);
        this.mockMvc.perform(MockMvcRequestBuilders
                        .delete("/trade-detail/delete/2a84de6e-22c2-4f47-a596-9716a87d30b7"))
                .andExpect(status().isNoContent());
    }

    @Test
    void updateTradeDetails() throws Exception {
        BigInteger userId = tradeDetailDto.getUserId();
        UUID tradeDetailId = tradeDetailDto.getTradeDetailId();
        Mockito.when(tradeDetailsService.updateTradeDetails(userId, tradeDetailId)).thenReturn(tradeDetailDto);
        this.mockMvc.perform(MockMvcRequestBuilders
                        .get("/update/" + userId + "/" + tradeDetailId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$", Matchers.notNullValue()))
                .andExpect(MockMvcResultMatchers.content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.jsonPath("$.pricePerTicker", new Object[0]).value(tradeDetailDto.getPricePerTicker()));
    }

    @Test
    void handleTradeAlertToDetails() throws Exception {
        TradeDetail tradeDetail = new TradeDetail();
        when(tradeDetailsService.tradeAlertToDetails(any())).thenReturn(tradeDetail);
        String body = objectWriter.writeValueAsString(new TradeAlertUserIdDto());
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
                .post("/user/trade-details")
                .content(body).contentType(MediaType.APPLICATION_JSON)).andReturn();
        assertEquals(objectWriter.writeValueAsString(tradeDetail), mvcResult.getResponse().getContentAsString());

    }

}
