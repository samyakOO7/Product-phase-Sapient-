package com.sapient.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExecutedTradeTest {

    ExecutedTrade executedTrade;

    @BeforeEach
    void setUp() {
        executedTrade = new ExecutedTrade();
    }

    @Test
    void getExecutedTradesId() {
        UUID expected = UUID.randomUUID();
        executedTrade.setExecutedTradesId(expected);
        assertEquals(expected, executedTrade.getExecutedTradesId());

    }

    @Test
    void getUserId() {
        BigInteger expected = BigInteger.ONE;
        executedTrade.setUserId(expected);
        assertEquals(expected, executedTrade.getUserId());
    }

    @Test
    void getTicker() {
        Tickers tickers =  new Tickers();
        executedTrade.setTicker(tickers);
        assertEquals(tickers, executedTrade.getTicker());
    }

    @Test
    void getBuyTradeDetail() {
        TradeDetail tradeDetail = new TradeDetail();
        executedTrade.setBuyTradeDetail(tradeDetail);
        assertEquals(tradeDetail, executedTrade.getBuyTradeDetail());
    }

    @Test
    void getSellTradeDetail() {
        TradeDetail tradeDetail =  new TradeDetail();
        executedTrade.setSellTradeDetail(tradeDetail);
        assertEquals(tradeDetail, executedTrade.getSellTradeDetail());
    }

    @Test
    void getTimeframe() {
        Integer expected = 1440;
        executedTrade.setTimeframe(expected);
        assertEquals(expected, executedTrade.getTimeframe());
    }

    @Test
    void getTradeOpenedAt() {
        Timestamp expected = new Timestamp(12345678);
        executedTrade.setTradeOpenedAt(expected);
        assertEquals(expected, executedTrade.getTradeOpenedAt());
    }

    @Test
    void getTradeClosedAt() {
        Timestamp expected = new Timestamp(12345678);
        executedTrade.setTradeClosedAt(expected);
        assertEquals(expected, executedTrade.getTradeClosedAt());
    }

    @Test
    void getGain() {
        Double expected = 10.00;
        executedTrade.setGain(expected);
        assertEquals(expected, executedTrade.getGain());
    }

    @Test
    void getPricePerTicker() {
        Double expected = 10.00;
        executedTrade.setPricePerTicker(expected);
        assertEquals(expected, executedTrade.getPricePerTicker());
    }

    @Test
    void getSoldPricePerTicker() {
        Double expected = 10.00;
        executedTrade.setSoldPricePerTicker(expected);
        assertEquals(expected, executedTrade.getSoldPricePerTicker());
    }

    @Test
    void testToString() {
        ExecutedTrade executedTrade1 = new ExecutedTrade(UUID.randomUUID(), BigInteger.ONE, new Tickers(),
                new TradeDetail(), new TradeDetail(), 1440, new Timestamp(12345678),
                new Timestamp(12345678),10.00 , 10.00, 10.00);

        String expected = "ExecutedTrade{"+
                "executedTradesId=" + executedTrade1.getExecutedTradesId()+
                ", userId="+ executedTrade1.getUserId()+
                ", ticker="+ executedTrade1.getTicker()+
                ", buyTradeDetail=" + executedTrade1.getBuyTradeDetail()+
                ", sellTradeDetail=" + executedTrade1.getSellTradeDetail()+
                ", timeframe=" + executedTrade1.getTimeframe()+
                ", tradeOpenedAt="+ executedTrade1.getTradeOpenedAt()+
                ", tradeClosedAt=" + executedTrade1.getTradeClosedAt()+
                ", gain=" + executedTrade1.getGain()+
                ", pricePerTicker=" + executedTrade1.getPricePerTicker()+
                ", soldPricePerTicker=" + executedTrade1.getSoldPricePerTicker()+
                "}";
        assertEquals(expected, executedTrade1.toString());

    }
}