package com.sapient.entity;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TradeAlertTest {

    TradeAlert tradeAlert;

    @BeforeEach
    void setUp() {
        tradeAlert = new TradeAlert();
    }
    @Test
    void getTradeAlertId() {
        UUID expected = UUID.randomUUID();
        tradeAlert.setTradeAlertId(expected);
        assertEquals(expected,tradeAlert.getTradeAlertId());
    }

    @Test
    void getTicker() {
        Tickers tickers = new Tickers();
        tradeAlert.setTicker(tickers);
        assertEquals(tickers,tradeAlert.getTicker());
    }

    @Test
    void getTimeframe() {
        Integer expected = 1440;
        tradeAlert.setTimeframe(expected);
        assertEquals(expected,tradeAlert.getTimeframe());
    }

    @Test
    void getTradeDirection() {
        String expected = "buy";
        tradeAlert.setTradeDirection(expected);
        assertEquals(expected,tradeAlert.getTradeDirection());
    }

    @Test
    void getGenerationTime() {
        Timestamp expected = new Timestamp(12346789);
        tradeAlert.setGenerationTime(expected);
        assertEquals(expected,tradeAlert.getGenerationTime());
    }

    @Test
    void getExpiryTime() {
        Timestamp expected = new Timestamp(12345678);
        tradeAlert.setExpiryTime(expected);
        assertEquals(expected,tradeAlert.getExpiryTime());
    }

    @Test
    void getConfidence() {
        Double expected = 90.00;
        tradeAlert.setConfidence(expected);
        assertEquals(expected,tradeAlert.getConfidence());
    }

    @Test
    void getAtr() {
        Double expected = 110.00;
        tradeAlert.setAtr(expected);
        assertEquals(expected,tradeAlert.getAtr());
    }
    @Test
    void testToString() {
        TradeAlert tradeAlert1 = new TradeAlert(UUID.randomUUID(),new Tickers(),1440,"buy",new Timestamp(12345678),new Timestamp(12345679),90.00,110.00);
        String expected = "TradeAlert{" +
                "tradeAlertId=" + tradeAlert1.getTradeAlertId()+
                ", ticker=" + tradeAlert1.getTicker()+
                ", timeframe=" + tradeAlert1.getTimeframe()+
                ", tradeDirection='"+ tradeAlert1.getTradeDirection()+"'"+
                ", generationTime=" + tradeAlert1.getGenerationTime()+
                ", expiryTime=" + tradeAlert1.getExpiryTime()+
                ", confidence="+ tradeAlert1.getConfidence()+
                ", atr=" + tradeAlert1.getAtr()+
                "}";
        assertEquals(expected,tradeAlert1.toString());
    }
}