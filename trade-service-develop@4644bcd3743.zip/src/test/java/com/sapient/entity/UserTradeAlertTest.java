package com.sapient.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradeAlertTest {

    UserTradeAlert userTradeAlert;

    @BeforeEach
    void setUp() {
        userTradeAlert = new UserTradeAlert();
    }

    @Test
    void testToString() {
        UserTradeAlert userTradeAlert1 = new UserTradeAlert(UUID.randomUUID(), BigInteger.ONE, new TradeAlert());
        String expected = "UserTradeAlert{"+
                "userTradeAlertId=" + userTradeAlert1.getUserTradeAlertId()+
                ", userId="+ userTradeAlert1.getUserId()+
                ", tradeAlert=" + userTradeAlert1.getTradeAlert()+
                "}";
        assertEquals(expected, userTradeAlert1.toString());
    }

    @Test
    void getUserTradeAlertId() {
        UUID expected = UUID.randomUUID();
        userTradeAlert.setUserTradeAlertId(expected);
        assertEquals(expected, userTradeAlert.getUserTradeAlertId());
    }

    @Test
    void getUserId() {
        BigInteger expected = BigInteger.ONE;
        userTradeAlert.setUserId(expected);
        assertEquals(expected, userTradeAlert.getUserId());
    }

    @Test
    void getTradeAlert() {
        TradeAlert tradeAlert = new TradeAlert();
        userTradeAlert.setTradeAlert(tradeAlert);
        assertEquals(tradeAlert, userTradeAlert.getTradeAlert());
    }
}