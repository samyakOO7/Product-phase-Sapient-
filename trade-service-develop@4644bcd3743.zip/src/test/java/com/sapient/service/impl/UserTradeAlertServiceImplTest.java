package com.sapient.service.impl;

import com.sapient.dto.UserTradeAlertDto;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.UserTradeAlert;
import com.sapient.exception.ListOfAlertNotFoundException;
import com.sapient.exception.NoTradeAlertFoundException;
import com.sapient.exception.TradeAlertNotFoundException;
import com.sapient.exception.UserNotFoundException;
import com.sapient.repository.UserTradeAlertRepository;
import com.sapient.service.UserTradeAlertService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = UserTradeAlertServiceImpl.class)
class UserTradeAlertServiceImplTest {

    @MockBean
    UserTradeAlertRepository userTradeAlertRepository;

    @Autowired
    UserTradeAlertService userTradeAlertService;

    Timestamp timestamp=Timestamp.from(Instant.now());
    Tickers ticker = new Tickers(1,"hdfc","h","stock");
    TradeAlert tradeAlert = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),ticker,1,"buy",timestamp,timestamp,94.5,10.5 );
    UserTradeAlert dummyUserTradeAlert = new UserTradeAlert(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7"),
            BigInteger.ONE, tradeAlert);

    UUID uuid = UUID.randomUUID();
    int sec = 600;
    BigInteger userId= BigInteger.valueOf(1);
    Timestamp later = new Timestamp(timestamp.getTime() + (sec * 1000L));
    TradeAlert tradeAlert1 = new TradeAlert(uuid,ticker,1,"buy",timestamp,later,94.5,10.5 );
    UserTradeAlert dummyUserTradeAlert1 = new UserTradeAlert(uuid,
            BigInteger.ONE, tradeAlert1);

    UserTradeAlertDto userTradeAlertDto = new UserTradeAlertDto(uuid,1,1,"buy",timestamp,94.5,"hdfc");
    @Test
    void deleteTradeAlert() {
        when(userTradeAlertRepository.findUserTradeAlert(BigInteger.ONE, UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c")))
                .thenReturn(dummyUserTradeAlert);
        userTradeAlertService.deleteTradeAlert(BigInteger.ONE, UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        verify(userTradeAlertRepository, times(1)).delete(dummyUserTradeAlert);
    }

    @Test
    void deleteTradeAlertNotException() throws TradeAlertNotFoundException {
        when(userTradeAlertRepository.findUserTradeAlert(BigInteger.ONE, UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c")))
                .thenReturn(null);
        TradeAlertNotFoundException tradeAlertNotFoundException = assertThrows(TradeAlertNotFoundException.class,
                this::executeDeleteTradeAlert
        );
        assertEquals("Trade Alert Not Found For : 0fc3705a-6b44-4371-8f23-6b77cef94c2c", tradeAlertNotFoundException.getMessage());

    }

    private void executeDeleteTradeAlert() {
        userTradeAlertService.deleteTradeAlert(BigInteger.ONE, UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
    }

    @Test
    void findUserTradeInfo() throws UserNotFoundException, ListOfAlertNotFoundException, NoTradeAlertFoundException {
        List<UserTradeAlert> dummy = new ArrayList<>();
        dummy.add(dummyUserTradeAlert1);
        System.out.println(dummy);

        Mockito.when(userTradeAlertRepository.getUserTradeAlert(userId)).thenReturn(dummy);

        List<UserTradeAlertDto> expectedResponse= new ArrayList<>();
        expectedResponse.add(userTradeAlertDto);
        List<UserTradeAlertDto> actualResponse=userTradeAlertService.findByAlert(userId);
        assertEquals(expectedResponse.toString(),actualResponse.toString());
    }


    @Test
    void getUserByIdUserNotFoundException() {
        BigInteger id = dummyUserTradeAlert1.getUserId();
        NoTradeAlertFoundException noTradeAlertFoundException = assertThrows(NoTradeAlertFoundException.class,
                () -> userTradeAlertService.findByAlert(userId));
        assertEquals("No trade alert found", noTradeAlertFoundException.getMessage());
    }
}