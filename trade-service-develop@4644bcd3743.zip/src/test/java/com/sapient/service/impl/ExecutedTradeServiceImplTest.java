package com.sapient.service.impl;

import com.sapient.client.UserServiceFeignClient;
import com.sapient.dto.ClosedTradeResponseDto;
import com.sapient.dto.UserTradeInfoDto;
import com.sapient.dto.UserTradeStatsDto;
import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.NoClosedTradesException;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.ExecutedTradeService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ExecutedTradeServiceImpl.class)
@TestPropertySource("classpath:application.properties")
class ExecutedTradeServiceImplTest {



    @MockBean
    ExecutedTradeRepository executedTradeRepository;

    @MockBean
    TradeDetailRepository tradeDetailRepository;

    @MockBean
    TradeAlertRepository tradeAlertRepository;

    @MockBean
    UserServiceFeignClient userServiceFeignClient;

    @Autowired
    ExecutedTradeService executedTradeService;




    static UserTradeInfoDto userTradeInfoDto;
    static List<ExecutedTrade> allOpenTrades;
    static BigInteger userId;
    static ExecutedTrade executedTrade1;
    static ExecutedTrade executedTrade2;

    static  UserTradeStatsDto userTradeStatsDto;

    @BeforeAll
    static void setUp() {
        userId= BigInteger.valueOf(1);
        userTradeInfoDto = new UserTradeInfoDto(1,1,1,1,1,40.0,1,1000.0);
        Timestamp timestamp=Timestamp.from(Instant.now());
        executedTrade1=new ExecutedTrade(UUID.randomUUID(),BigInteger.valueOf(1),new Tickers(),new TradeDetail(), new TradeDetail(),1440,new Timestamp(1234567), new Timestamp(12345678),10.00, 100.00,95.0);
        executedTrade2 = new ExecutedTrade(UUID.randomUUID(),BigInteger.valueOf(5),new Tickers(),new TradeDetail(), new TradeDetail(),1440,new Timestamp(1234567), new Timestamp(12345678),20.00, 200.00,195.0);
        userTradeStatsDto=new UserTradeStatsDto(40.0,1,1,1000.0);
        allOpenTrades=new ArrayList<>();
        allOpenTrades.add(executedTrade1);
        allOpenTrades.add(executedTrade2);
    }

    @Test
    void findUserTradeInfo(){
        when(executedTradeRepository.findOpenTrades(userId)).thenReturn(userTradeInfoDto.getOpenTrades());
        when(executedTradeRepository.findClosedTrades(userId)).thenReturn(userTradeInfoDto.getClosedTrades());
        when(tradeDetailRepository.findTradeConverted(userId)).thenReturn(userTradeInfoDto.getAlertsConvertedToTrades());
        when(tradeAlertRepository.findAllAlertByMonth(userId)).thenReturn(userTradeInfoDto.getTradeAlertsGenerated());
        when(userServiceFeignClient.findUserTradeStats(userId)).thenReturn(ResponseEntity.ok(userTradeStatsDto));

        UserTradeInfoDto resultUserTradeInfoDto=executedTradeService.findUserTradeInfo(userId);

        assertEquals(resultUserTradeInfoDto.toString(),userTradeInfoDto.toString());
    }

    @Test
    void findAllClosedTradesShouldReturnAllClosedTrades() throws NoClosedTradesException {
        int page = 0;
        int limit = 7;
        BigInteger userId = BigInteger.ONE;
        PageRequest pageRequest = PageRequest.of(page, limit);
        UUID uuid = UUID.randomUUID();
        Tickers tickers = new Tickers(1,"Infosys", "INFY", "Stock");
        TradeDetail buyTradeDetail = new TradeDetail(UUID.randomUUID(),userId,new Tickers(), 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);
        TradeDetail sellTradeDetail = new TradeDetail(UUID.randomUUID(),userId,new Tickers(), 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);

        ExecutedTrade executedTrade = new ExecutedTrade(uuid,userId,tickers,buyTradeDetail,sellTradeDetail,1440,new Timestamp(1234568),new Timestamp(1234578),100.0,50.0,60.0);

        List<ExecutedTrade> closedTrades = new ArrayList<>();
        closedTrades.add(executedTrade);

        when(executedTradeRepository.findAllClosedTrades(userId,pageRequest)).thenReturn(closedTrades);
        when(executedTradeRepository.countOfClosedTrades(userId)).thenReturn(1L);
        ClosedTradeResponseDto closedTradeResponseDto = new ClosedTradeResponseDto("INFY","Infosys",new Timestamp(1234568),new Timestamp(1234578),1000.0,50.0,60.0,10);
        Map<Object,Object> expectedResult = new HashMap<>();
        List<ClosedTradeResponseDto> closedTradeResponseDtos = new ArrayList<>();
        closedTradeResponseDtos.add(closedTradeResponseDto);
        expectedResult.put("closedTrades", closedTradeResponseDtos);
        expectedResult.put("pageCount",1);
        assertEquals(expectedResult, executedTradeService.findAllClosed(userId,page,limit));

    }

    @Test
    void findAllClosedTradesShouldThrowNoClosedTradesException() throws NoClosedTradesException
    {
        int page = 0;
        int limit = 7;
        BigInteger userId = BigInteger.ONE;
        PageRequest pageRequest = PageRequest.of(page, limit);

        assertThrows(NoClosedTradesException.class, () -> executedTradeService.findAllClosed(userId,page,limit));
    }
}
