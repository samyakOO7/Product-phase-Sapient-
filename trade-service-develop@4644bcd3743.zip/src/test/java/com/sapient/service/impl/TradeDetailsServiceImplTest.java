package com.sapient.service.impl;

import com.sapient.client.StockServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.constant.Constant;
import com.sapient.constant.TradeDetailStatus;
import com.sapient.dto.*;
import com.sapient.entity.ExecutedTrade;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.exception.*;
import com.sapient.repository.ExecutedTradeRepository;
import com.sapient.repository.TickerRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.service.TradeDetailsService;
import com.sapient.util.CurrentTimeUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TradeDetailsServiceImpl.class)
@TestPropertySource("classpath:application.properties")
class TradeDetailsServiceImplTest {

    @MockBean
    TradeDetailRepository tradeDetailRepository;

//    @MockBean
//    PageRequest pageRequest;

    @Autowired
    TradeDetailsService tradeDetailsService;
    @Autowired
    TradeDetailsServiceImpl tradeDetailsServiceImpl;

    @MockBean
    StockServiceFeignClient stockServiceFeignClient;
    @MockBean
    UserServiceFeignClient userServiceFeignClient;

    @MockBean
    TickerRepository tickerRepository;

    @MockBean
    TradeAlertRepository tradeAlertRepository;


    @MockBean
    ExecutedTradeRepository executedTradeRepository;


    @MockBean
    CurrentTimeUtil currentTimeUtil;

    @MockBean
    ModelMapper modelMapper;
    static TradeDetail tradeDetail;
    static TradeDetail tradeDetail0;
    static TradeDetail tradeDetailUpdated;
    static TradeDetail tradeDetailForSell;
    static TradeDetailDto tradeDetailDtoUpdated;
    static UserTradingDetailsDto userTradingDetailsDto;
    static Tickers tickerDetails;
    static UUID tradeDetailId;
    static Timestamp timestamp;
    static TradeDetail dummyUserTradeDetail;
    static TradeAlert tradeAlert;

    static Tickers ticker;
    static TradeDetail manualBuyTradeDetail;
    static TradeDetailDto manualBuyTradeDetailDto;
    static Map<String,BigDecimal> tickerPrice;

    static UserTradingDetailsDto userTradeDetailDto;
    static TradeDetail tradeDetailQuantity;
    static TradeDetail tradeDetailUpdatedQuantity;
    static TradeDetailDto tradeDetailDtoUpdatedQuantity;
    static TradeDetail tradeDetailZero;
    private UserTradeDetailUpdateDto userTradeDetailUpdateDtoNew;

    @BeforeEach
    void setup(){
        tickerPrice=new HashMap<>();
        tickerPrice.put("price_per_stock", BigDecimal.valueOf(15.0));

        timestamp=Timestamp.from(Instant.now());
        ticker = new Tickers(1,"hdfc","h","stock");
        tradeAlert = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),ticker,1,"buy",timestamp,timestamp,94.5,10.5 );
        dummyUserTradeDetail = new TradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7"),BigInteger.valueOf(1),ticker,12,"buy",timestamp,20.0,2,90.0,12.0,15.0,"pending",tradeAlert,23.0,6.0);
        tradeDetailId = UUID.randomUUID();
        tickerDetails = new Tickers(1, "Infosys", "INFY", "stock");

        userTradingDetailsDto = new UserTradingDetailsDto(BigInteger.ONE, 1000.0, 10.0, 5.0, BigInteger.ONE, 10000.0);

        tradeDetail = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10.0, 10, 100.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailUpdated = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 20.0, 5, 100.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailDtoUpdated = new TradeDetailDto(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 20.0, 50, 1000.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailForSell= new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "sell", timestamp, 10.0, 10, 100.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

        tradeDetailQuantity = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 20.0, 10, 200.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailUpdatedQuantity = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10000.0, 10, 100000.0, 2.0, 2.0, "insufficient_funds", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        tradeDetailDtoUpdatedQuantity = new TradeDetailDto(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10000.0, 10, 100000.0, 2.0, 2.0, "insufficient_funds", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

        tradeDetailZero = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10.0, 0, 100.0, 2.0, 2.0, "no_action", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);

        manualBuyTradeDetail =new TradeDetail(UUID.fromString("3db23635-1307-4bdd-b8ca-d1ceabb31c93"), BigInteger.ONE, tickerDetails, 1440, "buy", timestamp, 10.0, 10, 100.0, 5.0, 5.0, "no_action", null, null, 1.0);
        manualBuyTradeDetailDto =new TradeDetailDto(UUID.fromString("3db23635-1307-4bdd-b8ca-d1ceabb31c93"), BigInteger.ONE, tickerDetails, 1440, "buy", timestamp, 10.0, 10, 100.0, 5.0, 5.0, "no_action", null, null, 1.0);

        userTradeDetailUpdateDto=new UserTradeDetailUpdateDto(UUID.randomUUID(),5,10.0,10.0);
        userTradeDetailUpdateDtoNew=new UserTradeDetailUpdateDto(UUID.randomUUID(),0,10.0,10.0);

        tickers=new Tickers(101,"hdfc","hdfc","stock");
        tradeDetail0= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);

        tradeDetail1= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "sell", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "pending", new TradeAlert(), 10.00, 10.00);

        tradeDetail2= new TradeDetail(UUID.randomUUID(),BigInteger.ONE,tickers, 1440,
                "buy", new Timestamp(1234568), 100.00, 10, 1000.00, 98.00,
                1200.00, "executed", new TradeAlert(), 10.00, 10.00);

        userTradeDetailDto=new UserTradingDetailsDto(BigInteger.ONE,200.0,30.0,10.0,BigInteger.ONE,1000.0);
        tradeExecutionResponseDto1=new TradeExecutionResponseDto("pending");
        tradeExecutionResponseDto2=new TradeExecutionResponseDto("executed");

        executedTrade1=new ExecutedTrade(UUID.randomUUID(),BigInteger.valueOf(1),tickers,tradeDetail,null,1,Timestamp.from(Instant.now()),null,0.0,15.0,null);


        userTradeDetailUpdateDto2=new UserTradeDetailUpdateDto(UUID.randomUUID(),500,10.0,10.0);
        userTradeDetailUpdateDto3=new UserTradeDetailUpdateDto(UUID.randomUUID(),18,10.0,10.0);
        tradeDetailList=new ArrayList<>();
        tradeDetailList.add(tradeDetail2);

            }
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto;
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto2;
    static UserTradeDetailUpdateDto userTradeDetailUpdateDto3;
    static TradeDetail tradeDetail2;

    static TradeDetail tradeDetail1;

    static Tickers tickers;

    static TradeExecutionResponseDto tradeExecutionResponseDto1;
    static TradeExecutionResponseDto tradeExecutionResponseDto2;

    static List<TradeDetail> tradeDetailList;


    static ExecutedTrade executedTrade1;



    @Test
    void findTradeDetails() throws TradeDetailsNotFoundException {
        TradeDetail tradeDetail = new TradeDetail(UUID.randomUUID(), BigInteger.ONE,new Tickers(), 1,"buy",new Timestamp(123456789),10.2,10,102.0,12.9,100.5,"pending",new TradeAlert(),2.0,3.0);
        List<TradeDetail> list = new ArrayList<>();
        list.add(tradeDetail);
        when(tradeDetailRepository.findByUserId(any(),any(PageRequest.class))).thenReturn(list);
        when(tradeDetailRepository.countByUserId(any())).thenReturn(1L);
        Map<Object,Object> expectedMap=new HashMap<>();
        expectedMap.put("data", list);
        expectedMap.put("totalPageCount", 1);
        assertEquals(expectedMap, tradeDetailsService.findTradeDetails(BigInteger.valueOf(1),1,1));
    }

    @Test
    void checkExceptionTradeDetail() throws TradeDetailsNotFoundException {
        List<TradeDetail> list = new ArrayList<>();
        when(tradeDetailRepository.findByUserId(any(),any(PageRequest.class))).thenReturn(list);
        when(tradeDetailRepository.countByUserId(any())).thenReturn(0L);

        assertThrows(TradeDetailsNotFoundException.class,()->{
            tradeDetailsService.findTradeDetails(BigInteger.ONE,1,1);
        });

    }

    @Test
    void deleteTradeDetail() {
        when(tradeDetailRepository.findByUserTradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7")))
                .thenReturn(dummyUserTradeDetail);
        tradeDetailsService.deleteTradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7"));
        verify(tradeDetailRepository, times(1)).delete(dummyUserTradeDetail);
    }

    @Test
    void deleteTradeDetailNotException() throws TradeDetailsNotFoundException {
        when(tradeDetailRepository.findByUserTradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7")))
                .thenReturn(null);
        TradeDetailsNotFoundException tradeDetailsNotFoundException = assertThrows(TradeDetailsNotFoundException.class,
                this::executeDeleteTradeDetail
        );
        assertEquals("Trade details not found", tradeDetailsNotFoundException.getMessage());

    }

    @Test
    void updateTradeDetails() throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        Map<String, BigDecimal> tickerResponse = new HashMap();
        tickerResponse.put("price_per_stock", new BigDecimal(20));
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetail));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        Mockito.when(this.tickerRepository.findById(1)).thenReturn(Optional.ofNullable(tickerDetails));
        Mockito.when(this.stockServiceFeignClient.getTickerPrice("INFY")).thenReturn(ResponseEntity.of(Optional.ofNullable(tickerResponse)));
        Mockito.when((TradeDetail)this.tradeDetailRepository.save(tradeDetailUpdated)).thenReturn(tradeDetailUpdated);
        when(modelMapper.map(tradeDetailUpdated,TradeDetailDto.class)).thenReturn(tradeDetailDtoUpdated);
        TradeDetailDto tradeDetailDto1 = this.tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId);
        tradeDetailDto1.setCreatedAt(timestamp);
        Assertions.assertEquals(tradeDetailDto1.toString(), tradeDetailDtoUpdated.toString());
    }
    @Test
    void updateTradeDetailsQuantityIssue() throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        Map<String, BigDecimal> tickerResponse = new HashMap();
        tickerResponse.put("price_per_stock", new BigDecimal(10000));
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetailQuantity));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        Mockito.when(this.tickerRepository.findById(1)).thenReturn(Optional.ofNullable(tickerDetails));
        Mockito.when(this.stockServiceFeignClient.getTickerPrice("INFY")).thenReturn(ResponseEntity.of(Optional.ofNullable(tickerResponse)));
        Mockito.when((TradeDetail)this.tradeDetailRepository.save(tradeDetailUpdated)).thenReturn(tradeDetailUpdatedQuantity);
        when(modelMapper.map(tradeDetailUpdated,TradeDetailDto.class)).thenReturn(tradeDetailDtoUpdatedQuantity);
        TradeDetailDto tradeDetailDto1 = this.tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId);
        tradeDetailDto1.setCreatedAt(timestamp);
        Assertions.assertEquals(tradeDetailDto1.toString(), tradeDetailDtoUpdatedQuantity.toString());
    }

    @Test
    void addTradeDetail() throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        Map<String, BigDecimal> tickerResponse = new HashMap();
        tickerResponse.put("price_per_stock", new BigDecimal(10));
        when(tickerRepository.findById(1)).thenReturn(Optional.ofNullable(tickerDetails));
        when(userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        when(this.stockServiceFeignClient.getTickerPrice("INFY")).thenReturn(ResponseEntity.of(Optional.ofNullable(tickerResponse)));
        when(this.tradeDetailRepository.save(manualBuyTradeDetail)).thenReturn(manualBuyTradeDetail);
        when(modelMapper.map(manualBuyTradeDetail,TradeDetailDto.class)).thenReturn(manualBuyTradeDetailDto);
        TradeDetailDto tradeDetailDto1 = this.tradeDetailsService.addTradeDetail(BigInteger.ONE, 1);
        tradeDetailDto1.setTradeDetailId(UUID.fromString("3db23635-1307-4bdd-b8ca-d1ceabb31c93"));
        tradeDetailDto1.setCreatedAt(timestamp);
        Assertions.assertEquals(tradeDetailDto1.toString(), manualBuyTradeDetailDto.toString());
    }

    @Test
    void addTradeDetailTickerNotFoundException() throws TickerNotFoundException{
        when(tickerRepository.findById(2)).thenReturn(Optional.of(ticker));
        TickerNotFoundException tickerNotFoundException = assertThrows(TickerNotFoundException.class,
                () -> tradeDetailsService.addTradeDetail(BigInteger.ONE, 5));
        assertEquals("Ticker does not exist", tickerNotFoundException.getMessage());
    }

    @Test
    void addTradeDetailUserNotFoundException() throws UserNotFoundException {
        when(tickerRepository.findById(2)).thenReturn(Optional.of(ticker));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.TWO)).thenReturn(new ResponseEntity<>(null, HttpStatus.NOT_FOUND));
        UserNotFoundException userNotFoundException = new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
        NullPointerException exp = assertThrows(NullPointerException.class,
                () -> tradeDetailsService.addTradeDetail(BigInteger.TWO, 2));
        assertEquals("User does not exist", userNotFoundException.getMessage());
    }

    @Test
    void updateTradeDetailsUserNotFoundException() throws UserNotFoundException{
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetail));

        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.TWO)).thenReturn(new ResponseEntity<>(null, HttpStatus.NOT_FOUND));
        UserNotFoundException userNotFoundException = new UserNotFoundException(Constant.USER_NOT_FOUND.toString());
        NullPointerException exp = assertThrows(NullPointerException.class,
                () -> tradeDetailsService.updateTradeDetails(BigInteger.TWO, tradeDetailId));
        assertEquals("User does not exist", userNotFoundException.getMessage());
    }

    @Test
    void updateTradeDetailsTradeDetailsNotFoundException() throws TradeDetailsNotFoundException{
        TradeDetailsNotFoundException tradeDetailsNotFoundException = assertThrows(TradeDetailsNotFoundException.class,
                () -> tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId));
        assertEquals("Trade details not found", tradeDetailsNotFoundException.getMessage());
    }

    @Test
    void updateTradeDetailsTickerPriceNotFoundException() throws TickerPriceNotFoundException{
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetail));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        Mockito.when(this.tickerRepository.findById(1)).thenReturn(Optional.ofNullable(tickerDetails));
        Mockito.when(this.stockServiceFeignClient.getTickerPrice("INF")).thenReturn(new ResponseEntity<>(null, HttpStatus.NOT_FOUND));
        TickerPriceNotFoundException tickerPriceNotFoundException = new TickerPriceNotFoundException(Constant.TICKER_PRICE_NOT_FOUND.toString());
        NullPointerException exp = assertThrows(NullPointerException.class,
                () -> tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId));
        assertEquals("Unable to fetch ticker price currently", tickerPriceNotFoundException.getMessage());
    }


    @Test
    void updateTradeDetailsTickerNotFoundException() throws TickerNotFoundException{
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetail));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        when(tickerRepository.findById(2)).thenReturn(Optional.of(ticker));

        TickerNotFoundException tickerNotFoundException = assertThrows(TickerNotFoundException.class,
                () -> tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId));
        assertEquals("Ticker does not exist", tickerNotFoundException.getMessage());
    }

    @Test
    void updateTradeDetailsRefreshNotSupportedException() throws RefreshNotSupportedException{
        TradeDetail td = new TradeDetail(tradeDetailId, BigInteger.ONE, tickerDetails, 1, "Buy", timestamp, 10.0, 10, 100.0, 2.0, 2.0, "pending", new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"),tickerDetails,1,"BUY",timestamp,timestamp,10.0,20.0), 10.0, 1.0);
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(td));
        RefreshNotSupportedException refreshNotSupportedException = assertThrows(RefreshNotSupportedException.class,
                () -> tradeDetailsService.updateTradeDetails(BigInteger.ONE, tradeDetailId));
        assertEquals("Trade details refresh not supported", refreshNotSupportedException.getMessage());
    }

    private void executeDeleteTradeDetail() {
        tradeDetailsService.deleteTradeDetail(UUID.fromString("2a84de6e-22c2-4f47-a596-9716a87d30b7"));
    }

    @Test
    void PendingStatusTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException,Exception {
        when(tradeDetailRepository.findById(any(UUID.class))).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        Timestamp timeStamp=Timestamp.valueOf("2022-10-10 08:45:15");
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when(currentTimeUtil.getCurrentTime()).thenReturn(timeStamp);
        when(tradeDetailRepository.getById(any())).thenReturn(tradeDetail0);

        TradeExecutionResponseDto actual=tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto);
        assertEquals(tradeExecutionResponseDto1.toString(),actual.toString());

    }

    @Test
    void TradeDetailNotFoundExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.empty() );
        assertThrows(TradeDetailNotFoundException.class, () -> {
            tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto);
        });

    }
    @Test
    void ZeroQuantityExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetailZero));
        assertThrows(ZeroQuantityException.class, () -> {
            tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDtoNew);
        });

    }
    @Test
    void TradeAlreadyExecutedExceptionTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail2) );
        assertThrows(TradeAlreadyExecutedException.class, () -> {
            tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto);
        });

    }

    @Test
    void ExceedingAmountPerTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.of(Optional.of(tickerPrice )));




        assertThrows(ExceedingAmountPerTradeException.class, () -> {
            tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto2);
        });

    }

    @Test
    void InsufficientFundsTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException {
        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.of(Optional.of(tickerPrice )));



        assertThrows(InsufficientFundsException.class, () -> {
            tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto3);
        });

    }





    @Test
    void ExecutedStatusTest() throws TradeDetailNotFoundException, TradeAlreadyExecutedException, InsufficientFundsException, ExceedingAmountPerTradeException, UserNotFoundException, QuantityMismatchException, NoHoldingException, ZeroQuantityException {



        when(tradeDetailRepository.findById(any())).thenReturn(Optional.of(tradeDetail0) );
        when(tradeDetailRepository.save(tradeDetail0)).thenReturn(tradeDetail0);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.of(Optional.of(userTradeDetailDto)));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        Timestamp timeStamp=Timestamp.valueOf("2022-10-10 09:45:15");
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when( executedTradeRepository.save(any())).thenReturn(executedTrade1);
        when(tradeDetailRepository.getById(any())).thenReturn(tradeDetail0);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.of(Optional.empty()));
        when(currentTimeUtil.getCurrentTime()).thenReturn(timeStamp);
        TradeExecutionResponseDto actual=tradeDetailsService.executeTradeDetail(userTradeDetailUpdateDto);
        assertEquals(tradeExecutionResponseDto2.toString(),actual.toString());

    }

        @Test
    void tradeAlertToDetails() throws TickerNotFoundException, TickerPriceNotFoundException {
        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map=new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(),tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(userTradingDetailDto));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(map));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.of(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.of(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        TradeDetail tradeDetail = tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        UUID uuid = UUID.randomUUID();
        tradeDetail.setTradeDetailId(uuid);
        Timestamp ts = new Timestamp(12345);
        tradeDetail.setCreatedAt(ts);

        TradeDetail expected = new TradeDetail(uuid, BigInteger.ONE, ticker1, 1, "buy", ts, 140.0, 71, 9940.0, 40.0,
                10.5, "no_action", tradeAlert1, null, 3.8095238095238093);

        assertEquals(expected.toString(), tradeDetail.toString());

    }
    @Test
    void tradeAlertNotFoundException() {

        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map=new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(userTradingDetailDto));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(map));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(null));
        when(tickerRepository.findById(any())).thenReturn(Optional.of(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        assertThrows(TradeAlertNotFoundException.class, () -> {
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });

    }

    @Test
    void tickerDetailNotFoundException() {

        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map=new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(userTradingDetailDto));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(map));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.ofNullable(null));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        assertThrows(TickerNotFoundException.class, () -> {
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });
    }
    @Test
    void tradeTickerPriceNotFoundException() throws TickerNotFoundException, TickerPriceNotFoundException {
        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map = new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(userTradingDetailDto));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(null);
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.ofNullable(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));

        assertThrows(TickerPriceNotFoundException.class,()->{
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });

    }

    @Test
    void tradeTickerPriceNotFoundException2() throws TickerNotFoundException, TickerPriceNotFoundException {
        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map = new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(userTradingDetailDto));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(null));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.ofNullable(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));

        assertThrows(TickerPriceNotFoundException.class,()->{
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });

    }

    @Test
    void userTradingDetailsNotFoundException() {

        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map=new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(null);
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(map));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.of(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        assertThrows(TradeDetailsNotFoundException.class, () -> {
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });
    }



    @Test
    void userTradingDetailsNotFoundException2() {

        UserTradingDetailsDto userTradingDetailDto = new UserTradingDetailsDto(BigInteger.ONE, 14000.0, 20.00, 40.00,
                BigInteger.valueOf(10), 50000.0);
        TradeAlert tradeAlert1 = new TradeAlert(UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"), ticker, 1,
                "buy", timestamp, timestamp, 94.5, 10.5);
        Tickers ticker1 = new Tickers(1, "hdfc", "h", "stock");
        BigDecimal tickerPrice = BigDecimal.valueOf(140.0);
        Map<String, BigDecimal> map=new HashMap<>();
        map.put(Constant.PRICE_PER_STOCK.toString(), tickerPrice);
        when(userServiceFeignClient.getTradingDetails(any())).thenReturn(ResponseEntity.ok(null));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(map));
        when(tradeAlertRepository.findById(any())).thenReturn(Optional.ofNullable(tradeAlert1));
        when(tickerRepository.findById(any())).thenReturn(Optional.of(ticker1));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeAlertUserIdDto tradeAlertUserIdDto = new TradeAlertUserIdDto(BigInteger.ONE,
                UUID.fromString("0fc3705a-6b44-4371-8f23-6b77cef94c2c"));
        assertThrows(TradeDetailsNotFoundException.class, () -> {
            tradeDetailsService.tradeAlertToDetails(tradeAlertUserIdDto);
        });
    }

    @Test
    void validateRefreshForTradeDetail() {
        TradeDetail detail =tradeDetailUpdated;
        detail.setStatus("executed");
        assertThrows(RefreshNotSupportedException.class, ()->tradeDetailsServiceImpl.validateRefreshForTradeDetail(detail));
        detail.setStatus("pending");
        assertThrows(RefreshNotSupportedException.class, ()->tradeDetailsServiceImpl.validateRefreshForTradeDetail(detail));
        detail.setStatus("no_action");
        assertDoesNotThrow( ()->tradeDetailsServiceImpl.validateRefreshForTradeDetail(detail));
    }

    @Test
    void refreshForSellShouldReturnValidTradeDetail() throws NoHoldingException {
        UserPortfolioDto portfolioDto = new UserPortfolioDto(BigInteger.ONE, 3, 30.0,BigInteger.TWO,new Tickers());
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(any(BigInteger.class), anyInt())).thenReturn(portfolioDto);
        when(tradeDetailRepository.save(any(TradeDetail.class))).thenReturn(tradeDetail);
        TradeDetailDto dto = tradeDetailsServiceImpl.refreshForSell(tradeDetail,34.8);

        assertEquals( 4.8,round(dto.getGain(),1) );
        assertEquals( 104.4, round(dto.getTotalCost(),1));
        assertEquals("no_action", dto.getStatus());
        assertEquals(34.8, round(dto.getPricePerTicker(),1));
        verify(tradeDetailRepository).save(any());
    }




    @Test
    void populateTradeDetailsSell() {
        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf("2022-08-01 08:01:15"));
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        BigDecimal currentPrice=BigDecimal.valueOf(345);
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,10,345.0,BigInteger.TEN,ticker);
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-08-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(userPortfolioDto.getQuantity());
        tradeDetail.setGain(currentPrice.doubleValue()-userPortfolioDto.getAveragePrice());
        tradeDetail.setPricePerTicker(userPortfolioDto.getAveragePrice());
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(userPortfolioDto.getTicker());
        tradeDetail.setTotalCost(currentPrice.doubleValue()*userPortfolioDto.getQuantity());
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        TradeDetail actual=tradeDetailsServiceImpl.populateTradeDetailsSell(userPortfolioDto,currentPrice);
        Assertions.assertEquals(tradeDetail,actual);
    }


    @Test
    void generateSellTradeDetailNotPresentInDb() {
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,10,345.0,BigInteger.TEN,ticker);
        when(userServiceFeignClient.getUserPortfolio(Mockito.any(BigInteger.class))).thenReturn(userPortfolioDto);
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(3432))));

        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf("2022-08-01 08:01:15"));
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-08-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(userPortfolioDto.getQuantity());
        tradeDetail.setGain(3432-userPortfolioDto.getAveragePrice());
        tradeDetail.setPricePerTicker(3432.0);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(userPortfolioDto.getTicker());
        tradeDetail.setTotalCost(3432.0*userPortfolioDto.getQuantity());
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        when(tradeDetailRepository.findFirstByUserIdAndTicker_TickerNumberAndTradeDirectionAndStatus(any(),any(),any(),any())).thenReturn(Optional.empty());
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeDetail actual=tradeDetailsService.generateSellTradeDetail(BigInteger.TWO);
        Assertions.assertEquals(actual,tradeDetail);
    }
    @Test
    void generateSellTradeDetailPresentInDb() {
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,10,345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolio(Mockito.any(BigInteger.class))).thenReturn(userPortfolioDto);
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(3432))));

        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf("2022-07-01 08:01:15"));
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(userPortfolioDto.getQuantity());
        tradeDetail.setGain(3432-userPortfolioDto.getAveragePrice());
        tradeDetail.setPricePerTicker(3432.0);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(userPortfolioDto.getTicker());
        tradeDetail.setTotalCost(3432.0*userPortfolioDto.getQuantity());
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        TradeDetail tradeDetail2=new TradeDetail();
        tradeDetail2.setTradeDetailId(uuid);
        tradeDetail2.setCreatedAt(Timestamp.valueOf("2022-08-01 08:01:15"));
        tradeDetail2.setTradeDirection("sell");
        tradeDetail2.setQuantity(userPortfolioDto.getQuantity());
        tradeDetail2.setGain(332-userPortfolioDto.getAveragePrice());
        tradeDetail2.setPricePerTicker(332.0);
        tradeDetail2.setStatus("no_action");
        tradeDetail2.setTicker(userPortfolioDto.getTicker());
        tradeDetail2.setTotalCost(332.0*userPortfolioDto.getQuantity());
        tradeDetail2.setUserId(userPortfolioDto.getUserId());
        when(tradeDetailRepository.findFirstByUserIdAndTicker_TickerNumberAndTradeDirectionAndStatus(any(),any(),any(),any())).thenReturn(Optional.of(tradeDetail2));
        when(tradeDetailRepository.save(any())).thenReturn(null);
        TradeDetail actual=tradeDetailsService.generateSellTradeDetail(BigInteger.TWO);
        Assertions.assertEquals(actual,tradeDetail);
    }


    boolean canBeExecutedTest(Timestamp timestamp) {
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        boolean actual=tradeDetailsServiceImpl.canBeExecuted(timestamp);
        return actual;
    }
    @ParameterizedTest
    @ValueSource(ints={0,1,2,3,4})
    void canBeExecuted(int index) {

        Timestamp timeStamp[]={Timestamp.valueOf("2022-10-10 23:45:15"),Timestamp.valueOf("2022-10-10 09:45:15"),
                Timestamp.valueOf("2022-10-10 08:45:15"),Timestamp.valueOf("2022-10-09 09:45:15"),
                Timestamp.valueOf("2022-10-08 13:45:15")};
        boolean expected[]={false,true,false,false,false};
        Assertions.assertEquals(expected[index],canBeExecutedTest(timeStamp[index]));

    }
    @ParameterizedTest
    @ValueSource(ints={0,1,2})
    void executeSellTradeExecuted(int index) throws Exception {
        int userQuantity[]={10,10,1};
        int tradeQuantity[]={10,10,5};
        TradeDetailStatus tradeDetailStatus[]={TradeDetailStatus.EXECUTED_STATUS,TradeDetailStatus.PENDING_STATUS,TradeDetailStatus.PENDING_STATUS};
        String status[]={"no_action","no_action","quantity_mismatch"};
        String []time={"2022-10-10 14:01:15","2022-10-10 16:01:15","2022-10-10 16:01:15"};
        //Set up for test
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,userQuantity[index],345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.ok("Updated"));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));
        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf(time[index]));
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        ExecutedTrade trade=new ExecutedTrade();
        trade.setPricePerTicker(1231.0);
        when(executedTradeRepository.findByUserIdAndTickerAndTradeClosedAtIsNull(any(),any())).thenReturn(List.of(trade));
        when(executedTradeRepository.saveAll(any())).thenReturn(null);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(tradeQuantity[index]);
        tradeDetail.setStatus(status[index]);
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        TradeDetailStatus expected=tradeDetailStatus[index];
        TradeDetailStatus actual=tradeDetailsService.executeSellTrade(tradeDetail);
        Assertions.assertEquals(expected,actual);
    }

    @Test
    void executeSellQuantityMisMatch() throws NoHoldingException {
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,10,345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(4);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        Assertions.assertThrows(QuantityMismatchException.class,()->tradeDetailsService.executeSellTrade(tradeDetail));
    }
    @Test
    void executeSellQuantityNoHolding() throws NoHoldingException {
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenThrow(NoHoldingException.class);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(4);
        tradeDetail.setStatus("no_action");
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(BigInteger.ONE);
        Assertions.assertThrows(NoHoldingException.class,()->tradeDetailsService.executeSellTrade(tradeDetail));
    }
    @ParameterizedTest
    @ValueSource(ints = {0,1,2})
    void executeTradeDetailForSell(int index) throws Exception {
        int userQuantity[]={10,10,1};
        int tradeQuantity[]={10,10,5};
        TradeDetailStatus tradeDetailStatus[]={TradeDetailStatus.EXECUTED_STATUS,TradeDetailStatus.PENDING_STATUS,TradeDetailStatus.PENDING_STATUS};
        String status[]={"no_action","no_action","quantity_mismatch"};
        String []time={"2022-10-10 14:01:15","2022-10-10 16:01:15","2022-10-10 16:01:15"};
        TradeExecutionResponseDto expected[]={new TradeExecutionResponseDto(Constant.EXECUTED_MESSAGE.toString()),new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString()),new TradeExecutionResponseDto(Constant.PENDING_MESSAGE.toString())};
        //Set up for test
        Tickers ticker=new Tickers(12321,"ICICI","ICICI bank ltd","stock");
        UserPortfolioDto userPortfolioDto=new UserPortfolioDto(BigInteger.ONE,userQuantity[index],345.0,BigInteger.TWO,ticker);
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(Mockito.any(BigInteger.class),any())).thenReturn(userPortfolioDto);
        when(userServiceFeignClient.updateUserPortfolio(any())).thenReturn(ResponseEntity.ok("Updated"));
        when(stockServiceFeignClient.getTickerPrice(any())).thenReturn(ResponseEntity.ok(Map.of("price_per_stock",BigDecimal.valueOf(15))));

        when(currentTimeUtil.getCurrentTime()).thenReturn(Timestamp.valueOf(time[index]));
        Calendar tradingDay=Calendar.getInstance();
        tradingDay.set(Calendar.DAY_OF_MONTH,10);
        tradingDay.set(Calendar.YEAR,2022);
        tradingDay.set(Calendar.MONTH,Calendar.OCTOBER);
        when(currentTimeUtil.getCalendarInstance()).thenReturn(tradingDay).thenReturn((Calendar) tradingDay.clone());
        when(executedTradeRepository.findByUserIdAndTickerAndTradeClosedAtIsNull(any(),any())).thenReturn(new ArrayList<>());
        when(executedTradeRepository.saveAll(any())).thenReturn(null);
        UUID uuid=UUID.randomUUID();
        TradeDetail tradeDetail=new TradeDetail();
        tradeDetail.setTradeDetailId(uuid);
        tradeDetail.setCreatedAt(Timestamp.valueOf("2022-07-01 08:01:15"));
        tradeDetail.setTradeDirection("sell");
        tradeDetail.setQuantity(tradeQuantity[index]);
        tradeDetail.setStatus(status[index]);
        tradeDetail.setTicker(ticker);
        tradeDetail.setUserId(userPortfolioDto.getUserId());
        Mockito.when((tradeDetailRepository.findById(Mockito.any()))).thenReturn(Optional.of(tradeDetail));
        TradeExecutionResponseDto expectedResult=expected[index];
        TradeExecutionResponseDto actual=tradeDetailsService.executeTradeDetail(new UserTradeDetailUpdateDto());
        Assertions.assertEquals(expectedResult,actual);
    }

    @Test
    void refreshForSellShouldReturnNoHoldingTradeDetail() throws NoHoldingException {
        UserPortfolioDto portfolioDto = new UserPortfolioDto(BigInteger.ONE, 3, 30.0,BigInteger.TWO,new Tickers());
        when(userServiceFeignClient.getUserPortfolioByUserIdAndTickerNumber(any(BigInteger.class), anyInt())).thenThrow(new NoHoldingException());
        when(tradeDetailRepository.save(any(TradeDetail.class))).thenReturn(tradeDetail);
        TradeDetailDto dto = tradeDetailsServiceImpl.refreshForSell(tradeDetail,34.8);
        assertEquals("no_holding", dto.getStatus());
        assertEquals(tradeDetail.getTradeDetailId(), dto.getTradeDetailId());
        verify(tradeDetailRepository).save(any());
    }

    @Test
    void getUserDetailsException() throws Exception {
        when(userServiceFeignClient.getTradingDetails(BigInteger.TEN)).thenThrow(new NullPointerException());
        UserNotFoundException exp = assertThrows(UserNotFoundException.class,
                () -> tradeDetailsServiceImpl.getUserDetails(BigInteger.TWO));
        assertEquals("User does not exist", exp.getMessage());

    }

    @Test
    void getCurrentTickerPriceException() throws Exception {
        when(stockServiceFeignClient.getTickerPrice("tickerId")).thenThrow(new NullPointerException());
        TickerPriceNotFoundException exp = assertThrows(TickerPriceNotFoundException.class,
                () -> tradeDetailsServiceImpl.getCurrentTickerPrice("tickerId"));
        assertEquals("Unable to fetch ticker price currently", exp.getMessage());


    }

    @Test
    void updateTradeDetailsForSell() throws UserNotFoundException, TickerNotFoundException, TickerPriceNotFoundException {
        Map<String, BigDecimal> tickerResponse = new HashMap();
        tickerResponse.put("price_per_stock", new BigDecimal(20));
        TradeDetailsServiceImpl ts = Mockito.spy(this.tradeDetailsServiceImpl);
        Mockito.when(this.tradeDetailRepository.findById(tradeDetailId)).thenReturn(Optional.ofNullable(tradeDetailForSell));
        Mockito.when(this.userServiceFeignClient.getTradingDetails(BigInteger.ONE)).thenReturn(ResponseEntity.of(Optional.ofNullable(userTradingDetailsDto)));
        Mockito.when(this.tickerRepository.findById(1)).thenReturn(Optional.ofNullable(tickerDetails));
        Mockito.when(this.stockServiceFeignClient.getTickerPrice("INFY")).thenReturn(ResponseEntity.of(Optional.ofNullable(tickerResponse)));
        doReturn(tradeDetailDtoUpdated).when(ts).refreshForSell(any(),any());
//        Mockito.when(ts.refreshForSell(tradeDetailForSell,34.8)).thenReturn(tradeDetailDtoUpdated);
        TradeDetailDto tradeDetailDto1 = ts.updateTradeDetails(BigInteger.ONE, tradeDetailId);
        tradeDetailDto1.setCreatedAt(timestamp);
        Assertions.assertEquals(tradeDetailDto1.toString(), tradeDetailDtoUpdated.toString());
    }

    static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}