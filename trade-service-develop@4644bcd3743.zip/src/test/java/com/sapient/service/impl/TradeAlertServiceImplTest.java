package com.sapient.service.impl;

import com.sapient.client.AuthServiceFeignClient;
import com.sapient.client.UserServiceFeignClient;
import com.sapient.dto.TradeAlertDto;
import com.sapient.dto.ViewUserDto;
import com.sapient.entity.Tickers;
import com.sapient.entity.TradeAlert;
import com.sapient.entity.TradeDetail;
import com.sapient.entity.UserTradeAlert;
import com.sapient.exception.TickerNotFoundException;
import com.sapient.exception.TickerPriceNotFoundException;
import com.sapient.repository.TickerRepository;
import com.sapient.repository.TradeAlertRepository;
import com.sapient.repository.TradeDetailRepository;
import com.sapient.repository.UserTradeAlertRepository;
import com.sapient.service.TradeAlertService;
import com.sapient.service.TradeDetailsService;
import com.sapient.util.KafkaClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TradeAlertServiceImpl.class)
class TradeAlertServiceImplTest {

    @MockBean
    TradeAlertRepository tradeAlertRepository;

//    @MockBean
//    ObjectMapper objectMapper;

    @MockBean
    KafkaClientUtil kafkaClientUtil;

    @MockBean
    UserServiceFeignClient userServiceFeignClient;

    @MockBean
    AuthServiceFeignClient authServiceFeignClient;

    @MockBean
    TickerRepository tickerRepository;

    @MockBean
    UserTradeAlertRepository userTradeAlertRepository;

//    @MockBean
//    TradeAlertServiceImpl tradeAlertService;
//
//    @Autowired
//    TradeAlertServiceImpl tradeAlertService2;

    @Autowired
    TradeAlertService tradeAlertService;

    @MockBean
    TradeDetailRepository tradeDetailRepository;
    @MockBean
    ModelMapper modelMapper;

    @MockBean
    TradeDetailsService tradeDetailsService;

    @Test
    void handleTradeAlert() throws TickerNotFoundException, TickerPriceNotFoundException {

        TradeAlertDto tradeAlertDto = new TradeAlertDto(1,1440,"buy",
                new Timestamp(12345678), new Timestamp(123456789),90.00, 110.00);
        Tickers tickers = new Tickers(1,"tesla","TES", "stock");
        TradeAlert tradeAlert = new TradeAlert(null,null, 1440, "buy", new Timestamp(12345678),
                new Timestamp(123456789),90.00, 110.00);

        TradeAlert savedTradeAlert = new TradeAlert(UUID.randomUUID(),tickers, 1440, "buy", new Timestamp(12345678),
                new Timestamp(123456789),90.00, 110.00);

        ViewUserDto userDto = new ViewUserDto(BigInteger.ONE,"username","email@email.com","email@email.com","12347890","firstname","lastname");

        List<BigInteger> userIds = new ArrayList<>();
        userIds.add(BigInteger.ONE);

        UserTradeAlert userTradeAlert = new UserTradeAlert(UUID.randomUUID(),BigInteger.ONE,savedTradeAlert);
//        when(objectMapper.convertValue(any(), any(TradeAlert.class))).thenReturn(tradeAlert);

        when(modelMapper.map(tradeAlertDto,TradeAlert.class)).thenReturn(tradeAlert);
        when(tickerRepository.getById(any())).thenReturn(tickers);
        when(tradeAlertRepository.save(any())).thenReturn(savedTradeAlert);
        when(userServiceFeignClient.getUserIdsFromTickerNumber(any())).thenReturn(userIds);
        when(userTradeAlertRepository.save(any())).thenReturn(userTradeAlert);
        when(authServiceFeignClient.getUserEmailAndName(any())).thenReturn(userDto);
        when(tradeDetailsService.tradeAlertToDetails(any())).thenReturn(new TradeDetail());
        when(tradeDetailRepository.setTradeStatus(any())).thenReturn(null);
        doNothing().when(kafkaClientUtil).sendAlert(any());

        TradeAlert actual = tradeAlertService.handleTradeAlert(tradeAlertDto);

        assertEquals(savedTradeAlert,actual);


    }

//    @Test
//    void listOfUserIdsFromTickerNumber() {
//        Integer tickerNumber = 1;
//        List<BigInteger> userIds = new ArrayList<>();
//        userIds.add(BigInteger.ONE);
//        userIds.add(BigInteger.TEN);
//        when(userServiceFeignClient.getUserIdsFromTickerNumber(tickerNumber)).thenReturn(userIds);
//
//        List<BigInteger> actualList = tradeAlertService2.listOfUserIdsFromTickerNumber(tickerNumber);
//
//        assertEquals(userIds,actualList);
//
//
//    }
//
//    @Test
//    void saveInUserTradeAlert() {
//        TradeAlert tradeAlert = new TradeAlert();
//        BigInteger userId = BigInteger.ONE;
//        UserTradeAlert userTradeAlert = new UserTradeAlert();
//        userTradeAlert.setTradeAlert(tradeAlert);
//        userTradeAlert.setUserId(userId);
//        when(userTradeAlertRepository.save(any())).thenReturn(userTradeAlert);
//
//        UserTradeAlert actual = tradeAlertService.saveInUserTradeAlert(tradeAlert, userId);
//
//        assertEquals(userTradeAlert,actual);
//
//    }
//
//    @Test
//    void placeMessageInKafka() {
//    }
}