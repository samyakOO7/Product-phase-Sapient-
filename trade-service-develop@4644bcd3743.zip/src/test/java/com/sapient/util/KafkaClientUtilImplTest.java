package com.sapient.util;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.sapient.message.TradeAlertMessage;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.concurrent.ListenableFuture;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {KafkaClientUtilImpl.class})
class KafkaClientUtilImplTest {


    @Autowired
    KafkaClientUtilImpl util;
    @MockBean
    KafkaTemplate<String, TradeAlertMessage> template;
    List<ILoggingEvent> listOfLogs;

    @BeforeEach
    void setUpListAppender(){
        Logger logger = (Logger) LoggerFactory.getLogger(KafkaClientUtilImpl.class);
        logger.setLevel(ch.qos.logback.classic.Level.TRACE);
        ListAppender<ILoggingEvent> listAppender = new ListAppender<>();
        listAppender.start();
        logger.addAppender(listAppender);
        listOfLogs = listAppender.list;
    }
    @Test
    @DisplayName("Send alert should show success in logs")
    void testSendAlert_whenSentSuccessfully(){
        //arrange
        TradeAlertMessage alert  = new TradeAlertMessage();
        alert.setEmail("ash@gmail.com");
        alert.setDirection("buy");
        alert.setFirstName("Harish");
        alert.setUrl("domainname.com/tradealert");
        alert.setConfidenceScore("85.5");
        alert.setTickerSymbol("INFY50");
        alert.setTickerName("MyTickerInc");
        alert.setTimestamp(Timestamp.from(Instant.now()).toString());
        alert.setTimeframe("1440");

        Message<TradeAlertMessage> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, "alert-trade")
                .build();
        ProducerRecord<String, TradeAlertMessage> record = new ProducerRecord<>("alert-trade", alert);
        RecordMetadata metadata = new RecordMetadata(new TopicPartition("alert-trade", 0),0, 0, System.currentTimeMillis(),12,12 );
        ListenableFuture<SendResult<String, TradeAlertMessage>> alertFuture = Mockito.spy(new AsyncResult<>(new SendResult<>(record, metadata)));
        when(template.send(any(userMessage.getClass()))).thenReturn(alertFuture);
        //act
        util.sendAlert(alert);
        //assert
        verify(template).send(any(userMessage.getClass()));
        assertThat(listOfLogs).isNotNull().hasSize(2);
        assertThat(listOfLogs.get(0).toString())
                .contains("[DEBUG]")
                .contains("received request to send alert ");
        assertThat(listOfLogs.get(1).toString())
                .contains("[INFO]")
                .contains("Record sent successfully");
    }

    @Test
    @DisplayName("Send alert failed should log error")
    void testSendAlert_whenFailed(){
        //arrange
        TradeAlertMessage alert  = new TradeAlertMessage();
        alert.setEmail("ash@gmail.com");
        alert.setDirection("buy");
        alert.setFirstName("Harish");
        alert.setUrl("domainname.com/tradealert");
        alert.setConfidenceScore("85.5");
        alert.setTickerSymbol("INFY50");
        alert.setTickerName("MyTickerInc");
        alert.setTimestamp(Timestamp.from(Instant.now()).toString());
        alert.setTimeframe("1440");

        Message<TradeAlertMessage> userMessage = MessageBuilder
                .withPayload(alert)
                .setHeader(KafkaHeaders.TOPIC, "alert-trade")
                .build();
        ProducerRecord<String, TradeAlertMessage> record = new ProducerRecord<>("alert-trade", alert);
        RecordMetadata metadata = new RecordMetadata(new TopicPartition("alert-trade", 0),0, 0, System.currentTimeMillis(),12,12 );
        AsyncResult<SendResult<String, TradeAlertMessage>> alertFutur= new AsyncResult<>(new SendResult<>(record, metadata));
        ListenableFuture<SendResult<String, TradeAlertMessage>> alertFuture = alertFutur.forExecutionException(new KafkaProducerException(record, "kafka failed", new Exception()));
        when(template.send(any(userMessage.getClass()))).thenReturn(alertFuture);
        //act
        util.sendAlert(alert);
        //assert
        verify(template).send(any(userMessage.getClass()));
        assertThat(listOfLogs).isNotNull().hasSize(2);
        assertThat(listOfLogs.get(0).toString())
                .contains("[DEBUG]")
                .contains("received request to send alert ");
        assertThat(listOfLogs.get(1).toString())
                .contains("[ERROR]")
                .contains("Failed to send the record ");
    }
}