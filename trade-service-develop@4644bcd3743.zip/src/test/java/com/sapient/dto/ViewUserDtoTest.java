package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ViewUserDtoTest {

    ViewUserDto viewUserDto;

    ViewUserDto viewUserDto1;

    @BeforeEach
    void setUp() {
        viewUserDto = new ViewUserDto();
        viewUserDto1 = new ViewUserDto(BigInteger.ONE,"username","email@email.com","email@email.com","123456789","firstname","lastname");
    }

    @Test
    void getUserId() {
        BigInteger expected = BigInteger.ONE;
        viewUserDto.setUserId(expected);
        assertEquals(expected,viewUserDto.getUserId());
    }

    @Test
    void getUserName() {
        String expected = "username";
        viewUserDto1.setUserName(expected);
        assertEquals(expected,viewUserDto1.getUserName());
    }

    @Test
    void getEmail() {
        String expected = "username@Gmail.com";
        viewUserDto.setEmail(expected);
        assertEquals(expected,viewUserDto.getEmail());
    }

    @Test
    void getAlternateEmail() {
        String expected = "username@Gmail.com";
        viewUserDto.setAlternateEmail(expected);
        assertEquals(expected,viewUserDto.getAlternateEmail());
    }

    @Test
    void getPhoneNumber() {
        String expected = "1234567890";
        viewUserDto.setPhoneNumber(expected);
        assertEquals(expected,viewUserDto.getPhoneNumber());
    }

    @Test
    void getFirstName() {
        String expected = "firstname";
        viewUserDto.setFirstName(expected);
        assertEquals(expected, viewUserDto.getFirstName());
    }

    @Test
    void getLastName() {
        String expected = "lastname";
        viewUserDto.setLastName(expected);
        assertEquals(expected,viewUserDto.getLastName());
    }
}