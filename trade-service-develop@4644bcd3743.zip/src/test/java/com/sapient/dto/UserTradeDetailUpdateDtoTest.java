package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradeDetailUpdateDtoTest {

    UserTradeDetailUpdateDto userTradeDetailUpdateDto;

    @BeforeEach
    void setUp(){userTradeDetailUpdateDto=new UserTradeDetailUpdateDto();}

    @Test
    void getTradeDetailId() {
        UUID id=UUID.randomUUID();
        userTradeDetailUpdateDto.setTradeDetailId(id);
        assertEquals(id,userTradeDetailUpdateDto.getTradeDetailId());
    }

    @Test
    void getProfitTarget() {
        double profit=10.0;
        userTradeDetailUpdateDto.setProfitTarget(profit);
        assertEquals(profit,userTradeDetailUpdateDto.getProfitTarget());
    }

    @Test
    void getStopLoss() {
        double stoploss=10.0;
        userTradeDetailUpdateDto.setStopLoss(stoploss);
        assertEquals(stoploss,userTradeDetailUpdateDto.getStopLoss());
    }

    @Test
    void getQuantity() {
        Integer quantity=10;
        userTradeDetailUpdateDto.setQuantity(quantity);
        assertEquals(quantity,userTradeDetailUpdateDto.getQuantity());
    }


    @Test
    void testToString() {
        UserTradeDetailUpdateDto userTradeDetailUpdateDto1=new UserTradeDetailUpdateDto(UUID.randomUUID(),1,5.0,5.0);
        String expected = "UserTradeDetailUpdateDto{" +
                "tradeDetailId=" + userTradeDetailUpdateDto1.getTradeDetailId() +
                ", quantity=" + userTradeDetailUpdateDto1.getQuantity() +
                ", stopLoss=" + userTradeDetailUpdateDto1.getStopLoss()+
                ", profitTarget=" + userTradeDetailUpdateDto1.getProfitTarget() +
                '}';
        Assertions.assertEquals(expected, userTradeDetailUpdateDto1.toString());
    }

}