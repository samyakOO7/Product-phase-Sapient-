package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;


@DisplayName("Closed Trade Response DTO testing")
class ClosedTradeResponseDtoTest {

    private ClosedTradeResponseDto closedTradeResponseDto;

    String tickerId = "ESL";
    String tickerName = "Esterline Technologies Corporation";
    Timestamp tradeOpenedAt = new Timestamp(1);
    Timestamp tradeClosedAt = new Timestamp(10);
    Double gain = 35.0;
    Double pricePerTicker = 100.0;
    Double soldPricePerTicker = 350.0;
    Integer quantity =10;


    @BeforeEach
    public void loadClosedTradeResponseDto() {
        closedTradeResponseDto = new ClosedTradeResponseDto();
    }

    @Test
    @DisplayName("Getting ticker ID test")
    void getTickerId() {
        closedTradeResponseDto.setTickerId(tickerId);
        Assertions.assertEquals(tickerId, closedTradeResponseDto.getTickerId());
    }

    @Test
    @DisplayName("Getting ticker name test")
    void getTickerName() {
        closedTradeResponseDto.setTickerName(tickerName);
        Assertions.assertEquals(tickerName, closedTradeResponseDto.getTickerName());
    }

    @Test
    @DisplayName("Getting trade opened at test")
    void getTradeOpenedAt() {
        closedTradeResponseDto.setTradeOpenedAt(tradeOpenedAt);
        Assertions.assertEquals(tradeOpenedAt, closedTradeResponseDto.getTradeOpenedAt());

    }

    @Test
    @DisplayName("Getting trade closed at test")
    void getTradeClosedAt() {
        closedTradeResponseDto.setTradeClosedAt(tradeClosedAt);
        Assertions.assertEquals(tradeClosedAt, closedTradeResponseDto.getTradeClosedAt());
    }

    @Test
    @DisplayName("Getting gain test")
    void getGain() {
        closedTradeResponseDto.setGain(gain);
        Assertions.assertEquals(gain, closedTradeResponseDto.getGain());
    }

    @Test
    @DisplayName("Getting price per ticker test")
    void getPricePerTicker() {
        closedTradeResponseDto.setPricePerTicker(pricePerTicker);
        Assertions.assertEquals(pricePerTicker, closedTradeResponseDto.getPricePerTicker());
    }

    @Test
    @DisplayName("Getting sold price per ticker test")
    void getSoldPricePerTicker() {
        closedTradeResponseDto.setSoldPricePerTicker(soldPricePerTicker);
        Assertions.assertEquals(soldPricePerTicker, closedTradeResponseDto.getSoldPricePerTicker());
    }
    @Test
    @DisplayName("Getting quantity")
    void getQuantity() {
        closedTradeResponseDto.setQuantity(quantity);
        Assertions.assertEquals(quantity, closedTradeResponseDto.getQuantity());
    }

    @Test
    @DisplayName("Setting ticker ID test")
    void setTickerId() {
        closedTradeResponseDto.setTickerId(tickerId);
        Assertions.assertEquals(tickerId, closedTradeResponseDto.getTickerId());
    }

    @Test
    @DisplayName("Setting ticker name test")
    void setTickerName() {
        closedTradeResponseDto.setTickerName(tickerName);
        Assertions.assertEquals(tickerName, closedTradeResponseDto.getTickerName());
    }

    @Test
    @DisplayName("Setting trade opened at test")
    void setTradeOpenedAt() {
        closedTradeResponseDto.setTradeOpenedAt(tradeOpenedAt);
        Assertions.assertEquals(tradeOpenedAt, closedTradeResponseDto.getTradeOpenedAt());
    }

    @Test
    @DisplayName("Setting trade closed at test")
    void setTradeClosedAt() {
        closedTradeResponseDto.setTradeClosedAt(tradeClosedAt);
        Assertions.assertEquals(tradeClosedAt, closedTradeResponseDto.getTradeClosedAt());
    }

    @Test
    @DisplayName("Setting gain test")
    void setGain() {
        closedTradeResponseDto.setGain(gain);
        Assertions.assertEquals(gain, closedTradeResponseDto.getGain());
    }

    @Test
    @DisplayName("Setting price per ticker test")
    void setPricePerTicker() {
        closedTradeResponseDto.setPricePerTicker(pricePerTicker);
        Assertions.assertEquals(pricePerTicker, closedTradeResponseDto.getPricePerTicker());
    }

    @Test
    @DisplayName("Setting sold price per ticker test")
    void setSoldPricePerTicker() {
        closedTradeResponseDto.setSoldPricePerTicker(soldPricePerTicker);
        Assertions.assertEquals(soldPricePerTicker, closedTradeResponseDto.getSoldPricePerTicker());
    }
    @Test
    @DisplayName("Setting quantity")
    void setQuantity() {
        closedTradeResponseDto.setQuantity(quantity);
        Assertions.assertEquals(quantity, closedTradeResponseDto.getQuantity());
    }

    @Test
    void testHashCode() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        assertEquals(closedTradeResponseDto1.hashCode(), closedTradeResponseDto2.hashCode());
    }

    @Test
    void testEquals() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = true;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTickerId() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto("INFY", tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTickerName() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, "INFOSYS", tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTradeOpenedAt() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, new Timestamp(2), tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsTradeClosedAt() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, new Timestamp(11), gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsGain() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, 900.0, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsPricePerTicker() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, 1.0, soldPricePerTicker,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsSoldPricePerTicker() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, 1.0,quantity);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }
    @Test
    void testNotEqualsQuantity() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,11);
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsNull() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = null;
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsObject() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Object closedTradeResponseDto2 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Boolean expected = true;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testEqualsForSameObject() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        ClosedTradeResponseDto closedTradeResponseDto2 = closedTradeResponseDto1;
        Boolean expected = true;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);
    }

    @Test
    void testNotEqualsObject() {
        ClosedTradeResponseDto closedTradeResponseDto1 = new ClosedTradeResponseDto(tickerId, tickerName, tradeOpenedAt, tradeClosedAt, gain, pricePerTicker, soldPricePerTicker,quantity);
        Integer closedTradeResponseDto2 = 3;
        Boolean expected = false;
        Boolean actual = closedTradeResponseDto1.equals(closedTradeResponseDto2);
        assertEquals(expected, actual);

    }

}