package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradeDetailDtoTest {
    UserTradeDetailDto userTradeDetailDto;

    @BeforeEach
    void setUp() {
        userTradeDetailDto = new UserTradeDetailDto();
    }

    @Test
    void getTotalAmount() {
        double number = 1;
        userTradeDetailDto.setTotalAmount(number);
        assertEquals(number,userTradeDetailDto.getTotalAmount());
    }

    @Test
    void getAmountPerTrade() {
        double number = 1;
        userTradeDetailDto.setAmountPerTrade(number);
        assertEquals(number,userTradeDetailDto.getAmountPerTrade());
    }

    @Test
    void getTotalEquity() {
        double number = 1;
        userTradeDetailDto.setTotalEquity(number);
        assertEquals(number,userTradeDetailDto.getTotalEquity());
    }

    @Test
    void getRiskPerTrade() {
        double number = 1;
        userTradeDetailDto.setRiskPerTrade(number);
        assertEquals(number,userTradeDetailDto.getRiskPerTrade());
    }

    @Test
    void testToString() {
        UserTradeDetailDto userTradeDetailDto1=new UserTradeDetailDto(1.0,1.0,1.0,1.0);
        String expected = "UserTradeDetailDto{" +
                "totalAmount=" + userTradeDetailDto1.getTotalAmount() +
                ", amountPerTrade=" + userTradeDetailDto1.getAmountPerTrade() +
                ", totalEquity=" + userTradeDetailDto1.getTotalEquity() +
                ", riskPerTrade=" + userTradeDetailDto1.getRiskPerTrade() +
                '}';
        Assertions.assertEquals(expected, userTradeDetailDto1.toString());
    }
}
