package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTradeStatsDtoTest {
    UserTradeStatsDto userTradeStatsDto;

    @BeforeEach
    void setUp() {
        userTradeStatsDto = new UserTradeStatsDto();
    }

    @Test
    void getGain() {
        double number = 1;
        userTradeStatsDto.setGain(number);
        assertEquals(number,userTradeStatsDto.getGain());
    }

    void getLosing() {
        Integer number = 1;
        userTradeStatsDto.setLoosing(number);
        assertEquals(number,userTradeStatsDto.getLoosing());
    }
    void getWinning() {
        Integer number = 1;
        userTradeStatsDto.setWinning(number);
        assertEquals(number,userTradeStatsDto.getWinning());
    }

    void getTotalEquity() {
        double number = 1;
        userTradeStatsDto.setTotalEquity(number);
        assertEquals(number,userTradeStatsDto.getTotalEquity());
    }

    @Test
    void testToString() {
        UserTradeStatsDto userTradeStatsDto1=new UserTradeStatsDto(1.0,1,1,1.0);
        String expected = "UserTradeStatsDto{" +
                "gain=" + userTradeStatsDto1.getGain() +
                ", winning=" + userTradeStatsDto1.getWinning() +
                ", losing=" + userTradeStatsDto1.getLoosing()+
                ", totalEquity=" + userTradeStatsDto1.getTotalEquity() +
                '}';
        Assertions.assertEquals(expected, userTradeStatsDto1.toString());
    }





}
