package com.sapient.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TradeAlertDtoTest {

    TradeAlertDto tradeAlertDto;

    @BeforeEach
    void setUp() {
        tradeAlertDto = new TradeAlertDto();
    }

    @Test
    void getTickerNumber() {
        Integer expected = 1;
        ReflectionTestUtils.setField(tradeAlertDto,"tickerNumber",expected);
        assertEquals(expected,tradeAlertDto.getTickerNumber());
    }

    @Test
    void getTimeframe() {
        Integer expected = 1440;
        ReflectionTestUtils.setField(tradeAlertDto,"timeframe", expected);
        assertEquals(expected,tradeAlertDto.getTimeframe());
    }

    @Test
    void getTradeDirection() {
        String expected = "buy";
        ReflectionTestUtils.setField(tradeAlertDto,"tradeDirection", expected);
        assertEquals(expected,tradeAlertDto.getTradeDirection());

    }

    @Test
    void getGenerationTime() {
        Timestamp expected = new Timestamp(12334568);
        ReflectionTestUtils.setField(tradeAlertDto,"generationTime", expected);
        assertEquals(expected,tradeAlertDto.getGenerationTime());
    }

    @Test
    void getExpiryTime() {
        Timestamp expected = new Timestamp(12334568);
        ReflectionTestUtils.setField(tradeAlertDto,"expiryTime", expected);
        assertEquals(expected,tradeAlertDto.getExpiryTime());
    }

    @Test
    void getConfidence() {
        Double expected = 90.00;
        ReflectionTestUtils.setField(tradeAlertDto,"confidence", expected);
        assertEquals(expected,tradeAlertDto.getConfidence());
    }

    @Test
    void getAtr() {
        Double expected = 90.00;
        ReflectionTestUtils.setField(tradeAlertDto,"atr", expected);
        assertEquals(expected,tradeAlertDto.getAtr());
    }
}