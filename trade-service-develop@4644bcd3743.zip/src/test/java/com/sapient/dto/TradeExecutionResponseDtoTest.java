package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TradeExecutionResponseDtoTest {
    TradeExecutionResponseDto tradeExecutionResponseDto;

    @BeforeEach
    void setUp() {
        tradeExecutionResponseDto=new TradeExecutionResponseDto();
    }

    @Test
    void getMessage() {
        String message="message";
        tradeExecutionResponseDto.setMessage(message);
        assertEquals(message,tradeExecutionResponseDto.getMessage());
    }

    @Test
    void testToString() {
        TradeExecutionResponseDto tradeExecutionResponseDto1=new TradeExecutionResponseDto("message");
        String expected = "TradeExecutionResponse{" +
                "message='" + tradeExecutionResponseDto1.getMessage() + '\'' +
                '}';
        Assertions.assertEquals(expected, tradeExecutionResponseDto1.toString());
    }
}
