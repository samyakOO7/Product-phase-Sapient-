package com.sapient.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;
@DisplayName("UserTradeAlertDto Test")
class UserTradeAlertDtoTest {
    private UserTradeAlertDto tradeAlert;

    @BeforeEach
    public void loadUser() {
        tradeAlert = new UserTradeAlertDto();
    }

    @Test
    @DisplayName("TradeAlertId Test")
    void getTradeAlertsId() {

        UUID id = UUID.randomUUID();
        tradeAlert.setTradeAlertId(id);
        Assertions.assertEquals(id, tradeAlert.getTradeAlertId());
    }

    @Test
    @DisplayName("TickerName Test")
    void getTickerName() {

        String s = "hdfc";
        tradeAlert.setTickerName(s);
        Assertions.assertEquals(s,tradeAlert.getTickerName());
    }

    @Test
    @DisplayName("Timeframe Test")
    void getTimeframe() {

        Integer t = 1;
        tradeAlert.setTimeframe(t);
        Assertions.assertEquals(t, tradeAlert.getTimeframe());
    }

    @Test
    @DisplayName("TradeDirection Test")
    void getTradeDirection() {

        String  direction = "buy";
        tradeAlert.setTradeDirection(direction);
        Assertions.assertEquals(direction, tradeAlert.getTradeDirection());
    }

    @Test
    @DisplayName("Timestamp Test")
    void getTimestamp() {
        Timestamp timestamp=Timestamp.from(Instant.now());
        tradeAlert.setTimestamp(timestamp);
        Assertions.assertEquals(timestamp, tradeAlert.getTimestamp());
    }

    @Test
    @DisplayName("Confidence Test")
    void getConfidence() {

        Double n=80.0;
        tradeAlert.setConfidence(n);
        Assertions.assertEquals(n, tradeAlert.getConfidence());
    }


    @Test
    void testToString() {
        Timestamp timestamp = Timestamp.from(Instant.now());
        UserTradeAlertDto userTradeAlertDto = new UserTradeAlertDto(UUID.randomUUID(),1,1,"buy",timestamp,80.0,"stock");
        String expected = "UserTradeAlertDto{" +
                "tradeAlertId=" + userTradeAlertDto.getTradeAlertId() +
                ", tickerNumber=" + userTradeAlertDto.getTickerNumber() +
                ", timeframe=" + userTradeAlertDto.getTimeframe() +
                ", tradeDirection='" + userTradeAlertDto.getTradeDirection() + '\'' +
                ", timestamp=" + userTradeAlertDto.getTimestamp() +
                ", confidence=" + userTradeAlertDto.getConfidence() +
                ", tickerName='" + userTradeAlertDto.getTickerName() + '\'' +
                '}';
        Assertions.assertEquals(expected, userTradeAlertDto.toString());
    }

}
