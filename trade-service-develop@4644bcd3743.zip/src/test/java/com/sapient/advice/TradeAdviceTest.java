package com.sapient.advice;

import com.sapient.constant.Constant;
import com.sapient.exception.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TradeAdvice.class)
class TradeAdviceTest {

    @Autowired
    TradeAdvice tradeAdvice;

    @Test
    void handleEntityNotFoundShouldReturnMapWhenTradeAlertNotFoundExceptionPassed() {
        UUID tradeAlertId = UUID.randomUUID();
        TradeAlertNotFoundException ex = new TradeAlertNotFoundException(tradeAlertId);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put(Constant.CODE.toString(), "NOT_FOUND");
        message.put(Constant.MESSAGE.toString(), ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, tradeAdvice.handleEntityNotFound(ex));
    }

    @Test
    void userNotFoundShouldReturnMapWhenUserNotFoundExceptionPassed() {
        String msg = Constant.USER_NOT_FOUND.toString();
        UserNotFoundException ex = new UserNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.USER_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, tradeAdvice.userNotFound(ex));
    }

    @Test
    void parameterNotFoundShouldReturnMapWhenParameterNotFoundExceptionPassed() {
        String msg = Constant.NO_CLOSED_TRADES.toString();
        ParameterNotFoundException ex = new ParameterNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.PARAMETER_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, tradeAdvice.parameterNotFound(ex));
    }

    @Test
    void listNotFoundShouldReturnMapWhenListOfAlertNotFoundExceptionPassed() {
        String msg = Constant.LIST_NOT_FOUND.toString();
        ListOfAlertNotFoundException ex = new ListOfAlertNotFoundException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.LIST_NOT_FOUND.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, tradeAdvice.listNotFound(ex));
    }

    @Test
    void emptyClosedTradeShouldReturnMapWhenNoClosedTradesExceptionPassed() {
        String msg = Constant.NO_CLOSED_TRADES.toString();
        NoClosedTradesException ex = new NoClosedTradesException(msg);
        List<Object> messages = new ArrayList<>();
        Map<String, String> message = new HashMap<>();
        message.put("code", Constant.NO_CLOSED_TRADES.name());
        message.put("message", ex.getMessage());
        messages.add(message);
        Map<String, List<Object>> expectedResult = new HashMap<>();
        expectedResult.put("errors", messages);
        assertEquals(expectedResult, tradeAdvice.emptyClosedTrade(ex));
    }
}