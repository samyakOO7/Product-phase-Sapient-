export const SMALL_SCREEN_ONLY_CLASS = "d-block d-md-none ";
export const LARGE_SCREEN_ONLY_CLASS = "d-none d-md-block "; 
export const SMALL_SCREEN_ONLY_TR_CLASS = "d-table-row d-md-none ";
export const LARGE_SCREEN_ONLY_TR_CLASS = "d-none d-md-table-row "; 
export const BADGE_STYLE_CLASS = "p-0 m-0 px-1 badge-font trade-detail-badge alert alert-";
export const MAX_SMALL_SCREEN_WIDTH = 768;
// Hook
export const MOBILE_MAX_THRESHOLD = 768;
export const TAB_MAX_THRESHOLD = 992;