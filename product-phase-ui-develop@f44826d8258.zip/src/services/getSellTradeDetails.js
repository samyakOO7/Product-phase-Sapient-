import axios from "axios";
import { toast } from "react-toastify";
import { LOAD_TRADE_DETAIL_MODAL } from "../config/typeConstants";
import { fetchTradeDetailForSellUrl } from "../config/urlConstants";
import { logger } from "../utils/logger";
import { refreshAccessToken } from "../utils/refreshAccessToken";

export const getSellTradeDetails = async (
  userPortfolioId,
  tradeDetailModalDispatcher,
  setShowModal
) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    const response = await axios.post(
      fetchTradeDetailForSellUrl,
      { userPortfolioId },
      config
    );
    tradeDetailModalDispatcher({
      type: LOAD_TRADE_DETAIL_MODAL,
      payload: response.data,
    });

    setShowModal(true);
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        getSellTradeDetails(
          userPortfolioId,
          tradeDetailModalDispatcher,
          setShowModal
        );
      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(err.message);
      }
    } else {
      logger.error("Error in fetching trade details - " + error.message);
      toast.error("Unable to fetch trade details, try after some time!");
    }
  }
};
