import { REMOVE_TICKER_FROM_WATCHLIST } from "../config/typeConstants";
import axios from "axios";
import { deleteFromWatchlistUrl } from "../config/urlConstants";
import { refreshAccessToken } from "../utils/refreshAccessToken";
import { logger } from "../utils/logger";
import { toast } from "react-toastify";

const removeTickerFromWatchlist = async (
  tickerNumber,
  userId,
  dashboardDispatcher
) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  try {
    await axios.post(deleteFromWatchlistUrl, { userId, tickerNumber }, config);

    dashboardDispatcher({
      type: REMOVE_TICKER_FROM_WATCHLIST,
      payload: tickerNumber,
    });
  } catch (error) {
    const { errors } = error?.response?.data;
    const { status } = error?.response;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        removeTickerFromWatchlist(tickerNumber, userId, dashboardDispatcher);
      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error("Error in feching dashboard data" + err.message);
        toast.error(err.message);
      }
    } else {
      logger.error(
        "Unknown error occurred in getUserWatchlist()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};
export default removeTickerFromWatchlist;
