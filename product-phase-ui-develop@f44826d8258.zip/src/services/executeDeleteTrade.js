import axios from "axios";
import { toast } from "react-toastify";
import {
  executeTradeURL,
  deleteTradeURL,
  refreshTradeDetailUrl,
} from "../config/urlConstants.js";
import { logger } from "../utils/logger";
import { loadTradeDetails } from "../context/trade/TradeState.jsx";
import { tradeMicroServiceUrl } from "./../config/urlConstants";
import { REFRESH_TRADE_MODAL } from "./../config/typeConstants";
export const executeTrade = async (executeTradeDetail) => {
  const {
    tradeDetailId,
    stopLoss,
    profitTarget,
    quantity,
    userId,
    currentPage,
    tradeDetailDispatcher,
    setExecuteDisabledState,
    setShowModal,
  } = executeTradeDetail;
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    if (typeof setExecuteDisabledState !== "undefined")
      setExecuteDisabledState(true);
    const res = await axios.post(
      executeTradeURL,
      {
        tradeDetailId,
        stopLoss: parseFloat(stopLoss),
        profitTarget: parseFloat(profitTarget),
        quantity,
      },
      config
    );
    logger.info({ message: res.data.message });
    logger.info(res);
    const message =
      res.data?.message?.charAt(0).toUpperCase() + res.data?.message?.slice(1);
    toast.success(message);
  } catch (error) {
    if (typeof setExecuteDisabledState !== "undefined")
      setExecuteDisabledState(false);
    logger.error({ errorName: "executeDetail", error });
    if (error.response.status === 0) {
      toast.error("Please check internet connection");
    } else if (error.response.status >= 400) {
      logger.info(error.response.data);
      toast.error(error.response.data.errors[0].message);
    } else {
      toast.error(error.message);
    }
    throw error;
  } finally {
    loadTradeDetails(userId, currentPage - 1, tradeDetailDispatcher);
    if (typeof setExecuteDisabledState !== "undefined")
      setExecuteDisabledState(false);
    if (typeof setShowModal !== "undefined") setShowModal(false);
  }
};

export const deleteTrade = async (
  tradeDetailId,
  userId,
  currentPage,
  tradeDetailDispatcher
) => {
  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    let res = await axios.delete(`${deleteTradeURL}/${tradeDetailId}`, config);
    logger.info({ message: res.data.message });
    logger.info(res);

    loadTradeDetails(userId, currentPage - 1, tradeDetailDispatcher);
    return res.data;
  } catch (error) {
    logger.error({ errorName: "deleteTrade", error });
    if (error.response.status === 0) {
      toast.error("Please check internet connection");
    } else if (error.response.status >= 400) {
      toast.error("Can't delete the trade. Please, try again later");
    } else {
      toast.error(error.message);
    }
    throw error;
  }
};
export const refreshTrade = async (
  tradeDetailId,
  userId,
  dispatcher,
  tradeDetailDispatcher
) => {
  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    const res = await axios.get(
      `${tradeMicroServiceUrl}${refreshTradeDetailUrl}/${userId}/${tradeDetailId}`,
      config
    );
    logger.info("refreshed trade" + res.data);
    dispatcher({
      type: REFRESH_TRADE_MODAL,
      payload: res.data,
      detailDispatcher: tradeDetailDispatcher,
    });
    toast.success("Refreshed Successfully");
  } catch (error) {
    logger.info("error refreshing trade details with id: " + tradeDetailId);
    toast.error("Unable to refresh trade at the moment");
  }
};
