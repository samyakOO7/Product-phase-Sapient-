import axios from "axios";
import { toast } from "react-toastify";

import {
  tradeAlertDataURL,
  getTradeDetailsUrl,
  deleteTradeAlertUrl,
} from "../config/urlConstants";
import { logger } from "../utils/logger";
import { refreshAccessToken } from "../utils/refreshAccessToken";
export default async function tradeAlertsData(userId) {
  try {
    const response = await axios.get(`${tradeAlertDataURL}/${userId}`);
    logger.info("trade elert data fetched " + response.data);
    return response.data;
  } catch (error) {
    const { errors } = error?.response?.data;

    const status = error?.response?.status;

    if (status === 403) {
      logger.warn("Access token expired");

      if (refreshAccessToken()) {
        tradeAlertsData(userId);
      }
    }else if(status === 404){
      return [];
    }else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error("Error in fetching tradeAlertsData()" + err?.message);

        toast.error(err?.message);
      }
    } else {
      logger.error("Error in fetching trade details - " + error.message);

      toast.error("Unable to fetch trade alerts, try after some time!");
    }
  }
}

export const handleDeleteTradeAlert = async (navigate, userId, alertId) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    await axios.delete(`${deleteTradeAlertUrl}/${userId}/${alertId}`, config);

    navigate("/alerts");
  } catch (error) {
    
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        handleDeleteTradeAlert(navigate, userId, alertId);
      }
    } else {
      logger.error("Error in deleting trade alert - " + error.message);
      toast.error("Unable to delete trade alert, try after some time!");
    }
  }
};

export const handleGetTradeDetails = async (userId, alertId) => {
  const data = {
    userId: userId,
    tradeAlertId: alertId,
  };
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    const response = await axios.post(getTradeDetailsUrl, data, config);
    return response.data;
  } catch (error) {
    
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        handleGetTradeDetails(userId, alertId);
      }
    } else {
      logger.error("Error in fetching trade details - " + error.message);
      toast.error("Unable to fetch trade details, try after some time!");
    }
  }
};
