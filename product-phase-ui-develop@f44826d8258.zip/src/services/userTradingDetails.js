import axios from "axios";
import { getTradingDetails, postTradingDetails } from "../config/urlConstants";
import { logger } from "../utils/logger";
import { refreshAccessToken } from "../utils/refreshAccessToken";
import { toast } from "react-toastify";


export const getUserTradingDetails = async (userId) => {
  try {
    const response = await axios.get(`${getTradingDetails}/${userId}`);
    logger.info("Data successfully fetched");
    return response.data;
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403   ) {
      logger.warn("Access token expired"  );
      if (refreshAccessToken()) {
        getUserTradingDetails(userId);
      }
    } else if (errors?.length > 0) {
      errors.forEach((err) => {
        logger.error(
          `${err.message} for user ${userId} in getting user trading details`
        );
      });
    } else {
      logger.error(
        "Unknown error occurred in getUserTradingDetails()()" +
          errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};

export const postUserTradingDetails = async (obj) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  let url = postTradingDetails;

  try {
    await axios.post(url, obj, config);
    return 0;
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403 ) {
      logger.warn("Access token expired"  );
      if (refreshAccessToken()) {
        postUserTradingDetails(obj);
      }
    } else if (errors?.length > 0) {
      errors.forEach((err) => {
        logger.error(
          `${err.message} for user ${obj} in posting user trading details`
        );
        toast.error(err.message);
      });
    } else {
      logger.error(
        "Unknown error occurred in postUserTradingDetails()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};
