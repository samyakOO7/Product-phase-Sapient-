import '@testing-library/jest-dom';
import axios from 'axios';
import { getSellTradeDetails } from "../getSellTradeDetails";
import { refreshAccessToken } from "../../utils/refreshAccessToken";
import { toast } from "react-toastify";
import { fetchTradeDetailForSellUrl} from "../../config/urlConstants";

jest.mock('axios');
jest.mock("../../utils/logger");
jest.mock("../../utils/refreshAccessToken");
jest.mock("react-toastify");

let userPortfolioId = 1;
let tradeDetailModalDispatcher = jest.fn();
let setShowModal = jest.fn();
let successResponse = {
  data: {
    tradeDetailId: "2c6f51ed-0ea2-477a-9b5b-ae0f59233143",
    userId: 1,
    ticker: {
      tickerNumber: 45681,
      tickerName: "ICICI Bank Ltd",
      tickerId: "ICICI.BNK",
      tickerType: "stock"
    },
    timeframe: 1440,
    tradeDirection: "sell",
    createdAt: "2022-09-25T18:30:00.000+00:00",
    pricePerTicker: 300.0,
    quantity: 5,
    totalCost: 1500.0,
    stopLoss: 5.0,
    profitTarget: 0.5,
    status: "no action",
    tradeAlert: null,
    gain: 1000,
    riskToRewardRatio: 10.0
  }
}
let errorResponse = {
  response: {
    data: {
        errors: [
            {
                message: "Error message",
                code: "INVALID_ACCESS_TOKEN"
            }
        ]
    },
    status: 403
}
};
let config = {
  headers: {
    "Content-Type": "application/json"
  }
};

describe('Test for getSellTradeDetails', () => {
  test('should return response data on successful get call', async () => {
    axios.post.mockResolvedValueOnce(successResponse);

    //when        
    await getSellTradeDetails(userPortfolioId, tradeDetailModalDispatcher, setShowModal);

    //then
    expect(axios.post).toBeCalledWith(fetchTradeDetailForSellUrl,{userPortfolioId},config);
    expect(axios.post).toHaveBeenCalledTimes(1);
  })
  test('should call refreshAccessToken() if access token is expired', async () => {

    axios.post.mockReturnValue(Promise.reject(errorResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    await getSellTradeDetails(userPortfolioId, tradeDetailModalDispatcher, setShowModal);

    expect(axios.post).toHaveBeenCalledWith(fetchTradeDetailForSellUrl,{userPortfolioId}, config);
    expect(refreshAccessToken).toBeCalled();
  })
  test('should display toast for some other error', async () => {
    let obj = {
      response: {
        data: [],
        status: 500,
      },
    };
    
    axios.post.mockReturnValue(Promise.reject(obj));
    refreshAccessToken.mockResolvedValueOnce(false);

    await getSellTradeDetails(userPortfolioId, tradeDetailModalDispatcher, setShowModal);
    
    expect(axios.post).toHaveBeenCalledWith(fetchTradeDetailForSellUrl,{userPortfolioId}, config);
    expect(toast.error).toHaveBeenCalled();
  })
  test('should show logs for multiple errors', async () => {
    let obj = {
      response: {
        data: {
            errors: [
                {
                    message: "Error message",
                    code: "NO_PAGE_FOUND"
                }
            ]
        },
        status: 404
    }
    }
    
    axios.post.mockReturnValue(Promise.reject(obj));

    await getSellTradeDetails(userPortfolioId, tradeDetailModalDispatcher, setShowModal);
    
    expect(axios.post).toHaveBeenCalledWith(fetchTradeDetailForSellUrl,{userPortfolioId}, config);
  })
})