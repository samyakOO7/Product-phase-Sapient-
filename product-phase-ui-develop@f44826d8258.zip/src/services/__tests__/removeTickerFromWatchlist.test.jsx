import '@testing-library/jest-dom';
import axios from 'axios';
import { deleteFromWatchlistUrl,deleteTradeAlertUrl, getTradeDetailsUrl, tradeAlertDataURL } from '../../config/urlConstants';
import tradeAlertsData, { handleDeleteTradeAlert, handleGetTradeDetails } from '../tradeAlertsData';
import { refreshAccessToken } from "../../utils/refreshAccessToken";
import removeTickerFromWatchlist from '../removeTickerFromWatchlist';
jest.mock("axios");
jest.mock("../../utils/logger");
jest.mock("../../utils/refreshAccessToken");
jest.mock('react-toastify')
let dashboardDispatcher = jest.fn();
let handleRemove=jest.fn();
jest.mock("pino", () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn(),
      success:jest.fn()
    };
});

let userId = 1;
let alertId=1;

const config = {
    headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": true,
        "Access-Control-Allow-Headers": "*",
      },
  
      mode: "cors",
  };


describe('handleDeleteTradeAlert function',() => {
   
    test('should return response status 204 on successful deletion of trade alert', async() => {
        axios.post.mockResolvedValue({
            status:204
        })
        await removeTickerFromWatchlist(101,1,dashboardDispatcher);
        expect(axios.post).toHaveBeenCalledTimes(1);
       
    })

    test('should throw error when access token is invalid', () => {
        
        let errResponse = {
            response: {
                data: {
                    errors: [
                        {   
                            message: "Error message",
                            code: "INVALID_ACCESS_TOKEN"
                        }
                    ]
                },
                status: 403
            }
        };

        let errResponse2 = {
            response: {
                data: {
                    errors: [
                        {   
                            message: "Error message",
                            code: "INVALID_ACCESS"
                        }
                    ]
                },
                status: 404
            }
        };

        axios.post.mockReturnValue(Promise.reject(errResponse));
        refreshAccessToken.mockResolvedValueOnce(false);

        removeTickerFromWatchlist(101,1,dashboardDispatcher);
        expect(axios.post).toHaveBeenCalledTimes(1);
       
        axios.post.mockReturnValue(Promise.reject(errResponse2));
        refreshAccessToken.mockResolvedValueOnce(false);
        removeTickerFromWatchlist(101,1,dashboardDispatcher);
        expect(axios.post).toHaveBeenCalledTimes(2)

        let errResponse3 = {
            response: {
                data: {
                    errors: [
                       
                    ]
                },
                status: 404
            }
        };

        axios.post.mockReturnValue(Promise.reject(errResponse3));
        refreshAccessToken.mockResolvedValueOnce(false);
        removeTickerFromWatchlist(101,1,dashboardDispatcher);
        expect(axios.post).toHaveBeenCalledTimes(3)

        axios.post.mockReturnValue(Promise.reject(errResponse));
        refreshAccessToken.mockResolvedValueOnce(true);
        removeTickerFromWatchlist(101,1,dashboardDispatcher);
        expect(axios.post).toHaveBeenCalledTimes(4
            )


     


    })
   
})