import "@testing-library/jest-dom";
import axios from "axios";
import {
  deleteTradeAlertUrl,
  getTradeDetailsUrl,
  tradeAlertDataURL,
} from "../../config/urlConstants";
import tradeAlertsData, {
  handleDeleteTradeAlert,
  handleGetTradeDetails,
} from "../tradeAlertsData";
import { refreshAccessToken } from "../../utils/refreshAccessToken";

jest.mock("axios");
jest.mock("../../utils/logger");
jest.mock("../../utils/refreshAccessToken");
jest.mock("react-toastify");
jest.mock("pino", () => () => {
  return {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
    success: jest.fn(),
  };
});

let userId = 1;
let alertId = 1;

const config = {
  headers: {
    "Content-Type": "application/json",
  },
};
describe("tradeAlertsData function", () => {
  test("should return trade-alerts on successful api call", async () => {
    axios.get.mockResolvedValue({
      data: [
        {
          tickerName: "RELIANCE",
          tradeAlertId: "123e4567-e89b-12d3-a456-426655440000",
          tickerNumber: 1,
          timeframe: 10,
          tradeDirection: "buy",
          timestamp: "2022-09-21T03:00:00.010+00:00",
          timeToLive: 11,
          confidence: 10,
        },

        {
          tickerName: "WIPRO",
          tradeAlertId: "123e4567-e89b-12d3-a456-426655440000",
          tickerNumber: 1,
          timeframe: 10,
          tradeDirection: "buy",
          timestamp: "2022-09-21T03:00:00.010+00:00",
          timeToLive: 11,
          confidence: 10,
        },
      ],
    });
    const resData = await tradeAlertsData(userId);
    expect(resData[0].tickerName).toEqual("RELIANCE");
    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toBeCalledWith(`${tradeAlertDataURL}/${userId}`);
  });

  test("should throw error when access token is invalid", () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    axios.get.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    tradeAlertsData(userId);

    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toBeCalledWith(`${tradeAlertDataURL}/${userId}`);
  });
  test("should throw all the errors when there are multiple errors in fetching alerts", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_USER_ID",
            },
          ],
        },
        status: 401,
      },
    };
    axios.get.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    await tradeAlertsData(userId);

    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toBeCalledWith(`${tradeAlertDataURL}/${userId}`);
  });
  test("should throw error when internal server error", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [],
        },
        status: 500,
      },
    };
    axios.get.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    await tradeAlertsData(userId);

    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toBeCalledWith(`${tradeAlertDataURL}/${userId}`);
  });
  test("should return empty array when status is 404", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [],
        },
        status: 404,
      },
    };
    axios.get.mockReturnValue(Promise.reject(errResponse));

    await tradeAlertsData(userId);

    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(axios.get).toBeCalledWith(`${tradeAlertDataURL}/${userId}`);
  });
});

describe("handleDeleteTradeAlert function", () => {
  test("should return response status 204 on successful deletion of trade alert", async () => {
    axios.delete.mockResolvedValue({
      status: 204,
    });
    await handleDeleteTradeAlert(jest.fn(), userId, alertId);
    expect(axios.delete).toHaveBeenCalledTimes(1);
  });

  test("should throw error when access token is invalid", () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    axios.delete.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    handleDeleteTradeAlert(jest.fn(), userId, alertId);

    expect(axios.delete).toHaveBeenCalledTimes(1);
    expect(axios.delete).toBeCalledWith(
      `${deleteTradeAlertUrl}/${userId}/${alertId}`,
      config
    );
  });

  test("should throw error for interal server error", () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INTERNAL_SERVER_ERROR",
            },
          ],
        },
        status: 500,
      },
    };
    axios.delete.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    handleDeleteTradeAlert(jest.fn(), userId, alertId);

    expect(axios.delete).toHaveBeenCalledTimes(1);
    expect(axios.delete).toBeCalledWith(
      `${deleteTradeAlertUrl}/${userId}/${alertId}`,
      config
    );
  });
});

describe("handleGetTradeDetails", () => {
  const data = {
    userId: userId,
    tradeAlertId: alertId,
  };
  test("should return status code of 200 on successful api call", async () => {
    axios.post.mockResolvedValue({
      status: 200,
      data: {
        tickerName: "HUL",
      },
    });
    const actualResponse = await handleGetTradeDetails(userId, alertId);
    expect(axios.post).toHaveBeenCalledTimes(1);
    expect(actualResponse.tickerName).toBe("HUL");
  });

  test("should throw error when access token is invalid", () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    axios.post.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    handleGetTradeDetails(userId, alertId);
    expect(axios.post).toHaveBeenCalledTimes(1);
    expect(axios.post).toBeCalledWith(getTradeDetailsUrl, data, config);
  });

  test("should throw error for internal server error", () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INTERNAL_SERVER_ERROR",
            },
          ],
        },
        status: 500,
      },
    };
    axios.post.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    handleGetTradeDetails(userId, alertId);
    expect(axios.post).toHaveBeenCalledTimes(1);
    expect(axios.post).toBeCalledWith(getTradeDetailsUrl, data, config);
  });
});
