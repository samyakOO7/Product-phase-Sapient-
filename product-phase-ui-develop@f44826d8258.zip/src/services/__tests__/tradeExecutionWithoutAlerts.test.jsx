import '@testing-library/jest-dom';
import axios from 'axios';
import { getSellTradeDetails } from "../getSellTradeDetails";
import { toast } from "react-toastify";
import  logger  from "../../utils/logger";
import { fetchTradeDetailForSellUrl, getTradeDetailModalURL, getTradeDetailsUrl } from "../../config/urlConstants";
import { handleGetWatchlistId } from '../tradeExecutionWithoutAlerts';
import { refreshAccessToken } from '../../utils/refreshAccessToken';

jest.mock('axios');
jest.mock("../../utils/logger");
jest.mock("../../utils/refreshAccessToken");
jest.mock("react-toastify");

let successResponse = {
  data: {
    tradeDetailId: "2c6f51ed-0ea2-477a-9b5b-ae0f59233143",
    userId: 1,
    ticker: {
      tickerNumber: 45681,
      tickerName: "ICICI Bank Ltd",
      tickerId: "ICICI.BNK",
      tickerType: "stock"
    },
    timeframe: 1440,
    tradeDirection: "buy",
    createdAt: "2022-09-25T18:30:00.000+00:00",
    pricePerTicker: 300.0,
    quantity: 5,
    totalCost: 1500.0,
    stopLoss: 5.0,
    profitTarget: 0.5,
    status: "no action",
    tradeAlert: null,
    gain: null,
    riskToRewardRatio: 10.0
  }
}
let errorResponse = {

  message: "error message 1",

  status : 403,
  
  code :  "INVALID_ACCESS_TOKEN"
  
  }

let config = {
    headers: {
        "Content-Type": "application/json",
        "Acess-Control-Allow-Origin": "*",
      },
};

describe('Test for tradeExecutionWithoutAlerts', () => {
  test('should return response data on successful get call', async () => {
    axios.get.mockResolvedValueOnce(successResponse);

    let expectedResponse = {
        tradeDetailId: "2c6f51ed-0ea2-477a-9b5b-ae0f59233143",
        userId: 1,
        ticker: {
            tickerNumber: 45681,
            tickerName: "ICICI Bank Ltd",
            tickerId: "ICICI.BNK",
            tickerType: "stock"
        },
        timeframe: 1440,
        tradeDirection: "buy",
        createdAt: "2022-09-25T18:30:00.000+00:00",
        pricePerTicker: 300.0,
        quantity: 5,
        totalCost: 1500.0,
        stopLoss: 5.0,
        profitTarget: 0.5,
        status: "no action",
        tradeAlert: null,
        gain: null,
        riskToRewardRatio: 10.0
      };
      let actualResponse = await handleGetWatchlistId(1, 45681);
  
      expect(axios.get).toHaveBeenCalledWith(`${getTradeDetailModalURL}/1/45681`,config);
      expect(JSON.stringify(actualResponse)).toBe(
        JSON.stringify(expectedResponse)
      );
      // logger.success.mockmockImplementation();
    //   expect(handleGetWatchlistId(1, 45681)).toEqual(actualResponse)
  })
  test('should call refreshAccessToken() if access token is expired', async () => {

    axios.get.mockReturnValue(Promise.reject(errorResponse));
    refreshAccessToken.mockResolvedValueOnce(false);

    await handleGetWatchlistId(1, 45681);
    
    expect(axios.get).toHaveBeenCalledWith(`${getTradeDetailModalURL}/1/45681`,config);
    expect(refreshAccessToken).toBeCalled();
    
  })
  test('should display toast for some other error', async () => {
    let obj = {
      response: {
        data: {
            errors: [
              {
                message: "Error message 1",
                code: "INVALID_USERNAME",
              },
              {
                message: "Error message 2",
                code: "INVALID_PASSWORD",
              },
            ],
          },
        status: 500,
      },
    };
    
    axios.get.mockReturnValue(Promise.reject(obj));
    refreshAccessToken.mockResolvedValueOnce(false);

    await handleGetWatchlistId(1, 45681);
    
    expect(axios.get).toHaveBeenCalledWith(`${getTradeDetailModalURL}/1/45681`,config);
    expect(toast.error).toHaveBeenCalled();
    
  })
})