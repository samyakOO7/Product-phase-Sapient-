import {
  getUserTradingDetails,
  postUserTradingDetails,
} from "../userTradingDetails";
import axios from "axios";
import {
  getTradingDetails,
  postTradingDetails,
} from "../../config/urlConstants";
import { refreshAccessToken } from "../../utils/refreshAccessToken";
import { toast } from "react-toastify";

jest.mock("axios");
jest.mock("../../utils/logger");
jest.mock("../../utils/refreshAccessToken");
jest.mock("react-toastify");

describe("Tests for getUserTradingDetails", () => {
  it("should return response data for successful get call", async () => {
    let obj = {
      data: {
        totalAmount: 50000,
        amountPerTrade: 10,
        riskPerTrade: 3,
        totalEquity: 50000,
      },
    };
    axios.get.mockResolvedValueOnce(obj);

    let expectedResponse = {
      totalAmount: 50000,
      amountPerTrade: 10,
      riskPerTrade: 3,
      totalEquity: 50000,
    };
    let actualResponse = await getUserTradingDetails(1);

    expect(axios.get).toHaveBeenCalledWith(`${getTradingDetails}/1`);
    expect(JSON.stringify(actualResponse)).toBe(
      JSON.stringify(expectedResponse)
    );
  });

  it("should call refreshAccessToken() for invalid access token error", async () => {
    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    axios.get.mockReturnValue(Promise.reject(obj));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getUserTradingDetails(1);
    expect(axios.get).toHaveBeenCalledWith(`${getTradingDetails}/1`);
    expect(refreshAccessToken).toBeCalled();
  });

  it("should display toast for mutiple errors", async () => {
    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "INVALID_USERNAME",
            },
            {
              message: "Error message 2",
              code: "INVALID_PASSWORD",
            },
          ],
        },
        status: 400,
      },
    };
    axios.get.mockReturnValue(Promise.reject(obj));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getUserTradingDetails(1);
    expect(axios.get).toHaveBeenCalledWith(`${getTradingDetails}/1`);
  });

  it("should display toast for unknown error", async () => {
    let obj = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };
    axios.get.mockReturnValue(Promise.reject(obj));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getUserTradingDetails(1);
    expect(axios.get).toHaveBeenCalledWith(`${getTradingDetails}/1`);
    expect(toast.error).toHaveBeenCalled();
  });
});

describe("Tests for postUserTradingDetails", () => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  let obj = {
    data: {
      totalAmount: 50000,
      amountPerTrade: 10,
      riskPerTrade: 3,
      totalEquity: 50000,
    },
  };

  it("should return response data for successful post call", async () => {
    axios.post.mockResolvedValueOnce(obj);
    await postUserTradingDetails(obj);
    expect(axios.post).toHaveBeenCalledWith(postTradingDetails, obj, config);
  });
  it("should call refreshAccessToken() for invalid access token error - post", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    axios.post.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    await postUserTradingDetails(obj);
    expect(axios.post).toHaveBeenCalledWith(postTradingDetails, obj, config);
    expect(refreshAccessToken).toBeCalled();
  });

  it("should display toast for mutiple errors", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "INVALID_USERNAME",
            },
            {
              message: "Error message 2",
              code: "INVALID_PASSWORD",
            },
          ],
        },
        status: 400,
      },
    };
    axios.post.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    await postUserTradingDetails(obj);
    expect(axios.post).toHaveBeenCalledWith(postTradingDetails, obj, config);
    expect(toast.error).toHaveBeenCalled();
  });

  it("should display toast for unknown error", async () => {
    let errResponse = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };
    axios.post.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    await postUserTradingDetails(obj);
    expect(axios.post).toHaveBeenCalledWith(postTradingDetails, obj, config);
    expect(toast.error).toHaveBeenCalled();
  });
});
