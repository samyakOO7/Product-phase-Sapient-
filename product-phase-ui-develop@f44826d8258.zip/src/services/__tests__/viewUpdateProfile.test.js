import axios from "axios";
import { refreshAccessToken } from "../../utils/refreshAccessToken";
import { toast } from "react-toastify";
import { updatePassword, fetchUserProfileData } from "../viewUpdateProfile";
import { encryptUsingRsa } from "../../utils/encryptUsingRsa";
import { updatedPasswordURL, userDataURL } from "../../config/urlConstants";

jest.mock("axios");
jest.mock("../../utils/logger");
jest.mock("react-toastify");
jest.mock("../../utils/encryptUsingRsa");
jest.mock("../../utils/refreshAccessToken");

const data = {
  userId: 1,
  currentPassword: 1231342,
  newPassword: 1232314,
};
describe("Tests for updatePassword", () => {
  it("should update  data for successful put call", async () => {
    let config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    try {
      axios.put.mockResolvedValueOnce(data);

      await updatePassword(data);
    } catch {
      expect(axios.put).toHaveBeenCalled();
    }
  });
  it("should call refreshAccessToken() for invalid access token error - put", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    try {
      axios.put.mockResolvedValueOnce(Promise.reject(errResponse));
      refreshAccessToken.mockReturnValue(false);
      await updatePassword(2, 1234, 1233);
    } catch {
      expect(axios.put).toHaveBeenCalled();
      expect(refreshAccessToken).toHaveBeenCalled();
    }
  });

  it("should display toast for mutiple errors", async () => {
    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "INVALID_USERNAME",
            },
            {
              message: "Error message 2",
              code: "INVALID_PASSWORD",
            },
          ],
        },
        status: 400,
      },
    };
    try {
      axios.put.mockReturnValue(Promise.reject(obj));
      refreshAccessToken.mockReturnValue(false);
      await updatePassword(2, 1234, 1233);
    } catch {
      expect(axios.put).toHaveBeenCalled();
      expect(toast.error).toHaveBeenCalled();
    }
  });

  it("should display toast for unknown error", async () => {
    let obj = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };
    try {
      axios.put.mockReturnValue(Promise.reject(obj));
      refreshAccessToken.mockReturnValue(false);
      await updatePassword(2, 1234, 1233);
    } catch {
      expect(axios.put).toHaveBeenCalled();
      expect(toast.error).toHaveBeenCalled();
    }
  });
  
});

describe("Tests for fetchUserProfileData", () => {
  it("should return response data for successful get call", async () => {
    let obj = {
      data: {
        totalAmount: 50000,
        amountPerTrade: 10,
        riskPerTrade: 3,
        totalEquity: 50000,
      },
    };
    axios.get.mockResolvedValueOnce(obj);

    let expectedResponse = {
      totalAmount: 50000,
      amountPerTrade: 10,
      riskPerTrade: 3,
      totalEquity: 50000,
    };
    let actualResponse = await fetchUserProfileData(1);

    expect(axios.get).toHaveBeenCalledWith(`${userDataURL}/1`);
    expect(JSON.stringify(actualResponse)).toBe(
      JSON.stringify(expectedResponse)
    );
  });

  it("should call refreshAccessToken() for invalid access token error", async () => {
    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };
    try {
      axios.get.mockResolvedValueOnce(Promise.reject(obj));
      refreshAccessToken.mockReturnValue(false);
      await fetchUserProfileData(1);
    } catch {
      expect(axios.get).toHaveBeenCalled();
      expect(refreshAccessToken).toBeCalled();
    }
  });

  it("should display toast for mutiple errors", async () => {
    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "INVALID_USERNAME",
            },
            {
              message: "Error message 2",
              code: "INVALID_PASSWORD",
            },
          ],
        },
        status: 400,
      },
    };
    try {
      axios.get.mockReturnValue(Promise.reject(obj));
      refreshAccessToken.mockResolvedValueOnce(false);
      await fetchUserProfileData(1);
    } catch {
      expect(axios.get).toHaveBeenCalled();
      expect(toast.error).toHaveBeenCalled();
    }
  });

  it("should display toast for unknown error", async () => {
    let obj = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };
    try {
      axios.get.mockReturnValue(Promise.reject(obj));
      refreshAccessToken.mockResolvedValueOnce(false);
      await fetchUserProfileData(1);
    } catch {
      expect(axios.get).toHaveBeenCalledWith(`${userDataURL}/1`);
      expect(toast.error).toHaveBeenCalled();
    }
  });
});
