import axios from "axios";
import { toast } from "react-toastify";
import { executeTradeURL, deleteTradeURL } from "../../config/urlConstants";
import { executeTrade, deleteTrade,refreshTrade } from "../executeDeleteTrade";
import { loadTradeDetails } from "../../context/trade/TradeState.jsx";

jest.mock("axios");
jest.mock("../../utils/logger");
jest.mock("react-toastify");
jest.mock("../../context/trade/TradeState.jsx");
const mockSetExecuteDisabledState = jest.fn();
const mockShowModal = jest.fn();

const execute = {
  tradeDetailId: 1,
  stopLoss: parseFloat(20.5),
  profitTarget: parseFloat(25.5),
  quantity: 2,
  userId: 101,
  currentPage: 1,
  tradeDetailDispatcher: jest.fn(),
  setExecuteDisabledState: mockSetExecuteDisabledState,
  setShowModal: mockShowModal,
};

const execute1 = {
  tradeDetailId: 1,
  stopLoss: parseFloat(20.5),
  profitTarget: parseFloat(25.5),
  quantity: 2,
  userId: 101,
  currentPage: 1,
  tradeDetailDispatcher: jest.fn(),
};

const mockDelete = {
  tradeDetailId: 1,
  userId: 1,
  currentPage: 1,
  tradeDetailDispatcher: jest.fn(),
};

describe("Tests for executeTrade", () => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  let obj = {
    data: {
      tradeDetailId: 1,
      stopLoss: parseFloat(20.5),
      profitTarget: parseFloat(25.5),
      quantity: 2,
    },
  };

  it("should return response data for successful get call", async () => {
    axios.post.mockResolvedValueOnce(obj);
    await executeTrade(execute);
    //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
    expect(axios.post).toHaveBeenCalled();
  });
  it("should return response data for not successful with status code >400", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Can't place the trade. Please, try again later",
          },
        ],
        status: 403,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));
    try {
      await executeTrade(execute1);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.post).toHaveBeenCalled();
    }
  });
  it("should return response data for not successful with status code 0", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Please check internet connection",
          },
        ],
        status: 0,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));
    try {
      await executeTrade(execute);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.post).toHaveBeenCalled();
    }
  });

  it("should return response data for not successful ", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Can't place the trade. Please, try again later",
          },
        ],
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));
    try {
      await executeTrade(execute);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.post).toHaveBeenCalled();
    }
  });
});

describe("Tests for deleteTrade", () => {
  it("should return response data for successful get call", async () => {
    let obj = {
      data: {
        message: "deleteMock",
      },
    };

    axios.delete.mockResolvedValueOnce(obj);
    await deleteTrade(mockDelete);
    expect(axios.delete).toHaveBeenCalled();
  });

  it("should return response data for not successful with status code >400", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Can't place the trade. Please, try again later",
          },
        ],
        status: 403,
      },
    };

    axios.delete.mockReturnValue(Promise.reject(errResponse));
    try {
      await deleteTrade(mockDelete);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.delete).toHaveBeenCalled();
    }
  });
  it("should return response data for not successful with status code 0", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Please check internet connection",
          },
        ],
        status: 0,
      },
    };

    axios.delete.mockReturnValue(Promise.reject(errResponse));
    try {
      await deleteTrade(mockDelete);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.delete).toHaveBeenCalled();
    }
  });

  it("should return response data for not successful ", async () => {
    let errResponse = {
      response: {
        errors: [
          {
            message: "Can't place the trade. Please, try again later",
          },
        ],
      },
    };

    axios.delete.mockReturnValue(Promise.reject(errResponse));
    try {
      await deleteTrade(mockDelete);
    } catch {
      //expect(axios.post).toHaveBeenCalledWith(executeTradeURL, obj, config);
      expect(axios.delete).toHaveBeenCalled();
    }
  });
  it("Should refresh trdade successfully",async ()=>{
    let obj = {
      data: {
        message: "deleteMock",
      },
    };
    axios.get.mockResolvedValueOnce(obj);
    refreshTrade('342342dwefef2542354235','34',jest.fn(),jest.fn());
  });
  it("Should refresh trdade un succesfull",async ()=>{
    let errResponse = {
      response: {
        errors: [
          {
            message: "Please check internet connection",
          },
        ],
        status: 0,
      },
    };

    axios.get.mockReturnValue(Promise.reject(errResponse));
    refreshTrade('342342dwefef2542354235','34',jest.fn(),jest.fn());
  });
});

