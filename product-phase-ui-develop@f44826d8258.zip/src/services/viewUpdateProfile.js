import axios from "axios";
import { toast } from "react-toastify";

import { updatedPasswordURL, userDataURL } from "../config/urlConstants";
import { encryptUsingRsa } from "../utils/encryptUsingRsa";
import { logger } from "../utils/logger";
import { refreshAccessToken } from "../utils/refreshAccessToken";

export const updatePassword = async (userId, currentPassword, newPassword) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try{
  let publicKey = process.env.REACT_APP_PUBLIC_KEY
    let encryptedCurrentPassword = encryptUsingRsa(currentPassword, publicKey);
    let encryptedOldPassword = encryptUsingRsa(newPassword, publicKey);
    const res = await axios.put(
      updatedPasswordURL,
      { encryptedCurrentPassword, encryptedOldPassword, userId },
      config
    );
    logger.info({ message: res.data.message });
    logger.info(res);
    return res.data;
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403 ) {
     logger.warn("Access token expired"  );
      if (refreshAccessToken()) {
        updatePassword(userId, currentPassword, newPassword);

      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(
          `${err.message} for user ${userId} in updatePassword()`
        );
        toast.error(err.message);
      }
    } else {
      logger.error(
        "Unknow error Occoured in getWinningTradeList()" + errors?.toString()
      );
      toast.error("Oops!! try after some time");
    }
    throw error;
  }
};

export const fetchUserProfileData = async (userId) => {
  try {
    let res = await axios.get(userDataURL + `/${userId}`);
    logger.info({ message: res.data.message });
    logger.info(res);
    return res.data;
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403 ) {
      logger.warn("Access token expired"  );
      if (refreshAccessToken()) {
        fetchUserProfileData(userId);
      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(
          `${err.message} for user ${userId} in getting winning trade list`
        );
        toast.error(err.message);
      }
    } else {
      logger.error(
        "Unknow error Occoured in getWinningTradeList()" + errors?.toString()
      );
      toast.error("Oops!! try after some time");
    }
    throw error;
  }
};
