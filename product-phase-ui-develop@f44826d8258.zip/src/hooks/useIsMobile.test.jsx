import "@testing-library/jest-dom";

import { fireEvent, act, render } from "@testing-library/react";
import useIsMobile from "./useIsMobile";
import { MOBILE_MAX_THRESHOLD } from "../config/screenConstants";

describe("useIsMobile", () => {
  window.setImmediate = window.setTimeout;
  it("testing", () => {
    const TestComponent = () => {
      const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
      return <>{isMobile}</>;
    };
    render(<TestComponent />);
  });
  it("testing hook on small screens", async () => {
    window.setImmediate = window.setTimeout;
    const TestComponent = () => {
      const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
      return <>{isMobile}</>;
    };
    render(<TestComponent />);
    await act(() => {
      window.innerHeight = 500;
      window.innerWidth = 500;
      fireEvent(window, new Event("resize"));
    });
  
  });
  it("testing hooks on small screens", async () => {
    window.setImmediate = window.setTimeout;
    const TestComponent = () => {
      const isMobile = useIsMobile();
      return <>{isMobile}</>;
    };
    render(<TestComponent />);
    await act(() => {
      window.innerHeight = 500;
      window.innerWidth = 500;
      fireEvent(window, new Event("resize"));
    });
   
  });
  it("testing hooks on large screens", async () => {
    window.setImmediate = window.setTimeout;
    const TestComponent = () => {
      const isMobile = useIsMobile();
      return <>{isMobile}</>;
    };
    render(<TestComponent />);
    await act(() => {
      window.innerHeight = 1000;
      window.innerWidth = 1000;
      fireEvent(window, new Event("resize"));
    });
  
  });
});
