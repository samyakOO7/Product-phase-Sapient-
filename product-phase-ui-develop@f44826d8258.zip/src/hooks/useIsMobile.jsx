import { useState, useEffect } from "react";

import { MOBILE_MAX_THRESHOLD } from "../config/screenConstants";

export default function useIsMobile(threshold = MOBILE_MAX_THRESHOLD) {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= threshold);

  const handleWindowSizeChange = () => {
    let width = window.innerWidth;
    if (width <= threshold) {
      setIsMobile(true);
    }
    else  {
      setIsMobile(false);
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleWindowSizeChange);
    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return isMobile;
}
