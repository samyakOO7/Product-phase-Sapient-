import { useContext, useReducer, useEffect } from "react";
import AuthContext from "./authContext";
import authReducer from "./authReducer";
import axios from "axios";
import { encryptUsingRsa } from "../../utils/encryptUsingRsa";
import {
  AUTH_WITH_TOKEN,
  LOGIN_SUCCESS,
  SET_LOADING,
} from "../../config/typeConstants";
import {
  loginURL,
  signUpURL,
  resetPasswordURL,
  authWithToken,
  signupVerificationURL,
} from "../../config/urlConstants";

import setAuthToken from "../../utils/setAuthToken";
import { toast } from "react-toastify";
import { logger } from "../../utils/logger";
import { refreshAccessToken } from "../../utils/refreshAccessToken";

export const useAuth = () => {
  const { authState, authDispatch } = useContext(AuthContext);
  return [authState, authDispatch];
};
export const LoginUser = async (data, dispatch) => {
  const { email, password } = data;

  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    const publicKey = process.env.REACT_APP_PUBLIC_KEY;
    const encryptedPassword = encryptUsingRsa(password, publicKey);
    const res = await axios.post(
      loginURL,
      { email, password: encryptedPassword },
      config
    );
    logger.info("user login succcessfull");
    setAuthToken(res.data.accessToken, res.data.refreshToken);
    dispatch({
      type: LOGIN_SUCCESS,
      payload: res.data,
    });
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;

    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        LoginUser(data, dispatch);
      }
    } else if (error?.response?.data?.message === "Email Not Verified") {
      logger.error("Email not verified for user");
      toast.error("Email not verified!");
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(`${err?.message} for user ${data?.email}`);
        toast.error(err?.message);
      }
    } else {
      logger.error(
        "Unknown error occurred in LoginUser()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};
export const RegisterUser = async (data, dispatch) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    let publicKey = process.env.REACT_APP_PUBLIC_KEY;
    data.password = encryptUsingRsa(data.password, publicKey);

    delete data.confirmPassword;

    await axios.post(signUpURL, data, config);

    toast.success("Verify your email");
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        RegisterUser(data, dispatch);
      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(`${err?.message} for user ${data?.email}`);
        toast.error(err?.message);
      }
    } else {
      logger.error(
        "Unknown error occurred in RegisterUser()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};
export const resetPassword = async (password, code) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    let publicKey = process.env.REACT_APP_PUBLIC_KEY;
    let encryptedPassword = encryptUsingRsa(password, publicKey);

    await axios.post(
      `${resetPasswordURL}/${code}`,
      { password: encryptedPassword },
      config
    );
    return true;
  } catch (error) {
    const { errors } = error?.response?.data;
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        resetPassword(password);
      }
    } else if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(`${err.message} for reset passwoard request`);
        toast.error(err.message);
      }
    } else {
      logger.error(
        "Unknown error occurred in resetPassword()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};

const validateWithToken = async (token, authDispatch) => {
  try {
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    const res = await axios.post(authWithToken);

    authDispatch({
      type: AUTH_WITH_TOKEN,
      payload: res?.data?.userId,
    });
  } catch (error) {
    authDispatch({
      type: SET_LOADING,
      payload: false,
    });
    const { errors } = error?.response?.data;
    if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(`${err?.message} for user`);
      }
    } else {
      logger.error(
        "Unknown error occurred in validateWithToken()" + errors?.toString()
      );
    }
  }
};

export const AuthState = (props) => {
  const intialState = {
    accessToken: localStorage.getItem("accessToken"),
    refreshToken: localStorage.getItem("refreshToken"),
    isAuthenticated: false,
    loading: false,
    user: null
  };

  const [authState, authDispatch] = useReducer(authReducer, intialState);

  useEffect(() => {
    if (authState.accessToken !== undefined && authState.accessToken !== null) {
      authDispatch({
        type: SET_LOADING,
        payload: true,
      });
      validateWithToken(authState.accessToken, authDispatch);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authState.accessToken]);

  return (
    <AuthContext.Provider
      value={{
        authState,
        authDispatch,
      }}
    >
      {props.children}
    </AuthContext.Provider>
  );
};
export default AuthState;

export const SendingEmail = async (email) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    await axios.post(resetPasswordURL, { email }, config);
    logger.info("email sent successfull to " + email);
    return true;
  } catch (error) {
    const { errors } = error?.response?.data;
    if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(`${err?.message} for user ${email}`);
        toast.error(err?.message);
      }
    } else {
      logger.error(
        "Unknown error occurred in ResetPassword()" + errors?.toString()
      );
      toast.error("Oops!! Try after some time");
    }
  }
};

export const CheckResetPasswordLink = async (code, navigate) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    await axios.get(`${resetPasswordURL}/${code}`, config);
    return true;
  } catch (error) {
    const { errors } = error?.response?.data;
    if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(err.message);
      }
    }
    logger.error("Invaild Link or Link expired");
    toast.error(
      "Your Link is Expired or Invalid! Kindly, generate new link from here"
    );
    navigate("/forgot-password");
  }
};
export const SignUpVerification = async (code, navigate) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    await axios.get(`${signupVerificationURL}?code=${code}`, config);
    return true;
  } catch (error) {
    const { errors } = error?.response?.data;
    if (errors?.length > 0) {
      for (let err of errors) {
        logger.error(err.message);
      }
    }
    logger.error("Invaild Link or Link expired");
    toast.error("Your Link is Expired or Invalid! Kindly, sign up again.");
    navigate("/signUp");
  }
};
