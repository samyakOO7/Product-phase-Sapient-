import {
    AUTH_WITH_TOKEN,
    LOGIN_SUCCESS,
    LOG_OUT,
    SET_LOADING,
  } from "../../../config/typeConstants";
import authReducer  from "../authReducer";
describe("",()=>{
    const initialAuthState ={

            accessToken: "some-accessToken",
            refreshToken: "some-refreshToken",
            isAuthenticated: false,
            loading: false,
            user: null,
    };
    it("auth with token",()=>{
       localStorage.setItem("userName","harish")
       const updateState = authReducer(initialAuthState, {type:AUTH_WITH_TOKEN, payload:2});
       expect(updateState.user.userId).toBe(2);
       expect(updateState.user.userName).toBe("harish");
       expect(updateState.isAuthenticated).toBe(true);
    })
    it("login success",()=>{
        const updateState = authReducer(initialAuthState, {type:LOGIN_SUCCESS, payload: {userId:2, userName:"harish"}});
        expect(updateState.user.userId).toBe(2);
        expect(updateState.user.userName).toBe("harish");
        expect(updateState.isAuthenticated).toBe(true);
    })
    it("log out",()=>{
        const updateState = authReducer(initialAuthState, {type:LOG_OUT});
        expect(updateState.isAuthenticated).toBe(false);
    })
    it("set loading",()=>{
        const updateState = authReducer(initialAuthState, {type:SET_LOADING,payload : false});
        expect(updateState.loading).toBe(false);
    })
 
    it("default case",()=>{
        const updateState = authReducer(initialAuthState, {type:"SOME_OTHER_UNEXPECTED_TYPE"});
        expect(updateState).toStrictEqual(initialAuthState);
    })
})



