import axios from "axios";

import { refreshAccessToken } from "../../../utils/refreshAccessToken";

import { toast } from "react-toastify";

import {
  useAuth,
  AuthState,
  LoginUser,
  RegisterUser,
  resetPassword,
  SendingEmail,
  CheckResetPasswordLink,
  SignUpVerification,
} from "../AuthState";

import setAuthToken from "../../../utils/setAuthToken";

import authContext from "../authContext";
import { render } from "@testing-library/react";

jest.mock("axios");

jest.mock("../../../utils/logger");

jest.mock("react-toastify");

jest.mock("../../../utils/encryptUsingRsa");

jest.mock("../../../utils/refreshAccessToken");

jest.mock("../authContext");

jest.mock("../authReducer");

jest.mock("../../../utils/setAuthToken");

jest.mock("");

let MockComponent = () => {
  useAuth();
  return <></>;
};

describe("Test case for useAuth()", () => {
  it("should return authState and authDispatch", () => {
    render(
      <authContext.Provider
        value={{
          authState: {
            user: {
              userId: 1,

              userName: "Sanjay",
            },
          },
        }}
      >
        <MockComponent />
      </authContext.Provider>
    );
  });
});

describe("Tests for Login User", () => {
  it("should call dispatch for successfull login", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    const res = {
      data: {
        accessToken: "access token",
        refreshToken: "refresh token",
      },
    };

    axios.post.mockReturnValue(Promise.resolve(res));

    await LoginUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(dispatch).toHaveBeenCalled();
    expect(setAuthToken).toHaveBeenCalled();
  });

  it("should throw error for status 403", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };

    axios.post.mockReturnValue(Promise.reject(obj));

    await LoginUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(refreshAccessToken).toHaveBeenCalled();
  });
  

  it("should display toast for multiple errors", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await LoginUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });

  it("should display toast for unknown error", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let errResponse = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await LoginUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
});

describe("Tests for register user", () => {
  it("should call success toast for successfull registration", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    const res = {
      data: {
        password: "password",
        confirmPassword: "confirm password",
      },
    };

    axios.post.mockReturnValue(Promise.resolve(res));

    await RegisterUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalled();
  });
  it("should throw error for status 403", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };

    axios.post.mockReturnValue(Promise.reject(obj));

    await RegisterUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(refreshAccessToken).toHaveBeenCalled();
  });

  it("should display toast for multiple errors", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await RegisterUser(data, dispatch);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
  it("should display toast for unknown error", async () => {
    const dispatch = jest.fn();
    const data = {
      email: "madhavan@gmail.com",
      password: "dummypwd",
    };

    let errResponse = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await RegisterUser(data, dispatch);
    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
});

describe("Tests for reset password", () => {
  it("should return true for successfull reset of password", async () => {
    const password = "password";
    const code = 1234;

    axios.post.mockResolvedValueOnce(Promise.resolve("nothing"));

    const result = await resetPassword(password, code);

    expect(axios.post).toHaveBeenCalled();
    expect(result).toBeTruthy();
  });

  it("should throw error for status 403", async () => {
    const password = "password";
    const code = 1234;

    let obj = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };

    axios.post.mockReturnValue(Promise.reject(obj));

    await resetPassword(password, code);

    expect(axios.post).toHaveBeenCalled();
    expect(refreshAccessToken).toHaveBeenCalled();
  });

  it("should display toast for multiple errors", async () => {
    const password = "password";
    const code = 1234;

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await resetPassword(password, code);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
  it("should display toast for unknown error", async () => {
    const password = "password";
    const code = 1234;

    let errResponse = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await resetPassword(password, code);
    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
});

describe("Tests for Auth State component", () => {
  it("should render auth state", async () => {
    render(<AuthState></AuthState>);
  });
});

describe("Tests for sending email", () => {
  it("should return true when email is sent for reset password", async () => {
    const email = "johndoe@gmail.com";

    const res = {
      data: {
        password: "password",
        confirmPassword: "confirm password",
      },
    };

    axios.post.mockReturnValue(Promise.resolve(res));

    const result = await SendingEmail(email);

    expect(axios.post).toHaveBeenCalled();
    expect(result).toBeTruthy();
  });
  it("should display toast for multiple errors", async () => {
    const email = "johndoe@gmail.com";

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await SendingEmail(email);

    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
  it("should display toast for unknown error", async () => {
    const email = "johndoe@gmail.com";

    let errResponse = {
      response: {
        data: { errors: [] },
        status: 500,
      },
    };

    axios.post.mockReturnValue(Promise.reject(errResponse));

    await SendingEmail(email);
    expect(axios.post).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
  });
});

describe("Tests for check reset password link", () => {
  it("should return true for successfull get axios call", async () => {
    const code = 1234;

    const navigate = jest.fn();

    axios.get.mockReturnValue(Promise.resolve("nothing"));

    const result = await CheckResetPasswordLink(code, navigate);

    expect(axios.get).toHaveBeenCalled();
    expect(result).toBeTruthy();
  });
  it("should display toast for multiple errors", async () => {
    const code = 1234;

    const navigate = jest.fn();

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.get.mockReturnValue(Promise.reject(errResponse));

    await CheckResetPasswordLink(code, navigate);

    expect(axios.get).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
    expect(navigate).toHaveBeenCalled();
  });
});

describe("Tests for sign up verification", () => {
  it("should return true for successfull get axios call", async () => {
    const code = 1234;

    const navigate = jest.fn();

    axios.get.mockReturnValue(Promise.resolve("nothing"));

    const result = await SignUpVerification(code, navigate);

    expect(axios.get).toHaveBeenCalled();
    expect(result).toBeTruthy();
  });

  it("should display toast for multiple errors", async () => {
    const code = 1234;

    const navigate = jest.fn();

    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message 1",
              code: "ERROR_CODE_1",
            },
            {
              message: "Error message 2",
              code: "ERROR_CODE_2",
            },
          ],
        },
        status: 400,
      },
    };

    axios.get.mockReturnValue(Promise.reject(errResponse));

    await SignUpVerification(code, navigate);

    expect(axios.get).toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalled();
    expect(navigate).toHaveBeenCalled();
  });
});
