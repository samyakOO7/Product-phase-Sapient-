import { UPDATE_QUANTITY,
  LOAD_TRADE_DETAIL_MODAL,
  UPDATE_STOP_LOSS,
  UPDATE_PROFIT_TARGET,
  DECREMENT_PROFIT_TARGET,
  INCREMENT_PROFIT_TARGET,
  INCREMENT_STOP_LOSS,
  DECREMENT_STOP_LOSS,
  REFRESH_TRADE_MODAL,
  INCREMENT_STOCK_QUANTITY,
  DECREMENT_STOCK_QUANTITY,
  SET_STOP_LOSS_VALIDITY,
  SET_PROFIT_TARGET_VALIDITY,
  SET_QUANTITY_VALIDITY
} from "../../config/typeConstants";

const incrementStockQuantity=(tradeModalState)=>{
  if(tradeModalState.quantity==='')
    tradeModalState.quantity=0;
  tradeModalState.quantity=parseInt(tradeModalState.quantity);
  if (tradeModalState.quantity < tradeModalState.item.quantity) {
    tradeModalState.quantity += 1;
    tradeModalState.item.totalCost =
      tradeModalState.quantity * tradeModalState.item.pricePerTicker;
  }
  if (tradeModalState.quantity === tradeModalState.item.quantity) {
    tradeModalState.incrementQuantityStatus = false;
  }
  if (tradeModalState.quantity !== 1)
    tradeModalState.decrementQuantityStatus = true;

}
const decrementStockQuantity=(tradeModalState)=>{
  if(tradeModalState.quantity==='')
    tradeModalState.quantity=0;
  tradeModalState.quantity=parseInt(tradeModalState.quantity);
  if (tradeModalState.quantity > 1) {
    tradeModalState.quantity -= 1;
    tradeModalState.item.totalCost =
      tradeModalState.quantity * tradeModalState.item.pricePerTicker;
  }
  if (tradeModalState.quantity === 1) {
    tradeModalState.decrementQuantityStatus = false;
  }
  if (tradeModalState.quantity !== tradeModalState.item.quantity){
    tradeModalState.incrementQuantityStatus = true;
  }
  
}
const updatedStopLoss=(tradeModalState,action)=>{
  let updateStopLoss = action.payload;
      let updateStopLossFloat = parseFloat(updateStopLoss);
      if (updateStopLoss === "")
        return { ...tradeModalState, stopLoss: updateStopLoss };
      if (
        /^\d{1,3}$|^\d{1,3}\.\d{0,2}$/.test(updateStopLoss) &&
        updateStopLossFloat >= 1 &&
        updateStopLossFloat <= 100
      ){
        return { ...tradeModalState, stopLoss: updateStopLoss };
      }
      return {...tradeModalState};
}
const incrementStopLoss=(tradeModalState)=>{
  let updatedStopLossInc = parseInt(tradeModalState.stopLoss) + 1;
      if (updatedStopLossInc >= 1 && updatedStopLossInc <= 100)
        return { ...tradeModalState, stopLoss: updatedStopLossInc };
      return { ...tradeModalState };
}
const decrementStopLoss=(tradeModalState)=>{
  let updatedStopLossDec = parseInt(tradeModalState.stopLoss) - 1;
      if (updatedStopLossDec >= 1 && updatedStopLossDec <= 100)
        return { ...tradeModalState, stopLoss: updatedStopLossDec };
      return { ...tradeModalState };
}
const updatedProfitTarget=(tradeModalState,action)=>{
  let updateProfitTarget = action.payload;
      let updateProfitTargetFloat = parseFloat(updateProfitTarget);
      if (updateProfitTarget === "")
        return { ...tradeModalState, profitTarget: updateProfitTarget };
      if (
          /^\d{1,3}$|^\d{1,3}\.\d{0,2}$/.test(updateProfitTarget) &&
          updateProfitTargetFloat >= 1 &&
          updateProfitTargetFloat <= 100
        ){
          return { ...tradeModalState, profitTarget: updateProfitTarget };
        }
      return { ...tradeModalState };
}
const updatedQuantity=(tradeModalState,action)=>{
  let updateQuantity = action.payload;
      if (updateQuantity === "")
        return { ...tradeModalState, quantity: updateQuantity };
      if (
          /^\d{1,10}$/.test(updateQuantity) &&
          updateQuantity >= 1 &&
          updateQuantity <= tradeModalState.item.quantity
        ){
          tradeModalState.item.totalCost=parseInt(updateQuantity)*tradeModalState.item.pricePerTicker;
          return { ...tradeModalState, quantity: updateQuantity };
        }
      return { ...tradeModalState };
}
const incrementingProfitTarget=(tradeModalState)=>{
  let incrementProfitTarget = parseInt(tradeModalState.profitTarget) + 1;
      if (incrementProfitTarget >= 1 && incrementProfitTarget <= 100)
        return { ...tradeModalState, profitTarget: incrementProfitTarget };
      return { ...tradeModalState };
}
const decrementingProfitTarget=(tradeModalState)=>{
  let decrementProfitTarget = parseInt(tradeModalState.profitTarget) - 1;
      if (decrementProfitTarget >= 1 && decrementProfitTarget <= 100)
        return { ...tradeModalState, profitTarget: decrementProfitTarget };
      return { ...tradeModalState };
}
export const tradeModalReducer = (tradeModalState, action) => {
  switch (action.type) {
    //loads initial data
    case LOAD_TRADE_DETAIL_MODAL:
      let item = action.payload;
      item.stopLoss=Math.round( item.stopLoss*100)/100;
      item.profitTarget=Math.round( item.profitTarget*100)/100;
      item.gain=Math.round( item.gain*100)/100;
      let quantity = item.quantity;
      let stopLoss = item.stopLoss;
      let profitTarget = item.profitTarget;
      return {
        item: { ...item },
        quantity: quantity,
        stopLoss: stopLoss,
        profitTarget: profitTarget,
        incrementQuantityStatus: true,
        decrementQuantityStatus: true,
        incrementStopLossStatus: true,
        decrementStopLossStatus: true,
        incrementProfitTargetStatus: true,
        decrementProfitTargetStatus: true,
        isStopLossValid: true,
        isProfitTargetValid: true,
        isQuantityValid:true
      };

    case REFRESH_TRADE_MODAL:
      let update = action.payload;
      if (tradeModalState.item.tradeDetailId === update.tradeDetailId) {
        action.detailDispatcher({
          type:REFRESH_TRADE_MODAL,
          payload:update
        });
        return {
          item: { ...update },
          quantity: update.quantity,
          stopLoss: update.stopLoss,
          profitTarget: update.profitTarget,
          incrementQuantityStatus: true,
          decrementQuantityStatus: true,
          incrementStopLossStatus: true,
          decrementStopLossStatus: true,
          incrementProfitTargetStatus: true,
          decrementProfitTargetStatus: true,
          isStopLossValid: true,
          isProfitTargetValid: true,
          isQuantityValid:true
        };
      }
      break;
    case INCREMENT_STOCK_QUANTITY:
      incrementStockQuantity(tradeModalState);
      return { ...tradeModalState };

    case DECREMENT_STOCK_QUANTITY:
      decrementStockQuantity(tradeModalState);
      return { ...tradeModalState };
    case UPDATE_QUANTITY:
      return updatedQuantity(tradeModalState,action);
    case UPDATE_STOP_LOSS:
      return updatedStopLoss(tradeModalState,action);
    case INCREMENT_STOP_LOSS:
      return incrementStopLoss(tradeModalState);
    case DECREMENT_STOP_LOSS:
      return decrementStopLoss(tradeModalState);
    case UPDATE_PROFIT_TARGET:
      return updatedProfitTarget(tradeModalState,action);
    case INCREMENT_PROFIT_TARGET:
      return incrementingProfitTarget(tradeModalState);
    case DECREMENT_PROFIT_TARGET:
      return decrementingProfitTarget(tradeModalState);
    case SET_PROFIT_TARGET_VALIDITY:
      return { ...tradeModalState, isProfitTargetValid: action.payload };
    case SET_STOP_LOSS_VALIDITY:
      return { ...tradeModalState, isStopLossValid: action.payload };
      case SET_QUANTITY_VALIDITY:
        return { ...tradeModalState, isQuantityValid: action.payload };
    default:
      return tradeModalState;
  }
};
