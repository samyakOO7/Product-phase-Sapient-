import { LOAD_TRADE_DETAIL_DASHBOARD, REFRESH_TRADE_MODAL} from './../../config/typeConstants';
function tradeDetailReducer(tradeState,action){
    switch(action.type){
        case LOAD_TRADE_DETAIL_DASHBOARD:
            return {
                data:action.payload.data,
                pageCount:action.payload.totalPageCount
            };
        case REFRESH_TRADE_MODAL:
            let update=action.payload;
            

            for(let i=0;i<tradeState.data.length;i++)
            {
                if(tradeState.data[i].tradeDetailId===update.tradeDetailId){
                    tradeState.data[i]=update;
                }
            }
            return {...tradeState};
    default:
      return tradeState;
  }
}

export default tradeDetailReducer;
