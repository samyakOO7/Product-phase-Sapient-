import { createContext } from "react";

export const tradeContext=createContext();
