import {LOAD_TRADE_DETAIL_DASHBOARD, UPDATE_TRADE_DETAIL} from "../../../config/typeConstants";
import tradeDetailReducer from "../tradeDetailReducer";
import { REFRESH_TRADE_MODAL } from './../../../config/typeConstants';

describe("tradeModalReducer",()=>{
    const mockInitialState = {
       data :[{tradeDetailId:12}, {tradeDetailId:34}],
       pageCount : 2
    }
    it ("loading initial state",()=>{
        const updateState = tradeDetailReducer(mockInitialState,
             {type: LOAD_TRADE_DETAIL_DASHBOARD, payload: {...mockInitialState, totalPageCount : 2}});
        expect(mockInitialState).toStrictEqual(updateState)
    })
    it ("refresh trade modal",()=>{
        const updateState = tradeDetailReducer(mockInitialState,{type: REFRESH_TRADE_MODAL, payload: {tradeDetailId:34, quantity:5}});
        expect(updateState.data[1].quantity).toBe(5);
    })
    it ("refresh trade modal",()=>{
        const updateState = tradeDetailReducer(mockInitialState,{type: "SOME_DUMMY_TYPE"});
        expect(updateState).toStrictEqual(mockInitialState);
    })
})
