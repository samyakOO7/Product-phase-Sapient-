import axios from 'axios';
import { logger } from '../../../utils/logger';
import TradeState, {loadTradeDetails} from '../TradeState';
import {render} from '@testing-library/react'
jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });
jest.mock("axios")

describe("loadTradeDetails",()=>{
    it ("loading trade details ",async ()=>{
        axios.get.mockResolvedValueOnce({data:[{tradeDetailId:12},{tradeDetailId:13}]});
        const mockDispatcher = jest.fn();
        await loadTradeDetails(23,3,mockDispatcher);
        expect(mockDispatcher).toHaveBeenCalled();
    })
    it (" trade details ",async ()=>{
        axios.get.mockRejectedValueOnce(new Error());
        const mockDispatcher = jest.fn();
        await loadTradeDetails(23,3,mockDispatcher);
        expect(logger.error).toHaveBeenCalled();
    })
})


describe('TradeState',()=>{
    it("trade state is rendering",()=>{
        render(<TradeState><></></TradeState>)
    })
})
