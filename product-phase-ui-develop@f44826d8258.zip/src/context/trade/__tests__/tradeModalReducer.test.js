import {
    LOAD_TRADE_DETAIL_MODAL,
    UPDATE_STOP_LOSS,
    UPDATE_PROFIT_TARGET,
    DECREMENT_PROFIT_TARGET,
    INCREMENT_PROFIT_TARGET,
    INCREMENT_STOP_LOSS,
    DECREMENT_STOP_LOSS,
    REFRESH_TRADE_MODAL,
    INCREMENT_STOCK_QUANTITY,
    DECREMENT_STOCK_QUANTITY,
    SET_STOP_LOSS_VALIDITY,
    SET_PROFIT_TARGET_VALIDITY,
    UPDATE_QUANTITY,
    SET_QUANTITY_VALIDITY,
  } from "../../../config/typeConstants";
import {tradeModalReducer} from "../tradeModalReducer";


describe("tradeModalReducer",()=>{
    const mockItem = {
        tradeDetailId:"aasasfa",
        gain: 3,
        quantity:5,
        stopLoss:4.5,
        profitTarget:10,
    }
    const mockInitialState = {
        item: { ...mockItem},
        quantity: mockItem.quantity,
        stopLoss: mockItem.stopLoss,
        profitTarget: mockItem.profitTarget,
        incrementQuantityStatus: true,
        decrementQuantityStatus: true,
        incrementStopLossStatus: true,
        decrementStopLossStatus: true,
        incrementProfitTargetStatus: true,
        decrementProfitTargetStatus: true,
        isStopLossValid: true,
        isProfitTargetValid: true,
        isQuantityValid:true
    }
    it ("loading initial state",()=>{
        const updateState = tradeModalReducer({},
             {type: LOAD_TRADE_DETAIL_MODAL, payload: mockItem});
        expect(mockInitialState).toStrictEqual(updateState)
    })
    it ("refresh trade modal",()=>{
        let updateState = tradeModalReducer({...mockInitialState},
             {  type: REFRESH_TRADE_MODAL,
                 payload: {...mockItem, quantity: 5},
                 detailDispatcher:jest.fn()
            });
        expect(updateState.quantity).toStrictEqual(5);
        updateState = tradeModalReducer({...mockInitialState},
            {  type: REFRESH_TRADE_MODAL,
                payload: {...mockItem,tradeDetailId :"afdasd" }
           });

    })
    it("Increment stock quantity",()=>{
        let updatedState = tradeModalReducer({...mockInitialState},{
            type: INCREMENT_STOCK_QUANTITY
        })
        expect(updatedState.incrementQuantityStatus).toBe(false);
        updatedState = tradeModalReducer({...mockInitialState, quantity: 2},{
            type: INCREMENT_STOCK_QUANTITY
        })
        expect(updatedState.quantity).toBe(3);
        expect(updatedState.decrementQuantityStatus).toBe(true);
    })

    it("decrement stock quantity",()=>{
        let updatedState = tradeModalReducer({...mockInitialState, quantity:1},{
            type: DECREMENT_STOCK_QUANTITY
        })
        expect(updatedState.decrementQuantityStatus).toBe(false);
        updatedState = tradeModalReducer({...mockInitialState, quantity: 2},{
            type: DECREMENT_STOCK_QUANTITY
        })
        expect(updatedState.quantity).toBe(1);
        expect(updatedState.incrementQuantityStatus).toBe(true);
        const mockInTest={...mockInitialState};
        mockInTest.item.quantity=50;
        mockInTest.quantity=50;
        updatedState = tradeModalReducer(mockInTest,{
            type: DECREMENT_STOCK_QUANTITY
        })
        expect(updatedState.quantity).toBe(49);
    })
    it("update stop loss",()=>{
        let updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_STOP_LOSS, payload: ""});
        expect(updateState.stopLoss).toStrictEqual("");
        updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_STOP_LOSS, payload: "34"})
        expect(updateState.stopLoss).toBe("34");
        updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_STOP_LOSS, payload: "134.8"})
        expect(updateState.stopLoss).toBe(mockInitialState.stopLoss);
    })
    it("update profit target",()=>{
        let updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_PROFIT_TARGET, payload: ""});
        expect(updateState.profitTarget).toStrictEqual("");
        updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_PROFIT_TARGET, payload: "34"})
        expect(updateState.profitTarget).toBe("34");
        updateState = tradeModalReducer({...mockInitialState},{type: UPDATE_PROFIT_TARGET, payload: "134.8"})
        expect(updateState.profitTarget).toBe(mockInitialState.profitTarget);
    })
    it("increment stop loss", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState, stopLoss:4}, {type:INCREMENT_STOP_LOSS});
        expect(updatedState.stopLoss).toBe(5);
        let updateState = tradeModalReducer({...mockInitialState,stopLoss :100},{type:INCREMENT_STOP_LOSS});
        expect(updateState.stopLoss).toBe(100);
    })
    it("increment profit target", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState, profitTarget: 4}, {type:INCREMENT_PROFIT_TARGET});
        expect(updatedState.profitTarget).toBe(5);
        let updateState = tradeModalReducer({...mockInitialState, profitTarget :100},{type:INCREMENT_PROFIT_TARGET});
        expect(updateState.profitTarget).toBe(100);
    })
    it("decrement stop loss", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState, stopLoss:4}, {type:DECREMENT_STOP_LOSS});
        expect(updatedState.stopLoss).toBe(3);
        let updateState = tradeModalReducer({...mockInitialState,stopLoss :1},{type:DECREMENT_STOP_LOSS});
        expect(updateState.stopLoss).toBe(1);
    })
    it("decrement profit target", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState, profitTarget:4}, {type:DECREMENT_PROFIT_TARGET});
        expect(updatedState.profitTarget).toBe(3);
        let updateState = tradeModalReducer({...mockInitialState,profitTarget :1},{type:DECREMENT_PROFIT_TARGET});
        expect(updateState.profitTarget).toBe(1);
    })
    it("set profit target validity", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState}, {type:SET_PROFIT_TARGET_VALIDITY,payload:true});
        expect(updatedState.isProfitTargetValid).toBe(true);
    })
    it("set profit target validity", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState}, {type:SET_STOP_LOSS_VALIDITY,payload:true});
        expect(updatedState.isStopLossValid).toBe(true);
    })
    it("quantity empty increment", ()=>{
        const actual={...mockInitialState};
        actual.quantity=1;
        actual.item.totalCost=actual.quantity*actual.item.pricePerTicker;
        let updatedState = tradeModalReducer({...mockInitialState,quantity:''}, {type:INCREMENT_STOCK_QUANTITY});
        expect(updatedState).toStrictEqual(actual);
    })
    it("quantity empty decrement", ()=>{
        const actual={...mockInitialState};
        actual.quantity=0;
        let updatedState = tradeModalReducer({...mockInitialState,quantity:''}, {type:DECREMENT_STOCK_QUANTITY});
        expect(updatedState).toStrictEqual(actual);
    })
    it("update quantity",()=>{
        const mockInTest={...mockInitialState};
        mockInTest.item.quantity=50;
        mockInTest.quantity=50;
        let updateState = tradeModalReducer(mockInTest,{type: UPDATE_QUANTITY, payload: ""});
        expect(updateState.quantity).toStrictEqual("");
        updateState = tradeModalReducer(mockInTest,{type: UPDATE_QUANTITY, payload: "34"});
        expect(updateState.quantity).toBe("34");
        updateState = tradeModalReducer(mockInTest,{type: UPDATE_QUANTITY, payload: "134.8"})
        expect(updateState.quantity).toBe(mockInTest.quantity);
    })
    it("set quantity validity", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState}, {type:SET_QUANTITY_VALIDITY,payload:true});
        expect(updatedState.isQuantityValid).toBe(true);
    })
    it("default case", ()=>{
        let updatedState = tradeModalReducer({...mockInitialState}, {type:"SOME DUMMY"});
        expect(updatedState).toStrictEqual(mockInitialState);
    })
})
