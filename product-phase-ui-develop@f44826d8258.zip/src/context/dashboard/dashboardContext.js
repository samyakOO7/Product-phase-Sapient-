import { createContext } from "react";

const dashboardContext = createContext();

export default dashboardContext;
