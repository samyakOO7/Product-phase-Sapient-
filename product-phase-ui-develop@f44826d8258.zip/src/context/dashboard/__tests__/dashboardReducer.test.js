import {
  ADD_TICKER_TO_WATCHLIST,
  GET_ClOSE_TARDE_LIST,
  LOAD_DASHBOARD_DATA,
  GET_LOSING_TRADE_LIST,
  GET_OPEN_TARDE_LIST,
  REMOVE_TICKER_FROM_WATCHLIST,
  GET_WINNING_TRADE_LIST,
  LOAD_USER_WATCHLIST,
} from "../../../config/typeConstants";
import dashboardReducer from "../dashboardReducer";
import DASHBOARD_DATA from "../__tests__/dashboardTestConstants.json";
const watchList = DASHBOARD_DATA.watchlist;

describe("Dashboard Reducer Tests", () => {
  const initialDashboardState = {
    openTrades: 84,
    closedTrades: 5,
    winningTrades: 80,
    losingTrades: 4,
    alertsConvertedToTrades: 25,
    gain: 89,
    tradeAlertsGenerated: 23,
    equity: 89,
  };
  it("load-user-watchlist", () => {
    const updateState = dashboardReducer(initialDashboardState, {
      type: LOAD_USER_WATCHLIST,
      payload: watchList,
    });
    expect(updateState.watchlist).toStrictEqual(watchList);
  });

  it("load dashboard data", () => {
    const updateState = dashboardReducer(
      {},
      { type: LOAD_DASHBOARD_DATA, payload: initialDashboardState }
    );
    expect(updateState).toStrictEqual(initialDashboardState);
  });
  it("remove ticker from watchlist", () => {
    const updateState = dashboardReducer(
      {
        ...initialDashboardState,
        watchlist: [{ tickerNumber: 2345 }, { tickerNumber: 4567 }],
      },
      { type: REMOVE_TICKER_FROM_WATCHLIST, payload: 2345 }
    );
    expect(updateState.watchlist).toStrictEqual([{ tickerNumber: 4567 }]);
  });
  it("add ticker to watchlist", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState, watchlist: watchList },
      { type: ADD_TICKER_TO_WATCHLIST, payload: watchList[0] }
    );
    expect(updatedState.watchlist.length).toBe(3);
  });
  it("get open trade list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState, openTradeList: [] },
      { type: GET_OPEN_TARDE_LIST, payload: DASHBOARD_DATA.openTrades }
    );
    expect(updatedState.openTradeList).toStrictEqual(DASHBOARD_DATA.openTrades);
  });
  it("get close trade list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      {
        type: GET_ClOSE_TARDE_LIST,
        payload: { closedTrades: DASHBOARD_DATA.closedTrades },
      }
    );
    expect(updatedState.closeTradeList).toStrictEqual(
      DASHBOARD_DATA.closedTrades
    );
  });
  it("get winning trades list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: GET_WINNING_TRADE_LIST, payload: DASHBOARD_DATA.winningTrades }
    );
    expect(updatedState.winningTradeList).toStrictEqual(
      DASHBOARD_DATA.winningTrades
    );
  });
  it("get losing trades list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: GET_LOSING_TRADE_LIST, payload: DASHBOARD_DATA.losingTrades }
    );
    expect(updatedState.losingTradeList).toStrictEqual(
      DASHBOARD_DATA.losingTrades
    );
  });
  it("default case", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: "SOME_RANDOM_STATE" }
    );
    expect(updatedState).toStrictEqual(updatedState);
  });

  it("load dashboard data", () => {
    const updateState = dashboardReducer(
      {},
      { type: LOAD_DASHBOARD_DATA, payload: initialDashboardState }
    );
    expect(updateState).toStrictEqual(initialDashboardState);
  });
  it("remove ticker from watchlist", () => {
    const updateState = dashboardReducer(
      {
        ...initialDashboardState,
        watchlist: [{ tickerNumber: 2345 }, { tickerNumber: 4567 }],
      },
      { type: REMOVE_TICKER_FROM_WATCHLIST, payload: 2345 }
    );
    expect(updateState.watchlist).toStrictEqual([{ tickerNumber: 4567 }]);
  });
  it("add ticker to watchlist", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState, watchlist: watchList },
      { type: ADD_TICKER_TO_WATCHLIST, payload: watchList[0] }
    );
    expect(updatedState.watchlist.length).toBe(3);
  });
  it("get open trade list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState, openTradeList: [] },
      { type: GET_OPEN_TARDE_LIST, payload: DASHBOARD_DATA.openTrades }
    );
    expect(updatedState.openTradeList).toStrictEqual(DASHBOARD_DATA.openTrades);
  });
  it("get close trade list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      {
        type: GET_ClOSE_TARDE_LIST,
        payload: { closedTrades: DASHBOARD_DATA.closedTrades },
      }
    );
    expect(updatedState.closeTradeList).toStrictEqual(
      DASHBOARD_DATA.closedTrades
    );
  });
  it("get winning trades list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: GET_WINNING_TRADE_LIST, payload: DASHBOARD_DATA.winningTrades }
    );
    expect(updatedState.winningTradeList).toStrictEqual(
      DASHBOARD_DATA.winningTrades
    );
  });
  it("get losing trades list", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: GET_LOSING_TRADE_LIST, payload: DASHBOARD_DATA.losingTrades }
    );
    expect(updatedState.losingTradeList).toStrictEqual(
      DASHBOARD_DATA.losingTrades
    );
  });
  it("default case", () => {
    const updatedState = dashboardReducer(
      { ...initialDashboardState },
      { type: "SOME_RANDOM_STATE" }
    );
    expect(updatedState).toStrictEqual(updatedState);
  });
});
