import "@testing-library/jest-dom";
import axios from "axios";
import { getOpenTradeList } from "../DashboardState";
import { refreshAccessToken } from "../../../utils/refreshAccessToken";

jest.mock("axios");
jest.mock("../../../utils/logger");
jest.mock("../../../utils/refreshAccessToken");
jest.mock("react-toastify");
let dashboardDispatcher = jest.fn();
jest.mock("pino", () => () => {
  return {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
    success: jest.fn(),
  };
});
describe("getOpenTradeList function", () => {
  it("should return response status 204 on successful deletion of trade alert", async () => {
    axios.get.mockResolvedValue({ data: ["this", "is", "drep"] });
    await getOpenTradeList(101, dashboardDispatcher);
    expect(axios.get).toHaveBeenCalledTimes(1);
    expect(dashboardDispatcher).toHaveBeenCalled();
  });
  it("should throw error when status 403 or invalid access token ", async () => {
    let errResponse = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS_TOKEN",
            },
          ],
        },
        status: 403,
      },
    };

    axios.get.mockReturnValue(Promise.reject(errResponse));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getOpenTradeList(101, dashboardDispatcher);
    expect(axios.get).toHaveBeenCalled();
  });
  it("should throw error when  400", async () => {
    let errResponse2 = {
      response: {
        data: {
          errors: [
            {
              message: "Error message",
              code: "INVALID_ACCESS",
            },
          ],
        },
        status: 404,
      },
    };

    axios.get.mockReturnValue(Promise.reject(errResponse2));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getOpenTradeList(101, dashboardDispatcher);
    expect(axios.get).toHaveBeenCalled();
  });

  it("should throw error when access token is invalid", async () => {
    let errResponse3 = {
      response: {
        data: {
          errors: [],
        },
        status: 404,
      },
    };
    axios.get.mockReturnValue(Promise.reject(errResponse3));
    refreshAccessToken.mockResolvedValueOnce(false);
    await getOpenTradeList(101, dashboardDispatcher);
    expect(axios.get).toHaveBeenCalled();

    axios.get.mockReturnValue(Promise.reject(errResponse3));
    refreshAccessToken.mockResolvedValueOnce(true);
    await getOpenTradeList(101, dashboardDispatcher);
    expect(axios.get).toHaveBeenCalled();
  });
});
