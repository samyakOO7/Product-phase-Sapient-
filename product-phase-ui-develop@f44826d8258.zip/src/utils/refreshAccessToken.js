import axios from "axios";
import { toast } from "react-toastify";
import { refreshTokenURL } from "../config/urlConstants";
import setAuthToken from "./setAuthToken";

export const refreshAccessToken = async () => {
  const refreshToken = localStorage.getItem("refreshToken");
  if (!refreshToken) {
    return false;
  }

  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    axios.defaults.headers.common["Authorization"] = `Bearer ${refreshToken}`;
    const res = await axios.post(refreshTokenURL, config);

    setAuthToken(res?.data?.accessToken, refreshToken);
    return true;
  } catch (err) {
    toast.error("Session expired. Login again!")
    setAuthToken();
    return false;
  }
};
