import { JSEncrypt } from "jsencrypt";

export const encryptUsingRsa = (message, publicKey) => {
  const jsEncrypt = new JSEncrypt();

  jsEncrypt.setPublicKey(publicKey);
  return jsEncrypt.encrypt(message).toString();
};
