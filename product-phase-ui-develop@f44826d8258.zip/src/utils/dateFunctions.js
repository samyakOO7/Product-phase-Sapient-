import moment from "moment";

export const prettyDateTime=(rawDate)=>{
    let formattedDate=moment(rawDate);
    let returnDate=formattedDate.format("Do MMMM YYYY") ;
    let returnTime=formattedDate.format("h:mm a");
    return {
        date:returnDate,
        time:returnTime
    }    
}