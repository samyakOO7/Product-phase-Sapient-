import "@testing-library/jest-dom";
import axios from "axios";
import setAuthToken from "../setAuthToken";
import { refreshAccessToken } from './../refreshAccessToken';
jest.mock("axios");
jest.mock("../setAuthToken")
describe("test refresh token",()=>{
    it("refresh token false",async ()=>{
        const output=await refreshAccessToken();
        expect(output).toBe(false);
    })
    it("refresh token true",async ()=>{
        localStorage.setItem("refreshToken","fdcscd");
        const output=await refreshAccessToken();
        expect(output).toBe(true);
    })
    it("refresh token error",async ()=>{
        let errResponse = {
            response: {
                data: {
                    errors: [
                        {   
                            message: "Error message",
                            code: "INVALID_ACCESS_TOKEN"
                        }
                    ]
                },
                status: 403
            }
        };
        localStorage.setItem("refreshToken","fdcscd");
        axios.post.mockReturnValue(Promise.reject(errResponse));
        const output=await refreshAccessToken();
        expect(output).toBe(false);
    })
})
