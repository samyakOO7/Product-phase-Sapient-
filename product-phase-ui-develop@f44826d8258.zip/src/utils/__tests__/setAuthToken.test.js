import "@testing-library/jest-dom";
import axios from "axios";
import setAuthToken from './../setAuthToken';
import { refreshAccessToken } from './../refreshAccessToken';
jest.mock("axios");
describe("set Auth token",()=>{
    it("access token true",async ()=>{
        const accessToken=true;
        const refreshAccessToken="fdfvf"
        setAuthToken(accessToken,refreshAccessToken);
        expect(localStorage.getItem("accessToken")).toBe("true");
        expect(localStorage.getItem("refreshToken")).toBe("fdfvf");

    })
    it("access token false",async ()=>{
        const accessToken=false;
        const refreshAccessToken="fdfvf"
        setAuthToken(accessToken,refreshAccessToken);
        expect(localStorage.getItem("accessToken")).toBe(null);
        expect(localStorage.getItem("refreshToken")).toBe(null);
    })
})
