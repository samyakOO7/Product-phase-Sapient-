/**
 * @jest-environment jsdom
 */


import React, { useContext } from "react";
import { useLocation, useNavigate } from "react-router-dom";

import { logger } from "../../utils/logger";
import {
  handleDeleteTradeAlert,
  handleGetTradeDetails,
} from "../../services/tradeAlertsData";
import authContext from "../../context/auth/authContext";
import "./TradeAlertPage.css";
import { prettyDateTime } from "../../utils/dateFunctions";
import TradeModal from "../tradeDetails/TradeModal";
import { tradeContext } from "../../context/trade/tradeContext";
import { LOAD_TRADE_DETAIL_MODAL } from "../../config/typeConstants";
export default function TradeAlertPage() {
  const { showModal, setShowModal, tradeDetailModalDispatcher } =
    useContext(tradeContext);

  const location = useLocation();
  const navigate = useNavigate();
  const tickerName = location.state.tickerName;
  const timeFrame = location.state.timeframe;
  const tradeDirection = location.state.tradeDirection;
  const timeStamp = location.state.timestamp;
  const tradeAlertId = location.state.tradeAlertId;

  const { authState } = useContext(authContext);
  /*
   * @jest-environment node
   */
  function deleteTradeAlert() {
    logger.info("Delete trade alert pressed" + authState.userId);
    handleDeleteTradeAlert(navigate, authState?.user?.userId, tradeAlertId);
  }

  const { date, time } = prettyDateTime(timeStamp);
  return (
    <>
      <div style={{ height: "89.5vh" }}>
        <div className="container bg-white rounded border bg-white rounded border w-75 list-group my-2 p-1 text-center d-flex flex-row justify-content-center align-items-center">
          <img
            src="details.gif"
            alt="details"
            width={40}
            height={40}
            className="m-2 alert-details-icon"
            style={{ display: "inline-block" }}
          />
          <h3 className="m-0 text-break heading-trade-alert-page">
            Trade Alert Details
          </h3>
        </div>

        <div className="container rounded bg-white border w-75 d-flex flex-column p-2">
          <div className="card-body fw-bold mb-2 text-center">
            <h4 className="card-text fw-bold mb-2 text-capitalize text-center text-wrap text-break tickername">
              {tickerName}
            </h4>
          </div>
          <ul className="rounded list-group list-group-flush">
            <li className="container rounded border-bottom border-2 list-group-item alert-details">
              Trade direction :{" "}
              <span
                className="fw-bold"
                style={
                  tradeDirection === "buy"
                    ? { color: "green" }
                    : { color: "red" }
                }
              >
                {tradeDirection.toUpperCase()}{" "}
              </span>{" "}
            </li>
            <li className="container rounded border-bottom border-2 list-group-item alert-details">
              Time frame : {timeFrame / 1440} day
            </li>
            <li className="list-group-item alert-details">
              Alert generated on : {date},&nbsp;{time}
            </li>
          </ul>
          <div className="d-flex card-body justify-content-center align-items-center flex-wrap m-1">
            <button
              type="button"
              className="btn btn-primary m-2 button"
              data-testid="get-info-btn"
              onClick={() =>
                handleGetTradeDetails(
                  authState?.user?.userId,
                  tradeAlertId
                ).then((res) => {
                  tradeDetailModalDispatcher({
                    type: LOAD_TRADE_DETAIL_MODAL,
                    payload: res,
                  });
                  setShowModal(true);
                })
              }
            >
              Get Insights
            </button>
            <button
              type="button"
              className="btn btn-danger m-2 button"
              data-testid="delete-alert-btn"
              onClick={deleteTradeAlert}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
      <TradeModal show={showModal} onHide={() => setShowModal(false)} />
    </>
  );
}
