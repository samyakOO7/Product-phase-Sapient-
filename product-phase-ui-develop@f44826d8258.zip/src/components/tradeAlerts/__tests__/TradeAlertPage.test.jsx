import React from "react";
import TradeAlertPage from "../TradeAlertPage";
import AuthState from "../../../context/auth/AuthState";
import { render, fireEvent, screen, act } from "@testing-library/react";
import { BrowserRouter, useLocation } from "react-router-dom";
import authContext from "../../../context/auth/authContext";
import TradeState from "../../../context/trade/TradeState";
import {
  handleDeleteTradeAlert,
  handleGetTradeDetails,
} from "../../../services/tradeAlertsData";
import { tradeContext } from "../../../context/trade/tradeContext";
import user from "@testing-library/user-event";
jest.mock("pino", () => () => {
  return {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  };
});
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useLocation: jest.fn(),
}));

const dispatchMock = jest.fn();
const onShowModalMock = jest.fn();
const TestComponent = () => (
  <authContext.Provider
    value={{
      authState: {
        user: {
          userId: 1,
          userName: "Sanjay",
        },
      },
    }}
  >
    <tradeContext.Provider
      value={{
        showModal: false,
        setShowModal: onShowModalMock,
        tradeDetailModalDispatcher: dispatchMock,
      }}
    >
      <BrowserRouter>
        <TradeAlertPage />
      </BrowserRouter>
    </tradeContext.Provider>
  </authContext.Provider>
);
jest.mock("../../tradeDetails/TradeModal", () => ({ show, onHide }) => {
  onHide();
  return <></>;
});
jest.mock("../../../services/tradeAlertsData");
describe("TradeAlertPage", () => {
  window.setImmediate = window.setTimeout;
  it("delete is pressed", async () => {
    useLocation.mockImplementation(() => ({
      pathname: "localhost:3000/example/path",
      state: {
        tickerName: "Reliance",
        timeFrame: 1,
        tradeDirection: "buy",
        timestamp: 1231231,
        tradeAlertId: 122,
      },
    }));
    handleDeleteTradeAlert.mockReturnValueOnce(true);
    render(<TestComponent />);
    let deleteBtn = await screen.findByText(/Delete/i);
    await act(() => fireEvent.click(deleteBtn));
  });
  it("get info button  is pressed for buy", async () => {
    useLocation.mockImplementation(() => ({
      pathname: "localhost:3000/example/path",
      state: {
        tickerName: "Reliance",
        timeFrame: 1,
        tradeDirection: "buy",
        timestamp: 1231231,
        tradeAlertId: 122,
      },
    }));
    handleGetTradeDetails.mockResolvedValueOnce(true);
    render(<TestComponent />);
    let getInfoBtn = screen.getByTestId("get-info-btn");
    user.click(getInfoBtn);
  });
  it("get info button is pressed for sell", async () => {
    useLocation.mockImplementation(() => ({
      pathname: "localhost:3000/example/path",
      state: {
        tickerName: "Reliance",
        timeFrame: 1,
        tradeDirection: "sell",
        timestamp: 1231231,
        tradeAlertId: 122,
      },
    }));
    handleGetTradeDetails.mockResolvedValueOnce(true);
    render(<TestComponent />);
    let getInfoBtn = screen.getByTestId("get-info-btn");
    user.click(getInfoBtn);
  });
});
