import '../TradeAlerts'
import '@testing-library/jest-dom'
import { render } from "@testing-library/react";
import '@testing-library/jest-dom'
import { BrowserRouter } from "react-router-dom";
import TradeAlerts from "../TradeAlerts"
import authContext from "../../../context/auth/authContext";
import tradeAlertsData from '../../../services/tradeAlertsData';
import TradeAlertsList from './TradeAlertsList.json'
const sleep = ms => new Promise(
    resolve => setTimeout(resolve, ms)
  );
jest.mock('react-infinite-scroll-component',()=>{return (props)=>{
    setTimeout(()=>{
        props.next()
    },1000);
    return (<></>);
}});
jest.mock('../../../services/tradeAlertsData');

const RenderPage=()  =>{ 
    return  (
        <authContext.Provider
         value={{
        authState: {
            user: {
                userId: 1,
                userName:"Sanjay",
            }
        }
    }}>
      <BrowserRouter>
        <TradeAlerts />
      </BrowserRouter>

      </authContext.Provider>)
}

describe('Trade Alert fetch data',()=>{
    jest.setTimeout(10000);
    it("some test",async()=>{
        tradeAlertsData.mockResolvedValueOnce(TradeAlertsList);
        render(<RenderPage/>);
        await sleep(4000);
    })
})