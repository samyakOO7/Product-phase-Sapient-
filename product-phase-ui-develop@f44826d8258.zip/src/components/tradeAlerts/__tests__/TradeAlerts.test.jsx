import { render,screen,fireEvent,act } from "@testing-library/react";
import '@testing-library/jest-dom'
import { BrowserRouter } from "react-router-dom";
import TradeAlerts from "../TradeAlerts"
import authContext from "../../../context/auth/authContext";
import tradeAlertsData from '../../../services/tradeAlertsData';
import TradeAlertsList from './TradeAlertsList.json'
import  user  from '@testing-library/user-event';
jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });
  const sleep = ms => new Promise(
    resolve => setTimeout(resolve, ms)
  );
jest.mock('../../../services/tradeAlertsData');
const RenderPage=()  =>{ 
    return  (
        <authContext.Provider
         value={{
        authState: {
            user: {
                userId: 1,
                userName:"Sanjay",
            }
        }
    }}>
      <BrowserRouter>
        <TradeAlerts />
      </BrowserRouter>

      </authContext.Provider>)
}
describe('TradeAlerts',()=>{
    it('render alerts with data ',()=>{
        tradeAlertsData.mockResolvedValueOnce(TradeAlertsList);
        render(<RenderPage/>);
    })
    it('render alerts with empty list ',async()=>{
        tradeAlertsData.mockResolvedValueOnce([]);
        render(<RenderPage/>);
        await sleep(2000);
    })
    it('render alerts with data scroll',async()=>{
        tradeAlertsData.mockResolvedValueOnce(TradeAlertsList);
        render(<RenderPage/>);
        const infinite=screen.getByTestId("scrollbar");
        await act(()=>fireEvent.scroll(infinite,{ target: { scrollY: 1000000 } }));
        await sleep(1000);
        
    })
    it('alerts direct on click',async()=>{
        tradeAlertsData.mockResolvedValue(TradeAlertsList);
        render(<RenderPage/>);
        const infinite=screen.getByTestId("scrollbar");
        await act(()=>fireEvent.scroll(infinite,{ target: { scrollY: 1000000 } }));
        await sleep(1000);
        const alert_rows=await screen.findAllByTestId("alert-row");
        user.click(alert_rows[0]);
    })
    
}
)