import { Link, useNavigate, useLocation } from "react-router-dom";
import InfiniteScroll from "react-infinite-scroll-component";
import { useState, useEffect, useContext } from "react";
import tradeAlertsData from "../../services/tradeAlertsData";
import { FcClock } from "react-icons/fc";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import authContext from "../../context/auth/authContext";
import "./TradeAlerts.css";
import { prettyDateTime } from "../../utils/dateFunctions";

function TriggerTruncate20Char(p) {
  return p.tickerName.length > 20 ? (
    <OverlayTrigger
      placement="bottom"
      delay={{ show: 250, hide: 400 }}
      overlay={
        <Tooltip id="button-tooltip" className="text-capitalize">
          {p.tickerName}
        </Tooltip>
      }
    >
      <h6 className="extra-small-tickername mb-1 text-start text-capitalize">
        {`${p.tickerName.substring(0, 20)}...`}
      </h6>
    </OverlayTrigger>
  ) : (
    <h6 className="extra-small-tickername mb-1 text-capitalize">
      {p.tickerName}
    </h6>
  );
}
export default function TradeAlerts() {
  const { authState } = useContext(authContext);
  const [alertList, setAlertList] = useState([]);
  const [alertFeed, setAlertFeed] = useState([]);
  const [noAlerts, setNoAlerts] = useState(false);
  const location = useLocation();

  useEffect(() => {
    tradeAlertsData(authState.user.userId).then((value) => {
      if (value.length === 0) {
        setNoAlerts(true);
      }
      setAlertList(value);
      setAlertFeed(value.slice(0, pageSize));
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location]);

  const navigate = useNavigate();
  const pageSize = 11;
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);

  const fetchData = () => {
    if (alertFeed.length < alertList.length) {
      setTimeout(() => {
        setAlertFeed(
          alertFeed.concat(
            alertList.slice(
              currentPage * pageSize,
              currentPage * pageSize + pageSize
            )
          )
        );
      }, 500);
      setCurrentPage(currentPage + 1);
    } 
    else setHasMore(false);
  };

  return noAlerts ? (
    <div>
      <div style={{height: "90vh"}} className="bg-white jumbotron d-flex flex-column justify-content-center align-items-center">
        <h1 className="display-6 fw-bold">No Alerts Found!</h1>
        <p className="lead text-center">You have no alerts, start trading with Tradezy!</p>
        <img src="notFound.png" height={140} width={140} alt="noAlerts" />
        <p></p>
        <Link to="/" className="btn btn-warning btn-md fw-normal" role="button">
          Go To Home
        </Link>
      </div>
    </div>
  ) : (
    <>
      <div>
        <div className="container bg-white rounded border w-75 list-group my-2 p-0 text-center d-flex flex-row justify-content-center align-items-center">
          <img
            src="notification.gif"
            alt="alert icon"
            width={40}
            height={40}
            className="m-2 bell-icon "
            style={{ display: "inline-block" }}
          />
          <h3 className="heading-trade-alert">Trade Alerts</h3>
        </div>

        <div className="list-group" data-testid="scrollbar">
          <InfiniteScroll
            dataLength={alertFeed.length}
            next={fetchData}
            hasMore={hasMore}
            loader={
              <div style={{ textAlign: "center" }}>
                <div className="spinner-grow text-primary" role="status"></div>
              </div>
            }
            endMessage={
              <p style={{ textAlign: "center" }}>
                <b>You have seen it all!</b>
              </p>
            }
          >
            {alertFeed.map((p, i) => {
              const { date, time } = prettyDateTime(p.timestamp);
              return (
                <div
                  data-testid="alert-row"
                  key={i}
                  onClick={() => {
                    navigate("/alert-details", {
                      state: {
                        tickerName: p.tickerName,
                        timeframe: p.timeframe,
                        tradeDirection: p.tradeDirection,
                        timestamp: p.timestamp,
                        tradeAlertId: p.tradeAlertId,
                      },
                    });
                  }}
                  className="container rounded w-75 list-group-item list-group-item-action alert-list"
                >
                  <div className="extra-small-screen d-sm-flex flex-sm-column justify-content-sm-center align-items-sm-start d-lg-flex flex-lg-row  my-2 justify-content-between">
                    <div className="tickername-truncate-20characters">
                      {TriggerTruncate20Char(p)}
                    </div>
                    <div className="tickername-truncate-40characters">
                      {p.tickerName.length > 30 ? (
                        <OverlayTrigger
                          placement="bottom"
                          delay={{ show: 250, hide: 400 }}
                          overlay={
                            <Tooltip id="button-tooltip">
                              {p.tickerName}
                            </Tooltip>
                          }
                        >
                          <h6 className="extra-small-tickername mb-1 text-start text-capitalize">
                            {`${p.tickerName.substring(0, 30)}...`}
                          </h6>
                        </OverlayTrigger>
                      ) : (
                        <h6 className="extra-small-tickername mb-1 text-capitalize">
                          {p.tickerName}
                        </h6>
                      )}
                    </div>
                    <div className="w-100 extra-small-screen-child1 d-sm-flex justify-content-sm-between align-items-sm-end align-self-sm-start justify-content-md-between align-items-md-center justify-content-lg-evenly">
                      <div className="extra-small-screen-child2 d-sm-flex flex-sm-column justify-content-sm-center align-items-sm-center  flex-md-row justify-content-lg-center">
                        <span
                          className="extra-small-alertdetails badge text-dark my-sm-1 my-lg-0 mx-2 pt-2 fw-bold"
                          style={{ background: "#e0dfdf" }}
                        >
                          Trade Direction :{" "}
                          <span
                            style={
                              p.tradeDirection === "buy"
                                ? { color: "green", fontWeight: 700 }
                                : { color: "red", fontWeight: 700 }
                            }
                          >
                            {p.tradeDirection.toUpperCase()}{" "}
                          </span>
                        </span>
                        <span className="extra-small-alertdetails badge  bg-warning text-dark my-sm-1 my-lg-0 mx-2 pt-2 ">
                          {" "}
                          Time Frame : {p.timeframe / 1440} day
                        </span>
                        <span className="extra-small-alertdetails badge  bg-success my-sm-1 my-lg-0 mx-2 pt-2">
                          Confidence Score : {p.confidence}%
                        </span>
                      </div>
                      <div className="both-clock-and-time">
                        <span className="mx-2">
                          <FcClock />
                        </span>
                        <em>
                          {date},&nbsp;
                          {time}
                        </em>
                      </div>
                      <div className="only-clock">
                        <OverlayTrigger
                          placement="bottom"
                          delay={{ show: 250, hide: 400 }}
                          overlay={
                            <Tooltip id="button-tooltip">
                              <em>
                                {date},&nbsp;
                                {time}
                              </em>
                            </Tooltip>
                          }
                        >
                          <span className="mx-2">
                            <FcClock />
                          </span>
                        </OverlayTrigger>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </InfiniteScroll>
        </div>
      </div>
    </>
  );
}
