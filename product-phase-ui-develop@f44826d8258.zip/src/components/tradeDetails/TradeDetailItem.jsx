
import React, { useState ,useRef} from 'react'
import { logger } from './../../utils/logger';
import {  capitalize , getDirectionColor,abbreviate,  getStatusColor} from './../../utils/TradeDetailUtil';
import {   BADGE_STYLE_CLASS } from '../../config/screenConstants';
import {MdDelete} from 'react-icons/md';
import {VscRefresh} from 'react-icons/vsc';
import DropdownActions from './DropDownActions';
import useClickOutside from './hooks/useClickOutside';
import { prettyDateTime } from './../../utils/dateFunctions';

const SuffixCell = ({main, suffix})=>{
    return (<div className="d-flex flex-column justify-content-center">
            <div>{main}</div>
            <em  className = {" trade-details-time-text "} > {suffix}</em> 
        </div>)
}
const ActionComponent = ({isMobile, showDrop, setShowDrop, item, ...rest})=>
{
    if(isMobile){
        return <DropdownActions show = {showDrop} setShow = {setShowDrop} item ={item} {...rest} />
    }else{

    
            return (<>
             <button className={(rest.refreshDisabled) ? 'mx-1 btn btn-outline-secondary' : 'mx-1 btn btn-outline-primary' } 
                    disabled ={rest.refreshDisabled} 
                    onClick = {()=>rest.onRefresh(item)}
                    >
                      <span className='hidden-element' >refresh</span> 
                      <VscRefresh/>
              </button>
              <button className={(rest.deleteDisabled) ? 'mx-1 btn btn-outline-secondary' : 'mx-1 btn btn-outline-danger' } 
                      disabled={rest.deleteDisabled}  
                      onClick ={()=>rest.onDelete(item)}
                      > 
                      <span className='hidden-element'>delete</span>   
                      <MdDelete/>
              </button> 
              <button className={(rest.executeDisabled) ? 'mx-1 btn btn-outline-secondary execute-button-text' : 'mx-1 btn btn-outline-dark execute-button-text' } 
                      disabled={rest.executeDisabled}   
                      onClick ={()=>rest.onExecute(item)} 
                      > Execute 
              </button>
            </>);
    }
}
const TickerComponent = ({isMobile, 
                            tickerId,
                            tickerName,
                            tradeDirection,
                            tradeDirectionClass,
                            date
                            
                        })=>{

    const tickerNameClass = "trade-detail-ticker-font";
    const main = (isMobile)? (   <> 
                                    <span className={tickerNameClass}>{tickerId} </span>
                                    <span className={tradeDirectionClass} style = {{fontSize:"9px"}}>{tradeDirection}</span>
                                 </> ):
                                 (<>{tickerId}</>);
    const suffix = (isMobile)? date : tickerName
    return <SuffixCell  main ={main} suffix ={suffix} />   
}
const TradeDetailItem = ({item, isMobile, setModalValues, ...rest}) => {
    const [showAction, setShowAction] = useState(false);
    const dropRef = useRef();
    useClickOutside(dropRef, ()=>{setShowAction(false) });
    const tdClass= "p-xs-0 px-sm-4 align-middle px-md-0 py-2 px-lg-2";
  
    const openModal = ()=>{
      setModalValues(item);
    }
    const capitalizeDirection  = capitalize(item.tradeDirection);
    const{date ,time } = prettyDateTime(item.createdAt);
    const tradeDirectionClass =BADGE_STYLE_CLASS+getDirectionColor(item.tradeDirection);
    const statusClass = BADGE_STYLE_CLASS+getStatusColor(item.status);
    const statusText = (isMobile)?abbreviate(item.status) :capitalize(item.status);
    const TradeDirectionComponent =  <span className= { tradeDirectionClass}>{capitalize(item.tradeDirection)} </span>
    const TradeDirectionOnDesktop = (!isMobile)? (<>
                                            <td onClick ={openModal} className ={tdClass}> 
                                                {TradeDirectionComponent}
                                            </td>
                                            <td onClick ={openModal} className ={tdClass}>
                                                <SuffixCell main ={time} suffix ={date} />
                                            </td>
                                     </>) : <></>;
    const actionHandler = (isMobile)? ()=>{ setShowAction(status => !status);} : ()=>{ logger.debug({message :"action pressed on desktop"})}
    const pricePerTickerDtext = (item.status !=='no_holding') ? ("₹ "+(Math.round(item.pricePerTicker*100)/100) ): "-"
    const quantityDtext = (item.status !=='no_holding') ? item.quantity: "-"
    const totalCostDtext = (item.status !=='no_holding') ? ("₹ "+(Math.round(item.totalCost*100)/100)): "-"
    return (    
      <tr className ={"p-0 mb-xs-3 trade-detail-font"}    >
            <td onClick ={openModal}  className = {tdClass }>
                    <TickerComponent 
                        isMobile ={isMobile}
                        tradeDirection ={capitalizeDirection}
                        tradeDirectionClass = {tradeDirectionClass}
                        tickerId ={item.ticker.tickerId}
                        tickerName = {item.ticker.tickerName}
                        date = {date}
                        />
            </td>
            {TradeDirectionOnDesktop}
            <td onClick ={openModal} className ={tdClass +" wrap-white-space "}>
                <span className= {statusClass}>{statusText} </span> 
            </td>
            <td onClick ={openModal} className ={tdClass}> {pricePerTickerDtext} </td>
            <td onClick ={openModal} className ={tdClass}>{quantityDtext} </td>
            <td onClick ={openModal} className ={tdClass}>  {totalCostDtext} </td>
            <td 
                ref = {dropRef}
                className='trade-detail-ddn'
                onClick = {actionHandler}
                data-testid = "more"
                >
                <div className='d-flex my-xs-2 p-0 my-lg-1' >
                    <ActionComponent
                                 isMobile ={isMobile}
                                 showDrop ={showAction} 
                                 setShowDrop = {setShowAction}
                                 item ={item}
                                 {...rest}
                                />
                </div>
            </td>
      </tr>)
  }

TradeDetailItem.defaultProps = {
  refreshDisabled : false,
  executeDisabled : false,
  deleteDisabled : false
}
export default TradeDetailItem;