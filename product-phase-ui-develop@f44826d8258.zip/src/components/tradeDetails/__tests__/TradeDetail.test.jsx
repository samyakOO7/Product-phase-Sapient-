import "@testing-library/jest-dom";

import { render, screen } from "@testing-library/react";
import AuthContext from "../../../context/auth/authContext";
import { BrowserRouter } from "react-router-dom";
import { tradeContext } from "../../../context/trade/tradeContext";
import TradeDetails from "../TradeDetails";
import LIST_ITEM from "./TradeDetailsListTestConstant.json";
import { loadTradeDetails } from "../../../context/trade/TradeState";
import useIsMobile from "../../../hooks/useIsMobile";

jest.mock("pino", () => () => {
  return {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  };
});
jest.mock("../../../context/trade/TradeState");
jest.mock("../../../hooks/useIsMobile");
jest.mock("../../pagination/Pagination", () => ({ onPageChange, ...rest }) => {
  onPageChange();
  return <></>;
});
jest.mock("../TradeDetailHeader", () => () => <></>);
jest.mock("../TradeModal", () => ({ show, onHide }) => {
  onHide();
  return <></>;
});
const modalDispatcherMock = jest.fn();
const setShowModalMock = jest.fn();
const detailDispatcherMock = jest.fn();

const TestComponent = ({ tradeDetailData }) => (
  <AuthContext.Provider
    value={{
      authState: {
        accessToken: localStorage.getItem("accessToken"),
        isAuthenticated: false,
        loading: true,
        user: { userId: 1, userName: "sanjay" },
      },
    }}
  >
    <tradeContext.Provider
      value={{
        tradeDetail: tradeDetailData,
        tradeDetailModalDispatcher: modalDispatcherMock,
        showModal: false,
        setShowModal: setShowModalMock,
        currentPage: 1,
        setCurrentPage: jest.fn(),
        tradeDetailDispatcher: detailDispatcherMock,
      }}
    >
      <TradeDetails />
    </tradeContext.Provider>
  </AuthContext.Provider>
);

describe("TradeDetail", () => {
  window.setImmediate = window.setTimeout;
  beforeEach(() => {
    useIsMobile.mockImplementation(() => false);
  });
  it("render correctly", async () => {
    window.setImmediate = window.setTimeout;
    loadTradeDetails.mockResolvedValueOnce(true);
    render(
      <TestComponent tradeDetailData={{ data: LIST_ITEM, pageCount: 2 }} />
    );
    const tickerIdElement = await screen.findByText(/ICICI.BNK/i);
    expect(tickerIdElement).toBeInTheDocument();
  });
  it("renders Empty trade detail when trade detail is undefined", async () => {
    window.setImmediate = window.setTimeout;
    loadTradeDetails.mockResolvedValueOnce(true);
    render(
      <BrowserRouter>
        <TestComponent />{" "}
      </BrowserRouter>
    );
    await screen.findByText(/you have no trade detail/i);
  });
});
