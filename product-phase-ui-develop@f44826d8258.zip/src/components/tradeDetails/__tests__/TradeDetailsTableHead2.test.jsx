import '@testing-library/jest-dom'
import { render,screen} from "@testing-library/react";
import TradeDetailsTableHead from '../TradeDetailTableHead';

jest.mock("../../../hooks/useIsMobile",()=>()=>true);

const TestComponent = ({isMobile}) =>
                <TradeDetailsTableHead isMobile={isMobile} /> ;
describe('TradeDetailTableHead',()=>{
    it('should render correcty on desktop',()=>{
        render(<TestComponent isMobile={false}/>)
        screen.getAllByText(/^Ticker$/i);
        // screen.getByText(/Ticker/i);
        screen.getByText(/Direction/i);
        screen.getByText(/updated/i);
        screen.getByText(/Status/i);
        screen.getByText(/Price/i);
        screen.getByText(/Qty/i);
        screen.getByText(/Total/i);
    })
    it('should render correcty when  isMobile is true',()=>{
        render(<TestComponent isMobile={true}/>)
        screen.getByText(/^Ticker$/i);
        screen.getByText(/Status/i);
        screen.getByText(/Price/i);
        screen.getByText(/Qty/i);
        screen.getByText(/Total/i);
    })
 
});