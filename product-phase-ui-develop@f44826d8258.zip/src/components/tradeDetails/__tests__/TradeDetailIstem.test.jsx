import '@testing-library/jest-dom'
import { render,screen} from "@testing-library/react";
import user from "@testing-library/user-event";
import { tradeContext } from '../../../context/trade/tradeContext';
import { logger } from '../../../utils/logger';
import TradeDetailsItem from "../TradeDetailItem";
import ISF_ITEM from "./TradeDetailsItemTestConstant.json";

jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });

const dispatchMock = jest.fn();
const item = ISF_ITEM;
const TestComponent = ({item, ...rest}) =>
                          <tradeContext.Provider value ={{tradeDetailModalDispatcher :dispatchMock}} >
                            <TradeDetailsItem item = {item} isMobile={false} {...rest}/> 
                          </tradeContext.Provider>
describe("TradeDetailsItem",()=>{
  
    beforeEach(()=>{
      jest.mock("../../../utils/logger");
      logger.debug.mockImplementationOnce(()=>{});
    })
   
    it("should render correctly",()=>{
        render(<TestComponent item = {item}/>);
        const tickerIdElement = screen.getAllByText(/ICICI.BNK/i);
        expect(tickerIdElement.length).toBe(1);
        const statusElement = screen.getByText(/insufficient funds/i);
        expect(statusElement).toBeInTheDocument();
    })
    it("should render correctly for no holdings",()=>{

      render(<TestComponent item = {{...item, status:'no_holding'}}/>);
      const tickerIdElement = screen.getAllByText(/-/i);
      expect(tickerIdElement.length).toBe(3);
      // const statusElement = screen.getByText(/insufficient funds/i);
      // expect(statusElement).toBeInTheDocument();
  })

    it("should refresh on clicking refresh",()=>{
       const mockOnRefresh = jest.fn();
       render(<TestComponent item = {item} onRefresh={mockOnRefresh} />);
       const refreshElement =  screen.getByRole('button',{name:/refresh/i});
       user.click(refreshElement);
       expect(mockOnRefresh).toHaveBeenCalledTimes(1);
    })
    it("should call ondelete  on clicking delete ",()=>{
      const mockOnDelete = jest.fn();
      render(<TestComponent item = {item} onDelete={mockOnDelete}  />);
      const deleteElement =  screen.getByRole('button',{name:/delete/i});
      user.click(deleteElement);
      expect(mockOnDelete).toHaveBeenCalledTimes(1);
   })
   it("should call onExecute  on clicking execute ",()=>{
      const mockOnExecute = jest.fn();
      render(<TestComponent item = {item} onExecute ={mockOnExecute} />);
      const executeElement =  screen.getByRole('button',{name:/execute/i});
      user.click(executeElement);
      expect(mockOnExecute).toHaveBeenCalledTimes(1);
    })

    it("should invoke onshow on click in any of entry fields",async ()=>{
        const onShowMock = jest.fn();
        render(<TestComponent item={item} setModalValues = {onShowMock}/>);
        const tickerIdElement = screen.getByText(/ICICI.BNK/i);
        expect(tickerIdElement).toBeInTheDocument();
        user.click(tickerIdElement);
        expect(onShowMock).toHaveBeenCalledTimes(1);
    })
    it("should show drop down on clicking actions in mobile",async ()=>{
        render(<TestComponent item={item} isMobile ={true} />);
        const moreElement = screen.getByText(/more/i);
        user.click(moreElement);
        await screen.findByText(/refresh/i);
    })

})