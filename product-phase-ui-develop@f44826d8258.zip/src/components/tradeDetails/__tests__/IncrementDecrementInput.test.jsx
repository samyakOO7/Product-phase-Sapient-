import '@testing-library/jest-dom'
import { render,screen } from "@testing-library/react";
import user from '@testing-library/user-event';
import IncrementDecrementInput from '../IncrementDecrementInput';

const onUpdateMock = jest.fn();
const onIncrementMock = jest.fn();
const onDecrementMock = jest.fn();


const TestComponent = ({...props})=>{
    return (
    <IncrementDecrementInput {...props} />
    )
}
TestComponent.defaultProps ={
    property : "mockProperty", 
    onIncrement : onIncrementMock,
    onDecrement : onDecrementMock, 
    onUpdate : onUpdateMock,
    isIncrementDisabled : false,
    isDecrementDisabled : false,
    isUpdateDisabled : false,
    isError : false,
    errorMessage : "error  message"
}
describe("EmptyTradeDetail",()=>{
    
   
    it("should render correctly",()=>{
        render(
                <TestComponent />
                );
       screen.getByTestId("decrement-button");
       screen.getByTestId("increment-button");
       screen.getByTestId("update-input");
    })

    it("should redirect to alerts-page",()=>{
        
        render(
            <TestComponent isError={true} errorMessage={"error"} />
            );
        const errMessag = screen.getByText(/error/i);
        expect(errMessag).toBeInTheDocument();
    })
    it("should fire onIncrement on clicking on increment",()=>{
        const onIncrementMock = jest.fn();
        render(<TestComponent  onIncrement={onIncrementMock} />);
        const incrementButton = screen.getByTestId("increment-button");
        user.click(incrementButton);
        expect(onIncrementMock).toHaveBeenCalled();
    })
    it("should fire onDecrement on clicking on increment",()=>{
        const onDecrementMock = jest.fn();
        render(<TestComponent  onDecrement={onDecrementMock} />);
        const decrementButton = screen.getByTestId("decrement-button");
        user.click(decrementButton);
        expect(onDecrementMock).toHaveBeenCalled();
    })
    it("should fire onUpdate on clicking on increment",()=>{
        const onUpdateMock = jest.fn();
        render(<TestComponent  onUpdate={onUpdateMock} />);
        const updateInput = screen.getByTestId("update-input");
        user.type(updateInput,"23");
        expect(onUpdateMock).toHaveBeenCalled();
    })
})
