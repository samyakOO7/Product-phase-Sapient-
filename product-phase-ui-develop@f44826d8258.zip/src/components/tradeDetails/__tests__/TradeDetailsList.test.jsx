import "@testing-library/jest-dom";

import { render, screen } from "@testing-library/react";
import user from "@testing-library/user-event";
import AuthContext from "../../../context/auth/authContext";
import { BrowserRouter } from "react-router-dom";
import { tradeContext } from "../../../context/trade/tradeContext";
import TradeDetailsList from "../TradeDetailsList";
import LIST_ITEM from "./TradeDetailsListTestConstant.json";
import {
  deleteTrade,
  executeTrade,
} from "../../../services/executeDeleteTrade";

jest.mock("pino", () => () => {
  return {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  };
});
jest.mock("../../../services/executeDeleteTrade");
const hideMock = jest.fn();
jest.mock("../TradeModal", () => ({ show, onHide }) => {
  onHide();
  return <></>;
});
const onHideCatchMock = jest.fn();

const modalDispatcherMock = jest.fn();
const setShowModalMock = jest.fn();
const detailDispatcherMock = jest.fn();

const TestComponent = ({ data, isMobile }) => (
  <AuthContext.Provider
    value={{
      authState: {
        accessToken: localStorage.getItem("accessToken"),
        isAuthenticated: false,
        loading: true,
        user: { userId: 1, userName: "sanjay" },
      },
    }}
  >
    <tradeContext.Provider
      value={{
        tradeDetailModalDispatcher: modalDispatcherMock,
        showModal: false,
        setShowModal: setShowModalMock,
        currentPage: 1,
        tradeDetailDispatcher: detailDispatcherMock,
      }}
    >
      <TradeDetailsList data={data} isMobile={isMobile} userId={1} />
    </tradeContext.Provider>
  </AuthContext.Provider>
);

TestComponent.defaultProps = {
  data: LIST_ITEM,
  isMobile: false,
};

describe("TradeDetailList", () => {
  beforeEach(() => {
    executeTrade.mockImplementation(() => {});
    deleteTrade.mockImplementation(() => {});
  });
  it("should render correctly on desktop", () => {
    render(<TestComponent />);
    const tickerIdElement = screen.getByText(/FELL.NS/i);
    expect(tickerIdElement).toBeInTheDocument();
  });
  it("should render correctly on mobile", () => {
    render(<TestComponent isMobile={true} />);
    const tickerIdElement = screen.getByText(/FELL.NS/i);
    expect(tickerIdElement).toBeInTheDocument();
  });

  it("should open modal", () => {
    render(<TestComponent />);
    const tickerIdElement = screen.getByText(/FELL.NS/i);
    user.click(tickerIdElement);
    expect(modalDispatcherMock).toHaveBeenCalled();
    expect(setShowModalMock).toHaveBeenCalled();
  });

  it("should refresh on clicking refresh", () => {
    render(<TestComponent />);
    const refreshElement = screen.getAllByText(/refresh/i);
    user.click(refreshElement[0]);
  });

  it("should delete on clicking delete", () => {
    render(<TestComponent />);
    const deleteElement = screen.getAllByText(/delete/i);
    user.click(deleteElement[0]);
    expect(deleteTrade).toHaveBeenCalled();
  });
  it("should execute on clicking execute", () => {
    render(<TestComponent />);
    const executeElement = screen.getAllByText(/execute/i);
    user.click(executeElement[0]);
    expect(executeTrade).toHaveBeenCalled();
  });
  it("should render empty trade details component when data is empty", () => {
    render(
      <BrowserRouter>
        <TestComponent data={[]} />
      </BrowserRouter>
    );
    screen.getByText(/You have no trade details/i);
  });
});
