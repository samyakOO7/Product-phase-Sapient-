import '@testing-library/jest-dom'

import { render,screen} from "@testing-library/react";
import user from "@testing-library/user-event";
import ToolTip from '../../util/ToolTip';


const TestComponent = ({props}) =>
               <table><thead> <th> <ToolTip  {...props} /> </th></thead></table> ;

describe('ToolTip',()=>{
    it('renders correctly ',async ()=>{
        // render(<TestComponent actualMessage ="ticker"  toolTipMessage ="ttlmsg"/>);
        // const overlay = screen.getByText('ticker');
        // expect(overlay).toBeInTheDocument();
        // user.click(overlay);
    })
})  

