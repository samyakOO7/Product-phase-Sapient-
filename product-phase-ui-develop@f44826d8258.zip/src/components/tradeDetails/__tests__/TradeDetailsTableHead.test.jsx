import '@testing-library/jest-dom'

import { render,screen, act} from "@testing-library/react";
import user from "@testing-library/user-event";
import TradeDetailsTableHead from '../TradeDetailTableHead';

jest.mock("../../../hooks/useIsMobile",()=>()=>false);

const TestComponent = ({isMobile}) =>
                <TradeDetailsTableHead isMobile={isMobile} /> ;
describe('TradeDetailTableHead',()=>{
    it('should render correcty on desktop',async ()=>{
        render(<TestComponent isMobile={false} />)
        screen.getAllByText(/^Ticker$/i);
        const dirComponent = screen.getByText(/Direction/i);
        await act(()=>user.hover(dirComponent));
        await screen.findByText(/trade direction/i);
        screen.getByText(/updated/i);
        screen.getByText(/Status/i);
        screen.getByText(/Price/i);
        screen.getByText(/Quantity/i);
        screen.getByText(/Total/i);
    })
    it('should render correcty on medium screen',()=>{
        render(<TestComponent isMobile={true}/>)
        screen.getByText(/^Ticker$/i);
        screen.getByText(/Status/i);
        screen.getByText(/Price/i);
        screen.getByText(/Quantity/i);
        screen.getByText(/Total/i);
    })
 
});


