import '@testing-library/jest-dom'

import { render,screen} from "@testing-library/react";
import user from "@testing-library/user-event";
import React from 'react';
import useClickOutside from '../hooks/useClickOutside';
import TradeDetailHeader from '../TradeDetailHeader';


jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });

const mockedUseState = jest.fn();
jest.mock('react', () => ({
                   ...jest.requireActual('react') ,
                  useState: () => [true, mockedUseState]
}));
jest.mock("../hooks/useClickOutside");
const callerClickOutside = jest.fn();

const TestComponent = ({...rest}) =>
                <TradeDetailHeader {...rest} /> ;
TestComponent.defaultProps = {
    isMobile : false
}
describe('TradeDetailHeader',()=>{
    beforeEach(()=>{
        useClickOutside.mockImplementation((ref, fnc)=>{ callerClickOutside(fnc);});
    })
    it('should render header ',()=>{
        render(<TestComponent />);
        const heading  = screen.getByText(/trade detail/i);
        expect(heading).toBeInTheDocument();
       
    });
    it('should open info on click for mobile screens ',()=>{
        
        render(<TestComponent isMobile={true} />);
        const heading  = screen.getByText(/info/i);
        expect(heading).toBeInTheDocument();

    });

    it('should open  on click for  ',()=>{
        render(<TestComponent isMobile ={true} />);
        const heading  = screen.getByText(/trade detail/i);
        user.click(heading);
        const isf = screen.getByText(/ISF/i);
        expect(isf).toBeInTheDocument();
    });
    it('should not open slide up on clicking header in desktop ', async ()=>{
        render(<TestComponent isMobile={false} />);
        const heading  = screen.getByText(/trade detail/i);
        user.click(heading);
        const isf = screen.queryByText(/ISF/i);
        expect(isf).not.toBeInTheDocument();
    });
    it('should  change state on click outside  ',()=>{
        render(<TestComponent isMobile={true} />);
        const argument = callerClickOutside.mock.calls[0][0];
        argument.call();
        expect(mockedUseState).toHaveBeenCalledTimes(1);
    });
    it('should  change state of open collapse ',()=>{
        render(<TestComponent isMobile={true} />);
        const tradeDetail = screen.getByText(/trade detail/i);
        user.click(tradeDetail);
        expect(mockedUseState).toHaveBeenCalledTimes(1);
        const argument = mockedUseState.mock.calls[0][0];
        expect(argument.call(false)).toBe(true);
    });
   
})