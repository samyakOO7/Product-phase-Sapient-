import '@testing-library/jest-dom'
import AuthContext from "../../../context/auth/authContext";
import {BrowserRouter} from 'react-router-dom';
import { tradeContext } from '../../../context/trade/tradeContext';
import TradeDetails from '../TradeDetails';
import LIST_ITEM from "./TradeDetailsListTestConstant.json";
import TRADE_MODAL_ITEMS from "./TradeModal.json"
import user from "@testing-library/user-event";
import { loadTradeDetails } from '../../../context/trade/TradeState';
import TradeModal from '../TradeModal';
import { executeTrade } from '../../../services/executeDeleteTrade';
import { fireEvent, render,screen } from '@testing-library/react';
import { refreshTrade } from './../../../services/executeDeleteTrade';
jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });

jest.mock('../../../context/trade/TradeState');
jest.mock('../../../services/executeDeleteTrade');
jest.mock('../../../context/trade/tradeModalReducer')
const modalDispatcherMock= jest.fn();
const setShowModalMock = jest.fn();
const detailDispatcherMock = jest.fn();
const getMockTradeModal=(TRADE_MODAL_ITEM)=>{
    return {
    item: { ...TRADE_MODAL_ITEM },
        quantity: 10,
        stopLoss: 10,
        profitTarget: 10,
        incrementQuantityStatus: false,
        decrementQuantityStatus: true,
        incrementStopLossStatus: true,
        decrementStopLossStatus: true,
        incrementProfitTargetStatus: true,
        decrementProfitTargetStatus: true, 
        isStopLossValid: true,
        isProfitTargetValid: true};
}
const TestComponent = ({tradeModalState}) =>
            ( <AuthContext.Provider
                value={{
                  authState:  {
                    accessToken: localStorage.getItem("accessToken"),
                    isAuthenticated: false,
                    loading: true,
                    user: { userId: 1, userName: "sanjay" },
                  }
                  
                }}
              >
                <tradeContext.Provider value ={{
                                                tradeDetailModal:tradeModalState,
                                                tradeDetailModalDispatcher :modalDispatcherMock,
                                                showModal: true,
                                                setShowModal: setShowModalMock,
                                                currentPage :1,
                                                setCurrentPage : jest.fn(),
                                                tradeDetailDispatcher : detailDispatcherMock
                                                }} >
                                <TradeModal show={true} onHide ={"hello"}/>
                    </tradeContext.Provider>
        </AuthContext.Provider>
            )

describe('TradeModal',()=>{
    it('render for buy no action ',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])}/>);
        const tradeStatus=screen.getByText(/NO ACTION/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/BUY/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('render for buy executed ',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["buy_executed"])}/>);
        const tradeStatus=screen.getByText(/EXECUTED/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/BUY/i);
        expect(tradeDirection).toBeInTheDocument();
    })   
    it('render for buy pending',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["buy_pending"])}/>);
        const tradeStatus=screen.getByText(/PENDING/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/BUY/i);
        expect(tradeDirection).toBeInTheDocument();
    })   
    it('render for buy insufficient funds ',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["buy_insufficient_funds"])}/>);
        const tradeStatus=screen.getByText(/INSUFFICIENT FUNDS/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/BUY/i);
        expect(tradeDirection).toBeInTheDocument();
    }) 
    it('render for sell no action ',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"])}/>);
        const tradeStatus=screen.getByText(/NO ACTION/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/SELL/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('render for sell executed ',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_executed"])}/>);
        const tradeStatus=screen.getByText(/EXECUTED/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/SELL/i);
        expect(tradeDirection).toBeInTheDocument();
    })   
    it('render for sell pending',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_pending"])}/>);
        const tradeStatus=screen.getByText(/PENDING/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/SELL/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('render for sell quantity mismatch',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_quantity_mismatch"])}/>);
        const tradeStatus=screen.getByText(/QUANTITY MISMATCH/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/SELL/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('render for sell no holding',()=>{
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_holding"])}/>);
        const tradeStatus=screen.getByText(/NO HOLDING/i);
        expect(tradeStatus).toBeInTheDocument();
        const tradeDirection=screen.getByText(/SELL/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('check the execute button being pressed successful',()=>{
        const mockExecute=jest.fn();
        executeTrade.mockImplementation(mockExecute);
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"])}/>);
        const executeButton=screen.getByTestId("execute");
        user.click(executeButton);
        expect(mockExecute).toHaveBeenCalledTimes(1);
    })
    it('check the refresh button being pressed successful',()=>{
        const mockExecute=jest.fn();
        refreshTrade.mockImplementation(mockExecute);
        render(<TestComponent tradeModalState={getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"])}/>);
        const executeButton=screen.getByTestId("refresh");
        user.click(executeButton);
        expect(mockExecute).toHaveBeenCalledTimes(1);
    })
    it('check the execute button stop loss empty',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"]),stopLoss:""};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const executeButton=screen.getByTestId("execute");
        user.click(executeButton);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('check the execute button profit target empty',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"]),profitTarget:""};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const executeButton=screen.getByTestId("execute");
        user.click(executeButton);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('negative gain',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"])};
        tradeDetail.item.gain=-232;
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const tradeDirection=screen.getByText(/- ₹ 232/i);
        expect(tradeDirection).toBeInTheDocument();
    })
    it('decrement button in stop loss',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const decrement=screen.getAllByTestId("decrement-button")[1]
        user.click(decrement);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('decrement button in profit target',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const decrement=screen.getAllByTestId("decrement-button")[2]
        user.click(decrement);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('increment button in stop loss',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const increment=screen.getAllByTestId("increment-button")[1]
        user.click(increment);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('increment button in profit target',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const increment=screen.getAllByTestId("increment-button")[2]
        user.click(increment);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('change in stop loss',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const updateStopLoss=screen.getAllByTestId("update-input")[1];
        user.type(updateStopLoss,'23');
        expect(modalDispatcherMock).toHaveBeenCalledTimes(2);
    })
    it('change in profit target',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const updateProfitTarget=screen.getAllByTestId("update-input")[2];
        user.type(updateProfitTarget,'23');
        expect(modalDispatcherMock).toHaveBeenCalledTimes(2);
    })
    it('undefined gain',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["sell_no_action"])};
        tradeDetail.item.gain=undefined;
        render(<TestComponent tradeModalState={tradeDetail}/>);;
    })
    it('increment button in quantity',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        tradeDetail.incrementQuantityStatus=true;
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const increment=screen.getAllByTestId("increment-button")[0]
        user.click(increment);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('decrement button in quantity',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const decrement=screen.getAllByTestId("decrement-button")[0]
        user.click(decrement);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
    it('execute disabled for 0 quantity',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["zero_quantity"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const execute=screen.getByTestId("execute");
        expect(execute).toBeDisabled();
    })
    it('change in quantity',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"])};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const updateStopLoss=screen.getAllByTestId("update-input")[0];
        user.type(updateStopLoss,'23');
        expect(modalDispatcherMock).toHaveBeenCalledTimes(2);
    })
    it('check the execute button quantity empty',()=>{
        const tradeDetail={...getMockTradeModal(TRADE_MODAL_ITEMS["buy_no_action"]),quantity:""};
        render(<TestComponent tradeModalState={tradeDetail}/>);
        const executeButton=screen.getByTestId("execute");
        user.click(executeButton);
        expect(modalDispatcherMock).toHaveBeenCalledTimes(1);
    })
})