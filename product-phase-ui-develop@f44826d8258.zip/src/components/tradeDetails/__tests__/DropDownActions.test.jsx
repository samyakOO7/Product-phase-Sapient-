import '@testing-library/jest-dom'

import { render,screen} from "@testing-library/react";
import user from "@testing-library/user-event";
import DropdownActions from '../DropDownActions';
import  ISF_ITEM from "./TradeDetailsItemTestConstant.json";

jest.mock('pino', () => () => {
    return {
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn(),
      debug: jest.fn()
    };
  });
const setModalValuesMock = jest.fn();
const onRefreshMock = jest.fn();
const onDeleteMock = jest.fn();
const onExecuteMock = jest.fn();

const TestComponent = ({item ,...rest}) =>
      
                <DropdownActions item = {item} setModalValues = {setModalValuesMock} {...rest} /> ;

TestComponent.defaultProps = {
    key : "2c6f51ed-0ea2-477a-9b5b-ae0f592331445",
    refreshDisabled : false,
    deleteDisabled : false,
    executeDisabled : false,
    onRefresh : onRefreshMock,
    onDelete : onDeleteMock,
    onExecute :onExecuteMock
}

describe('DropDownActions',()=>{
    it('should call onRefresh on refresh',()=>{
        render(<TestComponent item ={ISF_ITEM} show={true} setShow ={jest.fn()} />);
    
        const refresh = screen.getByText(/Refresh/i);
        expect(refresh).toBeInTheDocument();
        user.click(refresh)
        expect(onRefreshMock).toHaveBeenCalledTimes(1);
    })

    it('should call onDelete on delete',()=>{
        render(<TestComponent item = {ISF_ITEM} show={true} />);
        const deleteElement = screen.getByText(/delete/i);
        expect(deleteElement).toBeInTheDocument();
        user.click(deleteElement);
        expect(onDeleteMock).toHaveBeenCalledTimes(1);
    })

    it('should call onExecute on execute',()=>{
        render(<TestComponent item = {ISF_ITEM} show={true} />);
        const executeElement = screen.getByText(/execute/i);
        expect(executeElement).toBeInTheDocument();
        user.click(executeElement);
        expect(onExecuteMock).toHaveBeenCalledTimes(1);
    })
    it('should  disable refresh on disabled',()=>{
        render(<TestComponent item = {ISF_ITEM} setShow ={jest.fn()} show={true} refreshDisabled={true} deleteDisabled ={false} executeDisabled = {false} />);
        const refresh = screen.getByText(/refresh/i).closest('div');
        expect(refresh).toHaveAttribute('disabled');
        const deleteElement = screen.getByText(/delete/i).closest('div');
        expect(deleteElement).not.toHaveAttribute('disabled');
        const executeElement = screen.getByText(/execute/i).closest('div');
        expect(executeElement).not.toHaveAttribute('disabled');
       
      
    })

    it('should  disable delete on disabled',()=>{
        render(<TestComponent item = {ISF_ITEM} setShow ={jest.fn()} show={true} refreshDisabled={false} deleteDisabled ={true} executeDisabled = {false} />);
        const refresh = screen.getByText(/refresh/i).closest('div');
        expect(refresh).not.toHaveAttribute('disabled');
        const deleteElement = screen.getByText(/delete/i).closest('div');
        expect(deleteElement).toHaveAttribute('disabled');
        const executeElement = screen.getByText(/execute/i).closest('div');
        expect(executeElement).not.toHaveAttribute('disabled');
    })

    it('should  disable refresh on disabled',()=>{
        render(<TestComponent item = {ISF_ITEM} setShow ={jest.fn()} show={true} executeDisabled = {true} />);
        const refresh = screen.getByText(/refresh/i).closest('div');
        expect(refresh).not.toHaveAttribute('disabled');
        const deleteElement = screen.getByText(/delete/i).closest('div');
        expect(deleteElement).not.toHaveAttribute('disabled');
        const executeElement = screen.getByText(/execute/i).closest('div');
        expect(executeElement).toHaveAttribute('disabled');
       
    })
    
});