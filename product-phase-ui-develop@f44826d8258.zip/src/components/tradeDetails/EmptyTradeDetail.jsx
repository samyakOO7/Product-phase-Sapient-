import {BsFillInboxFill} from 'react-icons/bs';
import {useNavigate} from 'react-router-dom';
const EmptyTradeDetail =()=>{
    const navigate = useNavigate();
    const redirect  = ()=>{
        navigate("/alerts");
    }
    return (
        <div className=' bg-grey d-flex justify-content-center align-items-center flex-column' style ={{height: "100vh"}}>
            <div className=' d-flex justify-content-center align-items-center flex-column p-3'>
                <br/>
                <br/>
           
           <div>
               <BsFillInboxFill color={'primary'} size ={70}/> 
            </div> 
                <br/>
           <div>
                <h4>You have no trade details </h4>
            </div> 
            <div>
                <p> Start by adding trade details</p>
            </div>
            <div>
                <button className='btn btn-primary' onClick = {redirect}> go to alerts </button>
            </div>
            </div>
        </div>
    )
}
export default EmptyTradeDetail;
