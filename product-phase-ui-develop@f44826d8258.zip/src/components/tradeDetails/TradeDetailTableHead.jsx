import { TAB_MAX_THRESHOLD} from '../../config/screenConstants';
import ToolTip from "../util/ToolTip";
import useIsMobile from '../../hooks/useIsMobile';
export const TradeDetailTableHead = ({isMobile})=>{
    const isTab = useIsMobile(TAB_MAX_THRESHOLD);
    
    const priceMessage = (!isTab)? "Price Per Ticker" : "Price";
    const qtyMessage = (!isTab)? "Quantity": "Qty";
    const costMessage = (!isTab)? "Total Cost": "Total";
    const headingClass = "px-md-1";
    const directionComponent = (!isMobile)? (<> 
                                              <th className={headingClass}><ToolTip actualMessage="Direction" toolTipMessage = " trade Direction like buy or sell for the user"/></th>
                                              <th className={headingClass}><ToolTip actualMessage="Updated At"  toolTipMessage = "Shows the time at which it is created"/></th>
                                          </>) : (<></>);
    const tableHeadClass = "d-table-row";
    const totalFold = (!isMobile)? "Actions"  : "";
    return(<tr className={tableHeadClass }>
            <th className={headingClass}><ToolTip actualMessage = "Ticker" toolTipMessage = "Ticker Id of the stock " /></th>
            {directionComponent}
            <th className={headingClass}><ToolTip actualMessage="Status" toolTipMessage = "Shows the status of the trade detail like pending, executed"/></th>
            <th className={headingClass}><ToolTip actualMessage={priceMessage}  toolTipMessage = "Shows the current price of the ticker"/></th>
            <th className={headingClass}><ToolTip actualMessage={qtyMessage}  toolTipMessage = "Shows the quantity of the stocks that are present in the trade detail"/></th>
            <th className={headingClass}><ToolTip actualMessage={costMessage} toolTipMessage = "Shows the total cost / gain which a user can get from this trade detail"/></th>
            <th className={headingClass}>
               <ToolTip actualMessage={totalFold} toolTipMessage ="Show the actions that you can take on trade details"/>
            </th>
          </tr>)
}

export default TradeDetailTableHead;