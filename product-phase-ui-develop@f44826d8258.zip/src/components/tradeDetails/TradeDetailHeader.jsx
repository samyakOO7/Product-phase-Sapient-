import { BADGE_STYLE_CLASS } from "../../config/screenConstants";
import Collapse from 'react-bootstrap/Collapse';
import {BsFillInfoCircleFill} from 'react-icons/bs';

import {useState,useRef} from 'react';
import { abbreviate, getAllKeys ,capitalize, getStatusColor} from "../../utils/TradeDetailUtil";
import useClickOutside from "./hooks/useClickOutside";

const InfoTable = ({open})=>{
    return ( <Collapse in = {open} >
        <div className={" mt-0 mb-2 px-4"}   >
            <div className="bg-white">
                <table className=" table table-sm">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Abbreviation</th>
                        </tr>
                    </thead>
                    <tbody >
                        {
                            getAllKeys().map(key => <tr key = {key} ><td><span className={ BADGE_STYLE_CLASS+getStatusColor(key)}>{abbreviate(key)} </span></td><td>{capitalize(key)}</td></tr>)
                        }
                    </tbody>
                </table>
           </div>
        </div>
 </Collapse>)
}
const TradeDetailHeader = ({isMobile})=>{

    const [open,setOpen] = useState(false);
    const tradeRef = useRef();
    useClickOutside(tradeRef,()=>{setOpen(false)});
    const InfoComponent = (isMobile) ? ( <div className="d-inline">
                                                <BsFillInfoCircleFill />
                                                <span className="hidden-element"> info</span>
                                            </div> ):(
                                                <></>);
    const infoClickHandler = ()=>{
        if(isMobile)
        {
            setOpen(state => !state);
        }
    }  
    const infoTable  = (isMobile)? <InfoTable open ={open} /> :<></>  ;                           
    return (<div ref ={tradeRef}>
                <div 
                    className={"text-center shadow-sm bg-white p-2 my-2 rounded "}
                    onClick={infoClickHandler}
                    > 
                    <h3 className="d-inline trade-detail-header mx-2">Trade Details</h3>
                    {InfoComponent}
                </div>
                    {infoTable}
        </div>
    );
}
export default TradeDetailHeader;