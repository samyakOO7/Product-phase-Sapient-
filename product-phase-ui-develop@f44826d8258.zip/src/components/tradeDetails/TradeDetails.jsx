import React, { useMemo, useContext,useState } from 'react'
import {tradeContext} from './../../context/trade/tradeContext';
import authContext from './../../context/auth/authContext';
import { loadTradeDetails } from './../../context/trade/TradeState';
import Spinner from "../pages/Spinner";


import EmptyTradeDetail from './EmptyTradeDetail';
import TradeDetailHeader from './TradeDetailHeader';
import TradeDetailsList from './TradeDetailsList';
import Pagination from './../pagination/Pagination';
import { MOBILE_MAX_THRESHOLD } from '../../config/screenConstants';
import useIsMobile from '../../hooks/useIsMobile.jsx';
import '../commonCss/TradeTable.css';
import { logger } from '../../utils/logger';
let PageSize = 7;
const TradeDetailHome = () => {
  const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
  const {tradeDetail,tradeDetailDispatcher}=useContext(tradeContext);
  const [loading, setLoading] = useState(true);
  const {currentPage, setCurrentPage} = useContext(tradeContext);
  const {authState}=useContext(authContext);

  logger.info("authState userId" ,authState.user.userId )
  useMemo(() => {
    setLoading(true);
    loadTradeDetails(
      authState.user.userId,
      currentPage - 1,
      tradeDetailDispatcher
    ).then(() => setLoading(false));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage]);
  if (loading) return <Spinner />;

  if (typeof tradeDetail==='undefined')
    return(<EmptyTradeDetail isMobile={isMobile} />);
  return (
    <div className ="trade-detail-container height-component "  >
        <div>
              <TradeDetailHeader  isMobile ={isMobile} />
              <TradeDetailsList data={tradeDetail.data} isMobile = {isMobile} userId={ authState.user.userId} />
              <div className='trade-detail-pagination'>
                            <Pagination 
                            className="pagination-bar"
                            currentPage={currentPage}
                            totalPages={tradeDetail.pageCount}
                            pageSize={PageSize}
                            onPageChange={(page) =>{ 
                              setCurrentPage(page); 
                          
                              }}
                          />
              </div>
        </div>
    </div>
  );
};

const TradeDetails = () => {
  return <TradeDetailHome />;
};

export default TradeDetails;
