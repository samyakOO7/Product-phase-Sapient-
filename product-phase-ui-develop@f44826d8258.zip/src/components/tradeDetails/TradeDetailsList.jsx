import React , { useContext } from 'react'
import EmptyTradeDetail from './EmptyTradeDetail.jsx';
import TradeModal from './TradeModal'
import TradeDetailItem from './TradeDetailItem';
import {  LOAD_TRADE_DETAIL_MODAL } from '../../config/typeConstants';
import { tradeContext } from './../../context/trade/tradeContext';
import { logger } from "../../utils/logger";
import TradeDetailTableHead from './TradeDetailTableHead';
import { deleteTrade, executeTrade, refreshTrade } from './../../services/executeDeleteTrade';
import {Table} from 'react-bootstrap';

const TradeDetailsList = ({data, userId, isMobile}) => {
  const{showModal,setShowModal,tradeDetailModalDispatcher,currentPage,tradeDetailDispatcher}=useContext(tradeContext);

  const tableClass = (isMobile)? "table-sm" : "table-hover";
  const setModalValues=(item)=>{
    tradeDetailModalDispatcher({
      type: LOAD_TRADE_DETAIL_MODAL,
      payload: item,
    });
    setShowModal(true);
  };
  const executeTradeDetail = (item) => {
    executeTrade({
      tradeDetailId: item.tradeDetailId,
      stopLoss: item.stopLoss,
      profitTarget: item.profitLoss,
      quantity: item.quantity,
      userId: userId,
      currentPage: currentPage,
      tradeDetailDispatcher: tradeDetailDispatcher,
    });
  };
  const deleteTradeDetail=(item)=>{
    logger.info()
    deleteTrade(item.tradeDetailId,userId,currentPage,tradeDetailDispatcher);
  };
  const refreshHandler = (item)=>{
    refreshTrade(item.tradeDetailId,userId,tradeDetailDispatcher); 
  }
  const deleteHandler = (item)=>{
    logger.debug({message:"delete btn is pressed"}); 
    deleteTradeDetail(item);
  }
  const executeHandler = (item)=>{
    logger.debug({message:"execute btn is pressed"}); 
    executeTradeDetail(item);
  }
  logger.debug({message: "render in Trade details list",data})
  return (
    <div className='shadow-sm my-md-3 mb-5  bg-white rounded '>
       <Table   className= {tableClass}>
            <thead>
              <TradeDetailTableHead  isMobile ={isMobile} />
            </thead>
            <tbody id ="scrollable-target">
              {data?.map(item => 
              <TradeDetailItem 
                    isMobile ={isMobile}
                    item = {item} 
                    key = {item.tradeDetailId} 
                    setModalValues ={setModalValues}
                    onRefresh = {refreshHandler}
                    onDelete = {deleteHandler}
                    onExecute = {executeHandler}
                    refreshDisabled = {(item.status === 'pending' || item.status === 'executed')}
                    executeDisabled = {(item.status === 'pending' || item.status === 'executed' ||item.quantity===0)}
                    deleteDisabled = {(item.status === 'executed')}
                  
                    />)
                  }
            </tbody>  
      </Table>
      <TradeModal show={showModal} onHide ={()=>setShowModal(false)} />
        {(data?.length === 0) && <EmptyTradeDetail/>}
    </div>
  )
}

export default TradeDetailsList;
