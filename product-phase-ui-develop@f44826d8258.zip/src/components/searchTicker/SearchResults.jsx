import axios from "axios";
import React, { useContext, useEffect, useState } from "react";
import dashboardContext from "../../context/dashboard/dashboardContext";
import { ClipLoader } from "react-spinners";
import TickerResult from "./TickerResult";
import { searchTickerURL } from "../../config/urlConstants";
import { logger } from "../../utils/logger";
import { refreshAccessToken } from "../../utils/refreshAccessToken";

const Loading = ({ isLoading }) => {
  return (
    <>
      {isLoading && (
        <div className="spinnerContainer">
          <ClipLoader color="#3454cf" size={20} />
          <span className="loadingText">Searching...</span>
        </div>
      )}
    </>
  );
};

const searchStocks = async (query) => {
  let config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  try {
    const res = await axios.get(
      `${searchTickerURL}/${query.toString()}`,
      config
    );

    return res.data;
  } catch (error) {
    const status = error?.response?.status;
    if (status === 403) {
      logger.warn("Access token expired");
      if (refreshAccessToken()) {
        searchStocks(query);
      }
    } else {
      return null;
    }
  }
};


const SearchResults = ({ query }) => {
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { dashboardState } = useContext(dashboardContext);
  const { watchlist } = dashboardState;

  const checkForWatchlist = (tickerNumber) => {
    for (let item of watchlist) {
      if (item.tickerNumber === tickerNumber) return true;
    }
    return false;
  };
  //API call - 1
 

  useEffect(() => {
    setIsLoading(true);
    let timeOut = setTimeout(async() => {
      const res = await searchStocks(query); //call api to get search result based on query.
      setSearchResults(res);
      setIsLoading(false);
    }, 600);
    return () => clearTimeout(timeOut);
    //eslint-disable-next-line
  }, [query]);

  let noMatchFoundString = "";
  if (query.length > 20) {
    noMatchFoundString =
      "No match found for '" + query.substring(0, 20) + "...'";
  } else {
    noMatchFoundString = "No match found for '" + query + "'";
  }

  return (
    <>
      {searchResults != null ? (
        <div className="parent">
          <Loading isLoading={isLoading} />
          {!isLoading &&
            searchResults.map((val) => {
              return (
                <React.Fragment key={val.tickerNumber}>
                  <TickerResult
                    tickerDetalis={val}
                    isPresentInWatchlist={checkForWatchlist(val.tickerNumber)}
                    sizeOfWatchList={watchlist.length}
                  />
                </React.Fragment>
              );
            })}
        </div>
      ) : (
        <div className="noMatchFoundError">
          <Loading isLoading={isLoading} />
          {!isLoading && noMatchFoundString}
        </div>
      )}
    </>
  );
};

export default SearchResults;
