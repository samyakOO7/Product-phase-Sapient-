import { render, screen } from "@testing-library/react";
import '@testing-library/jest-dom';
import { BrowserRouter } from "react-router-dom";
import DashboardState from "../../../context/dashboard/DashboardState";
import Watchlist from "../Watchlist";
import dashboardContext from "../../../context/dashboard/dashboardContext";
import { tradeContext } from "../../../context/trade/tradeContext";
import TradeState from "../../../context/trade/TradeState";
import authContext from "../../../context/auth/authContext";
import userEvent from "@testing-library/user-event";
import axios from "axios"
import { deleteFromWatchlistUrl } from "../../../config/urlConstants";
jest.mock('axios');

const handleRemove = jest.fn();
const mount = () => {
  return render(
    <authContext.Provider
    value={{
        authState: {
            user: {
                userid: 1
            }
        }
    }}>
    <dashboardContext.Provider
      value={{
        dashboardState:{
          watchlist:[{tickerNumber: 1}]
        },
        dashboardDispatcher: jest.fn()
    }}>
      <tradeContext.Provider
        value={{
          showModal: false,
          setShowModal: jest.fn(),
          tradeDetailModalDispatcher: jest.fn()
        }}
      >
        <BrowserRouter>
          <Watchlist onClick={handleRemove} userId={1}/>
        </BrowserRouter>
      </tradeContext.Provider>
    </dashboardContext.Provider>
    </authContext.Provider>
  );
};
describe("WatchList Component", () => {
  it("testing Watchlist component when  watchlist is empty", () => {
    mount();
  });
  it('axios call failed',async ()=>{
    mount();
    let cartBtnElement = await screen.findByTestId('cartBtn');
    expect(cartBtnElement).toBeInTheDocument();
    
    userEvent.click(cartBtnElement);
  })
  
  it("testing Watchlist component with tickers", async () => {
    axios.get.mockResolvedValue(
      { 
          data: {
              tickerName: "Hindustan Unilever",
              tickerId: "HUL",
              tickerNumber: 2,
              tickerType: "stock",
              quantity:5,
              stopLoss:5,
              profitTarget:10
          }
      }
  )
    mount();
    let cartBtnElement = screen.getByTestId('cartBtn');
    expect(cartBtnElement).toBeInTheDocument();

    userEvent.click(cartBtnElement);
  });
});