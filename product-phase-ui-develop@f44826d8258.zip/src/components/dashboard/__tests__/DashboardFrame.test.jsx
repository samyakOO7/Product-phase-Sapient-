import { fireEvent, render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";

import DashboardFrame from "../DashboardFrame";

const showDetails = jest.fn();
jest.mock("../../../utils/logger");

const navigate = jest.fn();

describe("DashboardFrame test cases", () => {
   
  it("should render DashboardFrame", () => {
    render(
      <BrowserRouter>
        <DashboardFrame />
      </BrowserRouter>
    );
  });

  it("showDetails function  be called", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame onClick={showDetails}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
  it("showDetails function  be navigate to respective page", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame  useNavigate={navigate}
       />
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
  it("showDetails function be navigate to Open Trades page", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "green"
         title= "Open Trades"
         no={17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
  it("showDetails function be navigate to Closed Trades page", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "green"
         title= "Closed Trades"
         no={17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
  it("showDetails function be navigate to Winning Trades page", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "green"
         title= "Winning Trades"
         no={17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
  it("showDetails function be navigate to Losing Trade page", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "green"
         title= "Losing Trade"
         no={17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });

  it("Profit/Loss coverage with -ve value", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "red"
         title="Profit/Loss"
         no={-17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });

  it("Profit/Loss coverage with +ve value", async () => {
    render(
      <BrowserRouter>
        <DashboardFrame 
         color= "red"
         title="Profit/Loss"
         no={17}
         hoverStatus= "clickable"
        useNavigate={navigate}/>
      </BrowserRouter>
    );

   const frame =  screen.getByTestId("frame");

   fireEvent.click(frame);
  });
});
