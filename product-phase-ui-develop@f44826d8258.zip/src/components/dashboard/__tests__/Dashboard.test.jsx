import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../context/auth/AuthState";
import DashboardState from "../../../context/dashboard/DashboardState";
import TradeState from "../../../context/trade/TradeState";
import Dashboard from "../Dashboard";

describe("dashbaord test cases", () => {
  it("dahsboard should be rendered", () => {
    render(
      <AuthState>
        <DashboardState>
          <TradeState>
            <BrowserRouter>
              <Dashboard />
            </BrowserRouter>
          </TradeState>
        </DashboardState>
      </AuthState>
    );
  });
});
