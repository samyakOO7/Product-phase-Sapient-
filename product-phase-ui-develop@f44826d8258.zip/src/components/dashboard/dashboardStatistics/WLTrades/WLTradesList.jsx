import React from 'react'

import {Table} from 'react-bootstrap';
import WLTradeItem from './WLTradeItem';
import { logger } from '../../../../utils/logger';
import WLTableHead from './WLTableHead';

const WLTradesList = ({data, isMobile}) => {
    
 

  const tableClass = (isMobile)? "table-sm" : "table-hover";
  
  logger.debug({message: "render in Open Trades list",data})
  return (
    <div className='shadow-sm my-md-3 mb-5  bg-white rounded '>
       <Table   className= {tableClass}>
            <thead>
              <WLTableHead  isMobile ={isMobile} />
            </thead>
            <tbody id ="scrollable-target">
              {data.map(openTrade => 
              <WLTradeItem 
                    isMobile ={isMobile}
                    item = {openTrade} 
                    key = {openTrade.tickerId} 
                    
                   
                    />)
                  }
            </tbody>  
      </Table>
    
      
    </div>

  )
}

export default WLTradesList;