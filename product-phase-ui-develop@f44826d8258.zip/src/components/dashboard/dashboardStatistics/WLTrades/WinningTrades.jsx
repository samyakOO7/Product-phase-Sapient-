import React, { useMemo, useContext, useEffect, useState } from "react";

import useIsMobile from "../../../../hooks/useIsMobile.jsx";
import "../../../commonCss/TradeTable.css";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import authContext from "../../../../context/auth/authContext";
import { getWinningTradeList } from "../../../../context/dashboard/DashboardState";
import NotFound from "../NotFound";
import Pagination from "../../../pagination/Pagination";

import TableTitile from "../table/TableTitile";
import WLTradesList from "./WLTradesList";
import { MOBILE_MAX_THRESHOLD } from "../../../../config/screenConstants.js";
import Spinner from "../../../pages/Spinner";

const WinningTrades = () => {
  const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
  const [isLoading, setIsLoading] = useState(false);
  const { dashboardState, dashboardDispatcher } = useContext(dashboardContext);
  const { authState } = useContext(authContext);
  useEffect(() => {
    setIsLoading(true);
    getWinningTradeList(authState?.user?.userId, dashboardDispatcher).then(
      () => {
        setIsLoading(false);
      }
    );
    //eslint-disable-next-line
  }, []);
  const { winningTradeList } = dashboardState;
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;
  let winningTradeListPage = useMemo(() => {
    const firstPageIndex = (currentPage - 1) * pageSize;
    const lastPageIndex = firstPageIndex + pageSize;
    return winningTradeList.slice(firstPageIndex, lastPageIndex);
  }, [currentPage, winningTradeList]);
  if (isLoading) return <Spinner />;
  if (winningTradeList?.length === 0) return <NotFound title="Winning" />;

  return (
    <div className="trade-detail-container height-component table-responsive">
      <div>
        <TableTitile title={"Winning  Trades"} />
        <WLTradesList data={winningTradeListPage} isMobile={isMobile} />
        <div className="trade-detail-pagination">
          <Pagination
            data-testid="pagination"
            className="pagination-bar"
            currentPage={currentPage}
            siblingCount={1}
            totalCount={winningTradeList.length}
            pageSize={pageSize}
            onPageChange={(page) => {
              setCurrentPage(page);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default WinningTrades;
