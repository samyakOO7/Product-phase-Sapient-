import "../../../commonCss/TradeTable.css";

const SuffixCell = ({ main, suffix }) => {
  return (
    <div className="d-flex flex-column justify-content-center">
      <div>{main}</div>
      <em className={" trade-details-time-text "}> {suffix}</em>
    </div>
  );
};

const WLTradeItem = ({ item, isMobile }) => {
  const {
    tickerName,
    tickerId,
    averagePrice,
    quantity,
    currentPrice,
    currentProfitOrLoss,
  } = item;
  const tdClass = "p-xs-0 px-sm-4 align-middle px-md-0 py-2 px-lg-2";

  return (
    <tr className={"p-0 mb-xs-3 trade-detail-font"}>
      <td className={tdClass}>
        {isMobile ? (
          <SuffixCell main={tickerId} suffix={tickerName} />
        ) : (
          <SuffixCell main={tickerName} suffix={tickerId} />
        )}
      </td>

      <td className={tdClass}>
        &#8377; {Math.round(averagePrice * 100) / 100}
      </td>
      <td className={tdClass}>
        &#8377; {Math.round(currentPrice * 100) / 100}
      </td>
      <td className={tdClass}> {quantity} </td>
      <td
        className={tdClass}
        style={{
          color: currentProfitOrLoss >= 0 ? "green" : "red",
        }}
      >
        {currentProfitOrLoss < 0 ? "-" : ""} &#8377;
        {Math.round(Math.abs(currentProfitOrLoss) * 100) / 100}
      </td>
    </tr>
  );
};

export default WLTradeItem;
