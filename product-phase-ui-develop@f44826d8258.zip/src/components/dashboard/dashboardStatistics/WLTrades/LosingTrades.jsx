import React, { useMemo, useContext, useEffect, useState } from "react";

import useIsMobile from "../../../../hooks/useIsMobile.jsx";
import "../../../commonCss/TradeTable.css";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import authContext from "../../../../context/auth/authContext";
import { getLosingTradeList } from "../../../../context/dashboard/DashboardState";
import NotFound from "../NotFound";
import Pagination from "../../../pagination/Pagination";

import TableTitile from "../table/TableTitile";
import WLTradesList from "./WLTradesList";
import { MOBILE_MAX_THRESHOLD } from "../../../../config/screenConstants.js";
import Spinner from "../../../pages/Spinner";

const LosingTrades = () => {
  const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
  const [isLoading, setIsLoading] = useState(false);
  const { dashboardState, dashboardDispatcher } = useContext(dashboardContext);
  const { authState } = useContext(authContext);
  useEffect(() => {
    setIsLoading(true);
    getLosingTradeList(authState?.user?.userId, dashboardDispatcher).then(
      () => {
        setIsLoading(false);
      }
    );
    //eslint-disable-next-line
  }, []);
  const { losingTradeList } = dashboardState;
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;
  let losingTradeListPage = useMemo(() => {
    const firstPageIndex = (currentPage - 1) * pageSize;
    const lastPageIndex = firstPageIndex + pageSize;
    return losingTradeList.slice(firstPageIndex, lastPageIndex);
  }, [currentPage, losingTradeList]);

  if (isLoading) return <Spinner />;
  if (losingTradeList?.length === 0) {
    return <NotFound title="Losing" />;
  }

  return (
    <div className="trade-detail-container height-component table-responsive">
      <div>
        <TableTitile title={"Losing Trades"} />
        <WLTradesList data={losingTradeListPage} isMobile={isMobile} />
        <div className="trade-detail-pagination">
          <Pagination
            data-testid="pagination"
            className="pagination-bar"
            currentPage={currentPage}
            siblingCount={1}
            totalCount={losingTradeList.length}
            pageSize={pageSize}
            onPageChange={(page) => {
              setCurrentPage(page);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default LosingTrades;
