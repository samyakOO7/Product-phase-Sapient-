import React, { useMemo, useContext, useState } from "react";
import "../../../commonCss/TradeTable.css";
import TableTitile from "../table/TableTitile";
import TradesList from "../table/TradesList";
import { MOBILE_MAX_THRESHOLD } from "../../../../config/screenConstants.js";
import useIsMobile from "../../../../hooks/useIsMobile.jsx";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import authContext from "../../../../context/auth/authContext";
import { getCloseTradeList } from "../../../../context/dashboard/DashboardState";
import NotFound from "../NotFound";

import Pagination from "../../../pagination/Pagination";
import Spinner from "../../../pages/Spinner";

const pageSize = 6;
const ClosedTrades = () => {
  const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
  const [isLoading, setIsLoading] = useState(false);
  const { dashboardState, dashboardDispatcher } = useContext(dashboardContext);
  const { authState } = useContext(authContext);
  const { closeTradeList, pageCount } = dashboardState;
  const [currentPage, setCurrentPage] = useState(1);

  const loadCloseTrade = async (page) => {
    setIsLoading(true);
    await getCloseTradeList(
      authState?.user?.userId,
      page,
      pageSize,
      dashboardDispatcher
    );
    setIsLoading(false);
  };

  useMemo(() => {
    loadCloseTrade(currentPage - 1);
  }, [currentPage]);
  if (isLoading) return <Spinner />;

  if (closeTradeList?.length === 0) {
    return <NotFound title="Closed" />;
  }

  return (
    <div className="trade-detail-container height-component table-responsive">
      <div>
        <TableTitile title={"Closed Trades"} />
        <TradesList data={closeTradeList} isMobile={isMobile} />
        <div className="trade-detail-pagination">
          <Pagination
            data-testid="pagination"
            className="pagination-bar"
            currentPage={currentPage}
            pageSize={pageSize}
            totalPages={pageCount}
            onPageChange={(page) => {
              setCurrentPage(page);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default ClosedTrades;
