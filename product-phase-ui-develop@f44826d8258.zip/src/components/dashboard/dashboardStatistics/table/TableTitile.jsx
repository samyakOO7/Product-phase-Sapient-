
 const TableTitile = ({title} )=>{
    return (
        <div className={"text-center shadow-sm bg-white p-2 my-2 rounded "} > 
             <h3 className="d-inline trade-detail-header ">{title}</h3>
        </div>
    );
}
export default  TableTitile;
