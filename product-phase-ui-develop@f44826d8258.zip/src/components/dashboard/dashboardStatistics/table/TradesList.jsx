import React from 'react'
import { logger } from '../../../../utils/logger';
import {Table} from 'react-bootstrap';
import TableHead from './TableHead';
import TradeTableRow from './TradeTableRow';


const TradesList = ({data, isMobile}) => {
    
   const tableClass = (isMobile)? "table-sm" : "table-hover";
  logger.debug({message: "render in Open Trades list",data})
  return (
    <div className='shadow-sm my-md-3 mb-5  bg-white rounded '>
       <Table   className= {tableClass}>
            <thead>
              <TableHead  isMobile ={isMobile} />
            </thead>
            <tbody id ="scrollable-target">
              {data.map(closeTrade => 
              <TradeTableRow 
                    isMobile ={isMobile}
                    item = {closeTrade} 
                    key = {closeTrade.tickerId} 
                    />)
                  }
            </tbody>  
      </Table>
     
    </div>

  )
}

export default TradesList;