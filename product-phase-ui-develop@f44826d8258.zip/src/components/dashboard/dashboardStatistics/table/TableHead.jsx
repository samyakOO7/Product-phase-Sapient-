import ToolTip from "../../../util/ToolTip";

export const TableHead = ({ isMobile }) => {
  
  
 
  const qtyMessage = !isMobile ? "Quantity" : "Qty";
  const PLMessage = !isMobile ? "Profit/Loss" : "P/L";
  const headingClass = "px-md-1 px-lg-3";
  const tableHeadClass = "d-table-row";

  return (
    <tr className={tableHeadClass}>
      <th className={headingClass}>
        <ToolTip actualMessage="Ticker" toolTipMessage="Name of the stock " />
      </th>

      <th className={headingClass}>
        <ToolTip
          actualMessage="Opened At"
          toolTipMessage="Trade Opened at "
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={"Avg Price"}
          toolTipMessage="Average Bought price"
        />
      </th>
    
      <th className={headingClass}>
        <ToolTip
          actualMessage="Closed At"
          toolTipMessage="Trade Closed At"
        />
      </th>
      <th className={headingClass}>
        <ToolTip actualMessage="Sold Price" toolTipMessage="Sold price" />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={qtyMessage}
          toolTipMessage="Quantity of the stocks"
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={PLMessage}
          toolTipMessage="Profit/Loss  in trade"
        />
      </th>
    </tr>
  );
};

export default TableHead;
