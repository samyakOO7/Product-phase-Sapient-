import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import LosingTrades from "../WLTrades/LosingTrades";
import { getLosingTradeList } from "../../../../context/dashboard/DashboardState";

const MockDashboardDispatcher = jest.fn();
jest.mock(
  "../../../pagination/Pagination",
  () =>
    ({ onPageChange, ...rest }) => {
      onPageChange();

      return <></>;
    }
);
jest.mock("../../../../context/dashboard/DashboardState");

describe("LosingTrades testing", () => {
  beforeEach(()=>{
    getLosingTradeList.mockResolvedValueOnce(true);
  });

  it("LosingTrades with some length", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              losingTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <LosingTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });

});
