import { render } from "@testing-library/react";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import TradeState from "../../../../context/trade/TradeState";

import OpenTradesList from "../openTrades/OpenTradesList";



jest.mock("../../../../utils/logger");

// const MockTradeDetailModalDispatcher = jest.fn();
describe("OpenTradesList testing", () => {
  it("OpenTradesList should be rendered", () => {
    render(
      <AuthState>
        <DashboardState>
        <TradeState>
          <OpenTradesList
            data={[
              {
                userPortfolioId: 1398,
                tickerId: "BAJAJFINSV.NS",
                tickerName: "Bajaj Finserv Ltd.",
                currentProfitOrLoss: -218.9,
                quantity: 22,
                averagePrice: 1698.25,
                currentPrice: 1688.3,
              },
            ]}
          />
        </TradeState>
        </DashboardState>
      </AuthState>
    );
  });

  it("OpenTradesList should be rendered when isMobile is true", () => {
    render(
      <AuthState>
        <DashboardState>
        <TradeState>
          <OpenTradesList
            data={[
              {
                userPortfolioId: 1398,
                tickerId: "BAJAJFINSV.NS",
                tickerName: "Bajaj Finserv Ltd.",
                currentProfitOrLoss: -218.9,
                quantity: 22,
                averagePrice: 1698.25,
                currentPrice: 1688.3,
              },
            ]}
            isMobile={true}
          />
        </TradeState>
        </DashboardState>
      </AuthState>
    );
  });
 
});
