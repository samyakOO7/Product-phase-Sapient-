import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import TradeState from "../../../../context/trade/TradeState";
import OpenTrades from "../openTrades/OpenTrades";

const MockDashboardDispatcher = jest.fn();
jest.mock(
    "../../../pagination/Pagination",
    () =>
      ({ onPageChange, ...rest }) => {
        onPageChange();
  
        return <></>;
      }
  );

describe("OpenTrades testing", () => {
  it("OpenTrades should be rendered", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              openTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <TradeState>
            <OpenTrades />
          </TradeState>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
  it("OpenTrades should be rendered for empty openTradeList", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              openTradeList: [],
            },
          }}
        >
          <TradeState>
            <BrowserRouter>
            <OpenTrades />
            </BrowserRouter>
          </TradeState>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
  it("OpenTrades should be rendered with pagination", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              openTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <TradeState>
            <OpenTrades />
          </TradeState>
        </dashboardContext.Provider>
      </AuthState>
    );
   
  });
});
