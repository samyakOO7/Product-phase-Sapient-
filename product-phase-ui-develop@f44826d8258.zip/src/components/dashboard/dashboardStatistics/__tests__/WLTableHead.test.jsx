import { render } from "@testing-library/react"
import WLTableHead from "../WLTrades/WLTableHead"



describe("WLTableHead testing",()=>{
    it("WLTableHead rendering when isMobile is true",()=>{
        render(<WLTableHead isMobile={true}/>)
    })
    it("WLTableHead rendering when isMobile is false",()=>{
        render(<WLTableHead isMobile={false}/>)
    })
})