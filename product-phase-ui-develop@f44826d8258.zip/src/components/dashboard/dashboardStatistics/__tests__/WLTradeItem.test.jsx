import { render } from "@testing-library/react";
import WLTradeItem from "../WLTrades/WLTradeItem";

describe("WLTradeItem testing", () => {
  it("WLTradeItem should be rendered", () => {
    render(
      <WLTradeItem
        item={{
          userPortfolioId: 1398,
          tickerId: "BAJAJFINSV.NS",
          tickerName: "Bajaj Finserv Ltd.",
          currentProfitOrLoss: 218.9,
          quantity: 22,
          averagePrice: 1600,
          currentPrice: 1688.3,
        }}
        isMobile={true}
      />
    );
  });
  it("WLTradeItem should be rendered with lossing trade", () => {
    render(
      <WLTradeItem
        item={{
          userPortfolioId: 1398,
          tickerId: "HDFC.NS",
          tickerName: "HDFC Finserv Ltd.",
          currentProfitOrLoss: -218.9,
          quantity: 22,
          averagePrice: 1700,
          currentPrice: 1688.3,
        }}
        isMobile={false}
      />
    );
  });
});
