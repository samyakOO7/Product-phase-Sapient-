import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import WinningTrades from "../WLTrades/WinningTrades";

const MockDashboardDispatcher = jest.fn();
jest.mock(
  "../../../pagination/Pagination",
  () =>
    ({ onPageChange, ...rest }) => {
      onPageChange();

      return <></>;
    }
);

describe("WinningTrades testing", () => {
  it("WinningTrades with 0 length", () => {
    render(
      <AuthState>
        <DashboardState>
          <BrowserRouter>
            <WinningTrades />
          </BrowserRouter>
        </DashboardState>
      </AuthState>
    );
  });

  it("WinningTrades with some length", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              winningTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1600,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <WinningTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
  it("WinningTrades with pagination", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              winningTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1600,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <WinningTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
});
