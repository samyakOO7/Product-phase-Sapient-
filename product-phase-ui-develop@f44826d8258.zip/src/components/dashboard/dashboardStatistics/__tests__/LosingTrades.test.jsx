import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import LosingTrades from "../WLTrades/LosingTrades";


const MockDashboardDispatcher = jest.fn();
jest.mock(
  "../../../pagination/Pagination",
  () =>
    ({ onPageChange, ...rest }) => {
      onPageChange();

      return <></>;
    }
);

describe("LosingTrades testing", () => {
  it("LosingTrades with 0 length", () => {
    render(
      <AuthState>
        <DashboardState>
          <BrowserRouter>
            <LosingTrades />
          </BrowserRouter>
        </DashboardState>
      </AuthState>
    );
  });

  it("LosingTrades with some length", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              losingTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <LosingTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
  it("LosingTrades with pagination", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              losingTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <LosingTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
});
