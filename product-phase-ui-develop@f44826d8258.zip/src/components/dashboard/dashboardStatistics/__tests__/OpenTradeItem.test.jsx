import { render, screen } from "@testing-library/react";
import '@testing-library/jest-dom';
import userEvent from "@testing-library/user-event";
import { BrowserRouter } from "react-router-dom";
import OpenTradeItem from "../openTrades/OpenTradeItem";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";

let item = (gain) => {
    return({
        userPortfolioId:23,
        tickerName:"Hindustan Unilever",
        tickerId:"HUL",
        averagePrice:323,
        quantity:23,
        currentPrice:313,
        currentProfitOrLoss: gain
        
    })
}
describe("OpenTrades testing", () => {
    test("OpenTradeItem should be rendered for profit", () => {
        render(
            <AuthState>
                <DashboardState>
        <OpenTradeItem
            isMobile= {false}
            item = {item(230)}
            key= {5}
            showModal={false}
            tradeDetailModalDispatcher={jest.fn()}
            setShowModal={jest.fn()}
        />
        </DashboardState>
        </AuthState>)       
        
        let btnElement = screen.getByRole('button',{
            name:/sell/i
        })
        expect(btnElement).toBeInTheDocument();
        userEvent.click(btnElement);
    })

    test("OpenTradeItem should be rendered for loss", () => {
        render(
            <AuthState>
            <DashboardState>
        <OpenTradeItem
            isMobile={true}
            item = {item(-5000)}
            key= {5}
            showModal={false}
            tradeDetailModalDispatcher={jest.fn()}
            setShowModal={jest.fn()}
        />
        </DashboardState>
        </AuthState>
        )       
        
        let btnElement = screen.getByRole('button',{
            name:/sell/i
        })
        expect(btnElement).toBeInTheDocument();
        userEvent.click(btnElement);
    })
})