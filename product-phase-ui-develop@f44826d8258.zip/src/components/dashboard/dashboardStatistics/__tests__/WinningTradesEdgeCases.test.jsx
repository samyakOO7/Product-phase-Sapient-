import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import WinningTrades from "../WLTrades/WinningTrades";
import { getWinningTradeList } from "../../../../context/dashboard/DashboardState";

const MockDashboardDispatcher = jest.fn();
jest.mock(
  "../../../pagination/Pagination",
  () =>
    ({ onPageChange, ...rest }) => {
      onPageChange();

      return <></>;
    }
);
jest.mock("../../../../context/dashboard/DashboardState");

describe("WinningTrades testing", () => {
  beforeEach(()=>{
    getWinningTradeList.mockResolvedValueOnce(true);
  });

  it("WinningTrades with some length", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              winningTradeList: [
                {
                  userPortfolioId: 1398,
                  tickerId: "BAJAJFINSV.NS",
                  tickerName: "Bajaj Finserv Ltd.",
                  currentProfitOrLoss: -218.9,
                  quantity: 22,
                  averagePrice: 1698.25,
                  currentPrice: 1688.3,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <WinningTrades />
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });

});
