import { render } from "@testing-library/react"
import TradesList from "../table/TradesList"



describe("TradesList testing",()=>{
    it("TradesList when isMobile is true",()=>{
        render(<TradesList data={[
            {
                tickerId: "ASIANPAINT.NS",
                tickerName: "Asian Paints Limited",
                tradeOpenedAt: 1644829500000,
                tradeClosedAt: 1657268340000,
                gain: 19.0,
                pricePerTicker: 1729.56,
                soldPricePerTicker: null,
              }
        ]} isMobile={true}/>)
    })
    it("TradesList when isMobile is true and data is empty array",()=>{
        render(<TradesList data={[]} isMobile={true}/>)
    })
})