import { render } from "@testing-library/react";
import WLTradesList from "../WLTrades/WLTradesList";

describe("WLTradesList", () => {
  it("WLTradesListshould be rendered", () => {
    render(
      <WLTradesList
        data={[
          {
            userPortfolioId: 1398,
            tickerId: "BAJAJFINSV.NS",
            tickerName: "Bajaj Finserv Ltd.",
            currentProfitOrLoss: -218.9,
            quantity: 22,
            averagePrice: 1600,
            currentPrice: 1688.3,
          },
        ]}
        isMobile={true}
      />
    );
  });
  it("WLTradesListshould be rendered when ismobile is false", () => {
    render(
      <WLTradesList
        data={[
          {
            userPortfolioId: 1398,
            tickerId: "HDFC.NS",
            tickerName: "HDFC Finserv Ltd.",
            currentProfitOrLoss: 218.9,
            quantity: 22,
            averagePrice: 1700,
            currentPrice: 1688.3,
          },
        ]}
        isMobile={false}
      />
    );
  });
});
