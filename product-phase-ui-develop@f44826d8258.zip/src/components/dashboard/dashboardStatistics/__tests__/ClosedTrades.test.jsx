import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../../context/auth/AuthState";
import DashboardState from "../../../../context/dashboard/DashboardState";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import ClosedTrades from "../closedTrades/ClosedTrades";

const MockDashboardDispatcher = jest.fn();
jest.mock(
  "../../../pagination/Pagination",
  () =>
    ({ onPageChange, ...rest }) => {
      onPageChange();

      return <></>;
    }
);

const mockLoadCloseTrade = jest.fn();
describe("ClosedTrades testing", () => {
  it("ClosedTrades with 0 length", () => {
    render(
      <AuthState>
        <DashboardState>
          <BrowserRouter>
            <ClosedTrades  loadCloseTrade ={mockLoadCloseTrade}/>
          </BrowserRouter>
        </DashboardState>
      </AuthState>
    );
  });

  it("ClosedTrades with some length", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              closeTradeList: [
                {
                  tickerId: "ASIANPAINT.NS",
                  tickerName: "Asian Paints Limited",
                  tradeOpenedAt: 1644829500000,
                  tradeClosedAt: 1657268340000,
                  gain: 19.0,
                  pricePerTicker: 1729.56,
                  soldPricePerTicker: null,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <ClosedTrades loadCloseTrade ={mockLoadCloseTrade}/>
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
  it("ClosedTrades with pagination", () => {
    render(
      <AuthState>
        <dashboardContext.Provider
          value={{
            dashboardDispatcher: MockDashboardDispatcher,
            dashboardState: {
              closeTradeList: [
                {
                  tickerId: "ASIANPAINT.NS",
                  tickerName: "Asian Paints Limited",
                  tradeOpenedAt: 1644829500000,
                  tradeClosedAt: 1657268340000,
                  gain: 19.0,
                  pricePerTicker: 1729.56,
                  soldPricePerTicker: null,
                },
              ],
            },
          }}
        >
          <BrowserRouter>
            <ClosedTrades  loadCloseTrade ={mockLoadCloseTrade}/>
          </BrowserRouter>
        </dashboardContext.Provider>
      </AuthState>
    );
  });
});
