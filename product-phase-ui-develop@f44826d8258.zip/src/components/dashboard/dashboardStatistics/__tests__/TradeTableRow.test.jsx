import { render } from "@testing-library/react";
import TradeTableRow from "../table/TradeTableRow";

describe("TradeTableRow testing", () => {
  it("TradeTableRow should rendered for profit", () => {
    render(
      <TradeTableRow
        item={{
          tickerName: "HDFC",
          tickerId: "HDFC.NS",
          tradeOpenedAt: 1661249220000,
          pricePerTicker: 2300,
          tradeClosedAt: 1665595320000,
          soldPricePerTicker: 2500,
          gain: 20000,
        }}
        isMobile={true}

      />
    );
  });
  it("TradeTableRow should rendered for loss", () => {
    render(
      <TradeTableRow
        item={{
          tickerName: "HDFC",
          tickerId: "HDFC.NS",
          tradeOpenedAt: 1661249220000,
          pricePerTicker: 2500,
          tradeClosedAt: 1665595320000,
          soldPricePerTicker: 2300,
          gain: -20000,
        }}
        isMobile={false}

      />
    );
  });
});
