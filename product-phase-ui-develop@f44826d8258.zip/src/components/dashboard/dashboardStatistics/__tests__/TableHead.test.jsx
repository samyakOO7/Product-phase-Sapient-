import { render } from "@testing-library/react"
import TableHead from "../table/TableHead"

describe("TableHead testing",()=>{
    it("TableHead when isMobile is true",()=>{

        render(<TableHead isMobile={true}/>)

    })
})