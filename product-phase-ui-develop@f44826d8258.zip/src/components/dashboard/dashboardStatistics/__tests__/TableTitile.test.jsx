import { render } from "@testing-library/react";
import TableTitile from "../table/TableTitile";

describe("TableTitle testing", () => {
  it("TableTitle shoud be rendered", () => {
    render(<TableTitile title="Open trade list" />);
  });
});
