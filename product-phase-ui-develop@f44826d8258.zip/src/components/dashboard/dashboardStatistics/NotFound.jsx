import React from 'react'
import { Link } from 'react-router-dom';
import "./TradeTable.css"
const NotFound = ({title}) => {
    return (
        <div
          className="d-flex justify-content-center align-items-center not-found-card"
          style={{ background: "#f1f2f7" }}
        >
          <div className="card p-3 text-center">
            <div className="card-body">
              <h5 className="card-title">No {title} Trades Found!</h5>
              <p className="card-text text-info">
                You have no {title} trades, start trading with Tradezy!
              </p>
              <Link to="/" className="btn btn-warning " role="button">
                Go To Home
              </Link>{" "}
            </div>
          </div>
        </div>
      );
}

export default NotFound