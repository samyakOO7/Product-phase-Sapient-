import React, { useMemo, useContext, useEffect, useState } from "react";

import OpenTradesList from "./OpenTradesList";

import { MOBILE_MAX_THRESHOLD } from "../../../../config/screenConstants.js";
import useIsMobile from "../../../../hooks/useIsMobile.jsx";

import "../../../commonCss/TradeTable.css";
import dashboardContext from "../../../../context/dashboard/dashboardContext";
import authContext from "../../../../context/auth/authContext";
import { getOpenTradeList } from "../../../../context/dashboard/DashboardState";
import NotFound from "../NotFound";
import Pagination from "../../../pagination/Pagination";

import TableTitile from "../table/TableTitile";
import Spinner from "../../../pages/Spinner";

const OpenTrades = () => {
  const isMobile = useIsMobile(MOBILE_MAX_THRESHOLD);
  const [isLoading, setIsLoading] = useState(false);
  const { dashboardState, dashboardDispatcher } = useContext(dashboardContext);
  const { authState } = useContext(authContext);
  useEffect(() => {
    setIsLoading(true);
    getOpenTradeList(authState?.user?.userId, dashboardDispatcher).then(() => {
      setIsLoading(false);
    });

    //eslint-disable-next-line
  }, []);
  const { openTradeList } = dashboardState;
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;
  let openTradeListPage = useMemo(() => {
    const firstPageIndex = (currentPage - 1) * pageSize;
    const lastPageIndex = firstPageIndex + pageSize;
    return openTradeList.slice(firstPageIndex, lastPageIndex);
  }, [currentPage, openTradeList]);
  if (isLoading) return <Spinner />;
  if (openTradeList?.length === 0) {
    return <NotFound title="Open" />;
  }

  return (
    <div className="trade-detail-container height-component table-responsive">
      <div>
        <TableTitile title={"Open Trades"} />
        <OpenTradesList data={openTradeListPage} isMobile={isMobile}  />
        <div className="trade-detail-pagination">
          <Pagination
            data-testid="pagination"
            className="pagination-bar"
            currentPage={currentPage}
            siblingCount={1}
            totalCount={openTradeList.length}
            pageSize={pageSize}
            onPageChange={(page) => {
              setCurrentPage(page);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default OpenTrades;
