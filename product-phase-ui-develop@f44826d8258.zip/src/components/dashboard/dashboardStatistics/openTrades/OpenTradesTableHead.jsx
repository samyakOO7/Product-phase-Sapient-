import ToolTip from "../../../util/ToolTip";
export const OpenTradesTableHead = ({ isMobile }) => {
  const priceMessage = !isMobile ? "Average Price" : "Avg Price";
  const qtyMessage = !isMobile ? "Quantity" : "Qty";
  const currPrice = !isMobile ? "Current Price" : "Curr Price";
  const PLMessage = !isMobile ? "Profit/Loss" : "P/L";
  const headingClass = "px-md-2 px-lg-4";
  const tableHeadClass = "d-table-row";

  return (
    <tr className={tableHeadClass}>
      <th className={headingClass}>
        <ToolTip
          actualMessage="Ticker"
          toolTipMessage="Ticker Id of the stock "
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={priceMessage}
          toolTipMessage="Average Bougth price"
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={currPrice}
          toolTipMessage="Current price of the ticker"
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={qtyMessage}
          toolTipMessage="Quantity of the stocks"
        />
      </th>
      <th className={headingClass}>
        <ToolTip
          actualMessage={PLMessage}
          toolTipMessage=" Profit/Loss  in trade"
        />
      </th>
      <th className={headingClass}></th>
    </tr>
  );
};

export default OpenTradesTableHead;
