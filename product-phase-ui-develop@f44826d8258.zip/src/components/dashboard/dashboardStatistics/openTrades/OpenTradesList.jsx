import { React, useContext } from "react";

import OpenTradeItem from "./OpenTradeItem";

import OpenTradesTableHead from "./OpenTradesTableHead";

import { Table } from "react-bootstrap";
import { tradeContext } from "../../../../context/trade/tradeContext";
import { logger } from "../../../../utils/logger";
import TradeModal from "../../../tradeDetails/TradeModal";

const OpenTradesList = ({ data, isMobile }) => {
  const { showModal, setShowModal, tradeDetailModalDispatcher } = useContext(tradeContext);
  const tableClass = isMobile ? "table-sm" : "table-hover";
  logger.debug({ message: "render in Open Trades list", data });
  return (
    <div className="shadow-sm my-md-3 mb-5  bg-white rounded ">
      <Table className={tableClass}>
        <thead>
          <OpenTradesTableHead isMobile={isMobile} />
        </thead>
        <tbody id="scrollable-target">
          {data.map((openTrade) => (
            <OpenTradeItem
              isMobile={isMobile}
              item={openTrade}
              key={openTrade.tickerId}
              showModal={showModal}
              tradeDetailModalDispatcher={tradeDetailModalDispatcher}
              setShowModal={setShowModal}
            />
          ))}
        </tbody>
      </Table>
      <TradeModal show={showModal} onHide={() => setShowModal(false)} />
    </div>
  );
};
export default OpenTradesList;
