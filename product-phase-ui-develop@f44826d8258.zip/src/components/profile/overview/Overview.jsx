import { useState, useEffect, useContext } from "react";
import "./Overview.css";
import { fetchUserProfileData } from "../../../services/viewUpdateProfile";
import authContext from "../../../context/auth/authContext";
import { toast } from "react-toastify";

const Overview = ({ setDetail }) => {
  const { authState } = useContext(authContext);
  const [userDetail, setUserDetail] = useState(authState?.user);

  var firstName = userDetail?.firstName;
  if (firstName === null || firstName === undefined) {
    firstName = "";
  }

  var lastName = userDetail?.lastName;
  if (lastName === null || lastName === undefined) {
    lastName = "";
  }

  useEffect(() => {
    getUserDetails();
    // eslint-disable-next-line
  }, []);

  const getUserDetails = () => {
    fetchUserProfileData(authState?.user?.userId)
      .then((response) => {
        setDetail(response);
        setUserDetail(response);
      })
      .catch((error) => {
        toast.error(error.message);
      });
  };
  const capitalizeFirstLowercaseRest = (str) => {
    return str?.charAt(0).toUpperCase() + str?.slice(1).toLowerCase();
  };

  return (
    <>
      <table>
        <tbody>
          <tr className="row row-css">
            <td
              data-testid="username"
              className="col-lg-3 col-md-4 label label-css text-start"
            >
              Username
            </td>
            <td className="col-lg-9 col-md-8 text-start">
              {userDetail?.userName}
            </td>
          </tr>

          <tr className="row row-css">
            <td
              data-testid="full-name"
              className="col-lg-3 col-md-4 label label-css text-start"
            >
              Full Name
            </td>
            <td className="col-lg-9 col-md-8 text-start">
              {capitalizeFirstLowercaseRest(firstName)}{" "}
              {capitalizeFirstLowercaseRest(lastName)}
            </td>
          </tr>

          <tr className="row row-css">
            <td
              data-testid="email"
              className="col-lg-3 col-md-4 label label-css text-start"
            >
              Email
            </td>
            <td className="col-lg-9 col-md-8 text-start">
              {userDetail?.email}
            </td>
          </tr>
          <tr className="row row-css">
            <td
              data-testid="mobile"
              className="col-lg-3 col-md-4 label label-css text-start"
            >
              Mobile Number
            </td>
            <td className="col-lg-9 col-md-8 text-start">
              {userDetail?.phoneNumber}
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};

export default Overview;
