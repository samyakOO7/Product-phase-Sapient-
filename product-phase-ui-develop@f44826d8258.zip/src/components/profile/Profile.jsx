import React, { useState, useContext } from "react";
import { Card, Nav } from "react-bootstrap";
import "./Profile.css";
import Overview from "./overview/Overview";
import Update from "./update/Update";
import authContext from "../../context/auth/authContext";
import TradingDetails from "./userTradingDetails/TradingDetails";
import Avatar from "react-avatar";

const Profile = () => {
  const [activeTab, setActiveTab] = useState("overview");

  const { authState } = useContext(authContext);
  // eslint-disable-next-line
  const [userDetail, setUserDetail] = useState(authState?.user);

  var firstName = userDetail?.firstName;
  if (firstName === null || firstName === undefined) {
    firstName = "";
  }

  var lastName = userDetail?.lastName;
  if (lastName === null || lastName === undefined) {
    lastName = "";
  }

  const handleOverView = () => {
    setActiveTab("overview");
  };

  const handleUpdate = () => {
    setActiveTab("update");
  };

  const handleTradingDetails = () => {
    setActiveTab("tradingDetails");
  };

  const currentTab = (tab) => {
    if (tab === "overview") return <Overview setDetail={setUserDetail} />;
    else if (tab === "update") return <Update />;
    return <TradingDetails />;
  };

  const capitalizeFirstLowercaseRest = (str) => {
    return str?.charAt(0).toUpperCase() + str?.slice(1).toLowerCase();
  };

  const fullName = `${capitalizeFirstLowercaseRest(
    firstName
  )} ${capitalizeFirstLowercaseRest(lastName)}`;

  return (
    <div className="main">
      <div className="row">
        <div className="col-xl-4">
          <div className="d-flex align-items-center justify-content-center">
            <Card
              data-testid="card1"
              className="detail-card profile-card d-flex align-items-center justify-content-center"
            >
              <Avatar
                name={fullName}
                color="#0d98c7"
                size="200"
                round={true}
                className="icon"
              />
              <Card.Body>
                <Card.Title>{fullName}</Card.Title>
              </Card.Body>
            </Card>
          </div>
        </div>
        <div className="col-xl-8">
          <Card data-testid="card2" className="detail-detail-card">
            <Nav className="nav">
              <Nav.Item className="nav-link">
                <button
                  name="overview"
                  data-testid="over-view"
                  className={
                    "btn-css " + (activeTab === "overview" ? "active1" : "")
                  }
                  onClick={handleOverView}
                >
                  Overview
                </button>
              </Nav.Item>
              <Nav.Item className="nav-link">
                <button
                  name="update"
                  data-testid="over-update"
                  className={
                    "btn-css " + (activeTab === "update" ? "active1" : "")
                  }
                  onClick={handleUpdate}
                >
                  Update Profile
                </button>
              </Nav.Item>
              <Nav.Item className="nav-link">
                <button
                  name="tradingDetails"
                  data-testid="trading-details"
                  className={
                    "btn-css " +
                    (activeTab === "tradingDetails" ? "active1" : "")
                  }
                  onClick={handleTradingDetails}
                >
                  Trading Details
                </button>
              </Nav.Item>
            </Nav>
            <Card.Body>{currentTab(activeTab)}</Card.Body>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
