import { React, useState, useEffect, useContext } from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./TradingDetails.css";
import { useFormik } from "formik";
import { toast } from "react-toastify";
import * as Yup from "yup";
import {
  getUserTradingDetails,
  postUserTradingDetails,
} from "../../../services/userTradingDetails";
import authContext from "../../../context/auth/authContext";

const updateClassName = (readOnly, className) => {
  if (readOnly) return className;
  return "d-none";
};

const formInputClassName = (readOnly) => {
  if (readOnly) return "form-control readOnlyInput";
  return "form-control";
};

const TradingDetails = () => {
  const { authState } = useContext(authContext);
  const [readOnly, setReadOnly] = useState(true);
  const [dataFound, setDataFound] = useState(false);
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: {
      totalAmount: "",
      amountPerTrade: "",
      risk: "",
      equity: "",
    },
    onSubmit: (values) => {
      handleSave();
    },
    validationSchema: Yup.object({
      totalAmount: Yup.number()
        .typeError("You must specify a number")
        .min(500, "Minimum amount of 500 should be added")
        .max(500000, "You can add only upto 5 Lacs at once")
        .required("Amount is required")
        .test(
          "is-decimal",

          "More than two decimal places are not allowed",

          (value) => (value + "").match(/^\d+\.{0,1}\d{0,2}$/)
        ),

      amountPerTrade: Yup.number()
        .typeError("You must specify a number")
        .min(0.1, "Amount per trade should be atleast 0.1%")
        .max(100, "Amount per trade cannot exceed 100%")
        .required("Amount per trade is required")
        .test(
          "is-decimal",

          "More than two decimal places are not allowed",

          (value) => (value + "").match(/^\d+\.{0,1}\d{0,2}$/)
        ),

      risk: Yup.number()
        .typeError("You must specify a number")
        .min(0.1, "Risk per trade should be atleast 0.1%")
        .max(100, "Risk per trade cannot exceed 100%")
        .required("Risk per trade is required")
        .test(
          "is-decimal",

          "More than two decimal places are not allowed",

          (value) => (value + "").match(/^\d+\.{0,1}\d{0,2}$/)
        ),
    }),
  });

  const loadData = () => {
    setLoading(true);
    getUserTradingDetails(authState?.user?.userId)
      .then((res) => {
        setDataFound(true);
        formik.setFieldValue("totalAmount", res.totalAmount);
        formik.setFieldValue("amountPerTrade", res.amountPerTrade);
        formik.setFieldValue("risk", res.riskPerTrade);
        formik.setFieldValue("equity", res.totalEquity);
      })
      .catch((err) => {
        setDataFound(false);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    if (readOnly === true) loadData();
  }, [readOnly]);

  const handleUpdate = (e) => {
    setDataFound(true);
    setReadOnly(false);
    formik.resetForm({ values: "" });
  };

  const handleCancel = () => {
    setReadOnly(true);
  };

  const handleSave = async () => {
    setLoading(true);
    let obj = {
      userId: authState?.user?.userId,
      totalAmount: formik.values.totalAmount,
      amountPerTrade: formik.values.amountPerTrade,
      riskPerTrade: formik.values.risk,
    };

    postUserTradingDetails(obj)
      .then((res) => {
        setLoading(false);
        setReadOnly(true);
      })
      .catch((err) => {
        setLoading(false);
        toast.error("Error saving the data. Please try again", {
          toastId: "saveErrorTradingDetails",
        });
      });
  };

  const submitBtnClassName = updateClassName(!readOnly, "btn-primary btn mx-2");

  const cancelBtnClassName = updateClassName(!readOnly, "btn-danger btn");

  const updateBtnClassName = updateClassName(readOnly, "change-btn");

  const totalEquityClassName = updateClassName(
    readOnly,
    "form-group row mb-3 mt-3"
  );

  const riskInputErrorComponent =
    formik.touched.risk && formik.errors.risk && !readOnly ? (
      <div role={"alert"} className="error_msg">
        {formik.errors.risk}
      </div>
    ) : null;

  const amntPerTradeInputErrorComponent =
    formik.touched.amountPerTrade &&
    formik.errors.amountPerTrade &&
    !readOnly ? (
      <div role={"alert"} className="error_msg">
        {formik.errors.amountPerTrade}
      </div>
    ) : null;

  const addAmountInputErrorComponent =
    formik.touched.totalAmount && formik.errors.totalAmount && !readOnly ? (
      <div role={"alert"} className="error_msg">
        {formik.errors.totalAmount}
      </div>
    ) : null;

  const totalAmntInputLabel = readOnly ? "Total Amount (₹)" : "Add Amount (₹)*";
  const AmountPerTradeLabel = readOnly ? "Amount Per Trade (%)" : "Amount Per Trade (%)*";
  const RiskPerTradeLabel = readOnly ? "Risk Per Trade (%)" : "Risk Per Trade (%)*";
  
  const loadingMessage = readOnly
    ? "Please wait while we fetch your details..."
    : "Saving...";

  return (
    <div>
      {loading ? (
        <>
          <div className="loader-container mb-3">
            <div className="spinner"></div>
          </div>
          <p className="loadingMessage">{loadingMessage}</p>
        </>
      ) : (
        <div>
          {!dataFound && (
            <div className="alert alert-warning" role="alert">
              Oops! It seems like you haven't setup your trading account. To
              setup your trading account click the button below.
            </div>
          )}
          {dataFound && (
            <form onSubmit={formik.handleSubmit}>
              <div className="form-group row mb-3">
                <label
                  htmlFor="totalAmount"
                  className="col-lg-3 col-form-label"
                >
                  {totalAmntInputLabel}
                </label>
                <div className="col-lg-5">
                  <input
                    type="number"
                    className={formInputClassName(readOnly)}
                    id="totalAmount"
                    readOnly={readOnly}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.totalAmount}
                    step={0.01}
                    data-testid={"totalAmntInput"}
                  />
                  {addAmountInputErrorComponent}
                </div>
              </div>
              <div className="form-group row mb-3">
                <label htmlFor="amountPerTrade" className="col-lg-3 form-label">
                  {AmountPerTradeLabel}
                </label>
                <div className="col-lg-5">
                  <input
                    type="number"
                    className={formInputClassName(readOnly)}
                    id="amountPerTrade"
                    readOnly={readOnly}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.amountPerTrade}
                    data-testid={"amntPerTrade"}
                  />
                  {amntPerTradeInputErrorComponent}
                </div>
              </div>
              <div className="form-group row mb-3 mt-3">
                <label htmlFor="risk" className="col-lg-3 form-label">
                  {RiskPerTradeLabel}
                </label>
                <div className="col-lg-5">
                  <input
                    type="number"
                    className={formInputClassName(readOnly)}
                    id="risk"
                    readOnly={readOnly}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.risk}
                    data-testid={"riskPerTrade"}
                  />
                  {riskInputErrorComponent}
                </div>
              </div>
              <div className={totalEquityClassName}>
                <label htmlFor="totalEquity" className="col-lg-3 form-label">
                  Total Equity
                </label>
                <div className="col-lg-5">
                  <input
                    type="number"
                    className={"readOnlyInput pl-2"}
                    id="totalEquity"
                    readOnly
                    value={formik.values.equity}
                    data-testid={"totalEquity"}
                  />
                </div>
              </div>
              <div className="text-center">
                <button type="submit" className={submitBtnClassName}>
                  &nbsp;Save&nbsp;
                </button>
                <span> </span>
                <button
                  type="button"
                  className={cancelBtnClassName}
                  onClick={handleCancel}
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
          <div className="col-md-12 text-center">
            <button
              type="button"
              className={updateBtnClassName}
              onClick={(e) => handleUpdate(e)}
            >
              Update
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TradingDetails;