import { fireEvent, render, screen } from "@testing-library/react";
import TradingDetails from "../TradingDetails";
import "@testing-library/jest-dom";
import * as userTradingDetails from "../../../../services/userTradingDetails";
import { ToastContainer } from "react-toastify";
import AuthState from "../../../../context/auth/AuthState";
jest.mock("../../../../services/userTradingDetails");
const MockTradingDetails = () => {
  return (
    <>
      <AuthState>
        <ToastContainer />
        <TradingDetails />
      </AuthState>
    </>
  );
};

describe("Tests for get axios call with error response", () => {
  window.setImmediate = window.setTimeout
  let error = {
    status: 404,
    code: "NO_DATA_FOUND",
    message: "No data found",
  };

  beforeEach(() => {
    userTradingDetails.getUserTradingDetails.mockRejectedValueOnce(() => {
      throw error;
    });
  });

  it("should contain loading screen for fetching details", () => {
    render(<MockTradingDetails />);
    const loadingMessage = screen.getByText(/please wait/i);
    expect(loadingMessage).toBeInTheDocument();
  });
  it("should contain alert message and update button", async () => {
    render(<MockTradingDetails />);
    const alertMessage = await screen.findByRole("alert");
    const updateButton = await screen.findByText(/update/i);

    expect(alertMessage).toBeInTheDocument();
    expect(updateButton).toBeInTheDocument();
  });

  it("should display alert and update button on clicking cancel if axios call fails", async () => {
    render(<MockTradingDetails />);
    let updateButton = await screen.findByText(/update/i);
    fireEvent.click(updateButton);
    const cancelButton = await screen.findByText(/cancel/i);
    userTradingDetails.getUserTradingDetails.mockRejectedValueOnce(() => {
      throw error;
    });
    fireEvent.click(cancelButton);
    const alertMessage = await screen.findByRole("alert");
    updateButton = await screen.findByText(/update/i);
    expect(alertMessage).toBeInTheDocument();
    expect(updateButton).toBeInTheDocument();
  });
});

describe("Tests for successfull response from mocked service", () => {
  beforeEach(() => {
    userTradingDetails.getUserTradingDetails.mockImplementation(() =>
      Promise.resolve({
        totalAmount: 50000,
        amountPerTrade: 10,
        riskPerTrade: 3,
        totalEquity: 50000,
      })
    );
    userTradingDetails.postUserTradingDetails.mockImplementation(() =>
      Promise.resolve({
        totalAmount: 20000,
        amountPerTrade: 10,
        riskPerTrade: 3,
        totalEquity: 20000,
      })
    );
  });

  it("should make form editable on clicking update button", async () => {
    render(<MockTradingDetails />);
    const updateButton = await screen.findByText(/update/i);
    fireEvent.click(updateButton);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    expect(totalAmntInputElement).toHaveClass("form-control");
    expect(totalAmntInputElement).not.toHaveClass("form-control readOnlyInput");
  });

  it("should display update button and form should be read only", async () => {
    render(<MockTradingDetails />);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    const amountPerTradeInputElement = await screen.findByTestId(
      "amntPerTrade"
    );
    const riskInputElement = await screen.findByTestId("riskPerTrade");
    const totalEquityInputElement = await screen.findByTestId("totalEquity");
    let updateButton = await screen.findByText(/update/i);
    expect(updateButton).toBeInTheDocument();
    expect(totalAmntInputElement).toHaveClass("form-control readOnlyInput");
    expect(totalAmntInputElement).toHaveValue(50000);
    expect(amountPerTradeInputElement).toHaveClass(
      "form-control readOnlyInput"
    );
    expect(amountPerTradeInputElement).toHaveValue(10);
    expect(riskInputElement).toHaveClass("form-control readOnlyInput");
    expect(riskInputElement).toHaveValue(3);
    expect(totalEquityInputElement).toHaveClass("readOnlyInput pl-2");
    expect(totalEquityInputElement).toHaveValue(50000);
  });

  it("should send the data and return back to view only on clicking save", async () => {
    render(<MockTradingDetails />);
    let updateButton = await screen.findByText(/update/i);
    expect(updateButton).toBeInTheDocument();
    fireEvent.click(updateButton);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    const amountPerTradeInputElement = await screen.findByTestId(
      "amntPerTrade"
    );
    const riskPerTradeInputElement = await screen.findByTestId("riskPerTrade");
    fireEvent.change(totalAmntInputElement, { target: { value: 20000 } });
    fireEvent.change(amountPerTradeInputElement, { target: { value: 10 } });
    fireEvent.change(riskPerTradeInputElement, { target: { value: 3 } });
    let saveButton = await screen.findByText(/save/i);
    expect(saveButton).toBeInTheDocument();
    fireEvent.click(saveButton);
    expect(updateButton).toBeInTheDocument();
  });

  it("should display error messages for invalid inputs", async () => {
    render(<MockTradingDetails />);
    let updateButton = await screen.findByText(/update/i);
    expect(updateButton).toBeInTheDocument();
    fireEvent.click(updateButton);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    const amountPerTradeInputElement = await screen.findByTestId(
      "amntPerTrade"
    );
    const riskPerTradeInputElement = await screen.findByTestId("riskPerTrade");
    fireEvent.change(totalAmntInputElement, { target: { value: 2000000 } });
    fireEvent.change(amountPerTradeInputElement, { target: { value: 101 } });
    fireEvent.change(riskPerTradeInputElement, { target: { value: 102 } });
    let saveButton = await screen.findByText(/save/i);
    expect(saveButton).toBeInTheDocument();
    fireEvent.click(saveButton);
    let errorElements = await screen.findAllByRole("alert");
    expect(errorElements.length).toBe(3);
  });
});

describe("Tests for checking error messages", () => {
  it("should display toast when unable to save", async () => {
    userTradingDetails.getUserTradingDetails.mockImplementation(() =>
      Promise.resolve({
        totalAmount: 50000,
        amountPerTrade: 10,
        risk: 3,
        equity: 50000,
      })
    );
    let error = {
      status: 404,
      code: "NO_DATA_FOUND",
      message: "No data found",
    };
    userTradingDetails.postUserTradingDetails.mockRejectedValueOnce(() => {
      throw error;
    });
    render(<MockTradingDetails />);
    let updateButton = await screen.findByText(/update/i);
    expect(updateButton).toBeInTheDocument();
    fireEvent.click(updateButton);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    const amountPerTradeInputElement = await screen.findByTestId(
      "amntPerTrade"
    );
    const riskPerTradeInputElement = await screen.findByTestId("riskPerTrade");
    fireEvent.change(totalAmntInputElement, { target: { value: 20000 } });
    fireEvent.change(amountPerTradeInputElement, { target: { value: 10 } });
    fireEvent.change(riskPerTradeInputElement, { target: { value: 3 } });
    let saveButton = await screen.findByText(/save/i);
    expect(saveButton).toBeInTheDocument();
    fireEvent.click(saveButton);
    const errorToastElement = await screen.findByRole("alert");
    expect(errorToastElement).toBeInTheDocument();
  });
  it("should display update button and form should be read only with no value for totalAmount, amoutPerTrade and riskPerTrade", async () => {
    userTradingDetails.getUserTradingDetails.mockImplementation(() =>
      Promise.resolve({
        totalEquity: 50000,
      })
    );
    render(<MockTradingDetails />);
    const totalAmntInputElement = await screen.findByTestId("totalAmntInput");
    const amountPerTradeInputElement = await screen.findByTestId(
      "amntPerTrade"
    );
    const riskInputElement = await screen.findByTestId("riskPerTrade");
    const totalEquityInputElement = await screen.findByTestId("totalEquity");

    let updateButton = await screen.findByText(/update/i);
    expect(updateButton).toBeInTheDocument();
    expect(totalAmntInputElement).toHaveValue(null);
    expect(amountPerTradeInputElement).toHaveValue(null);
    expect(riskInputElement).toHaveValue(null);
    expect(totalEquityInputElement).toHaveValue(50000);
  });
});
