import React from "react";
import "./emailSentSuccess.css";
import { useNavigate } from "react-router-dom";

const EmailSentSuccess = (props) => {
  
  const navigate = useNavigate();
  
  const handleClick = (event) => {
    event.preventDefault();
    navigate("/login");
  };
  
  return(
    <div className="email-success-parent-container">
      <div className="email-sent-container">
        <form onSubmit={handleClick} className="email-sent-form">
          <div>
            <img
              className="logo-email"
              data-testid="logoImage"
              src="https://cdn-icons-png.flaticon.com/512/2422/2422792.png"
              alt="stock.png"
            ></img>
          </div>

          <div>
            <img
              className="emailIcon"
              data-testid="emailIconImage"
              src="https://pluspng.com/img-png/email-icon-png-email-icon-image-122-2400.png"
              alt="emailIcon.png"
            ></img>
          </div>

          <h2 data-testid="h2Test" className="headingText-success">Check Your Email</h2>

          <h5 data-testid="h5Test" className="headingText5-success">
            We have sent a password reset link to
          </h5>

          <h5 className="headingText5-success" data-testid="emailFromPrevious">
            {props.email}
          </h5>

          <div className="form-btns-success-email">
            <button data-testid="buttonTest" type="submit"> &#8592; Back to Sign In </button>
          </div>
        </form>
      </div>
    </div>
  );
};
export default EmailSentSuccess;
