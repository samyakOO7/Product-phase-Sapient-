import { fireEvent,render, screen } from "@testing-library/react"
import '@testing-library/jest-dom'
import EmailSentSuccess from '../EmailSentSuccess';
import { BrowserRouter } from "react-router-dom";
import { act } from "react-dom/test-utils";



test('Email sent success', async ()=>{
    window.setImmediate = window.setTimeout;
    const handleClick=jest.fn();
    render(<BrowserRouter>
    <EmailSentSuccess onSubmit={handleClick}/>
    </BrowserRouter>
    )
    expect(screen.getByTestId('emailIconImage')).toBeInTheDocument();
    expect(screen.getByTestId('logoImage')).toBeInTheDocument();
    expect(screen.getByTestId('buttonTest')).toHaveTextContent(/← Back to Sign In/);
    expect(screen.getByTestId('h2Test')).toHaveTextContent(/Check Your Email/);
    expect(screen.getByTestId('h5Test')).toHaveTextContent(/We have sent a password reset link to/);
    expect(screen.getByTestId('buttonTest')).toBeEnabled();
    expect(screen.getByTestId('emailFromPrevious')).toBeDefined();
   


    await act(()=>{fireEvent.click(screen.getByTestId('buttonTest'))})
    
})




