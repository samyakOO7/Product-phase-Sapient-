import PasswordInput from "../PasswordInput";
import { fireEvent, render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import Router, { BrowserRouter } from "react-router-dom";
import { act } from "react-dom/test-utils";
import React from "react";
import axios from "axios";
import { resetPasswordURL } from "../../../config/urlConstants";

jest.mock("axios");
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
}));

const mockHandleSubmit = jest.fn();

describe("Reset Password Input Page", () => {
  window.setImmediate = window.setTimeout;
  beforeEach(() => {
    jest.mock("axios");
    jest.mock("../../../context/auth/AuthState", () => ({
      ...jest.requireActual("../../../context/auth/AuthState"),
      resetPassword: jest.fn().mockResolvedValue(true),
    }));
    axios.get = jest.fn().mockResolvedValue(true);
  });

  it("Entering new password", async () => {
    window.setImmediate = window.setTimeout;
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });

    axios.get.mockResolvedValueOnce(true);

    //when
    render(
      <BrowserRouter>
        <PasswordInput handleSubmit={mockHandleSubmit} />
      </BrowserRouter>
    );
    const inputPassword = await screen.findByTestId("newPassword");
    await act(() => {
      fireEvent.change(inputPassword, { target: { value: "Sapient@123" } });
    });
  });
  it("Entering confirm password", async () => {
    
    window.setImmediate = window.setTimeout;
    let config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });

    axios.get.mockResolvedValueOnce(true);
    //when
    render(
      <BrowserRouter>
        <PasswordInput handleSubmit={mockHandleSubmit} />
      </BrowserRouter>
    );
    const inputPassword = await screen.findByTestId("newPassword");
    const confirmPassword = await screen.findByTestId("confirmPassword");
    const getSubmitButton = await screen.findByTestId("buttonTest");

    await act(() => {
      fireEvent.change(inputPassword, { target: { value: "Sapient@123" } });
      fireEvent.change(confirmPassword, { target: { value: "Sapient@123" } });
    });

    expect(axios.get).toBeCalledWith(`${resetPasswordURL}/1`, config);
  });
  window.setImmediate = window.setTimeout;
  beforeEach(() => {
    jest.mock("axios");
    jest.mock("../../../context/auth/AuthState", () => ({
      ...jest.requireActual("../../../context/auth/AuthState"),
      resetPassword: jest.fn().mockResolvedValue(true),
    }));
    axios.get = jest.fn().mockResolvedValue(true);
  });

  it("Entering new password", async () => {
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });

    axios.get.mockResolvedValueOnce(true);

    //when
    render(
      <BrowserRouter>
        <PasswordInput handleSubmit={mockHandleSubmit} />
      </BrowserRouter>
    );
    const inputPassword = await screen.findByTestId("newPassword");
    await act(() => {
      fireEvent.change(inputPassword, { target: { value: "Sapient@123" } });
    });
  });
  it("Entering confirm password ", async () => {
    let config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });

    axios.get.mockResolvedValueOnce(true);
    //when
    render(
      <BrowserRouter>
        <PasswordInput handleSubmit={mockHandleSubmit} />
      </BrowserRouter>
    );
    const inputPassword = await screen.findByTestId("newPassword");
    const confirmPassword = await screen.findByTestId("confirmPassword");
    const getSubmitButton = await screen.findByTestId("buttonTest");

    await act(() => {
      fireEvent.change(inputPassword, { target: { value: "Sapient@123" } });
      fireEvent.change(confirmPassword, { target: { value: "Sapient@123" } });
    });
    expect(axios.get).toBeCalledWith(`${resetPasswordURL}/1`, config);
    
  });
});
