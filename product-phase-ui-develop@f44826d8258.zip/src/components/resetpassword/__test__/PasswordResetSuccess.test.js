import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import PasswordResetSuccess from "../PasswordResetSuccess";
import { BrowserRouter } from "react-router-dom";
import { act } from "react-dom/test-utils";

describe("password reset success page", () => {
  window.setImmediate = window.setTimeout
  it("testing page", async () => {
    window.setImmediate = window.setTimeout
    render(
      <BrowserRouter>
      <PasswordResetSuccess />
      </BrowserRouter>);
    expect(screen.getByTestId("successImage")).toBeInTheDocument();
    expect(screen.getByTestId("logoImage")).toBeInTheDocument();
    expect(screen.getByTestId("logoImage")).toBeVisible();
    expect(screen.getByRole("button")).toHaveTextContent(/← Back to Sign In/);
    expect(screen.getByRole("button")).toBeEnabled();
    await act(()=>{fireEvent.click(screen.getByRole("button"))});
    
  });
});
