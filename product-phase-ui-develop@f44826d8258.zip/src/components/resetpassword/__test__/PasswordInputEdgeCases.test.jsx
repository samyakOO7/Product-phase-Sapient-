import PasswordInput from "../PasswordInput";
import { fireEvent, render, screen } from "@testing-library/react";
import user from "@testing-library/user-event";
import "@testing-library/jest-dom";
import Router, { BrowserRouter } from "react-router-dom";
import React from "react";
import axios from "axios";
import {
  CheckResetPasswordLink,
  resetPassword,
} from "../../../context/auth/AuthState";

jest.mock("axios");
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
}));
jest.mock("axios");
jest.mock("../../../context/auth/AuthState");
axios.get = jest.fn().mockResolvedValue(true);
const mockHandleSubmit = jest.fn();

describe("Reset Password Input Page", () => {
  it("render password input submit ", async () => {
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });
    CheckResetPasswordLink.mockResolvedValueOnce(true);
    resetPassword.mockResolvedValueOnce(true);
    render(
      <BrowserRouter>
        <PasswordInput />
      </BrowserRouter>
    );
    const nwPwd = await screen.findByTestId("newPassword");
    const conPwd = await screen.findByTestId("confirmPassword");
    const submit = await screen.findByTestId("buttonTest");
    user.type(nwPwd, "Muna@123");
    user.type(conPwd, "Muna@123");
    user.click(submit);
  });
  it("render password  ", async () => {
    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });
    CheckResetPasswordLink.mockResolvedValueOnce(true);
    resetPassword.mockResolvedValueOnce(true);
    render(
      <BrowserRouter>
        <PasswordInput />
      </BrowserRouter>
    );
    const nwPwd = await screen.findByTestId("newPassword");
    const conPwd = await screen.findByTestId("confirmPassword");
    const submit = await screen.findByTestId("buttonTest");
    const word = "MunaHaf@123";
    user.type(nwPwd, word);
    user.type(conPwd, word);
    user.type(nwPwd, word);
    user.click(submit);
  });
});
