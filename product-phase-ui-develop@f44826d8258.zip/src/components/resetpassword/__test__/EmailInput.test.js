import { fireEvent, render, screen,act } from "@testing-library/react";
import React from "react";
import "@testing-library/jest-dom";
import EmailInput from "../EmailInput";
import { SendingEmail } from "../../../context/auth/AuthState";
import { BrowserRouter } from "react-router-dom";


const handleSubmit = jest.fn();
jest.mock('../../../context/auth/AuthState.jsx')
describe("Reset Password Page", () => {
  window.setImmediate = window.setTimeout;
  it("Input email", async () => {
    SendingEmail.mockResolvedValueOnce(true);
    window.setImmediate = window.setTimeout;
    const { getByTestId } = render(

        <BrowserRouter>
          <EmailInput onSubmit={handleSubmit} />
        </BrowserRouter>

    );
    expect(screen.getByRole("button")).toBeEnabled();
    expect(screen.getByTestId("emailInput")).toHaveDisplayValue("");
    expect(screen.getByTestId("logoImage")).toBeInTheDocument();
    expect(screen.getByTestId("lockImage")).toBeInTheDocument();

    const inputEmail = screen.getByTestId("emailInput");
    fireEvent.change(inputEmail, { target: { value: "test@sapient.com" } });
    expect(inputEmail.value).toBe("test@sapient.com");
  });

  it("submit button test", async () => {
    SendingEmail.mockResolvedValueOnce(true);
    window.setImmediate = window.setTimeout;
    const { getByTestId } = render(

        <BrowserRouter>
          <EmailInput onSubmit={handleSubmit} />
        </BrowserRouter>

    );
    const inputEmail = screen.getByTestId("emailInput");
    await act(() => {
      fireEvent.change(inputEmail, { target: { value: "test@sapient.com" } });
    });

    const buttonHandler = screen.getByTestId("buttonTest");
    await act(() => {
      fireEvent.click(buttonHandler);
    });
  });
});
