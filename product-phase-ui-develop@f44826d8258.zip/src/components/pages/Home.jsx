import Dashboard from "../dashboard/Dashboard";

const Home = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default Home;
