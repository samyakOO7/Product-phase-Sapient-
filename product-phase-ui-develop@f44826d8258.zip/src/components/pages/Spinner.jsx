import React from 'react';
import { HashLoader } from "react-spinners";


const Spinner = () => (
  <div className='d-flex justify-content-center align-items-center'
       style={{minHeight:"90.5vh"}}
  >
  <HashLoader
  size={75}
  color="#FDA085"
  speedMultiplier={2.5}
/>

</div>
);

export default Spinner;