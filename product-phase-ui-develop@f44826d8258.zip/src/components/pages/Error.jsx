import React from "react";
import { useNavigate } from "react-router-dom";
import "../commonCss/successTemplate.css"

const Error = () => {
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/");
  };

  return (
    <div className="d-flex justify-content-center align-items-center success-div">
      <div className="d-flex success-box p-3">
        <form
          onSubmit={handleSubmit}
          className="d-flex justify-content-center align-items-center success-form"
        >
          <img
            className="logo-pass"
            src="https://cdn-icons-png.flaticon.com/512/2422/2422792.png"
            alt="stock.png"
            data-testid="logoImage"
          ></img>
          <img
            className="success"
            src={process.env.PUBLIC_URL + "/notFound.png"}
            alt="not found"
            data-testid="successImage"
          ></img>

          <h3>This page isn't available!</h3>

          <h5 className="headingText5-success-reset">
            The link you followed may be broken, or the page doesn't exist.{" "}
          </h5>

          <div className="form-btns-success-pass">
            <button type="submit" data-testid="home-page-btn">
              &#8592; Back to home page
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Error;
