import { render } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import AuthState from "../../../context/auth/AuthState";
import DashboardState from "../../../context/dashboard/DashboardState";
import TradeState from "../../../context/trade/TradeState";
import Home from "../Home";

describe("Home page testing", () => {
  it("Home Page should be rendered", () => {
    render(
      <AuthState>
        <DashboardState>
          <TradeState>
            <BrowserRouter>
              <Home />
            </BrowserRouter>
          </TradeState>
        </DashboardState>
      </AuthState>
    );
  });
});
