import  { render } from "@testing-library/react";
import Spinner from "../Spinner"


describe("Spinner page testing",()=>{
    it("Spinner Page should be rendered",()=>{
        render(<Spinner/>)
    })
})
