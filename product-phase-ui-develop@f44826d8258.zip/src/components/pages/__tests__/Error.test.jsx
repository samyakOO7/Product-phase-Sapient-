import Error from "../Error";

import { fireEvent, render, screen } from "@testing-library/react";

import "@testing-library/jest-dom";

import { BrowserRouter } from "react-router-dom";

import { act } from "react-dom/test-utils";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
}));

describe("Error", () => {
  test("Go to home page", async () => {
    //given

    const handleSubmit = jest.fn();

    //when

    render(
      <BrowserRouter>
        <Error onSubmit={handleSubmit} />
      </BrowserRouter>
    );

    await act(() => {
      fireEvent.click(screen.getByTestId("home-page-btn"));
    });

    //then

    expect(screen.getByTestId("logoImage")).toBeInTheDocument();

    expect(screen.getByTestId("successImage")).toBeInTheDocument();
  });
});
