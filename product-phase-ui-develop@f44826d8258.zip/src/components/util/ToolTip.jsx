import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';

function ToolTip({actualMessage, toolTipMessage, placement}) {

  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" data-testid ={"tool-tip-"}{...props}  >
       {toolTipMessage}
    </Tooltip>
  );
 
  return (
    <OverlayTrigger
      placement={placement}
      delay={{ show: 250, hide: 400 }}
      overlay={renderTooltip}
      data-testid = {"overlay-trigger" }
    >
          <div className='d-inline-flex text-center' >{actualMessage}</div>
    </OverlayTrigger>
  );
}
ToolTip.defaultProps = {
    placement: "bottom"
}
export default ToolTip;