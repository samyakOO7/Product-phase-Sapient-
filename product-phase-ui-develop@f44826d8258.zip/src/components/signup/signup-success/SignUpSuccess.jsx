import React, { useState, useEffect } from "react";
import "../../commonCss/successTemplate.css";
import { useNavigate, useParams } from "react-router-dom";
import { SignUpVerification } from "../../../context/auth/AuthState";

const SignUpSuccess = () => {
  const navigate = useNavigate();
  let params = useParams();
  const [renderPage, setRenderPage] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/login");
  };

  useEffect(() => {
    SignUpVerification(params.code, navigate).then((res) => {
      setRenderPage(res);
    });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.code]);

  if (renderPage) {
    return (
      <div className="d-flex justify-content-center align-items-center success-div">
        <div className="d-flex success-box">
          <form
            onSubmit={handleSubmit}
            className="d-flex justify-content-center align-items-center success-form"
          >
            <div>
              <img
                className="logo-pass"
                src="https://cdn-icons-png.flaticon.com/512/2422/2422792.png"
                alt="stock.png"
                data-testid="logoImage"
              ></img>
            </div>

            <div>
              <img
                className="success"
                src="https://s3-eu-west-1.amazonaws.com/tpd/logos/5ffc0568c37c02000100a48e/0x0.png"
                alt="success.png"
                data-testid="successImage"
              ></img>
            </div>

            <h3>Registration successful!</h3>

            <h5 className="headingText5-success-reset">
              Now you can login using your credentials!
            </h5>

            <div className="form-btns-success-pass">
              <button type="submit" data-testid="sign-in-btn">
                &#8592; Sign In
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  } else {
    return (
      <div className="d-flex justify-content-center align-items-center success-div">
        <div className="d-flex success-box p-3">
          <form
            onSubmit={handleSubmit}
            className="d-flex justify-content-center align-items-center success-form"
          >
            <div>
              <img
                className="logo-pass"
                src="https://cdn-icons-png.flaticon.com/512/2422/2422792.png"
                alt="stock.png"
                data-testid="logoImage"
              ></img>
            </div>

            <div>
              <img
                className="success"
                src={process.env.PUBLIC_URL + "/sorry.png"}
                alt="sorry"
                data-testid="successImage"
              ></img>
            </div>

            <h3>Something went wrong!</h3>

            <h5 className="headingText5-success-reset">
              Invalid verification code or email has already been verified.
            </h5>

            <div className="form-btns-success-pass">
              <button type="submit" data-testid="sign-in-btn">
                &#8592; Sign In
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
};

export default SignUpSuccess;
