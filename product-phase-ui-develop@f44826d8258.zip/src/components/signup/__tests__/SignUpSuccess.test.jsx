import SignUpSuccess from "../signup-success/SignUpSuccess";

import { fireEvent, render, screen } from "@testing-library/react";

import "@testing-library/jest-dom";

import Router, { BrowserRouter } from "react-router-dom";

import { act } from "react-dom/test-utils";

import axios from "axios";

import { signupVerificationURL } from "../../../config/urlConstants";

const mockedUserPrams = jest.fn();

jest.mock("axios");

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),

  useParams: jest.fn(),
}));

describe("SignUpSuccess", () => {
  window.setImmediate = window.setTimeout
  test("Email sent success", async () => {
    //given
    window.setImmediate = window.setTimeout
    let config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    jest.spyOn(Router, "useParams").mockReturnValue({ code: 1 });

    const handleSubmit = jest.fn();

    axios.get.mockResolvedValueOnce(true);

    //when

    render(
      <BrowserRouter>
        <SignUpSuccess onSubmit={handleSubmit} />
      </BrowserRouter>
    );

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(() => {
      fireEvent.click(screen.getByTestId("sign-in-btn"));
    });

    //then

    expect(screen.getByTestId("logoImage")).toBeInTheDocument();

    expect(screen.getByTestId("successImage")).toBeInTheDocument();

    expect(axios.get).toBeCalledTimes(1);

    expect(axios.get).toBeCalledWith(`${signupVerificationURL}?code=1`, config);
  });
});
