import { render, screen, fireEvent, getByRole } from "@testing-library/react";
import SignUp from "../SignUp";
import "@testing-library/jest-dom";
import { act } from "react-dom/test-utils";
import React from "react";
import { BrowserRouter } from "react-router-dom";
import AuthState, { RegisterUser } from "../../../context/auth/AuthState";
import authContext from "../../../context/auth/authContext";
import {errorCheck} from "../SignUp"
import { wait } from "@testing-library/user-event/dist/utils";
const navigate = jest.fn();
const handleSubmit = jest.fn();
describe("Signup Component", () => {
   window.setImmediate = window.setTimeout
  it("Initial Conditions", () => {
    render(
      <AuthState>
        <BrowserRouter>
          <SignUp />
        </BrowserRouter>
      </AuthState>
    );
    const firstnameInput = screen.getByTestId("firstName");
    expect(firstnameInput).toBeInTheDocument();
    const lastnameInput = screen.getByTestId("lastName");
    expect(lastnameInput).toBeInTheDocument();
    const emailInput = screen.getByTestId("email");
    expect(emailInput).toBeInTheDocument();
    const passwordInput = screen.getByTestId("signup-password");
    expect(passwordInput).toBeInTheDocument();
    const confirmpasswordInput = screen.getByTestId("confirmPassword");
    expect(confirmpasswordInput).toBeInTheDocument();
    const submitButton = screen.getByRole("button", {
      name: "SignUp",
      exact: false,
    });
    expect(submitButton).toBeDisabled();
  });
  it("call the OnSubmit function", async () => {
    render(
      <AuthState>
        <BrowserRouter>
          <SignUp />
        </BrowserRouter>
      </AuthState>
    );
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      fireEvent.change(screen.getByTestId("userName"), {
        target: { value: "Ankita" },
      });
      fireEvent.change(screen.getByTestId("firstName"), {
        target: { value: "Ankita" },
      });
      fireEvent.change(screen.getByTestId("lastName"), {
        target: { value: "Ray" },
      });
      fireEvent.change(screen.getByTestId("email"), {
        target: { value: "test@gmail.com" },
      });
      fireEvent.change(screen.getByTestId("signup-password"), {
        target: { value: "Anki@2222" },
      });
      fireEvent.change(screen.getByTestId("confirmPassword"), {
        target: { value: "Anki@2222" },
      });
    });
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      fireEvent.click(screen.getByTestId("signup-button"));
    });
    expect(screen.getByTestId("userName").value).toBe("Ankita");
    expect(screen.getByTestId("firstName").value).toBe("Ankita");
    expect(screen.getByTestId("lastName").value).toBe("Ray");
    expect(screen.getByTestId("email").value).toBe("test@gmail.com");
    expect(screen.getByTestId("signup-password").value).toBe("Anki@2222");
    expect(screen.getByTestId("confirmPassword").value).toBe("Anki@2222");
  });
  it("call the OnSubmit function2", async () => {
    render(
      <AuthState>
        <BrowserRouter>
          <SignUp />
        </BrowserRouter>
      </AuthState>
    );
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      fireEvent.change(screen.getByTestId("userName"), {
        target: { value: 123 },
      });
      fireEvent.change(screen.getByTestId("firstName"), {
        target: { value: 123 },
      });
      fireEvent.change(screen.getByTestId("lastName"), {
        target: { value: 123 },
      });
      fireEvent.change(screen.getByTestId("email"), {
        target: { value: "test" },
      });
      fireEvent.change(screen.getByTestId("signup-password"), {
        target: { value: "nki@222" },
      });
      fireEvent.change(screen.getByTestId("confirmPassword"), {
        target: { value: "nki@2222" },
      });
    });
  });
  
  it("Testing navigation", async () => {
    render(
      <authContext.Provider
        value={{
          authState: {
            accessToken: "sfjklsdajlk32k3jl2l3",
            refreshToken: "dkfjlk3kl3kl2l4klj42nkl",
            isAuthenticated: true,
            loading: true,
            user: { userId: 1, userName: "sanjay" },
          },
          authDispatch: jest.fn(),
        }}
      >
        <BrowserRouter>
          <SignUp useNavigate={navigate} />
        </BrowserRouter>
      </authContext.Provider>
    );
  });

  it("should blur fields by wrong input", async () => {
    render(
      <AuthState>
        <BrowserRouter>
          <SignUp onSubmit={handleSubmit} />
        </BrowserRouter>
      </AuthState>
    );
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      const userNameInput = screen.getByTestId("userName");
      const firstNameInput = screen.getByTestId("firstName");
      const lastNameInput = screen.getByTestId("lastName");
      const emailInput = screen.getByTestId("email");
      const signupPasswordInput = screen.getByTestId("signup-password");
      const confirmPasswordInput = screen.getByTestId("confirmPassword");


      
      fireEvent.change(userNameInput, {
        target: { value: 123 },
      });
      fireEvent.change(firstNameInput, {
        target: { value: 123 },
      });
      fireEvent.change(lastNameInput, {
        target: { value: 123 },
      });
      fireEvent.change(emailInput, {
        target: { value: "test" },
      });
      fireEvent.blur(emailInput);
      expect(emailInput).toBeInTheDocument();
      fireEvent.change(signupPasswordInput, {
        target: { value: "nki" },
      });
      fireEvent.blur(signupPasswordInput);
      expect(signupPasswordInput).toBeInTheDocument();
      fireEvent.change(confirmPasswordInput, {
        target: { value: "nki@2222" },
      });
      fireEvent.click(screen.getByTestId("signup-button"))

    });
  });

  
  it("testing checkError function", () => {
   render( <authContext.Provider
        value={{
          authState: {
            accessToken: "sfjklsdajlk32k3jl2l3",
            refreshToken: "dkfjlk3kl3kl2l4klj42nkl",
            isAuthenticated: true,
            loading: true,
            user: { userId: 1, userName: "sanjay" },
          },
          authDispatch: jest.fn(),
        }}
      >
        <BrowserRouter>
          <SignUp useNavigate={navigate} />
        </BrowserRouter>
      </authContext.Provider>
    );
    expect(errorCheck("Password@12","Password@123")).toBe(true);
    expect(errorCheck("Password@123","Password@123")).toBe(false);
  });


  it("Checking for the case when user enters wrong password", async () => {
    render(
      <AuthState>
        <BrowserRouter>
          <SignUp onSubmit={handleSubmit} />
        </BrowserRouter>
      </AuthState>
    );
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      const userNameInput = screen.getByTestId("userName");
      const firstNameInput = screen.getByTestId("firstName");
      const lastNameInput = screen.getByTestId("lastName");
      const phoneNumberInput=screen.getByTestId("phoneNumber");
      const emailInput = screen.getByTestId("email");
      const signupPasswordInput = screen.getByTestId("signup-password");
      const confirmPasswordInput = screen.getByTestId("confirmPassword");
      const handleSubmit=jest.fn();

      
      fireEvent.change(userNameInput, {
        target: { value: "sk" },
      });
      fireEvent.change(firstNameInput, {
        target: { value: "Sanjay" },
      });
      fireEvent.change(lastNameInput, {
        target: { value: "Dutt" },
      });
      fireEvent.change(phoneNumberInput, {
        target: { value: 1234567899 },
      });
      fireEvent.change(emailInput, {
        target: { value: "sanjay@gmail.com" },
      });
      fireEvent.blur(emailInput);
      expect(emailInput).toBeInTheDocument();
      fireEvent.change(signupPasswordInput, {
        target: { value: "Password@123" },
      });
      fireEvent.blur(signupPasswordInput);
      expect(signupPasswordInput).toBeInTheDocument();
      fireEvent.change(confirmPasswordInput, {
        target: { value: "Password@123" },
      });
      fireEvent.click(screen.getByTestId("signup-button"))
      
    
    
    await wait(()=>{  expect(RegisterUser).toHaveBeenCalled() } );


    });
  });


  });

